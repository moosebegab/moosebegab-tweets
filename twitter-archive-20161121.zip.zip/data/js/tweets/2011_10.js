Grailbird.data.tweets_2011_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131169680449740800",
  "geo" : { },
  "id_str" : "131170575078006788",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts Cute! : )",
  "id" : 131170575078006788,
  "in_reply_to_status_id" : 131169680449740800,
  "created_at" : "2011-11-01 00:47:56 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131130451241873409",
  "text" : "@SamsaricWarrior sorry to hear that. our area should be all back online by wed. got ours back this afternoon.",
  "id" : 131130451241873409,
  "created_at" : "2011-10-31 22:08:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "itsbaxter",
      "screen_name" : "itsbaxter",
      "indices" : [ 3, 13 ],
      "id_str" : "16233069",
      "id" : 16233069
    }, {
      "name" : "Eyes Ears Open",
      "screen_name" : "eyesearsopen",
      "indices" : [ 15, 28 ],
      "id_str" : "292151421",
      "id" : 292151421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131110623718277120",
  "text" : "RT @itsbaxter: @eyesearsopen Yes, people live under a delusion that they are free in US and Canada. Gov controls everything, and is mani ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Eyes Ears Open",
        "screen_name" : "eyesearsopen",
        "indices" : [ 0, 13 ],
        "id_str" : "292151421",
        "id" : 292151421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "130884857730576384",
    "geo" : { },
    "id_str" : "131089964380332032",
    "in_reply_to_user_id" : 292151421,
    "text" : "@eyesearsopen Yes, people live under a delusion that they are free in US and Canada. Gov controls everything, and is manipulated.",
    "id" : 131089964380332032,
    "in_reply_to_status_id" : 130884857730576384,
    "created_at" : "2011-10-31 19:27:37 +0000",
    "in_reply_to_screen_name" : "eyesearsopen",
    "in_reply_to_user_id_str" : "292151421",
    "user" : {
      "name" : "itsbaxter",
      "screen_name" : "itsbaxter",
      "protected" : false,
      "id_str" : "16233069",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/885291714\/100_2892_normal.jpg",
      "id" : 16233069,
      "verified" : false
    }
  },
  "id" : 131110623718277120,
  "created_at" : "2011-10-31 20:49:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 26, 36 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/2FaLdj8k",
      "expanded_url" : "http:\/\/lockerz.com\/s\/152110233",
      "display_url" : "lockerz.com\/s\/152110233"
    } ]
  },
  "geo" : { },
  "id_str" : "131104960292196353",
  "text" : "My favorite inspector! RT @ShhDragon: Saki inspecting roof work http:\/\/t.co\/2FaLdj8k",
  "id" : 131104960292196353,
  "created_at" : "2011-10-31 20:27:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rick Chesler",
      "screen_name" : "RickChesler",
      "indices" : [ 3, 15 ],
      "id_str" : "17554456",
      "id" : 17554456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eco",
      "indices" : [ 130, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131089860726489089",
  "text" : "RT @RickChesler: Texas shooting burros, stirring backlash Unofficially, the state of Texas celebrates donkeys and their historica #eco   ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "eco",
        "indices" : [ 113, 117 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/OTFlcUU0",
        "expanded_url" : "http:\/\/goo.gl\/k4OJl",
        "display_url" : "goo.gl\/k4OJl"
      } ]
    },
    "geo" : { },
    "id_str" : "131089424145592320",
    "text" : "Texas shooting burros, stirring backlash Unofficially, the state of Texas celebrates donkeys and their historica #eco  http:\/\/t.co\/OTFlcUU0",
    "id" : 131089424145592320,
    "created_at" : "2011-10-31 19:25:28 +0000",
    "user" : {
      "name" : "Rick Chesler",
      "screen_name" : "RickChesler",
      "protected" : false,
      "id_str" : "17554456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/772163787654737920\/_e3IDVfp_normal.jpg",
      "id" : 17554456,
      "verified" : false
    }
  },
  "id" : 131089860726489089,
  "created_at" : "2011-10-31 19:27:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    }, {
      "name" : "The Hudson Valley",
      "screen_name" : "TheHudsonValley",
      "indices" : [ 104, 120 ],
      "id_str" : "102313523",
      "id" : 102313523
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/faBUCsyR",
      "expanded_url" : "http:\/\/bit.ly\/vhauFO",
      "display_url" : "bit.ly\/vhauFO"
    } ]
  },
  "geo" : { },
  "id_str" : "131088851849592832",
  "text" : "RT @petsalive: Dutchess County hosting FREE rabies clinic for dogs, cats, ferrets: http:\/\/t.co\/faBUCsyR @TheHudsonValley",
  "id" : 131088851849592832,
  "created_at" : "2011-10-31 19:23:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "131073189408276480",
  "geo" : { },
  "id_str" : "131073849923080192",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth : ) hurray for nice things!",
  "id" : 131073849923080192,
  "in_reply_to_status_id" : 131073189408276480,
  "created_at" : "2011-10-31 18:23:35 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131071230559256576",
  "text" : "thought a tree was gonna land on me when I was outside helping hubby w generator.. LOL",
  "id" : 131071230559256576,
  "created_at" : "2011-10-31 18:13:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131070844460994561",
  "text" : "RT @fearfuldogs: got questions abt the most humane & effective ways 2 deal w fearful, shy or anxious dogs? fearfuldogs.com built just 4 u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "131070271393243136",
    "text" : "got questions abt the most humane & effective ways 2 deal w fearful, shy or anxious dogs? fearfuldogs.com built just 4 u",
    "id" : 131070271393243136,
    "created_at" : "2011-10-31 18:09:22 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 131070844460994561,
  "created_at" : "2011-10-31 18:11:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131070720649338880",
  "text" : "also had crow right outside window on broken tree limb! : )",
  "id" : 131070720649338880,
  "created_at" : "2011-10-31 18:11:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131070607688347649",
  "text" : "lots of tree damage in yard but fun to watch squirrels run on broken branches on ground collecting nuts. good close ups.",
  "id" : 131070607688347649,
  "created_at" : "2011-10-31 18:10:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131067515920064512",
  "text" : "Hey Tennessee.. thx 4 letting us borrow your electric workers! : ) Love, New York",
  "id" : 131067515920064512,
  "created_at" : "2011-10-31 17:58:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131066914737897474",
  "text" : "not sure how halloween is gonna play out w all this snow. no school today so DD didnt get to wear costume to school : (",
  "id" : 131066914737897474,
  "created_at" : "2011-10-31 17:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 21, 28 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birdtog",
      "indices" : [ 85, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/lMl67NKS",
      "expanded_url" : "http:\/\/bit.ly\/u8dp7h",
      "display_url" : "bit.ly\/u8dp7h"
    } ]
  },
  "geo" : { },
  "id_str" : "131062988751908864",
  "text" : "RT @DwayneReaves: RT @screek: An American White Pelican Landing http:\/\/t.co\/lMl67NKS #birdtog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Creek",
        "screen_name" : "screek",
        "indices" : [ 3, 10 ],
        "id_str" : "12023102",
        "id" : 12023102
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birdtog",
        "indices" : [ 67, 75 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/lMl67NKS",
        "expanded_url" : "http:\/\/bit.ly\/u8dp7h",
        "display_url" : "bit.ly\/u8dp7h"
      } ]
    },
    "geo" : { },
    "id_str" : "131062151363309568",
    "text" : "RT @screek: An American White Pelican Landing http:\/\/t.co\/lMl67NKS #birdtog",
    "id" : 131062151363309568,
    "created_at" : "2011-10-31 17:37:06 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 131062988751908864,
  "created_at" : "2011-10-31 17:40:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "131060460031184896",
  "text" : "We are back in business! So grateful for all the electric workers.. thank you!",
  "id" : 131060460031184896,
  "created_at" : "2011-10-31 17:30:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amore Pizzeria",
      "screen_name" : "amorepizza12569",
      "indices" : [ 3, 19 ],
      "id_str" : "109286456",
      "id" : 109286456
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noreaster",
      "indices" : [ 39, 49 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/KBsrJOpW",
      "expanded_url" : "http:\/\/fb.me\/1o3JsrbWQ",
      "display_url" : "fb.me\/1o3JsrbWQ"
    } ]
  },
  "geo" : { },
  "id_str" : "130399631485059074",
  "text" : "RT @amorepizza12569: Happy Halloween?  #noreaster http:\/\/t.co\/KBsrJOpW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "noreaster",
        "indices" : [ 18, 28 ]
      } ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/KBsrJOpW",
        "expanded_url" : "http:\/\/fb.me\/1o3JsrbWQ",
        "display_url" : "fb.me\/1o3JsrbWQ"
      } ]
    },
    "geo" : { },
    "id_str" : "130399239456038912",
    "text" : "Happy Halloween?  #noreaster http:\/\/t.co\/KBsrJOpW",
    "id" : 130399239456038912,
    "created_at" : "2011-10-29 21:42:56 +0000",
    "user" : {
      "name" : "Amore Pizzeria",
      "screen_name" : "amorepizza12569",
      "protected" : false,
      "id_str" : "109286456",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1492261269\/Amore_Pizzeria_Logo_jpg_normal.jpg",
      "id" : 109286456,
      "verified" : false
    }
  },
  "id" : 130399631485059074,
  "created_at" : "2011-10-29 21:44:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130398132029755392",
  "geo" : { },
  "id_str" : "130399294061690880",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 omg.. LOL",
  "id" : 130399294061690880,
  "in_reply_to_status_id" : 130398132029755392,
  "created_at" : "2011-10-29 21:43:09 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130397646455177217",
  "text" : "\"I don't know how to log out. I've never logged out.\" - hubby - LOL",
  "id" : 130397646455177217,
  "created_at" : "2011-10-29 21:36:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130394780919279616",
  "geo" : { },
  "id_str" : "130397133844119552",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope thx! : )  we should be ok.",
  "id" : 130397133844119552,
  "in_reply_to_status_id" : 130394780919279616,
  "created_at" : "2011-10-29 21:34:34 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130395422391934976",
  "geo" : { },
  "id_str" : "130396820215050240",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 one I haven't seen or read..",
  "id" : 130396820215050240,
  "in_reply_to_status_id" : 130395422391934976,
  "created_at" : "2011-10-29 21:33:19 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130393374585913344",
  "geo" : { },
  "id_str" : "130394579194232833",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 clowns & balloons.. 2 of my NOT fave things! lol",
  "id" : 130394579194232833,
  "in_reply_to_status_id" : 130393374585913344,
  "created_at" : "2011-10-29 21:24:24 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130393800496525312",
  "text" : "tree branches falling down all around the house...",
  "id" : 130393800496525312,
  "created_at" : "2011-10-29 21:21:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130391420350627841",
  "geo" : { },
  "id_str" : "130393006862909440",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 omg.. your avatar!! ((runsaway))",
  "id" : 130393006862909440,
  "in_reply_to_status_id" : 130391420350627841,
  "created_at" : "2011-10-29 21:18:10 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130386367925592064",
  "text" : "finished Catcher, Caught last night on my Kindle. Loved it.",
  "id" : 130386367925592064,
  "created_at" : "2011-10-29 20:51:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 3, 15 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/2onGI1LM",
      "expanded_url" : "http:\/\/www.flickr.com\/photos\/tamanduagirl\/6292087181\/in\/photostream",
      "display_url" : "flickr.com\/photos\/tamandu\u2026"
    }, {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/Ks2jClcy",
      "expanded_url" : "http:\/\/fb.me\/SKaUaa9a",
      "display_url" : "fb.me\/SKaUaa9a"
    } ]
  },
  "geo" : { },
  "id_str" : "130385237510332416",
  "text" : "RT @PuaTamandua: Pua in her \"tutu\" http:\/\/t.co\/2onGI1LM http:\/\/t.co\/Ks2jClcy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/2onGI1LM",
        "expanded_url" : "http:\/\/www.flickr.com\/photos\/tamanduagirl\/6292087181\/in\/photostream",
        "display_url" : "flickr.com\/photos\/tamandu\u2026"
      }, {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/Ks2jClcy",
        "expanded_url" : "http:\/\/fb.me\/SKaUaa9a",
        "display_url" : "fb.me\/SKaUaa9a"
      } ]
    },
    "geo" : { },
    "id_str" : "130382103245373440",
    "text" : "Pua in her \"tutu\" http:\/\/t.co\/2onGI1LM http:\/\/t.co\/Ks2jClcy",
    "id" : 130382103245373440,
    "created_at" : "2011-10-29 20:34:50 +0000",
    "user" : {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "protected" : false,
      "id_str" : "17218256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63782435\/shirt_normal.jpg",
      "id" : 17218256,
      "verified" : false
    }
  },
  "id" : 130385237510332416,
  "created_at" : "2011-10-29 20:47:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "indices" : [ 3, 11 ],
      "id_str" : "61363491",
      "id" : 61363491
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/Kxq4lVww",
      "expanded_url" : "http:\/\/www.worldhost.co.za",
      "display_url" : "worldhost.co.za"
    } ]
  },
  "geo" : { },
  "id_str" : "130380236138360832",
  "text" : "RT @mbekezm: Free web hosting by Worldhost, Visit http:\/\/t.co\/Kxq4lVww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/Kxq4lVww",
        "expanded_url" : "http:\/\/www.worldhost.co.za",
        "display_url" : "worldhost.co.za"
      } ]
    },
    "geo" : { },
    "id_str" : "130376952308707328",
    "text" : "Free web hosting by Worldhost, Visit http:\/\/t.co\/Kxq4lVww",
    "id" : 130376952308707328,
    "created_at" : "2011-10-29 20:14:22 +0000",
    "user" : {
      "name" : "Ngoka Mhlanga lo",
      "screen_name" : "mbekezm",
      "protected" : false,
      "id_str" : "61363491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3337131859\/41d874380de15e72dd638ac8d9c8dd1a_normal.jpeg",
      "id" : 61363491,
      "verified" : false
    }
  },
  "id" : 130380236138360832,
  "created_at" : "2011-10-29 20:27:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 29, 42 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130362539992285185",
  "text" : "Did you take your blog down? @DwayneReaves I'm reading your book from that last post. It's very good!",
  "id" : 130362539992285185,
  "created_at" : "2011-10-29 19:17:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130359369673089025",
  "text" : "listening to my DD & BFF chat... oh, the sweet wisdom!",
  "id" : 130359369673089025,
  "created_at" : "2011-10-29 19:04:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130358953526820864",
  "text" : "RT @mssuzcatsilver: What u resist persists.... accept any negative emotion, give yrself permission to feel it, bless it & let it go with ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freedom",
        "indices" : [ 122, 130 ]
      }, {
        "text" : "suzcat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130358759699656704",
    "text" : "What u resist persists.... accept any negative emotion, give yrself permission to feel it, bless it & let it go with love #freedom #suzcat",
    "id" : 130358759699656704,
    "created_at" : "2011-10-29 19:02:04 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 130358953526820864,
  "created_at" : "2011-10-29 19:02:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130358351690342403",
  "text" : "RT @mssuzcatsilver: We are all different souls on different paths, some good, some bad, some indifferent (souls\/paths) & some are a pain ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "life",
        "indices" : [ 128, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130358023586717696",
    "text" : "We are all different souls on different paths, some good, some bad, some indifferent (souls\/paths) & some are a pain in the ass #life",
    "id" : 130358023586717696,
    "created_at" : "2011-10-29 18:59:09 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 130358351690342403,
  "created_at" : "2011-10-29 19:00:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130331395896786945",
  "text" : "@SamsaricWarrior bleh..bleh.. basically what I see out my window. trying to ignore it..lol",
  "id" : 130331395896786945,
  "created_at" : "2011-10-29 17:13:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130330946300944385",
  "text" : "RT @abe_quotes: ...you've taken the first step away from your awareness of your true Guidance.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130330510269485057",
    "text" : "...you've taken the first step away from your awareness of your true Guidance.",
    "id" : 130330510269485057,
    "created_at" : "2011-10-29 17:09:49 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 130330946300944385,
  "created_at" : "2011-10-29 17:11:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130330930480037889",
  "text" : "RT @abe_quotes: In the first moment that someone convinces you that your behavior must be controlled in order to effect their response t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130330506440097792",
    "text" : "In the first moment that someone convinces you that your behavior must be controlled in order to effect their response to you...",
    "id" : 130330506440097792,
    "created_at" : "2011-10-29 17:09:48 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 130330930480037889,
  "created_at" : "2011-10-29 17:11:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 72 ],
      "url" : "http:\/\/t.co\/68k2SLxu",
      "expanded_url" : "http:\/\/goo.gl\/fb\/mcWwJ",
      "display_url" : "goo.gl\/fb\/mcWwJ"
    } ]
  },
  "geo" : { },
  "id_str" : "130320008734703616",
  "text" : "RT @DwayneReaves: Do it really have to be this way? http:\/\/t.co\/68k2SLxu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/68k2SLxu",
        "expanded_url" : "http:\/\/goo.gl\/fb\/mcWwJ",
        "display_url" : "goo.gl\/fb\/mcWwJ"
      } ]
    },
    "geo" : { },
    "id_str" : "130317355942289408",
    "text" : "Do it really have to be this way? http:\/\/t.co\/68k2SLxu",
    "id" : 130317355942289408,
    "created_at" : "2011-10-29 16:17:33 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 130320008734703616,
  "created_at" : "2011-10-29 16:28:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Williams",
      "screen_name" : "KWilliams1984",
      "indices" : [ 0, 14 ],
      "id_str" : "22653799",
      "id" : 22653799
    }, {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 15, 27 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "130315848534589440",
  "geo" : { },
  "id_str" : "130318671485734912",
  "in_reply_to_user_id" : 22653799,
  "text" : "@KWilliams1984 @VirgoJohnny \"you know who\" .. lol",
  "id" : 130318671485734912,
  "in_reply_to_status_id" : 130315848534589440,
  "created_at" : "2011-10-29 16:22:47 +0000",
  "in_reply_to_screen_name" : "KWilliams1984",
  "in_reply_to_user_id_str" : "22653799",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Seasonal Pun",
      "screen_name" : "ChrisDStedman",
      "indices" : [ 3, 17 ],
      "id_str" : "76744905",
      "id" : 76744905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/mr33eaHk",
      "expanded_url" : "http:\/\/on.fb.me\/rHazKC",
      "display_url" : "on.fb.me\/rHazKC"
    } ]
  },
  "geo" : { },
  "id_str" : "130317918645923840",
  "text" : "RT @ChrisDStedman: Christian proselytizers came to my door this morning. Here's what happened: http:\/\/t.co\/mr33eaHk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/mr33eaHk",
        "expanded_url" : "http:\/\/on.fb.me\/rHazKC",
        "display_url" : "on.fb.me\/rHazKC"
      } ]
    },
    "geo" : { },
    "id_str" : "130303887520440320",
    "text" : "Christian proselytizers came to my door this morning. Here's what happened: http:\/\/t.co\/mr33eaHk",
    "id" : 130303887520440320,
    "created_at" : "2011-10-29 15:24:02 +0000",
    "user" : {
      "name" : "Seasonal Pun",
      "screen_name" : "ChrisDStedman",
      "protected" : false,
      "id_str" : "76744905",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800731505093971968\/HiPd-1mz_normal.jpg",
      "id" : 76744905,
      "verified" : true
    }
  },
  "id" : 130317918645923840,
  "created_at" : "2011-10-29 16:19:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danielle La Paglia",
      "screen_name" : "Dannigrrl5",
      "indices" : [ 3, 14 ],
      "id_str" : "51621763",
      "id" : 51621763
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fridayflash",
      "indices" : [ 114, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/gghP0Wq4",
      "expanded_url" : "http:\/\/wp.me\/pQ90n-iB",
      "display_url" : "wp.me\/pQ90n-iB"
    } ]
  },
  "geo" : { },
  "id_str" : "130313890423771136",
  "text" : "RT @Dannigrrl5: Can you find the hidden horror movie titles in this story? Once Upon a Grave http:\/\/t.co\/gghP0Wq4 #fridayflash",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fridayflash",
        "indices" : [ 98, 110 ]
      } ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/gghP0Wq4",
        "expanded_url" : "http:\/\/wp.me\/pQ90n-iB",
        "display_url" : "wp.me\/pQ90n-iB"
      } ]
    },
    "geo" : { },
    "id_str" : "130311217108631552",
    "text" : "Can you find the hidden horror movie titles in this story? Once Upon a Grave http:\/\/t.co\/gghP0Wq4 #fridayflash",
    "id" : 130311217108631552,
    "created_at" : "2011-10-29 15:53:09 +0000",
    "user" : {
      "name" : "Danielle La Paglia",
      "screen_name" : "Dannigrrl5",
      "protected" : false,
      "id_str" : "51621763",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3784360297\/397b4c6b9e8bbb136cf765f0452245cc_normal.jpeg",
      "id" : 51621763,
      "verified" : false
    }
  },
  "id" : 130313890423771136,
  "created_at" : "2011-10-29 16:03:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 9, 19 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/txIQWcEH",
      "expanded_url" : "http:\/\/yfrog.com\/obc9hqj",
      "display_url" : "yfrog.com\/obc9hqj"
    } ]
  },
  "geo" : { },
  "id_str" : "130309594525351937",
  "text" : "cute! RT @ScottBaio: http:\/\/t.co\/txIQWcEH",
  "id" : 130309594525351937,
  "created_at" : "2011-10-29 15:46:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Earthfire Institute",
      "screen_name" : "earthfireinst",
      "indices" : [ 3, 17 ],
      "id_str" : "92345960",
      "id" : 92345960
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130304798263222274",
  "text" : "RT @earthfireinst: All animals except man know that the ultimate point of life is the enjoy it- S.Butler",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "130300468214771713",
    "text" : "All animals except man know that the ultimate point of life is the enjoy it- S.Butler",
    "id" : 130300468214771713,
    "created_at" : "2011-10-29 15:10:27 +0000",
    "user" : {
      "name" : "Earthfire Institute",
      "screen_name" : "earthfireinst",
      "protected" : false,
      "id_str" : "92345960",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555852354\/E-mail_wolf_eye_normal.jpg",
      "id" : 92345960,
      "verified" : false
    }
  },
  "id" : 130304798263222274,
  "created_at" : "2011-10-29 15:27:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130291739578728448",
  "text" : "I should be called Half-n-Half...",
  "id" : 130291739578728448,
  "created_at" : "2011-10-29 14:35:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130289482267230208",
  "text" : "@SamsaricWarrior sorry for snarky reply, wasnt thinking.",
  "id" : 130289482267230208,
  "created_at" : "2011-10-29 14:26:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 31, 44 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/R5rwim4g",
      "expanded_url" : "http:\/\/twitpic.com\/779i70",
      "display_url" : "twitpic.com\/779i70"
    } ]
  },
  "geo" : { },
  "id_str" : "130083369932427265",
  "text" : "The cookies are divine, TY! RT @JoanneMFirth: Spooky treats for everyone. HAPPY HALLOWEEN WEEKEND! Love Me http:\/\/t.co\/R5rwim4g",
  "id" : 130083369932427265,
  "created_at" : "2011-10-29 00:47:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130049062530580481",
  "text" : "trying to remember thats not where I should be...",
  "id" : 130049062530580481,
  "created_at" : "2011-10-28 22:31:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130048912315789313",
  "text" : "so now there is the 53 percent? and they don't like the 99 percent?",
  "id" : 130048912315789313,
  "created_at" : "2011-10-28 22:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 17, 30 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "130004599573725184",
  "text" : "I will be sad if @DwayneReaves leaves Twitter : (",
  "id" : 130004599573725184,
  "created_at" : "2011-10-28 19:34:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129996186814914560",
  "text" : "@SamsaricWarrior Because...",
  "id" : 129996186814914560,
  "created_at" : "2011-10-28 19:01:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoOne Important.",
      "screen_name" : "LoveReadingx",
      "indices" : [ 3, 16 ],
      "id_str" : "4855983940",
      "id" : 4855983940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129968606049079298",
  "text" : "RT @lovereadingx: I want to change my twitter name to 'a creepy stalker' so when I follow someone they get an email saying \"A Creepy Sta ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129967912491552770",
    "text" : "I want to change my twitter name to 'a creepy stalker' so when I follow someone they get an email saying \"A Creepy Stalker is following you\"",
    "id" : 129967912491552770,
    "created_at" : "2011-10-28 17:08:59 +0000",
    "user" : {
      "name" : "Iffath",
      "screen_name" : "deariffath",
      "protected" : false,
      "id_str" : "79723007",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800524852411138048\/0siGa7ka_normal.jpg",
      "id" : 79723007,
      "verified" : false
    }
  },
  "id" : 129968606049079298,
  "created_at" : "2011-10-28 17:11:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "indices" : [ 3, 14 ],
      "id_str" : "385240011",
      "id" : 385240011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/d6K79WYa",
      "expanded_url" : "http:\/\/www.threadless.com\/slogans\/2407118\/Puppies_Heal_Souls\/from,tt+twitter",
      "display_url" : "threadless.com\/slogans\/240711\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129958978280095744",
  "text" : "RT @newordsnow: \"Puppies Heal Souls.\" Help put my slogan on a T-shirt. Vote here.Score my Threadless slogan: http:\/\/t.co\/d6K79WYa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/d6K79WYa",
        "expanded_url" : "http:\/\/www.threadless.com\/slogans\/2407118\/Puppies_Heal_Souls\/from,tt+twitter",
        "display_url" : "threadless.com\/slogans\/240711\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "129958327085051904",
    "text" : "\"Puppies Heal Souls.\" Help put my slogan on a T-shirt. Vote here.Score my Threadless slogan: http:\/\/t.co\/d6K79WYa",
    "id" : 129958327085051904,
    "created_at" : "2011-10-28 16:30:54 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "protected" : false,
      "id_str" : "385240011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1579459848\/images_normal.jpg",
      "id" : 385240011,
      "verified" : false
    }
  },
  "id" : 129958978280095744,
  "created_at" : "2011-10-28 16:33:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129952851442143233",
  "text" : "@SamsaricWarrior ((waves)) did you get some white stuff your way? I'm ignoring it..lol",
  "id" : 129952851442143233,
  "created_at" : "2011-10-28 16:09:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/hhgAL4ZC",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2011\/10\/dog-riding-a-donkey\/",
      "display_url" : "lifewithdogs.tv\/2011\/10\/dog-ri\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129939093063864320",
  "text" : "Dog Riding A Donkey http:\/\/t.co\/hhgAL4ZC via @nigelbugger",
  "id" : 129939093063864320,
  "created_at" : "2011-10-28 15:14:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Books",
      "screen_name" : "PenguinPbks",
      "indices" : [ 0, 12 ],
      "id_str" : "735512676990849025",
      "id" : 735512676990849025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129922681704431616",
  "geo" : { },
  "id_str" : "129924100910096384",
  "in_reply_to_user_id" : 23484629,
  "text" : "@PenguinPbks Rita Dove",
  "id" : 129924100910096384,
  "in_reply_to_status_id" : 129922681704431616,
  "created_at" : "2011-10-28 14:14:54 +0000",
  "in_reply_to_screen_name" : "PenguinBooks",
  "in_reply_to_user_id_str" : "23484629",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/lqi3hbpr",
      "expanded_url" : "http:\/\/coffeeforthebrain.blogspot.com\/2011\/10\/missing-squirrel-with-no-tail.html",
      "display_url" : "coffeeforthebrain.blogspot.com\/2011\/10\/missin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "129922272382300160",
  "text" : "Coffee for the Brain: Missing: Squirrel with no tail: http:\/\/t.co\/lqi3hbpr",
  "id" : 129922272382300160,
  "created_at" : "2011-10-28 14:07:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129921238763192320",
  "text" : "RT @ShipsofSong: If U C physicality as an enemy, it will B an enemy; if U C it as an advocate, it will be Ur advocate",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129920273481859073",
    "text" : "If U C physicality as an enemy, it will B an enemy; if U C it as an advocate, it will be Ur advocate",
    "id" : 129920273481859073,
    "created_at" : "2011-10-28 13:59:41 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 129921238763192320,
  "created_at" : "2011-10-28 14:03:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 3, 18 ],
      "id_str" : "24616866",
      "id" : 24616866
    }, {
      "name" : "Kristen Callihan",
      "screen_name" : "Kris10Callihan",
      "indices" : [ 29, 44 ],
      "id_str" : "255305729",
      "id" : 255305729
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129916060932640768",
  "text" : "RT @andrewtshaffer: BOOO. RT @Kris10Callihan: Halloween at school: no hats, toy weapons, makeup, masks, brooms, wigs, CANDY, or parades. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kristen Callihan",
        "screen_name" : "Kris10Callihan",
        "indices" : [ 9, 24 ],
        "id_str" : "255305729",
        "id" : 255305729
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129915883400339456",
    "text" : "BOOO. RT @Kris10Callihan: Halloween at school: no hats, toy weapons, makeup, masks, brooms, wigs, CANDY, or parades. Fun. Really. Fun.",
    "id" : 129915883400339456,
    "created_at" : "2011-10-28 13:42:14 +0000",
    "user" : {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "protected" : false,
      "id_str" : "24616866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798184019326365696\/Pv56h_bX_normal.jpg",
      "id" : 24616866,
      "verified" : true
    }
  },
  "id" : 129916060932640768,
  "created_at" : "2011-10-28 13:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte",
      "screen_name" : "KindleAuthors",
      "indices" : [ 3, 17 ],
      "id_str" : "911559336",
      "id" : 911559336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SampleSunday",
      "indices" : [ 19, 32 ]
    }, {
      "text" : "kindle",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "ebook",
      "indices" : [ 103, 109 ]
    }, {
      "text" : "book",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "writing",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "nook",
      "indices" : [ 125, 130 ]
    } ],
    "urls" : [ {
      "indices" : [ 74, 94 ],
      "url" : "http:\/\/t.co\/IlovjZC7",
      "expanded_url" : "http:\/\/bit.ly\/eofpmo",
      "display_url" : "bit.ly\/eofpmo"
    } ]
  },
  "geo" : { },
  "id_str" : "129913234244386817",
  "text" : "RT @kindleauthors: #SampleSunday\u2014a FREE and FUN way to promote your book! http:\/\/t.co\/IlovjZC7 #kindle #ebook #book #writing #nook\u2014PLZ RT!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SampleSunday",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "kindle",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "ebook",
        "indices" : [ 84, 90 ]
      }, {
        "text" : "book",
        "indices" : [ 91, 96 ]
      }, {
        "text" : "writing",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "nook",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/IlovjZC7",
        "expanded_url" : "http:\/\/bit.ly\/eofpmo",
        "display_url" : "bit.ly\/eofpmo"
      } ]
    },
    "geo" : { },
    "id_str" : "129912872825393152",
    "text" : "#SampleSunday\u2014a FREE and FUN way to promote your book! http:\/\/t.co\/IlovjZC7 #kindle #ebook #book #writing #nook\u2014PLZ RT!",
    "id" : 129912872825393152,
    "created_at" : "2011-10-28 13:30:17 +0000",
    "user" : {
      "name" : "David Wisehart",
      "screen_name" : "ebookimpresario",
      "protected" : false,
      "id_str" : "181461227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1583967511\/devils-lair-twitter-sm_normal.jpg",
      "id" : 181461227,
      "verified" : false
    }
  },
  "id" : 129913234244386817,
  "created_at" : "2011-10-28 13:31:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 3, 12 ],
      "id_str" : "18581294",
      "id" : 18581294
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/vc1d5PvE",
      "expanded_url" : "http:\/\/ebookfriendly.com",
      "display_url" : "ebookfriendly.com"
    } ]
  },
  "geo" : { },
  "id_str" : "129912860863242240",
  "text" : "RT @namenick: Folks, Google doesn't like my ebook site http:\/\/t.co\/vc1d5PvE because it's made for readers not SEO. Pls visit it and shar ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/vc1d5PvE",
        "expanded_url" : "http:\/\/ebookfriendly.com",
        "display_url" : "ebookfriendly.com"
      } ]
    },
    "geo" : { },
    "id_str" : "129911878288801792",
    "text" : "Folks, Google doesn't like my ebook site http:\/\/t.co\/vc1d5PvE because it's made for readers not SEO. Pls visit it and share, if possible",
    "id" : 129911878288801792,
    "created_at" : "2011-10-28 13:26:20 +0000",
    "user" : {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "protected" : false,
      "id_str" : "18581294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739156618710024192\/iSvI5Blh_normal.jpg",
      "id" : 18581294,
      "verified" : false
    }
  },
  "id" : 129912860863242240,
  "created_at" : "2011-10-28 13:30:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129909540614451200",
  "text" : "RT @Jambodhi: All people are rare and precious, not just ourselves.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129905041137078272",
    "text" : "All people are rare and precious, not just ourselves.",
    "id" : 129905041137078272,
    "created_at" : "2011-10-28 12:59:09 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 129909540614451200,
  "created_at" : "2011-10-28 13:17:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Phineas",
      "screen_name" : "PhineastheShiba",
      "indices" : [ 3, 19 ],
      "id_str" : "97585336",
      "id" : 97585336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShibaMindControl",
      "indices" : [ 91, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129739219227774976",
  "text" : "RT @PhineastheShiba: Returning for year TWO, The Secret Shiba Gift Exchange! Get involved! #ShibaMindControl\n\nsecretshiba.tumblr.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShibaMindControl",
        "indices" : [ 70, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 40.4052492503, -74.9761046419 ]
    },
    "id_str" : "129738622470586368",
    "text" : "Returning for year TWO, The Secret Shiba Gift Exchange! Get involved! #ShibaMindControl\n\nsecretshiba.tumblr.com",
    "id" : 129738622470586368,
    "created_at" : "2011-10-28 01:57:52 +0000",
    "user" : {
      "name" : "Phineas",
      "screen_name" : "PhineastheShiba",
      "protected" : false,
      "id_str" : "97585336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2967991829\/8bba92fadf8ab29bbe65bec0fc05ad1a_normal.jpeg",
      "id" : 97585336,
      "verified" : false
    }
  },
  "id" : 129739219227774976,
  "created_at" : "2011-10-28 02:00:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129732662784049152",
  "geo" : { },
  "id_str" : "129733474331533313",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses omg'ness! quick quick recovery so you can enjoy some of your vacation! ((hugs))",
  "id" : 129733474331533313,
  "in_reply_to_status_id" : 129732662784049152,
  "created_at" : "2011-10-28 01:37:25 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129731345088921601",
  "text" : "RT @abandontheherd: Don't compare your life to others. \nYou have no idea what their journey is all about.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129716936304099328",
    "text" : "Don't compare your life to others. \nYou have no idea what their journey is all about.",
    "id" : 129716936304099328,
    "created_at" : "2011-10-28 00:31:42 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 129731345088921601,
  "created_at" : "2011-10-28 01:28:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129729631610871808",
  "text" : "RT @not_hwa: Love one another. Because its all we got left.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129719768646303744",
    "text" : "Love one another. Because its all we got left.",
    "id" : 129719768646303744,
    "created_at" : "2011-10-28 00:42:57 +0000",
    "user" : {
      "name" : "Mrs @badkinkybunny",
      "screen_name" : "dark_bubblez",
      "protected" : false,
      "id_str" : "345296662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575913089884950528\/n4urLPOP_normal.jpeg",
      "id" : 345296662,
      "verified" : false
    }
  },
  "id" : 129729631610871808,
  "created_at" : "2011-10-28 01:22:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129691781494349824",
  "text" : "RT @TheEntertainer: Being realistic will get you NOWHERE. Be an innovator, an original & take life on & show what you REALLY have. Screw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129691428380098560",
    "text" : "Being realistic will get you NOWHERE. Be an innovator, an original & take life on & show what you REALLY have. Screw Normal",
    "id" : 129691428380098560,
    "created_at" : "2011-10-27 22:50:20 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 129691781494349824,
  "created_at" : "2011-10-27 22:51:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129690896957579264",
  "text" : "RT @TheEntertainer: Live by building brick by brick and do it with ALL you have. It WILL be something BIG when you're done.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129690668976189440",
    "text" : "Live by building brick by brick and do it with ALL you have. It WILL be something BIG when you're done.",
    "id" : 129690668976189440,
    "created_at" : "2011-10-27 22:47:19 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 129690896957579264,
  "created_at" : "2011-10-27 22:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 0, 13 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129688963219853312",
  "geo" : { },
  "id_str" : "129690466210942976",
  "in_reply_to_user_id" : 44101564,
  "text" : "@Joeandrasi93 shush now! I do NOT see snow out there.. no, I do not!",
  "id" : 129690466210942976,
  "in_reply_to_status_id" : 129688963219853312,
  "created_at" : "2011-10-27 22:46:31 +0000",
  "in_reply_to_screen_name" : "Joeandrasi93",
  "in_reply_to_user_id_str" : "44101564",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129690303694241792",
  "text" : "RT @DeepakChopra: What we see we become. Choose your seeing wisely.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129688989266477056",
    "text" : "What we see we become. Choose your seeing wisely.",
    "id" : 129688989266477056,
    "created_at" : "2011-10-27 22:40:39 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 129690303694241792,
  "created_at" : "2011-10-27 22:45:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 30, 40 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dadwithdaughter",
      "indices" : [ 68, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/Qrd9J9qq",
      "expanded_url" : "http:\/\/yfrog.com\/klrkeawxj",
      "display_url" : "yfrog.com\/klrkeawxj"
    } ]
  },
  "geo" : { },
  "id_str" : "129671338225971201",
  "text" : "good look for you! lol ; ) RT @ScottBaio: THIS is what happens..... #dadwithdaughter  http:\/\/t.co\/Qrd9J9qq",
  "id" : 129671338225971201,
  "created_at" : "2011-10-27 21:30:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129649455417933824",
  "text" : "RT @ThrillersRockT: If the deranged killer appears to be dead, don't run for help. CHOP HIS FREAKIN HEAD OFF!!! And take it with you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129647316410961921",
    "text" : "If the deranged killer appears to be dead, don't run for help. CHOP HIS FREAKIN HEAD OFF!!! And take it with you.",
    "id" : 129647316410961921,
    "created_at" : "2011-10-27 19:55:03 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 129649455417933824,
  "created_at" : "2011-10-27 20:03:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy ~ AllAboutEnergy",
      "screen_name" : "allaboutenergy",
      "indices" : [ 3, 18 ],
      "id_str" : "11202782",
      "id" : 11202782
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129638336376750080",
  "text" : "RT @allaboutenergy: Abundance Alert!  It's within 24 hrs after a Potent New Moon!  Write an Abundance Check & set intentions! Instructio ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/dXrJxxbk",
        "expanded_url" : "http:\/\/archive.aweber.com\/moneyreiki\/8Bw86",
        "display_url" : "archive.aweber.com\/moneyreiki\/8Bw\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "129468068463247361",
    "text" : "Abundance Alert!  It's within 24 hrs after a Potent New Moon!  Write an Abundance Check & set intentions! Instructions: http:\/\/t.co\/dXrJxxbk",
    "id" : 129468068463247361,
    "created_at" : "2011-10-27 08:02:47 +0000",
    "user" : {
      "name" : "Amy ~ AllAboutEnergy",
      "screen_name" : "allaboutenergy",
      "protected" : false,
      "id_str" : "11202782",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707294226397196288\/jlLROcNj_normal.jpg",
      "id" : 11202782,
      "verified" : false
    }
  },
  "id" : 129638336376750080,
  "created_at" : "2011-10-27 19:19:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129635694460149761",
  "text" : "RT @BrianMerritt: How can a Calvinist believe someone chooses to be gay when they don't believe in free will?  ;-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129634864751321088",
    "text" : "How can a Calvinist believe someone chooses to be gay when they don't believe in free will?  ;-)",
    "id" : 129634864751321088,
    "created_at" : "2011-10-27 19:05:34 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 129635694460149761,
  "created_at" : "2011-10-27 19:08:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "lisa kay",
      "screen_name" : "nymedium",
      "indices" : [ 3, 12 ],
      "id_str" : "32799607",
      "id" : 32799607
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Loa",
      "indices" : [ 63, 67 ]
    }, {
      "text" : "Shift",
      "indices" : [ 68, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129635618639716352",
  "text" : "RT @nymedium: We attract through inspiration, not desperation. #Loa #Shift",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Loa",
        "indices" : [ 49, 53 ]
      }, {
        "text" : "Shift",
        "indices" : [ 54, 60 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129635080586002432",
    "text" : "We attract through inspiration, not desperation. #Loa #Shift",
    "id" : 129635080586002432,
    "created_at" : "2011-10-27 19:06:26 +0000",
    "user" : {
      "name" : "lisa kay",
      "screen_name" : "nymedium",
      "protected" : false,
      "id_str" : "32799607",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/221666348\/lisak_normal.jpg",
      "id" : 32799607,
      "verified" : false
    }
  },
  "id" : 129635618639716352,
  "created_at" : "2011-10-27 19:08:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Karin Kremendahl",
      "screen_name" : "prodefi",
      "indices" : [ 55, 63 ],
      "id_str" : "20242688",
      "id" : 20242688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/yWBbS7oy",
      "expanded_url" : "http:\/\/tinyurl.com\/675dcd7",
      "display_url" : "tinyurl.com\/675dcd7"
    } ]
  },
  "geo" : { },
  "id_str" : "129614292944306178",
  "text" : "RT @KerriFar: Cute ALERT!  This is sooooo adorable! RT @prodefi: Have a look at this http:\/\/t.co\/yWBbS7oy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karin Kremendahl",
        "screen_name" : "prodefi",
        "indices" : [ 41, 49 ],
        "id_str" : "20242688",
        "id" : 20242688
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/yWBbS7oy",
        "expanded_url" : "http:\/\/tinyurl.com\/675dcd7",
        "display_url" : "tinyurl.com\/675dcd7"
      } ]
    },
    "geo" : { },
    "id_str" : "129613338714976256",
    "text" : "Cute ALERT!  This is sooooo adorable! RT @prodefi: Have a look at this http:\/\/t.co\/yWBbS7oy",
    "id" : 129613338714976256,
    "created_at" : "2011-10-27 17:40:02 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 129614292944306178,
  "created_at" : "2011-10-27 17:43:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 81, 94 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/Ej3I37kK",
      "expanded_url" : "http:\/\/bit.ly\/q247Om",
      "display_url" : "bit.ly\/q247Om"
    } ]
  },
  "in_reply_to_status_id_str" : "129609501308502017",
  "geo" : { },
  "id_str" : "129612517344423937",
  "in_reply_to_user_id" : 15588657,
  "text" : "\"I think the brain is an observation deck for the Universe to look at itself.\" - @DeepakChopra http:\/\/t.co\/Ej3I37kK",
  "id" : 129612517344423937,
  "in_reply_to_status_id" : 129609501308502017,
  "created_at" : "2011-10-27 17:36:46 +0000",
  "in_reply_to_screen_name" : "DeepakChopra",
  "in_reply_to_user_id_str" : "15588657",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129610864763486209",
  "text" : "RT @bunnybuddhism: Let no bunny work another bunny\u2019s undoing or even slight him at all.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129610374373842945",
    "text" : "Let no bunny work another bunny\u2019s undoing or even slight him at all.",
    "id" : 129610374373842945,
    "created_at" : "2011-10-27 17:28:15 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 129610864763486209,
  "created_at" : "2011-10-27 17:30:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 10, 25 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129610008445992960",
  "text" : "@Tideliar @thesexyatheist I love Einstein (we share a bday..lol) and Quantum stuff fascinates me... very cool. what a wondrous world!",
  "id" : 129610008445992960,
  "created_at" : "2011-10-27 17:26:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/LfIAbwtR",
      "expanded_url" : "http:\/\/ning.it\/w14JCE",
      "display_url" : "ning.it\/w14JCE"
    } ]
  },
  "geo" : { },
  "id_str" : "129609680887619585",
  "text" : "Checking out \"Seth Speaks about God\" on Temple Illuminatus: http:\/\/t.co\/LfIAbwtR",
  "id" : 129609680887619585,
  "created_at" : "2011-10-27 17:25:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129600119153770497",
  "geo" : { },
  "id_str" : "129601904421511169",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver \"look into my eyes\" muhaha",
  "id" : 129601904421511169,
  "in_reply_to_status_id" : 129600119153770497,
  "created_at" : "2011-10-27 16:54:36 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129601395836993537",
  "text" : "RT @CharlesBivona: My overdue rent is paid in full. My eviction has been cancelled. Reader donations actually saved my home. Whewwww. #T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankYou",
        "indices" : [ 115, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129599987008020480",
    "text" : "My overdue rent is paid in full. My eviction has been cancelled. Reader donations actually saved my home. Whewwww. #ThankYou all AGAIN!!",
    "id" : 129599987008020480,
    "created_at" : "2011-10-27 16:46:59 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 129601395836993537,
  "created_at" : "2011-10-27 16:52:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Plume Books",
      "screen_name" : "PlumeBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "97020002",
      "id" : 97020002
    }, {
      "name" : "Wendy Northcutt",
      "screen_name" : "WendyNorthcutt",
      "indices" : [ 52, 67 ],
      "id_str" : "34742525",
      "id" : 34742525
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129591191539949568",
  "text" : "RT @PlumeBooks: Be 1st to RT this msg & win copy of @WendyNorthcutt's DARWIN AWARDS CNTDN TO EXTINCTION + t-shirt! rules: http:\/\/t.co\/L1 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wendy Northcutt",
        "screen_name" : "WendyNorthcutt",
        "indices" : [ 36, 51 ],
        "id_str" : "34742525",
        "id" : 34742525
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "plumehumor",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/L1yToMjY",
        "expanded_url" : "http:\/\/ow.ly\/6vBrn",
        "display_url" : "ow.ly\/6vBrn"
      } ]
    },
    "geo" : { },
    "id_str" : "129590647937179648",
    "text" : "Be 1st to RT this msg & win copy of @WendyNorthcutt's DARWIN AWARDS CNTDN TO EXTINCTION + t-shirt! rules: http:\/\/t.co\/L1yToMjY #plumehumor",
    "id" : 129590647937179648,
    "created_at" : "2011-10-27 16:09:52 +0000",
    "user" : {
      "name" : "Plume Books",
      "screen_name" : "PlumeBooks",
      "protected" : false,
      "id_str" : "97020002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/641721042839465984\/GeeyojEb_normal.jpg",
      "id" : 97020002,
      "verified" : false
    }
  },
  "id" : 129591191539949568,
  "created_at" : "2011-10-27 16:12:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 122, 137 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/116tY4iV",
      "expanded_url" : "http:\/\/bit.ly\/sj0iiQ",
      "display_url" : "bit.ly\/sj0iiQ"
    } ]
  },
  "geo" : { },
  "id_str" : "129587717842538496",
  "text" : "THIS!! &gt;&gt; Can you take something and cut it in half so much that eventually it becomes nothing http:\/\/t.co\/116tY4iV @thesexyatheist",
  "id" : 129587717842538496,
  "created_at" : "2011-10-27 15:58:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quotes",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129586051445567489",
  "text" : "RT @UndertheNeonSky: We worry about what a child will become tomorrow, yet we forget that he is someone today #quotes Stacia Tauscher #T ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quotes",
        "indices" : [ 89, 96 ]
      }, {
        "text" : "TFTD",
        "indices" : [ 113, 118 ]
      }, {
        "text" : "thought",
        "indices" : [ 119, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129583316914548736",
    "text" : "We worry about what a child will become tomorrow, yet we forget that he is someone today #quotes Stacia Tauscher #TFTD #thought",
    "id" : 129583316914548736,
    "created_at" : "2011-10-27 15:40:44 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 129586051445567489,
  "created_at" : "2011-10-27 15:51:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 100, 109 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 111, 126 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129584988986425348",
  "text" : "What is in vacuumless space and what would you call that and could you measure that. bit.ly\/savg0I  @Tideliar  @thesexyatheist",
  "id" : 129584988986425348,
  "created_at" : "2011-10-27 15:47:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 6, 15 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 51, 66 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "science",
      "indices" : [ 39, 47 ]
    } ],
    "urls" : [ {
      "indices" : [ 119, 139 ],
      "url" : "http:\/\/t.co\/p9RVysve",
      "expanded_url" : "http:\/\/deck.ly\/~ab0J9",
      "display_url" : "deck.ly\/~ab0J9"
    } ]
  },
  "geo" : { },
  "id_str" : "129583930859978752",
  "text" : "maybe @Tideliar can post his thoughts? #science RT @thesexyatheist: krissthesexyatheist: Thoughts On Yesterday\u2026 (cont) http:\/\/t.co\/p9RVysve",
  "id" : 129583930859978752,
  "created_at" : "2011-10-27 15:43:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 85, 105 ],
      "url" : "http:\/\/t.co\/oMHDpeIE",
      "expanded_url" : "http:\/\/bit.ly\/savg0I",
      "display_url" : "bit.ly\/savg0I"
    } ]
  },
  "geo" : { },
  "id_str" : "129583358664646656",
  "text" : "What is in vacuumless space and what would you call that and could you measure that. http:\/\/t.co\/oMHDpeIE",
  "id" : 129583358664646656,
  "created_at" : "2011-10-27 15:40:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/77vrxS0R",
      "expanded_url" : "http:\/\/tumblr.com\/ZwrrNyBApom8",
      "display_url" : "tumblr.com\/ZwrrNyBApom8"
    } ]
  },
  "geo" : { },
  "id_str" : "129581605655285761",
  "text" : "RT @parkstepp: Audio: Did we not know that the Change was coming?Did we not understand that the current system was... http:\/\/t.co\/77vrxS0R",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 103, 123 ],
        "url" : "http:\/\/t.co\/77vrxS0R",
        "expanded_url" : "http:\/\/tumblr.com\/ZwrrNyBApom8",
        "display_url" : "tumblr.com\/ZwrrNyBApom8"
      } ]
    },
    "geo" : { },
    "id_str" : "129579648232329219",
    "text" : "Audio: Did we not know that the Change was coming?Did we not understand that the current system was... http:\/\/t.co\/77vrxS0R",
    "id" : 129579648232329219,
    "created_at" : "2011-10-27 15:26:10 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 129581605655285761,
  "created_at" : "2011-10-27 15:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129573134826340352",
  "text" : "RT @TheGodLight: You must not give into fear, the more you fear the tighter the grip fear has on you, let go & see it for what it is.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129572951724011522",
    "text" : "You must not give into fear, the more you fear the tighter the grip fear has on you, let go & see it for what it is.",
    "id" : 129572951724011522,
    "created_at" : "2011-10-27 14:59:33 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 129573134826340352,
  "created_at" : "2011-10-27 15:00:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129571701297131520",
  "text" : "@SamsaricWarrior world is in such turmoil and im feeling it but hanging on to hope. ((hugs)) to you",
  "id" : 129571701297131520,
  "created_at" : "2011-10-27 14:54:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129569989412917248",
  "text" : "school nurse def doesn't like me :\/",
  "id" : 129569989412917248,
  "created_at" : "2011-10-27 14:47:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129365769451601921",
  "text" : "RT @BeasBookNook: Huh.  Google+ has decided that Bea's Book Nook is not an acceptable profile name. I will be closing my Google+ account.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129363753149005824",
    "text" : "Huh.  Google+ has decided that Bea's Book Nook is not an acceptable profile name. I will be closing my Google+ account.",
    "id" : 129363753149005824,
    "created_at" : "2011-10-27 01:08:16 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 129365769451601921,
  "created_at" : "2011-10-27 01:16:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129313252122439680",
  "text" : "@SamsaricWarrior nice work, sir!",
  "id" : 129313252122439680,
  "created_at" : "2011-10-26 21:47:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole",
      "screen_name" : "carolesthought",
      "indices" : [ 3, 18 ],
      "id_str" : "8473622",
      "id" : 8473622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/T1n2yzjW",
      "expanded_url" : "http:\/\/www.carolesthoughtfulspot.com\/",
      "display_url" : "carolesthoughtfulspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "129251421085372416",
  "text" : "RT @carolesthought: I Had an Excuse to Visit Millbrook, NY and Pay My Respects to Taconic Newspapers  http:\/\/t.co\/T1n2yzjW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/T1n2yzjW",
        "expanded_url" : "http:\/\/www.carolesthoughtfulspot.com\/",
        "display_url" : "carolesthoughtfulspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "129242141376516096",
    "text" : "I Had an Excuse to Visit Millbrook, NY and Pay My Respects to Taconic Newspapers  http:\/\/t.co\/T1n2yzjW",
    "id" : 129242141376516096,
    "created_at" : "2011-10-26 17:05:02 +0000",
    "user" : {
      "name" : "Carole",
      "screen_name" : "carolesthought",
      "protected" : false,
      "id_str" : "8473622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580805790535036929\/jmab8LbB_normal.jpg",
      "id" : 8473622,
      "verified" : false
    }
  },
  "id" : 129251421085372416,
  "created_at" : "2011-10-26 17:41:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "indices" : [ 3, 18 ],
      "id_str" : "7622122",
      "id" : 7622122
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129250432747978753",
  "text" : "RT @indiebizchicks: Want to make extra $ in Dec by teaching people what you know? Preview the first lesson in my upcoming workshop for F ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/HSdbPFCv",
        "expanded_url" : "http:\/\/www.indiebizchicks.com\/teach-an-online-class-preview.pdf",
        "display_url" : "indiebizchicks.com\/teach-an-onlin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "129243857090134016",
    "text" : "Want to make extra $ in Dec by teaching people what you know? Preview the first lesson in my upcoming workshop for FREE http:\/\/t.co\/HSdbPFCv",
    "id" : 129243857090134016,
    "created_at" : "2011-10-26 17:11:51 +0000",
    "user" : {
      "name" : "Crissy Herron",
      "screen_name" : "indiebizchicks",
      "protected" : false,
      "id_str" : "7622122",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653393257959936001\/6VMDqhz3_normal.jpg",
      "id" : 7622122,
      "verified" : false
    }
  },
  "id" : 129250432747978753,
  "created_at" : "2011-10-26 17:37:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "indices" : [ 3, 9 ],
      "id_str" : "9930742",
      "id" : 9930742
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129219514247299072",
  "text" : "RT @sween: Rather than \u201Chuman remains found\u201D, they should just say \u201Chuman still not lost again\u201D.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129218300046618624",
    "text" : "Rather than \u201Chuman remains found\u201D, they should just say \u201Chuman still not lost again\u201D.",
    "id" : 129218300046618624,
    "created_at" : "2011-10-26 15:30:18 +0000",
    "user" : {
      "name" : "Jason Sweeney",
      "screen_name" : "sween",
      "protected" : false,
      "id_str" : "9930742",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576723767402983424\/xLGkIHkA_normal.jpeg",
      "id" : 9930742,
      "verified" : true
    }
  },
  "id" : 129219514247299072,
  "created_at" : "2011-10-26 15:35:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "129198225386242048",
  "text" : "RT @DrRus: Morning Mindbender Answer: 33% of women spend a big chuck of their morning discussing \"what to have for lunch\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "129195381874638850",
    "text" : "Morning Mindbender Answer: 33% of women spend a big chuck of their morning discussing \"what to have for lunch\".",
    "id" : 129195381874638850,
    "created_at" : "2011-10-26 13:59:14 +0000",
    "user" : {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "protected" : false,
      "id_str" : "11006552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2998045873\/401a4460295cb0375428b8b577bd2249_normal.jpeg",
      "id" : 11006552,
      "verified" : false
    }
  },
  "id" : 129198225386242048,
  "created_at" : "2011-10-26 14:10:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129188599408246784",
  "geo" : { },
  "id_str" : "129189141689810944",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I am good so far..lol",
  "id" : 129189141689810944,
  "in_reply_to_status_id" : 129188599408246784,
  "created_at" : "2011-10-26 13:34:26 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "129181005448876032",
  "geo" : { },
  "id_str" : "129188142250078208",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell and you, as well.",
  "id" : 129188142250078208,
  "in_reply_to_status_id" : 129181005448876032,
  "created_at" : "2011-10-26 13:30:27 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "indices" : [ 3, 15 ],
      "id_str" : "16126957",
      "id" : 16126957
    }, {
      "name" : "Alaska Raptor Center",
      "screen_name" : "RaptorOrg",
      "indices" : [ 129, 139 ],
      "id_str" : "227606087",
      "id" : 227606087
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/4EvSz59I",
      "expanded_url" : "http:\/\/twitpic.com\/75s8zs",
      "display_url" : "twitpic.com\/75s8zs"
    } ]
  },
  "geo" : { },
  "id_str" : "128973713419927552",
  "text" : "RT @paul_steele: Tootsie the little Saw-Whet Owl .. we are fixing her broken humerus for hopeful release http:\/\/t.co\/4EvSz59I RT @raptororg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alaska Raptor Center",
        "screen_name" : "RaptorOrg",
        "indices" : [ 112, 122 ],
        "id_str" : "227606087",
        "id" : 227606087
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/4EvSz59I",
        "expanded_url" : "http:\/\/twitpic.com\/75s8zs",
        "display_url" : "twitpic.com\/75s8zs"
      } ]
    },
    "geo" : { },
    "id_str" : "128972082242523136",
    "text" : "Tootsie the little Saw-Whet Owl .. we are fixing her broken humerus for hopeful release http:\/\/t.co\/4EvSz59I RT @raptororg",
    "id" : 128972082242523136,
    "created_at" : "2011-10-25 23:11:55 +0000",
    "user" : {
      "name" : "Paul Steele",
      "screen_name" : "paul_steele",
      "protected" : false,
      "id_str" : "16126957",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788690057599283200\/-_rph72s_normal.jpg",
      "id" : 16126957,
      "verified" : true
    }
  },
  "id" : 128973713419927552,
  "created_at" : "2011-10-25 23:18:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AddThis",
      "screen_name" : "addthis",
      "indices" : [ 98, 106 ],
      "id_str" : "15907720",
      "id" : 15907720
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/yBhIyX4R",
      "expanded_url" : "http:\/\/thefrugalereader.com\/2011\/10\/25\/the-tuesday-giveaway-a-kindle-copy-of-running-with-scissors-a-memoir\/#.Tqcr8e8swNk.twitter",
      "display_url" : "thefrugalereader.com\/2011\/10\/25\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128948296122245120",
  "text" : "The Tuesday Giveaway: A Kindle Copy of Running With Scissors: A Memoir!  http:\/\/t.co\/yBhIyX4R via @AddThis",
  "id" : 128948296122245120,
  "created_at" : "2011-10-25 21:37:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128935587616014337",
  "geo" : { },
  "id_str" : "128936287947333633",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell yeah, I think I'll keep you! : )",
  "id" : 128936287947333633,
  "in_reply_to_status_id" : 128935587616014337,
  "created_at" : "2011-10-25 20:49:41 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128935260678393856",
  "geo" : { },
  "id_str" : "128935708961406976",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell (chopped liver? lol) you are a lovely person, that's what you are!",
  "id" : 128935708961406976,
  "in_reply_to_status_id" : 128935260678393856,
  "created_at" : "2011-10-25 20:47:23 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128935431508205568",
  "text" : "spent time w someone whose nervous energy affected me. gave me stomachache.",
  "id" : 128935431508205568,
  "created_at" : "2011-10-25 20:46:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128934978301083648",
  "text" : "for my own sanity, might have to unfollow. some neg \/ fear really makes me ill..",
  "id" : 128934978301083648,
  "created_at" : "2011-10-25 20:44:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    }, {
      "name" : "Megan Carver",
      "screen_name" : "MegCarver",
      "indices" : [ 21, 31 ],
      "id_str" : "591318653",
      "id" : 591318653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128933467718299648",
  "text" : "RT @morsemusings: RT @MegCarver: Feeling isolated can be a calling of spiritual awakening. Quiet yourself and listen within.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Megan Carver",
        "screen_name" : "MegCarver",
        "indices" : [ 3, 13 ],
        "id_str" : "591318653",
        "id" : 591318653
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128932629520203778",
    "text" : "RT @MegCarver: Feeling isolated can be a calling of spiritual awakening. Quiet yourself and listen within.",
    "id" : 128932629520203778,
    "created_at" : "2011-10-25 20:35:08 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 128933467718299648,
  "created_at" : "2011-10-25 20:38:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheresMoreToLifeThanNegativeCrap",
      "indices" : [ 92, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128920838652170240",
  "text" : "RT @TheEntertainer: Hey news on Twitter, how about some freakin good news once in a while?? #TheresMoreToLifeThanNegativeCrap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheresMoreToLifeThanNegativeCrap",
        "indices" : [ 72, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128916962028949504",
    "text" : "Hey news on Twitter, how about some freakin good news once in a while?? #TheresMoreToLifeThanNegativeCrap",
    "id" : 128916962028949504,
    "created_at" : "2011-10-25 19:32:53 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 128920838652170240,
  "created_at" : "2011-10-25 19:48:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Henry Cat",
      "screen_name" : "HenryCat3",
      "indices" : [ 16, 26 ],
      "id_str" : "609396605",
      "id" : 609396605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128911287672516610",
  "geo" : { },
  "id_str" : "128912370201395200",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver @HenryCat3 purrz... happy cat",
  "id" : 128912370201395200,
  "in_reply_to_status_id" : 128911287672516610,
  "created_at" : "2011-10-25 19:14:38 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Marlo Thomas",
      "screen_name" : "MarloThomas",
      "indices" : [ 17, 29 ],
      "id_str" : "111595219",
      "id" : 111595219
    }, {
      "name" : "Maxine Clark",
      "screen_name" : "ChiefExecBear",
      "indices" : [ 70, 84 ],
      "id_str" : "15238609",
      "id" : 15238609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128901083195117570",
  "text" : "RT @JohnCali: RT @MarloThomas: I have 6 copies of a wonderful book by @ChiefExecBear to give away - just RT this to win! htt\u2026 (cont) htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marlo Thomas",
        "screen_name" : "MarloThomas",
        "indices" : [ 3, 15 ],
        "id_str" : "111595219",
        "id" : 111595219
      }, {
        "name" : "Maxine Clark",
        "screen_name" : "ChiefExecBear",
        "indices" : [ 56, 70 ],
        "id_str" : "15238609",
        "id" : 15238609
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/NQDg5jrb",
        "expanded_url" : "http:\/\/deck.ly\/~jsI9x",
        "display_url" : "deck.ly\/~jsI9x"
      } ]
    },
    "geo" : { },
    "id_str" : "128900496734949376",
    "text" : "RT @MarloThomas: I have 6 copies of a wonderful book by @ChiefExecBear to give away - just RT this to win! htt\u2026 (cont) http:\/\/t.co\/NQDg5jrb",
    "id" : 128900496734949376,
    "created_at" : "2011-10-25 18:27:27 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 128901083195117570,
  "created_at" : "2011-10-25 18:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/csAfsqNL",
      "expanded_url" : "http:\/\/tinyurl.com\/445sbpe",
      "display_url" : "tinyurl.com\/445sbpe"
    } ]
  },
  "geo" : { },
  "id_str" : "128896934432870401",
  "text" : "RT @Soulseedzforall: What if you had all the time in the world? YOU DO,   a new article about time http:\/\/t.co\/csAfsqNL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/csAfsqNL",
        "expanded_url" : "http:\/\/tinyurl.com\/445sbpe",
        "display_url" : "tinyurl.com\/445sbpe"
      } ]
    },
    "geo" : { },
    "id_str" : "128896443862884352",
    "text" : "What if you had all the time in the world? YOU DO,   a new article about time http:\/\/t.co\/csAfsqNL",
    "id" : 128896443862884352,
    "created_at" : "2011-10-25 18:11:21 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 128896934432870401,
  "created_at" : "2011-10-25 18:13:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128890780826877952",
  "text" : "I saw a horned cow licking another horned cow's head this morning. It was sweet.",
  "id" : 128890780826877952,
  "created_at" : "2011-10-25 17:48:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128890627533443072",
  "text" : "RT @abe_quotes: Disconnection and resistance are not letting it in; allowing, love, appreciation, and looking for positive aspects does.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128890341335105536",
    "text" : "Disconnection and resistance are not letting it in; allowing, love, appreciation, and looking for positive aspects does.",
    "id" : 128890341335105536,
    "created_at" : "2011-10-25 17:47:06 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 128890627533443072,
  "created_at" : "2011-10-25 17:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128890600719257600",
  "text" : "RT @abe_quotes: So who does it serve by joining the ranks of the condemning? It serves nothing. All it does is spread the disconnection.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128890334796201985",
    "text" : "So who does it serve by joining the ranks of the condemning? It serves nothing. All it does is spread the disconnection.",
    "id" : 128890334796201985,
    "created_at" : "2011-10-25 17:47:05 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 128890600719257600,
  "created_at" : "2011-10-25 17:48:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128885514215493632",
  "text" : "I feel like a wolf among the sheep at bible study...",
  "id" : 128885514215493632,
  "created_at" : "2011-10-25 17:27:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "lam",
      "indices" : [ 107, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/52qujxjM",
      "expanded_url" : "http:\/\/bit.ly\/sHdoDU",
      "display_url" : "bit.ly\/sHdoDU"
    } ]
  },
  "geo" : { },
  "id_str" : "128820145924751360",
  "text" : "RT @aliceinthewater: Your daily AWWW: How to pick up a baby Red Panda in 5 easy steps\nhttp:\/\/t.co\/52qujxjM #lam",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lam",
        "indices" : [ 86, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/52qujxjM",
        "expanded_url" : "http:\/\/bit.ly\/sHdoDU",
        "display_url" : "bit.ly\/sHdoDU"
      } ]
    },
    "geo" : { },
    "id_str" : "128816003953065984",
    "text" : "Your daily AWWW: How to pick up a baby Red Panda in 5 easy steps\nhttp:\/\/t.co\/52qujxjM #lam",
    "id" : 128816003953065984,
    "created_at" : "2011-10-25 12:51:43 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 128820145924751360,
  "created_at" : "2011-10-25 13:08:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 51, 71 ],
      "url" : "http:\/\/t.co\/YJxTowYC",
      "expanded_url" : "http:\/\/bit.ly\/ud8ZCi",
      "display_url" : "bit.ly\/ud8ZCi"
    } ]
  },
  "geo" : { },
  "id_str" : "128819555891023872",
  "text" : "Dwayne Reaves dot Net: I refuse to NOT be a Daddy! http:\/\/t.co\/YJxTowYC",
  "id" : 128819555891023872,
  "created_at" : "2011-10-25 13:05:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128648473494044673",
  "text" : "RT @abandontheherd: Our entire life is a reflection of our own mind and its current state.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128648126767702017",
    "text" : "Our entire life is a reflection of our own mind and its current state.",
    "id" : 128648126767702017,
    "created_at" : "2011-10-25 01:44:38 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 128648473494044673,
  "created_at" : "2011-10-25 01:46:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128628194944352257",
  "text" : "@SamsaricWarrior nice.. love the ducks hanging out..",
  "id" : 128628194944352257,
  "created_at" : "2011-10-25 00:25:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128621303266680832",
  "text" : "@SamsaricWarrior hope tomorrow is better for you",
  "id" : 128621303266680832,
  "created_at" : "2011-10-24 23:58:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128613815075094528",
  "text" : "@tragic_pizza uh-oh, I think I'm gonna hide for awhile then..lol",
  "id" : 128613815075094528,
  "created_at" : "2011-10-24 23:28:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Arene Alexandra",
      "screen_name" : "AniArene",
      "indices" : [ 13, 22 ],
      "id_str" : "116786271",
      "id" : 116786271
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128612709079064576",
  "text" : "RT @SangyeH: @AniArene If you like following them, why does it matter if they're not following back?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arene Alexandra",
        "screen_name" : "AniArene",
        "indices" : [ 0, 9 ],
        "id_str" : "116786271",
        "id" : 116786271
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "128609636919156737",
    "geo" : { },
    "id_str" : "128610193465548800",
    "in_reply_to_user_id" : 116786271,
    "text" : "@AniArene If you like following them, why does it matter if they're not following back?",
    "id" : 128610193465548800,
    "in_reply_to_status_id" : 128609636919156737,
    "created_at" : "2011-10-24 23:13:54 +0000",
    "in_reply_to_screen_name" : "AniArene",
    "in_reply_to_user_id_str" : "116786271",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 128612709079064576,
  "created_at" : "2011-10-24 23:23:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128607601742196736",
  "geo" : { },
  "id_str" : "128608750520115200",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I wholeheartedly agree \u2665",
  "id" : 128608750520115200,
  "in_reply_to_status_id" : 128607601742196736,
  "created_at" : "2011-10-24 23:08:10 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/9uIHKwS1",
      "expanded_url" : "http:\/\/bit.ly\/sjDCmG",
      "display_url" : "bit.ly\/sjDCmG"
    } ]
  },
  "geo" : { },
  "id_str" : "128603344913707008",
  "text" : "RT @GraveStomper: Yes, I know it's been awhile, but here's a brand new stomp.  Want Magic?  Then DO Something! http:\/\/t.co\/9uIHKwS1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/9uIHKwS1",
        "expanded_url" : "http:\/\/bit.ly\/sjDCmG",
        "display_url" : "bit.ly\/sjDCmG"
      } ]
    },
    "geo" : { },
    "id_str" : "128599570451152896",
    "text" : "Yes, I know it's been awhile, but here's a brand new stomp.  Want Magic?  Then DO Something! http:\/\/t.co\/9uIHKwS1",
    "id" : 128599570451152896,
    "created_at" : "2011-10-24 22:31:41 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 128603344913707008,
  "created_at" : "2011-10-24 22:46:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "martialarts",
      "indices" : [ 99, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/VgceDRTE",
      "expanded_url" : "http:\/\/bit.ly\/u1DeI0",
      "display_url" : "bit.ly\/u1DeI0"
    }, {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/VgceDRTE",
      "expanded_url" : "http:\/\/bit.ly\/u1DeI0",
      "display_url" : "bit.ly\/u1DeI0"
    } ]
  },
  "geo" : { },
  "id_str" : "128587635806580737",
  "text" : "10\/21's Fall Nationals 2011 ATA Invitational replay on http:\/\/t.co\/VgceDRTE  http:\/\/t.co\/VgceDRTE  #martialarts",
  "id" : 128587635806580737,
  "created_at" : "2011-10-24 21:44:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128573582921052160",
  "geo" : { },
  "id_str" : "128574734446235649",
  "in_reply_to_user_id" : 18256901,
  "text" : "@deonnasayed what a precious boy! : )",
  "id" : 128574734446235649,
  "in_reply_to_status_id" : 128573582921052160,
  "created_at" : "2011-10-24 20:53:00 +0000",
  "in_reply_to_screen_name" : "deonnakelli",
  "in_reply_to_user_id_str" : "18256901",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128568372886634496",
  "geo" : { },
  "id_str" : "128570344683470848",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench so exciting! good luck... and breathe..lol",
  "id" : 128570344683470848,
  "in_reply_to_status_id" : 128568372886634496,
  "created_at" : "2011-10-24 20:35:33 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "indices" : [ 3, 17 ],
      "id_str" : "16494321",
      "id" : 16494321
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/T3M5dw7f",
      "expanded_url" : "http:\/\/soc.li\/werjk7D",
      "display_url" : "soc.li\/werjk7D"
    } ]
  },
  "geo" : { },
  "id_str" : "128559792926101504",
  "text" : "RT @BrianRathbone: Ebook cards for selling ebooks http:\/\/t.co\/T3M5dw7f",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/T3M5dw7f",
        "expanded_url" : "http:\/\/soc.li\/werjk7D",
        "display_url" : "soc.li\/werjk7D"
      } ]
    },
    "geo" : { },
    "id_str" : "128557558528090113",
    "text" : "Ebook cards for selling ebooks http:\/\/t.co\/T3M5dw7f",
    "id" : 128557558528090113,
    "created_at" : "2011-10-24 19:44:45 +0000",
    "user" : {
      "name" : "Fantasy Author",
      "screen_name" : "BrianRathbone",
      "protected" : false,
      "id_str" : "16494321",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/596084202556260353\/YO9zjacn_normal.jpg",
      "id" : 16494321,
      "verified" : false
    }
  },
  "id" : 128559792926101504,
  "created_at" : "2011-10-24 19:53:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/qY3hcHNX",
      "expanded_url" : "http:\/\/bo.st\/stCoq7",
      "display_url" : "bo.st\/stCoq7"
    } ]
  },
  "geo" : { },
  "id_str" : "128558148058480640",
  "text" : "RT @screek: Who got rescued on the Mass Turnpike? An owl, that\u2019s who http:\/\/t.co\/qY3hcHNX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/qY3hcHNX",
        "expanded_url" : "http:\/\/bo.st\/stCoq7",
        "display_url" : "bo.st\/stCoq7"
      } ]
    },
    "geo" : { },
    "id_str" : "128555616213024769",
    "text" : "Who got rescued on the Mass Turnpike? An owl, that\u2019s who http:\/\/t.co\/qY3hcHNX",
    "id" : 128555616213024769,
    "created_at" : "2011-10-24 19:37:02 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 128558148058480640,
  "created_at" : "2011-10-24 19:47:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/E4CppTcv",
      "expanded_url" : "http:\/\/bit.ly\/sVhwlt",
      "display_url" : "bit.ly\/sVhwlt"
    } ]
  },
  "geo" : { },
  "id_str" : "128537879503847424",
  "text" : "about the word biblical and about what it might mean. http:\/\/t.co\/E4CppTcv",
  "id" : 128537879503847424,
  "created_at" : "2011-10-24 18:26:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 0, 11 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128528331732828161",
  "geo" : { },
  "id_str" : "128530344558329857",
  "in_reply_to_user_id" : 2772041,
  "text" : "@adampknave good to hear. bog smooches for sweet kitty.",
  "id" : 128530344558329857,
  "in_reply_to_status_id" : 128528331732828161,
  "created_at" : "2011-10-24 17:56:36 +0000",
  "in_reply_to_screen_name" : "adampknave",
  "in_reply_to_user_id_str" : "2772041",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128523664730750976",
  "text" : "RT @mssuzcatsilver: To whom it may concern, I knw u r feeling crap & that it seems u have is nothing to look forward to anytime soon, bu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "now",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128520146330451968",
    "text" : "To whom it may concern, I knw u r feeling crap & that it seems u have is nothing to look forward to anytime soon, but hang on in there #now",
    "id" : 128520146330451968,
    "created_at" : "2011-10-24 17:16:05 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 128523664730750976,
  "created_at" : "2011-10-24 17:30:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128523596468465665",
  "text" : "RT @mssuzcatsilver: What u resist persists.... accept any negative emotion, give yrself permission to feel it, bless it & let it go with ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "freedom",
        "indices" : [ 122, 130 ]
      }, {
        "text" : "suzcat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128520443048112128",
    "text" : "What u resist persists.... accept any negative emotion, give yrself permission to feel it, bless it & let it go with love #freedom #suzcat",
    "id" : 128520443048112128,
    "created_at" : "2011-10-24 17:17:16 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 128523596468465665,
  "created_at" : "2011-10-24 17:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "meme-meme",
      "screen_name" : "memememeorg",
      "indices" : [ 51, 63 ],
      "id_str" : "79210034",
      "id" : 79210034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/oPtzfgKK",
      "expanded_url" : "http:\/\/meme-meme.org\/post\/11842914127\/10-myths-about-introverts",
      "display_url" : "meme-meme.org\/post\/118429141\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128505993666625537",
  "text" : "10 Myths about introverts http:\/\/t.co\/oPtzfgKK via @memememeorg",
  "id" : 128505993666625537,
  "created_at" : "2011-10-24 16:19:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. SunWolf",
      "screen_name" : "WordWhispers",
      "indices" : [ 3, 16 ],
      "id_str" : "37977732",
      "id" : 37977732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128503942257721344",
  "text" : "RT @WordWhispers: Believing in even the possibility of a happy ending is a very powerful thing.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128316186143367168",
    "text" : "Believing in even the possibility of a happy ending is a very powerful thing.",
    "id" : 128316186143367168,
    "created_at" : "2011-10-24 03:45:37 +0000",
    "user" : {
      "name" : "Dr. SunWolf",
      "screen_name" : "WordWhispers",
      "protected" : false,
      "id_str" : "37977732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/650095326469095424\/ja2Vnm-5_normal.jpg",
      "id" : 37977732,
      "verified" : false
    }
  },
  "id" : 128503942257721344,
  "created_at" : "2011-10-24 16:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SciFi",
      "indices" : [ 33, 39 ]
    }, {
      "text" : "Kindle",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "Nook",
      "indices" : [ 59, 64 ]
    }, {
      "text" : "eBooks",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "RT",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/SIQW9O3e",
      "expanded_url" : "http:\/\/bit.ly\/q24Lx2",
      "display_url" : "bit.ly\/q24Lx2"
    } ]
  },
  "geo" : { },
  "id_str" : "128503550128033793",
  "text" : "RT @KreelanWarrior: Get a 5-star #SciFi novel for #Kindle, #Nook and other #eBooks *free*, no strings attached! http:\/\/t.co\/SIQW9O3e #RT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SciFi",
        "indices" : [ 13, 19 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 30, 37 ]
      }, {
        "text" : "Nook",
        "indices" : [ 39, 44 ]
      }, {
        "text" : "eBooks",
        "indices" : [ 55, 62 ]
      }, {
        "text" : "RT",
        "indices" : [ 113, 116 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/SIQW9O3e",
        "expanded_url" : "http:\/\/bit.ly\/q24Lx2",
        "display_url" : "bit.ly\/q24Lx2"
      } ]
    },
    "geo" : { },
    "id_str" : "128495476185108480",
    "text" : "Get a 5-star #SciFi novel for #Kindle, #Nook and other #eBooks *free*, no strings attached! http:\/\/t.co\/SIQW9O3e #RT",
    "id" : 128495476185108480,
    "created_at" : "2011-10-24 15:38:03 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 128503550128033793,
  "created_at" : "2011-10-24 16:10:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 9, 23 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128492335448326145",
  "geo" : { },
  "id_str" : "128498753899466753",
  "in_reply_to_user_id" : 16901470,
  "text" : "aww, lol @johnnie_cakes we have a couple possums visit our back porch for the cat food. they take off when they see us peeking at them.",
  "id" : 128498753899466753,
  "in_reply_to_status_id" : 128492335448326145,
  "created_at" : "2011-10-24 15:51:04 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128485625606324226",
  "text" : "RT @LSFProgram: Negativity is a product of our own mind as a result of stress. It does not ultimately exist.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128484384201379840",
    "text" : "Negativity is a product of our own mind as a result of stress. It does not ultimately exist.",
    "id" : 128484384201379840,
    "created_at" : "2011-10-24 14:53:58 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 128485625606324226,
  "created_at" : "2011-10-24 14:58:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128485527589621761",
  "text" : "RT @Buddhaworld: if you want to understand life stop  believing what people say or write, observe and think for yourself. Buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128484656080355328",
    "text" : "if you want to understand life stop  believing what people say or write, observe and think for yourself. Buddha volko",
    "id" : 128484656080355328,
    "created_at" : "2011-10-24 14:55:03 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 128485527589621761,
  "created_at" : "2011-10-24 14:58:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 9, 20 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128474332883193857",
  "geo" : { },
  "id_str" : "128475653644365824",
  "in_reply_to_user_id" : 2772041,
  "text" : "((hugs)) @adampknave I hope you get more time w her",
  "id" : 128475653644365824,
  "in_reply_to_status_id" : 128474332883193857,
  "created_at" : "2011-10-24 14:19:17 +0000",
  "in_reply_to_screen_name" : "adampknave",
  "in_reply_to_user_id_str" : "2772041",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/W5FZdtBP",
      "expanded_url" : "http:\/\/www.psychologytoday.com\/collections\/201110\/are-you-really-open-minded",
      "display_url" : "psychologytoday.com\/collections\/20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "128472694760030209",
  "text" : "RT @howtobesick: Thanks to PT for featuring my piece on non-judgment Are You Really Open-Minded? | Psychology Today http:\/\/t.co\/W5FZdtBP ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mindfulness",
        "indices" : [ 120, 132 ]
      }, {
        "text" : "Buddha",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/W5FZdtBP",
        "expanded_url" : "http:\/\/www.psychologytoday.com\/collections\/201110\/are-you-really-open-minded",
        "display_url" : "psychologytoday.com\/collections\/20\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "128471415371472898",
    "text" : "Thanks to PT for featuring my piece on non-judgment Are You Really Open-Minded? | Psychology Today http:\/\/t.co\/W5FZdtBP #mindfulness #Buddha",
    "id" : 128471415371472898,
    "created_at" : "2011-10-24 14:02:26 +0000",
    "user" : {
      "name" : "Toni Bernhard",
      "screen_name" : "toni_bernhard",
      "protected" : false,
      "id_str" : "169982819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759869867449196544\/dEV7yImo_normal.jpg",
      "id" : 169982819,
      "verified" : false
    }
  },
  "id" : 128472694760030209,
  "created_at" : "2011-10-24 14:07:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128238453765836800",
  "text" : "RT @TheEntertainer: If you're NOT moving towards YOUR dream at least a little EVERY day, it's like giving the finger to the Universe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128237173089640448",
    "text" : "If you're NOT moving towards YOUR dream at least a little EVERY day, it's like giving the finger to the Universe",
    "id" : 128237173089640448,
    "created_at" : "2011-10-23 22:31:39 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 128238453765836800,
  "created_at" : "2011-10-23 22:36:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "indices" : [ 3, 17 ],
      "id_str" : "183854047",
      "id" : 183854047
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128218479936544770",
  "text" : "RT @CatFoodBreath: Cats:  If you don't have a couch, consider Occupying the Windowsill, Chair, or nearest Squishy Lap in support of the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupythecouch",
        "indices" : [ 125, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128216164269690880",
    "text" : "Cats:  If you don't have a couch, consider Occupying the Windowsill, Chair, or nearest Squishy Lap in support of the cause.  #occupythecouch",
    "id" : 128216164269690880,
    "created_at" : "2011-10-23 21:08:10 +0000",
    "user" : {
      "name" : "Cat Food Breath",
      "screen_name" : "CatFoodBreath",
      "protected" : false,
      "id_str" : "183854047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1112259384\/birman_normal.jpg",
      "id" : 183854047,
      "verified" : false
    }
  },
  "id" : 128218479936544770,
  "created_at" : "2011-10-23 21:17:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/Y9mjQ3ZE",
      "expanded_url" : "http:\/\/wordpress.com",
      "display_url" : "wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "128216204753117185",
  "text" : "so I cant change blog address of http:\/\/t.co\/Y9mjQ3ZE blog? sigh...",
  "id" : 128216204753117185,
  "created_at" : "2011-10-23 21:08:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 0, 13 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128212532723859456",
  "geo" : { },
  "id_str" : "128213315628445696",
  "in_reply_to_user_id" : 124594428,
  "text" : "@golden_books LOL : )",
  "id" : 128213315628445696,
  "in_reply_to_status_id" : 128212532723859456,
  "created_at" : "2011-10-23 20:56:51 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OWS",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/Qr78PKZ6",
      "expanded_url" : "http:\/\/bit.ly\/pTtxSu",
      "display_url" : "bit.ly\/pTtxSu"
    } ]
  },
  "geo" : { },
  "id_str" : "128213021418983424",
  "text" : "The Infamous Brad - Nobody Will Ever Believe How We Got Here #OWS http:\/\/t.co\/Qr78PKZ6",
  "id" : 128213021418983424,
  "created_at" : "2011-10-23 20:55:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128212360040169472",
  "text" : "I would like to get an RV and travel the US visiting my twitter friends. Meet those great minds, kind hearts.",
  "id" : 128212360040169472,
  "created_at" : "2011-10-23 20:53:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128209889590919168",
  "geo" : { },
  "id_str" : "128210549715644416",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts lol.. you always know how to lift me up ((hugs))",
  "id" : 128210549715644416,
  "in_reply_to_status_id" : 128209889590919168,
  "created_at" : "2011-10-23 20:45:51 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128204142048051201",
  "text" : "I have been told Im a new soul. I think Im just failing at this whole human thing. You can bet Im not doing this again. blah!",
  "id" : 128204142048051201,
  "created_at" : "2011-10-23 20:20:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128198489371979779",
  "text" : "so I guess I cant transfer my G+ account to a different gmail account?",
  "id" : 128198489371979779,
  "created_at" : "2011-10-23 19:57:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128196984250175489",
  "text" : "its 2011 and we cant just transfer stuff from one email to another... wth?",
  "id" : 128196984250175489,
  "created_at" : "2011-10-23 19:51:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128195537919934464",
  "text" : "im soooo bored im creating my own issues. dropping abfabgab and changing everything is gonna be a LOT of work.",
  "id" : 128195537919934464,
  "created_at" : "2011-10-23 19:46:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christi Bowman",
      "screen_name" : "fastingfoody",
      "indices" : [ 0, 13 ],
      "id_str" : "199743576",
      "id" : 199743576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128195173585911809",
  "in_reply_to_user_id" : 199743576,
  "text" : "@fastingfoody ((hugs)) and no, not fair. You should get leniency.",
  "id" : 128195173585911809,
  "created_at" : "2011-10-23 19:44:45 +0000",
  "in_reply_to_screen_name" : "fastingfoody",
  "in_reply_to_user_id_str" : "199743576",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christi Bowman",
      "screen_name" : "fastingfoody",
      "indices" : [ 3, 16 ],
      "id_str" : "199743576",
      "id" : 199743576
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128194396595298304",
  "text" : "RT @fastingfoody: It's not black white... Cuz nothing ever is... You know?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128192339796701184",
    "text" : "It's not black white... Cuz nothing ever is... You know?",
    "id" : 128192339796701184,
    "created_at" : "2011-10-23 19:33:30 +0000",
    "user" : {
      "name" : "Christi Bowman",
      "screen_name" : "fastingfoody",
      "protected" : false,
      "id_str" : "199743576",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1499337090\/fastingfoody_normal.jpg",
      "id" : 199743576,
      "verified" : false
    }
  },
  "id" : 128194396595298304,
  "created_at" : "2011-10-23 19:41:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128169257916841985",
  "text" : "so no comments, eh? fine.. be that way ((sulking))",
  "id" : 128169257916841985,
  "created_at" : "2011-10-23 18:01:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128150483096444928",
  "text" : "then I'll need a bunch o' new profiles, new domain, new email.",
  "id" : 128150483096444928,
  "created_at" : "2011-10-23 16:47:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128149691404783616",
  "text" : "there are other abfabgab's out there that are not me. think I need a new ID. bleh.",
  "id" : 128149691404783616,
  "created_at" : "2011-10-23 16:44:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/h84EBWen",
      "expanded_url" : "http:\/\/livingstressfreeprogram.blogspot.com\/",
      "display_url" : "livingstressfreeprogram.blogspot.com"
    } ]
  },
  "geo" : { },
  "id_str" : "128143450901192704",
  "text" : "RT @LSFProgram: Marilyn and Lou invite you to their blog: http:\/\/t.co\/h84EBWen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 42, 62 ],
        "url" : "http:\/\/t.co\/h84EBWen",
        "expanded_url" : "http:\/\/livingstressfreeprogram.blogspot.com\/",
        "display_url" : "livingstressfreeprogram.blogspot.com"
      } ]
    },
    "geo" : { },
    "id_str" : "128143004459470848",
    "text" : "Marilyn and Lou invite you to their blog: http:\/\/t.co\/h84EBWen",
    "id" : 128143004459470848,
    "created_at" : "2011-10-23 16:17:27 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 128143450901192704,
  "created_at" : "2011-10-23 16:19:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "indices" : [ 3, 8 ],
      "id_str" : "18957524",
      "id" : 18957524
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128141727860129792",
  "text" : "RT @Syfy: The American audience is also much less accepting of sex\/nudity on TV. Interestingly, in other countries sex is okay but gore  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128141218633887744",
    "text" : "The American audience is also much less accepting of sex\/nudity on TV. Interestingly, in other countries sex is okay but gore isn't.",
    "id" : 128141218633887744,
    "created_at" : "2011-10-23 16:10:21 +0000",
    "user" : {
      "name" : "Syfy",
      "screen_name" : "Syfy",
      "protected" : false,
      "id_str" : "18957524",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793455496611172352\/4ntFcBSF_normal.jpg",
      "id" : 18957524,
      "verified" : true
    }
  },
  "id" : 128141727860129792,
  "created_at" : "2011-10-23 16:12:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128138508173983744",
  "text" : "choose the better feeling. keep reaching higher.",
  "id" : 128138508173983744,
  "created_at" : "2011-10-23 15:59:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    }, {
      "name" : "Charlie_O",
      "screen_name" : "Charlie_O",
      "indices" : [ 18, 28 ],
      "id_str" : "16122907",
      "id" : 16122907
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 30, 40 ],
      "id_str" : "75137401",
      "id" : 75137401
    }, {
      "name" : "The Guardian",
      "screen_name" : "guardian",
      "indices" : [ 41, 50 ],
      "id_str" : "87818409",
      "id" : 87818409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128138296151900161",
  "text" : "RT @JALpalyul: RT @Charlie_O: @JALpalyul @guardian Again the state asks \"How can we punish this person?\" when it should ask, \"How can we ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charlie_O",
        "screen_name" : "Charlie_O",
        "indices" : [ 3, 13 ],
        "id_str" : "16122907",
        "id" : 16122907
      }, {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 15, 25 ],
        "id_str" : "75137401",
        "id" : 75137401
      }, {
        "name" : "The Guardian",
        "screen_name" : "guardian",
        "indices" : [ 26, 35 ],
        "id_str" : "87818409",
        "id" : 87818409
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128137922632351744",
    "text" : "RT @Charlie_O: @JALpalyul @guardian Again the state asks \"How can we punish this person?\" when it should ask, \"How can we help this person?\"",
    "id" : 128137922632351744,
    "created_at" : "2011-10-23 15:57:16 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 128138296151900161,
  "created_at" : "2011-10-23 15:58:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 5, 15 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "128132199387111424",
  "geo" : { },
  "id_str" : "128132817673658369",
  "in_reply_to_user_id" : 16181537,
  "text" : "ha.. @ZachsMind I knew there was a reason I liked you!",
  "id" : 128132817673658369,
  "in_reply_to_status_id" : 128132199387111424,
  "created_at" : "2011-10-23 15:36:58 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesus Christ Show",
      "screen_name" : "JesusShow",
      "indices" : [ 3, 13 ],
      "id_str" : "25402790",
      "id" : 25402790
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128132474114023424",
  "text" : "RT @JesusShow: Don't harbor unforgiveness...it only hurts you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128128948952502272",
    "text" : "Don't harbor unforgiveness...it only hurts you.",
    "id" : 128128948952502272,
    "created_at" : "2011-10-23 15:21:36 +0000",
    "user" : {
      "name" : "Jesus Christ Show",
      "screen_name" : "JesusShow",
      "protected" : false,
      "id_str" : "25402790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/298355119\/JesusHand2_normal.jpg",
      "id" : 25402790,
      "verified" : false
    }
  },
  "id" : 128132474114023424,
  "created_at" : "2011-10-23 15:35:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "problem",
      "indices" : [ 74, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128132379234672641",
  "text" : "RT @Buddhaworld: the problem is, there is no problem and thats a really a #problem. Buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "problem",
        "indices" : [ 57, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128130073785139201",
    "text" : "the problem is, there is no problem and thats a really a #problem. Buddha volko.",
    "id" : 128130073785139201,
    "created_at" : "2011-10-23 15:26:04 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 128132379234672641,
  "created_at" : "2011-10-23 15:35:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "128129648151379968",
  "text" : "RT @GraveStomper: Just for today: help one person, who isn't you, to see their own gifts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "128122914225651712",
    "text" : "Just for today: help one person, who isn't you, to see their own gifts.",
    "id" : 128122914225651712,
    "created_at" : "2011-10-23 14:57:37 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 128129648151379968,
  "created_at" : "2011-10-23 15:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Barnett",
      "screen_name" : "planomike",
      "indices" : [ 3, 13 ],
      "id_str" : "22770373",
      "id" : 22770373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127927139071836160",
  "text" : "RT @planomike: Scientists are peeping toms at the keyhole of eternity. \n-Arthur Koestler",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127926588632334336",
    "text" : "Scientists are peeping toms at the keyhole of eternity. \n-Arthur Koestler",
    "id" : 127926588632334336,
    "created_at" : "2011-10-23 01:57:30 +0000",
    "user" : {
      "name" : "Michael Barnett",
      "screen_name" : "planomike",
      "protected" : false,
      "id_str" : "22770373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1201244218\/MichaelBarnett_normal.jpg",
      "id" : 22770373,
      "verified" : false
    }
  },
  "id" : 127927139071836160,
  "created_at" : "2011-10-23 01:59:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127926127862874112",
  "text" : "have to remember not to fall into fear mode.. I cant save the world if I do..",
  "id" : 127926127862874112,
  "created_at" : "2011-10-23 01:55:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Nickole Rinde",
      "screen_name" : "dragonweasle",
      "indices" : [ 16, 29 ],
      "id_str" : "24480551",
      "id" : 24480551
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/Mw4GNiBq",
      "expanded_url" : "http:\/\/bit.ly\/njuP1M",
      "display_url" : "bit.ly\/njuP1M"
    } ]
  },
  "geo" : { },
  "id_str" : "127917009957695489",
  "text" : "RT @SangyeH: RT @dragonweasle: Our guest for the evening ;Meet Mr.(or Mrs.)Elf owl;yes,he's full grown! http:\/\/t.co\/Mw4GNiBq  |\\ So cute!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nickole Rinde",
        "screen_name" : "dragonweasle",
        "indices" : [ 3, 16 ],
        "id_str" : "24480551",
        "id" : 24480551
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 111 ],
        "url" : "http:\/\/t.co\/Mw4GNiBq",
        "expanded_url" : "http:\/\/bit.ly\/njuP1M",
        "display_url" : "bit.ly\/njuP1M"
      } ]
    },
    "geo" : { },
    "id_str" : "127916627420393472",
    "text" : "RT @dragonweasle: Our guest for the evening ;Meet Mr.(or Mrs.)Elf owl;yes,he's full grown! http:\/\/t.co\/Mw4GNiBq  |\\ So cute!",
    "id" : 127916627420393472,
    "created_at" : "2011-10-23 01:17:55 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 127917009957695489,
  "created_at" : "2011-10-23 01:19:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127910975654473728",
  "text" : "RT @parkstepp: \"I mourn the loss of thousands of precious lives, but I will not rejoice in the death of one, not even...\" http:\/\/t.co\/ur ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/urMPolEd",
        "expanded_url" : "http:\/\/tumblr.com\/ZwrrNyA-7luc",
        "display_url" : "tumblr.com\/ZwrrNyA-7luc"
      } ]
    },
    "geo" : { },
    "id_str" : "127906382249857024",
    "text" : "\"I mourn the loss of thousands of precious lives, but I will not rejoice in the death of one, not even...\" http:\/\/t.co\/urMPolEd",
    "id" : 127906382249857024,
    "created_at" : "2011-10-23 00:37:12 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 127910975654473728,
  "created_at" : "2011-10-23 00:55:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/0CV0qZ92",
      "expanded_url" : "http:\/\/yfrog.com\/nxjbvqj",
      "display_url" : "yfrog.com\/nxjbvqj"
    } ]
  },
  "geo" : { },
  "id_str" : "127898386455199744",
  "text" : "Nice! RT @SamsaricWarrior: Where i come to clear my head. _\/|\\_  http:\/\/t.co\/0CV0qZ92",
  "id" : 127898386455199744,
  "created_at" : "2011-10-23 00:05:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 4, 16 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/UzUVKD4p",
      "expanded_url" : "http:\/\/tl.gd\/dp4fld",
      "display_url" : "tl.gd\/dp4fld"
    } ]
  },
  "geo" : { },
  "id_str" : "127889924417523714",
  "text" : "hmm @VirgoJohnny so it seems perhaps you are getting some of your esteem from this discourse w him.\n\nHe's (cont) http:\/\/t.co\/UzUVKD4p",
  "id" : 127889924417523714,
  "created_at" : "2011-10-22 23:31:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127886246608506880",
  "geo" : { },
  "id_str" : "127887813344636928",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad oh no! hope you are feeling better. ((hugs))",
  "id" : 127887813344636928,
  "in_reply_to_status_id" : 127886246608506880,
  "created_at" : "2011-10-22 23:23:25 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Keith Frankish",
      "screen_name" : "keithfrankish",
      "indices" : [ 3, 17 ],
      "id_str" : "52522040",
      "id" : 52522040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127882620456550400",
  "text" : "RT @keithfrankish: Few ppl change their minds in response to rational argument. If a person agrees w\/ you, argument is redundant; if the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127788140378324992",
    "text" : "Few ppl change their minds in response to rational argument. If a person agrees w\/ you, argument is redundant; if they don't it's futile.",
    "id" : 127788140378324992,
    "created_at" : "2011-10-22 16:47:21 +0000",
    "user" : {
      "name" : "Keith Frankish",
      "screen_name" : "keithfrankish",
      "protected" : false,
      "id_str" : "52522040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/550984261042327552\/yI7pBVTG_normal.jpeg",
      "id" : 52522040,
      "verified" : false
    }
  },
  "id" : 127882620456550400,
  "created_at" : "2011-10-22 23:02:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127875432220598273",
  "geo" : { },
  "id_str" : "127878478820417536",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny I don't know why you bother with this person. His self esteem is so entangled into his belief system.",
  "id" : 127878478820417536,
  "in_reply_to_status_id" : 127875432220598273,
  "created_at" : "2011-10-22 22:46:19 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127873817266761729",
  "text" : "had nice day at in-laws for nephews bday. pizza & ice cream cake. poor hubs stayed home, tho, ill w headache.",
  "id" : 127873817266761729,
  "created_at" : "2011-10-22 22:27:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127873177572483072",
  "text" : "@tragic_pizza always nice to see you in my stream, sir! : )",
  "id" : 127873177572483072,
  "created_at" : "2011-10-22 22:25:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127871379621167104",
  "geo" : { },
  "id_str" : "127872883094597632",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench heehee.. my lips are zipped! : )",
  "id" : 127872883094597632,
  "in_reply_to_status_id" : 127871379621167104,
  "created_at" : "2011-10-22 22:24:05 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127871191733121024",
  "text" : "Hello!",
  "id" : 127871191733121024,
  "created_at" : "2011-10-22 22:17:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/9ZgZkT2Z",
      "expanded_url" : "http:\/\/LivingStressFree.org\/?l=t&pageStewardLink=8027",
      "display_url" : "LivingStressFree.org\/?l=t&pageStewa\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127785321290137600",
  "text" : "RT @LSFProgram: Lou and I would love to help you! Contact us: http:\/\/t.co\/9ZgZkT2Z",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/9ZgZkT2Z",
        "expanded_url" : "http:\/\/LivingStressFree.org\/?l=t&pageStewardLink=8027",
        "display_url" : "LivingStressFree.org\/?l=t&pageStewa\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "127784833173831680",
    "text" : "Lou and I would love to help you! Contact us: http:\/\/t.co\/9ZgZkT2Z",
    "id" : 127784833173831680,
    "created_at" : "2011-10-22 16:34:13 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 127785321290137600,
  "created_at" : "2011-10-22 16:36:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127784871941779456",
  "text" : "RT @TheGodLight: Things are not always as bad as you think, if you step back, you will see there is more to any situation than meets the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127784290435088384",
    "text" : "Things are not always as bad as you think, if you step back, you will see there is more to any situation than meets the eye.",
    "id" : 127784290435088384,
    "created_at" : "2011-10-22 16:32:03 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 127784871941779456,
  "created_at" : "2011-10-22 16:34:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "indices" : [ 3, 16 ],
      "id_str" : "41965454",
      "id" : 41965454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127772399478378496",
  "text" : "RT @manzano_moon: Who are all these ignorant people cheering during the repub debates? Who ARE they? Are they being paid to do that or a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127772142568882176",
    "text" : "Who are all these ignorant people cheering during the repub debates? Who ARE they? Are they being paid to do that or are they real people?",
    "id" : 127772142568882176,
    "created_at" : "2011-10-22 15:43:47 +0000",
    "user" : {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "protected" : false,
      "id_str" : "41965454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/284181707\/IMG_5039_normal.JPG",
      "id" : 41965454,
      "verified" : false
    }
  },
  "id" : 127772399478378496,
  "created_at" : "2011-10-22 15:44:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127771372419162112",
  "text" : "@animalswisdom we have crows in our yard. I love to see & hear them. I caw back. (they prob think WTH is she saying?? lol)",
  "id" : 127771372419162112,
  "created_at" : "2011-10-22 15:40:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "indices" : [ 3, 16 ],
      "id_str" : "41965454",
      "id" : 41965454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127771001839828992",
  "text" : "RT @manzano_moon: Twitter should have a like button!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127770380323651584",
    "text" : "Twitter should have a like button!!!!",
    "id" : 127770380323651584,
    "created_at" : "2011-10-22 15:36:47 +0000",
    "user" : {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "protected" : false,
      "id_str" : "41965454",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/284181707\/IMG_5039_normal.JPG",
      "id" : 41965454,
      "verified" : false
    }
  },
  "id" : 127771001839828992,
  "created_at" : "2011-10-22 15:39:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127770160986718210",
  "geo" : { },
  "id_str" : "127770915000954881",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench awww! sp = special person? spouse?",
  "id" : 127770915000954881,
  "in_reply_to_status_id" : 127770160986718210,
  "created_at" : "2011-10-22 15:38:54 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127769644500123648",
  "geo" : { },
  "id_str" : "127770615418585088",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench think your right.. I RT a lot and forget to tweet my own",
  "id" : 127770615418585088,
  "in_reply_to_status_id" : 127769644500123648,
  "created_at" : "2011-10-22 15:37:43 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "indices" : [ 0, 13 ],
      "id_str" : "41965454",
      "id" : 41965454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127769219336126464",
  "geo" : { },
  "id_str" : "127770414524018690",
  "in_reply_to_user_id" : 41965454,
  "text" : "@manzano_moon no, but been reading about them in tweets..lol",
  "id" : 127770414524018690,
  "in_reply_to_status_id" : 127769219336126464,
  "created_at" : "2011-10-22 15:36:55 +0000",
  "in_reply_to_screen_name" : "manzano_moon",
  "in_reply_to_user_id_str" : "41965454",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127770089545142275",
  "text" : "@animalswisdom luuuuuucky!",
  "id" : 127770089545142275,
  "created_at" : "2011-10-22 15:35:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 23, 43 ],
      "url" : "http:\/\/t.co\/PT274fmt",
      "expanded_url" : "http:\/\/on.fb.me\/mZ5DHg",
      "display_url" : "on.fb.me\/mZ5DHg"
    } ]
  },
  "geo" : { },
  "id_str" : "127769864118087680",
  "text" : "animal \/ moose lovers: http:\/\/t.co\/PT274fmt - send David a card",
  "id" : 127769864118087680,
  "created_at" : "2011-10-22 15:34:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ann Bruner",
      "screen_name" : "manzano_moon",
      "indices" : [ 0, 13 ],
      "id_str" : "41965454",
      "id" : 41965454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127768446627885058",
  "geo" : { },
  "id_str" : "127768924489121792",
  "in_reply_to_user_id" : 41965454,
  "text" : "@manzano_moon goofy? haha.. I like goofy : )",
  "id" : 127768924489121792,
  "in_reply_to_status_id" : 127768446627885058,
  "created_at" : "2011-10-22 15:31:00 +0000",
  "in_reply_to_screen_name" : "manzano_moon",
  "in_reply_to_user_id_str" : "41965454",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127768691705253888",
  "text" : "what can I say to rile ppl up? ; )",
  "id" : 127768691705253888,
  "created_at" : "2011-10-22 15:30:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127767872478003201",
  "text" : "perhaps I should post more political, religious to get more ppl to talk to me.. hmm..",
  "id" : 127767872478003201,
  "created_at" : "2011-10-22 15:26:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl Barbarotto",
      "screen_name" : "Carlolight",
      "indices" : [ 3, 14 ],
      "id_str" : "146324614",
      "id" : 146324614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127765765351931905",
  "text" : "RT @Carlolight: The important thing is not to think much, but to love much. - St.Theresa of Avila",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127723393515651072",
    "text" : "The important thing is not to think much, but to love much. - St.Theresa of Avila",
    "id" : 127723393515651072,
    "created_at" : "2011-10-22 12:30:04 +0000",
    "user" : {
      "name" : "Carl Barbarotto",
      "screen_name" : "Carlolight",
      "protected" : false,
      "id_str" : "146324614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356639079\/Twitterwestern_sky_1_normal.jpg",
      "id" : 146324614,
      "verified" : false
    }
  },
  "id" : 127765765351931905,
  "created_at" : "2011-10-22 15:18:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : ".",
      "screen_name" : "thehomiesantini",
      "indices" : [ 3, 19 ],
      "id_str" : "48522781",
      "id" : 48522781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127765335179927552",
  "text" : "RT @theHomieSantini: \"Everything that irritates us about others can lead us to an understanding of ourselves.\" ~Carl Jung",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125983677242015744",
    "text" : "\"Everything that irritates us about others can lead us to an understanding of ourselves.\" ~Carl Jung",
    "id" : 125983677242015744,
    "created_at" : "2011-10-17 17:17:03 +0000",
    "user" : {
      "name" : "Scorptini",
      "screen_name" : "SantiniHoudini",
      "protected" : false,
      "id_str" : "121027109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796225557788659712\/_2bi8kML_normal.jpg",
      "id" : 121027109,
      "verified" : false
    }
  },
  "id" : 127765335179927552,
  "created_at" : "2011-10-22 15:16:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "indices" : [ 98, 114 ],
      "id_str" : "95607516",
      "id" : 95607516
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prpumpkinoff",
      "indices" : [ 18, 31 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/KIcpRvwr",
      "expanded_url" : "http:\/\/bit.ly\/pndEe9",
      "display_url" : "bit.ly\/pndEe9"
    } ]
  },
  "geo" : { },
  "id_str" : "127764790117539841",
  "text" : "RT your favourite #prpumpkinoff entry. Halloween donkey event... on Twitpic: http:\/\/t.co\/KIcpRvwr @DonkeySanctuary",
  "id" : 127764790117539841,
  "created_at" : "2011-10-22 15:14:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127763820050518016",
  "text" : "RT @DharmaTalks: Above the fog, above the clouds is the pure warm loving light. It never went away it is always there.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127763673497337856",
    "text" : "Above the fog, above the clouds is the pure warm loving light. It never went away it is always there.",
    "id" : 127763673497337856,
    "created_at" : "2011-10-22 15:10:08 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 127763820050518016,
  "created_at" : "2011-10-22 15:10:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127754901303463936",
  "text" : "bleh.. sore throat today.",
  "id" : 127754901303463936,
  "created_at" : "2011-10-22 14:35:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127741410500812800",
  "geo" : { },
  "id_str" : "127753306125770752",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time I like the candy...",
  "id" : 127753306125770752,
  "in_reply_to_status_id" : 127741410500812800,
  "created_at" : "2011-10-22 14:28:56 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127744050106335232",
  "geo" : { },
  "id_str" : "127753055587405824",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time ha, me, too!",
  "id" : 127753055587405824,
  "in_reply_to_status_id" : 127744050106335232,
  "created_at" : "2011-10-22 14:27:56 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheist",
      "indices" : [ 132, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127541569862639616",
  "text" : "RT @ZachsMind: I'll tell you this tho when I get to The Pearly Gates, I'll complain to Peter about the terrible customer service... #atheist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheist",
        "indices" : [ 117, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127540112652369920",
    "text" : "I'll tell you this tho when I get to The Pearly Gates, I'll complain to Peter about the terrible customer service... #atheist",
    "id" : 127540112652369920,
    "created_at" : "2011-10-22 00:21:47 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 127541569862639616,
  "created_at" : "2011-10-22 00:27:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 27, 37 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127539378317824001",
  "geo" : { },
  "id_str" : "127541301385236480",
  "in_reply_to_user_id" : 16181537,
  "text" : "raptured against your will @ZachsMind ..lol.. I like that one!",
  "id" : 127541301385236480,
  "in_reply_to_status_id" : 127539378317824001,
  "created_at" : "2011-10-22 00:26:30 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127541038905696256",
  "text" : "RT @ZachsMind: I also have Believers praying for me to go when the Rapture happens whether i wanna go or not so I'll be Raptured against ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheist",
        "indices" : [ 131, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127539378317824001",
    "text" : "I also have Believers praying for me to go when the Rapture happens whether i wanna go or not so I'll be Raptured against my will. #atheist",
    "id" : 127539378317824001,
    "created_at" : "2011-10-22 00:18:52 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 127541038905696256,
  "created_at" : "2011-10-22 00:25:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 0, 15 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127482347779133440",
  "geo" : { },
  "id_str" : "127484814189268992",
  "in_reply_to_user_id" : 104029814,
  "text" : "@stream_enterer yes I am",
  "id" : 127484814189268992,
  "in_reply_to_status_id" : 127482347779133440,
  "created_at" : "2011-10-21 20:42:02 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/GKs3DBIj",
      "expanded_url" : "http:\/\/bit.ly\/q5Vcbo",
      "display_url" : "bit.ly\/q5Vcbo"
    } ]
  },
  "geo" : { },
  "id_str" : "127467037294473216",
  "text" : "TONIGHT - ATA Martial Arts Invitational 7pm EST Fri. Oct 21 http:\/\/t.co\/GKs3DBIj",
  "id" : 127467037294473216,
  "created_at" : "2011-10-21 19:31:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/1MtlcgBE",
      "expanded_url" : "http:\/\/bit.ly\/r9hzYD",
      "display_url" : "bit.ly\/r9hzYD"
    } ]
  },
  "geo" : { },
  "id_str" : "127466502403272704",
  "text" : "Dad, instead of Mom, made contact after death (Hey Mom, we had a deal! lol) http:\/\/t.co\/1MtlcgBE - see RV report",
  "id" : 127466502403272704,
  "created_at" : "2011-10-21 19:29:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 9, 29 ],
      "url" : "http:\/\/t.co\/T2IT1niJ",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "127465650582069248",
  "text" : "my blog: http:\/\/t.co\/T2IT1niJ",
  "id" : 127465650582069248,
  "created_at" : "2011-10-21 19:25:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127463143692713984",
  "text" : "RT @stream_enterer: Hugs goes out to everyone! Yes, even those you might not think deserves it \u2014 because they most of all need it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127461625535021057",
    "text" : "Hugs goes out to everyone! Yes, even those you might not think deserves it \u2014 because they most of all need it.",
    "id" : 127461625535021057,
    "created_at" : "2011-10-21 19:09:54 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 127463143692713984,
  "created_at" : "2011-10-21 19:15:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 10, 25 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127443060228493312",
  "text" : "Always RT @richarddoetsch: \u265EWhen someone does their basic job that they are paid for should they be praised?",
  "id" : 127443060228493312,
  "created_at" : "2011-10-21 17:56:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "indices" : [ 3, 11 ],
      "id_str" : "20479813",
      "id" : 20479813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127440301144023040",
  "text" : "RT @MMFlint: Now that all the major killers of Americans r dead, I guess that means we can cut $500 billion from the Pentagon & spend it ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/orangatame.com\/products\/openbeak\/\" rel=\"nofollow\"\u003EOpenBeak\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127437059278381057",
    "text" : "Now that all the major killers of Americans r dead, I guess that means we can cut $500 billion from the Pentagon & spend it on schools?",
    "id" : 127437059278381057,
    "created_at" : "2011-10-21 17:32:17 +0000",
    "user" : {
      "name" : "Michael Moore",
      "screen_name" : "MMFlint",
      "protected" : false,
      "id_str" : "20479813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/440557378027520000\/DTvD2bbr_normal.jpeg",
      "id" : 20479813,
      "verified" : true
    }
  },
  "id" : 127440301144023040,
  "created_at" : "2011-10-21 17:45:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Williams",
      "screen_name" : "KWilliams1984",
      "indices" : [ 0, 14 ],
      "id_str" : "22653799",
      "id" : 22653799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127433668791762944",
  "geo" : { },
  "id_str" : "127439361095643136",
  "in_reply_to_user_id" : 22653799,
  "text" : "@KWilliams1984 dont think the cow would like that analogy ; )",
  "id" : 127439361095643136,
  "in_reply_to_status_id" : 127433668791762944,
  "created_at" : "2011-10-21 17:41:26 +0000",
  "in_reply_to_screen_name" : "KWilliams1984",
  "in_reply_to_user_id_str" : "22653799",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127438133863251968",
  "text" : "RT @bunnybuddhism: In bunniness, there is no place for blame.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127434606906585089",
    "text" : "In bunniness, there is no place for blame.",
    "id" : 127434606906585089,
    "created_at" : "2011-10-21 17:22:32 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 127438133863251968,
  "created_at" : "2011-10-21 17:36:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Kenny Williams",
      "screen_name" : "KWilliams1984",
      "indices" : [ 13, 27 ],
      "id_str" : "22653799",
      "id" : 22653799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127431007912730624",
  "geo" : { },
  "id_str" : "127431839760650241",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny @KWilliams1984 that's a compliment becuz animals are closer to Source than most humans...",
  "id" : 127431839760650241,
  "in_reply_to_status_id" : 127431007912730624,
  "created_at" : "2011-10-21 17:11:32 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 62 ],
      "url" : "http:\/\/t.co\/Nb2kmIUY",
      "expanded_url" : "http:\/\/goo.gl\/fb\/sfpDQ",
      "display_url" : "goo.gl\/fb\/sfpDQ"
    } ]
  },
  "geo" : { },
  "id_str" : "127428396534870016",
  "text" : "RT @DwayneReaves: Did I really hear that? http:\/\/t.co\/Nb2kmIUY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/Nb2kmIUY",
        "expanded_url" : "http:\/\/goo.gl\/fb\/sfpDQ",
        "display_url" : "goo.gl\/fb\/sfpDQ"
      } ]
    },
    "geo" : { },
    "id_str" : "127427365801426944",
    "text" : "Did I really hear that? http:\/\/t.co\/Nb2kmIUY",
    "id" : 127427365801426944,
    "created_at" : "2011-10-21 16:53:46 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 127428396534870016,
  "created_at" : "2011-10-21 16:57:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127424085843132416",
  "geo" : { },
  "id_str" : "127424721141772290",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench good luck",
  "id" : 127424721141772290,
  "in_reply_to_status_id" : 127424085843132416,
  "created_at" : "2011-10-21 16:43:15 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127423530114621440",
  "text" : "RT @oshum: When do observations turn into judgments?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127419858689343488",
    "text" : "When do observations turn into judgments?",
    "id" : 127419858689343488,
    "created_at" : "2011-10-21 16:23:56 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 127423530114621440,
  "created_at" : "2011-10-21 16:38:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 101, 121 ],
      "url" : "http:\/\/t.co\/6cvX3M0T",
      "expanded_url" : "http:\/\/ow.ly\/74dXs",
      "display_url" : "ow.ly\/74dXs"
    } ]
  },
  "geo" : { },
  "id_str" : "127415522810802176",
  "text" : "RT @CandyTX: Authors get your book reviewed by Candy's Raves THIS weekend - GUARANTEED - here's how: http:\/\/t.co\/6cvX3M0T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/6cvX3M0T",
        "expanded_url" : "http:\/\/ow.ly\/74dXs",
        "display_url" : "ow.ly\/74dXs"
      } ]
    },
    "geo" : { },
    "id_str" : "127413881869041664",
    "text" : "Authors get your book reviewed by Candy's Raves THIS weekend - GUARANTEED - here's how: http:\/\/t.co\/6cvX3M0T",
    "id" : 127413881869041664,
    "created_at" : "2011-10-21 16:00:11 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 127415522810802176,
  "created_at" : "2011-10-21 16:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127413888533803008",
  "text" : "it's not about judgement or good \/ bad .. it's about getting from point A to point B.",
  "id" : 127413888533803008,
  "created_at" : "2011-10-21 16:00:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 21, 36 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127412599515131905",
  "text" : "profound posts today @stream_enterer I am waiting for collective consciousness to \"click\" ..",
  "id" : 127412599515131905,
  "created_at" : "2011-10-21 15:55:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127411331908378627",
  "text" : "@akaAshkuff hope its a great day for you!",
  "id" : 127411331908378627,
  "created_at" : "2011-10-21 15:50:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/GKs3DBIj",
      "expanded_url" : "http:\/\/bit.ly\/q5Vcbo",
      "display_url" : "bit.ly\/q5Vcbo"
    } ]
  },
  "geo" : { },
  "id_str" : "127192255369981952",
  "text" : "Watch online ATA Martial Arts Invitational 7pm EST Fri. Oct 21 http:\/\/t.co\/GKs3DBIj",
  "id" : 127192255369981952,
  "created_at" : "2011-10-21 01:19:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127153794936078336",
  "text" : "@animalswisdom my fave time of day as well.. magical. : )",
  "id" : 127153794936078336,
  "created_at" : "2011-10-20 22:46:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127144043640655872",
  "text" : "RT @TheEntertainer: It's YOUR life, not someone elses.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127138224484253697",
    "text" : "It's YOUR life, not someone elses.",
    "id" : 127138224484253697,
    "created_at" : "2011-10-20 21:44:49 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 127144043640655872,
  "created_at" : "2011-10-20 22:07:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127125703203360768",
  "geo" : { },
  "id_str" : "127130394528190464",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 bless you for caring for her. ((hugs))",
  "id" : 127130394528190464,
  "in_reply_to_status_id" : 127125703203360768,
  "created_at" : "2011-10-20 21:13:42 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127128878736097280",
  "text" : "RT @TheEntertainer: Repeat after me: \"Something GREAT is trying to happen in my life, something MAGNIFICENT is trying to happen right... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/8P5BPDYe",
        "expanded_url" : "http:\/\/fb.me\/1fhoJ8tgq",
        "display_url" : "fb.me\/1fhoJ8tgq"
      } ]
    },
    "geo" : { },
    "id_str" : "127124745622798337",
    "text" : "Repeat after me: \"Something GREAT is trying to happen in my life, something MAGNIFICENT is trying to happen right... http:\/\/t.co\/8P5BPDYe",
    "id" : 127124745622798337,
    "created_at" : "2011-10-20 20:51:15 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 127128878736097280,
  "created_at" : "2011-10-20 21:07:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/7D6YOfCv",
      "expanded_url" : "http:\/\/bit.ly\/q0F0Ju",
      "display_url" : "bit.ly\/q0F0Ju"
    } ]
  },
  "geo" : { },
  "id_str" : "127128779666624512",
  "text" : "RT @TyrusBooks: If you write a book about an absolutely evil serial killer and I say I don't want it, this is why - http:\/\/t.co\/7D6YOfCv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/7D6YOfCv",
        "expanded_url" : "http:\/\/bit.ly\/q0F0Ju",
        "display_url" : "bit.ly\/q0F0Ju"
      } ]
    },
    "geo" : { },
    "id_str" : "127126188018761728",
    "text" : "If you write a book about an absolutely evil serial killer and I say I don't want it, this is why - http:\/\/t.co\/7D6YOfCv",
    "id" : 127126188018761728,
    "created_at" : "2011-10-20 20:56:59 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 127128779666624512,
  "created_at" : "2011-10-20 21:07:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127122837751332864",
  "text" : "RT @SangyeH: \u201CGive to every other human being every right that you claim for yourself - that is my doctrine.\u201D\r\u2015 Thomas Paine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127121958931402753",
    "text" : "\u201CGive to every other human being every right that you claim for yourself - that is my doctrine.\u201D\r\u2015 Thomas Paine",
    "id" : 127121958931402753,
    "created_at" : "2011-10-20 20:40:11 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 127122837751332864,
  "created_at" : "2011-10-20 20:43:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127115940080001024",
  "geo" : { },
  "id_str" : "127116867277033473",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC really? why?",
  "id" : 127116867277033473,
  "in_reply_to_status_id" : 127115940080001024,
  "created_at" : "2011-10-20 20:19:57 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/bGmP0Sxm",
      "expanded_url" : "http:\/\/bit.ly\/nBT3KF",
      "display_url" : "bit.ly\/nBT3KF"
    } ]
  },
  "geo" : { },
  "id_str" : "127116679363829760",
  "text" : "Doggy Tucks Himself Into Bed - The Animal Rescue Site http:\/\/t.co\/bGmP0Sxm",
  "id" : 127116679363829760,
  "created_at" : "2011-10-20 20:19:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 0, 13 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127101363304923136",
  "geo" : { },
  "id_str" : "127102643423285249",
  "in_reply_to_user_id" : 42974138,
  "text" : "@GraveStomper beneath that tough exterior lies a warm heart : )",
  "id" : 127102643423285249,
  "in_reply_to_status_id" : 127101363304923136,
  "created_at" : "2011-10-20 19:23:26 +0000",
  "in_reply_to_screen_name" : "GraveStomper",
  "in_reply_to_user_id_str" : "42974138",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127102039523213312",
  "text" : "RT @GraveStomper: Just for today: find someone who has a need to talk and just listen to them without expecting anything in return.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127101363304923136",
    "text" : "Just for today: find someone who has a need to talk and just listen to them without expecting anything in return.",
    "id" : 127101363304923136,
    "created_at" : "2011-10-20 19:18:21 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 127102039523213312,
  "created_at" : "2011-10-20 19:21:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/rNLveVkO",
      "expanded_url" : "http:\/\/en.wikipedia.org\/wiki\/Selective_mutism",
      "display_url" : "en.wikipedia.org\/wiki\/Selective\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127090145253015552",
  "text" : "fun fact about me: I had selective mutism as a child http:\/\/t.co\/rNLveVkO",
  "id" : 127090145253015552,
  "created_at" : "2011-10-20 18:33:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    }, {
      "name" : "Fred Cuellar",
      "screen_name" : "FredCuellar",
      "indices" : [ 21, 33 ],
      "id_str" : "31891798",
      "id" : 31891798
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Fredism",
      "indices" : [ 68, 76 ]
    }, {
      "text" : "Quote",
      "indices" : [ 77, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127080481605951488",
  "text" : "RT @earthXplorer: RT @FredCuellar: If U Don't Feed It, It Will Die. #Fredism #Quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Fred Cuellar",
        "screen_name" : "FredCuellar",
        "indices" : [ 3, 15 ],
        "id_str" : "31891798",
        "id" : 31891798
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Fredism",
        "indices" : [ 50, 58 ]
      }, {
        "text" : "Quote",
        "indices" : [ 59, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127079131635658752",
    "text" : "RT @FredCuellar: If U Don't Feed It, It Will Die. #Fredism #Quote",
    "id" : 127079131635658752,
    "created_at" : "2011-10-20 17:50:00 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 127080481605951488,
  "created_at" : "2011-10-20 17:55:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "indices" : [ 3, 14 ],
      "id_str" : "385240011",
      "id" : 385240011
    }, {
      "name" : "Twitter Support",
      "screen_name" : "Support",
      "indices" : [ 29, 37 ],
      "id_str" : "17874544",
      "id" : 17874544
    }, {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 68, 82 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/JCEIuSxu",
      "expanded_url" : "http:\/\/deck.ly\/~ZOCbZ",
      "display_url" : "deck.ly\/~ZOCbZ"
    } ]
  },
  "geo" : { },
  "id_str" : "127069936383303680",
  "text" : "RT @newordsnow: DEAR TWITTER @SUPPORT , Day 21 of I can't log in to @Wylieknowords my other Twitter site.(No\u2026 (cont) http:\/\/t.co\/JCEIuSxu",
  "id" : 127069936383303680,
  "created_at" : "2011-10-20 17:13:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127064494487764992",
  "text" : "RT @bcmystery: My cat is such a klutz. I just watch her walk across the backyard and trip over a twig. A TWIG!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127059472521768961",
    "text" : "My cat is such a klutz. I just watch her walk across the backyard and trip over a twig. A TWIG!",
    "id" : 127059472521768961,
    "created_at" : "2011-10-20 16:31:53 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 127064494487764992,
  "created_at" : "2011-10-20 16:51:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 121, 134 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/xrrH1zLT",
      "expanded_url" : "http:\/\/www.naturalnews.com\/033928_antidepressant_drugs_alternatives.html",
      "display_url" : "naturalnews.com\/033928_antidep\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127063592423006208",
  "text" : "How to avoid being like the 11 percent of Americans who now take antidepressant drugs every day http:\/\/t.co\/xrrH1zLT via @HealthRanger",
  "id" : 127063592423006208,
  "created_at" : "2011-10-20 16:48:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darynda Jones",
      "screen_name" : "Darynda",
      "indices" : [ 3, 11 ],
      "id_str" : "34045942",
      "id" : 34045942
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127057116132421632",
  "text" : "RT @Darynda: ATTENTION ALL READERS! The Rubies are hosting a survey to find out how today's readers get their hands on books.... http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/emsbE92J",
        "expanded_url" : "http:\/\/fb.me\/HYAfrSV0",
        "display_url" : "fb.me\/HYAfrSV0"
      } ]
    },
    "geo" : { },
    "id_str" : "127053837021351936",
    "text" : "ATTENTION ALL READERS! The Rubies are hosting a survey to find out how today's readers get their hands on books.... http:\/\/t.co\/emsbE92J",
    "id" : 127053837021351936,
    "created_at" : "2011-10-20 16:09:29 +0000",
    "user" : {
      "name" : "Darynda Jones",
      "screen_name" : "Darynda",
      "protected" : false,
      "id_str" : "34045942",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738374088205312004\/ZrgEQ3wL_normal.jpg",
      "id" : 34045942,
      "verified" : false
    }
  },
  "id" : 127057116132421632,
  "created_at" : "2011-10-20 16:22:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squirrel",
      "indices" : [ 35, 44 ]
    }, {
      "text" : "nature",
      "indices" : [ 86, 93 ]
    }, {
      "text" : "photo",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/MCYms4PK",
      "expanded_url" : "http:\/\/bit.ly\/qUY35h",
      "display_url" : "bit.ly\/qUY35h"
    } ]
  },
  "geo" : { },
  "id_str" : "127050250052583425",
  "text" : "RT @KerriFar: Saved for later  ~ A #squirrel  finds treasure ~ http:\/\/t.co\/MCYms4PK ~ #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squirrel",
        "indices" : [ 21, 30 ]
      }, {
        "text" : "nature",
        "indices" : [ 72, 79 ]
      }, {
        "text" : "photo",
        "indices" : [ 80, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/MCYms4PK",
        "expanded_url" : "http:\/\/bit.ly\/qUY35h",
        "display_url" : "bit.ly\/qUY35h"
      } ]
    },
    "geo" : { },
    "id_str" : "127048934517518337",
    "text" : "Saved for later  ~ A #squirrel  finds treasure ~ http:\/\/t.co\/MCYms4PK ~ #nature #photo",
    "id" : 127048934517518337,
    "created_at" : "2011-10-20 15:50:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 127050250052583425,
  "created_at" : "2011-10-20 15:55:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JohnCali",
      "indices" : [ 97, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127045671500005376",
  "text" : "RT @JohnCali: Life on Planet Earth was intended by your higher selves to be a joyful experience. #JohnCali",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JohnCali",
        "indices" : [ 83, 92 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127045039502270464",
    "text" : "Life on Planet Earth was intended by your higher selves to be a joyful experience. #JohnCali",
    "id" : 127045039502270464,
    "created_at" : "2011-10-20 15:34:32 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 127045671500005376,
  "created_at" : "2011-10-20 15:37:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JohnCali",
      "indices" : [ 121, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127045623642984448",
  "text" : "RT @JohnCali: Life is a big game you've chosen to play. It's supposed to be fun. That's what games are all about -- FUN! #JohnCali",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JohnCali",
        "indices" : [ 107, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127045072565968896",
    "text" : "Life is a big game you've chosen to play. It's supposed to be fun. That's what games are all about -- FUN! #JohnCali",
    "id" : 127045072565968896,
    "created_at" : "2011-10-20 15:34:40 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 127045623642984448,
  "created_at" : "2011-10-20 15:36:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Trudeau",
      "screen_name" : "KevinTrudeau",
      "indices" : [ 12, 25 ],
      "id_str" : "17198504",
      "id" : 17198504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127044228558757888",
  "text" : "kindness RT @KevinTrudeau: In your eyes, what is the most important characteristic a person can have?",
  "id" : 127044228558757888,
  "created_at" : "2011-10-20 15:31:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127043516646961153",
  "text" : "RT @gemswinc: Of course educated masses do not make malleable slaves..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127042863539302402",
    "text" : "Of course educated masses do not make malleable slaves..",
    "id" : 127042863539302402,
    "created_at" : "2011-10-20 15:25:53 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 127043516646961153,
  "created_at" : "2011-10-20 15:28:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "indices" : [ 3, 12 ],
      "id_str" : "19636553",
      "id" : 19636553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 86, 91 ]
    }, {
      "text" : "life",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "createItdaily",
      "indices" : [ 98, 112 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127043460275519488",
  "text" : "RT @LunaJune: love, staple of life \/ alllow the downpour of it \/ into your life daily\n#love #life #createItdaily",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 72, 77 ]
      }, {
        "text" : "life",
        "indices" : [ 78, 83 ]
      }, {
        "text" : "createItdaily",
        "indices" : [ 84, 98 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127042877959319552",
    "text" : "love, staple of life \/ alllow the downpour of it \/ into your life daily\n#love #life #createItdaily",
    "id" : 127042877959319552,
    "created_at" : "2011-10-20 15:25:57 +0000",
    "user" : {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "protected" : false,
      "id_str" : "19636553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521342919387533313\/KI-XkoTw_normal.jpeg",
      "id" : 19636553,
      "verified" : false
    }
  },
  "id" : 127043460275519488,
  "created_at" : "2011-10-20 15:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    }, {
      "name" : "Matthew Fry",
      "screen_name" : "lovepeaceunity",
      "indices" : [ 107, 122 ],
      "id_str" : "23939797",
      "id" : 23939797
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Proverb",
      "indices" : [ 94, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127043422992343040",
  "text" : "RT @SpiritualNurse: Give thanks for unknown blessings already on their way! ~ Native American #Proverb via @lovepeaceunity",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matthew Fry",
        "screen_name" : "lovepeaceunity",
        "indices" : [ 87, 102 ],
        "id_str" : "23939797",
        "id" : 23939797
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Proverb",
        "indices" : [ 74, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127042981856411648",
    "text" : "Give thanks for unknown blessings already on their way! ~ Native American #Proverb via @lovepeaceunity",
    "id" : 127042981856411648,
    "created_at" : "2011-10-20 15:26:21 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 127043422992343040,
  "created_at" : "2011-10-20 15:28:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127042210851078144",
  "geo" : { },
  "id_str" : "127043318298329090",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny Jesus would say he's got to take the class again ; ) (We all learn at a different pace)",
  "id" : 127043318298329090,
  "in_reply_to_status_id" : 127042210851078144,
  "created_at" : "2011-10-20 15:27:42 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/1MtlcgBE",
      "expanded_url" : "http:\/\/bit.ly\/r9hzYD",
      "display_url" : "bit.ly\/r9hzYD"
    } ]
  },
  "geo" : { },
  "id_str" : "127042496168595456",
  "text" : "Dad, instead of Mom, made contact after death (Hey Mom, we had a deal! lol) http:\/\/t.co\/1MtlcgBE - see RV report",
  "id" : 127042496168595456,
  "created_at" : "2011-10-20 15:24:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0950wizardparadox\u0950",
      "screen_name" : "wizard_paradox",
      "indices" : [ 0, 15 ],
      "id_str" : "125039271",
      "id" : 125039271
    }, {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 16, 31 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "127022090107887616",
  "geo" : { },
  "id_str" : "127041143564271616",
  "in_reply_to_user_id" : 125039271,
  "text" : "@wizard_paradox @mssuzcatsilver hmm.. maybe explains why I feel sick on & off..",
  "id" : 127041143564271616,
  "in_reply_to_status_id" : 127022090107887616,
  "created_at" : "2011-10-20 15:19:03 +0000",
  "in_reply_to_screen_name" : "wizard_paradox",
  "in_reply_to_user_id_str" : "125039271",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0950wizardparadox\u0950",
      "screen_name" : "wizard_paradox",
      "indices" : [ 3, 18 ],
      "id_str" : "125039271",
      "id" : 125039271
    }, {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 20, 35 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/a2SRSFPt",
      "expanded_url" : "http:\/\/planetaryenergies.net\/articles\/phoenix-rising-menopause-other-midlife-transformations\/",
      "display_url" : "planetaryenergies.net\/articles\/phoen\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "127040087153311745",
  "text" : "RT @wizard_paradox: @mssuzcatsilver this is an interesting one http:\/\/t.co\/a2SRSFPt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/stone.com\/Twittelator\" rel=\"nofollow\"\u003ETwittelator\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "suzcat",
        "screen_name" : "mssuzcatsilver",
        "indices" : [ 0, 15 ],
        "id_str" : "25846336",
        "id" : 25846336
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/a2SRSFPt",
        "expanded_url" : "http:\/\/planetaryenergies.net\/articles\/phoenix-rising-menopause-other-midlife-transformations\/",
        "display_url" : "planetaryenergies.net\/articles\/phoen\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "127021772800405504",
    "geo" : {
      "type" : "Point",
      "coordinates" : [ 55.860737, -4.260003 ]
    },
    "id_str" : "127022090107887616",
    "in_reply_to_user_id" : 25846336,
    "text" : "@mssuzcatsilver this is an interesting one http:\/\/t.co\/a2SRSFPt",
    "id" : 127022090107887616,
    "in_reply_to_status_id" : 127021772800405504,
    "created_at" : "2011-10-20 14:03:20 +0000",
    "in_reply_to_screen_name" : "mssuzcatsilver",
    "in_reply_to_user_id_str" : "25846336",
    "user" : {
      "name" : "\u0950wizardparadox\u0950",
      "screen_name" : "wizard_paradox",
      "protected" : false,
      "id_str" : "125039271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2629926276\/d66caef6a8d1a1f4a50ba0af7343fc54_normal.jpeg",
      "id" : 125039271,
      "verified" : false
    }
  },
  "id" : 127040087153311745,
  "created_at" : "2011-10-20 15:14:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127037206845079553",
  "text" : "I think the universe is using my stomach to get me to live in the NOW.. I never know how it's going to feel..",
  "id" : 127037206845079553,
  "created_at" : "2011-10-20 15:03:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    }, {
      "name" : "Nancy Freedman-Smith",
      "screen_name" : "Gooddogz",
      "indices" : [ 83, 92 ],
      "id_str" : "23052659",
      "id" : 23052659
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/QbywScxn",
      "expanded_url" : "http:\/\/shar.es\/buQz5",
      "display_url" : "shar.es\/buQz5"
    } ]
  },
  "geo" : { },
  "id_str" : "127028956770729984",
  "text" : "RT @fearfuldogs: ok 2 promote unrealistic body type but bothered by a few tats? RT @Gooddogz: Barbie Gets Tatted Up! http:\/\/t.co\/QbywScxn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nancy Freedman-Smith",
        "screen_name" : "Gooddogz",
        "indices" : [ 66, 75 ],
        "id_str" : "23052659",
        "id" : 23052659
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/QbywScxn",
        "expanded_url" : "http:\/\/shar.es\/buQz5",
        "display_url" : "shar.es\/buQz5"
      } ]
    },
    "geo" : { },
    "id_str" : "127025872812253186",
    "text" : "ok 2 promote unrealistic body type but bothered by a few tats? RT @Gooddogz: Barbie Gets Tatted Up! http:\/\/t.co\/QbywScxn",
    "id" : 127025872812253186,
    "created_at" : "2011-10-20 14:18:22 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 127028956770729984,
  "created_at" : "2011-10-20 14:30:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127026427169218560",
  "text" : "RT @DrRus: Morning Mindbender Answer: Experts say a man has a better chance of a woman falling for him if the date is slightly \"scary\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "127014718031400960",
    "text" : "Morning Mindbender Answer: Experts say a man has a better chance of a woman falling for him if the date is slightly \"scary\".",
    "id" : 127014718031400960,
    "created_at" : "2011-10-20 13:34:03 +0000",
    "user" : {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "protected" : false,
      "id_str" : "11006552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2998045873\/401a4460295cb0375428b8b577bd2249_normal.jpeg",
      "id" : 11006552,
      "verified" : false
    }
  },
  "id" : 127026427169218560,
  "created_at" : "2011-10-20 14:20:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingsweallhate",
      "indices" : [ 18, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "127013446993707008",
  "text" : "RT @DwayneReaves: #thingsweallhate ? I don't hate anything, don't have time for hate in my life!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thingsweallhate",
        "indices" : [ 0, 16 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126751320949530624",
    "text" : "#thingsweallhate ? I don't hate anything, don't have time for hate in my life!",
    "id" : 126751320949530624,
    "created_at" : "2011-10-19 20:07:24 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 127013446993707008,
  "created_at" : "2011-10-20 13:29:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126823511741308929",
  "text" : "RT @JosephRanseth: Just for the record, you are wonderful.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126820293170831360",
    "text" : "Just for the record, you are wonderful.",
    "id" : 126820293170831360,
    "created_at" : "2011-10-20 00:41:28 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 126823511741308929,
  "created_at" : "2011-10-20 00:54:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Ian Boudreau",
      "screen_name" : "iboudreau",
      "indices" : [ 62, 72 ],
      "id_str" : "40146181",
      "id" : 40146181
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126775698756079616",
  "text" : "RT @ZachsMind: you guys keep banging your heads against walls @iboudreau liberal or conservative or moderate aren't your answers; they'r ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ian Boudreau",
        "screen_name" : "iboudreau",
        "indices" : [ 47, 57 ],
        "id_str" : "40146181",
        "id" : 40146181
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126774871966494720",
    "text" : "you guys keep banging your heads against walls @iboudreau liberal or conservative or moderate aren't your answers; they're your problems.",
    "id" : 126774871966494720,
    "created_at" : "2011-10-19 21:40:59 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 126775698756079616,
  "created_at" : "2011-10-19 21:44:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126775570456510464",
  "text" : "I really really think I have some chronic viral thing. comes and goes.",
  "id" : 126775570456510464,
  "created_at" : "2011-10-19 21:43:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126770786143973377",
  "geo" : { },
  "id_str" : "126774218581999618",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater do you follow @tragic_pizza ? you might like him : )",
  "id" : 126774218581999618,
  "in_reply_to_status_id" : 126770786143973377,
  "created_at" : "2011-10-19 21:38:23 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 17, 31 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126760972235968512",
  "text" : "RT @JohnCali: RT @_NealeDWalsch: Seek not to be the recipient of anything but to be the source. That which you wish to have, cause anoth ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NDW",
        "screen_name" : "_NealeDWalsch",
        "indices" : [ 3, 17 ],
        "id_str" : "798611160945672192",
        "id" : 798611160945672192
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126760678404014080",
    "text" : "RT @_NealeDWalsch: Seek not to be the recipient of anything but to be the source. That which you wish to have, cause another to have.",
    "id" : 126760678404014080,
    "created_at" : "2011-10-19 20:44:35 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 126760972235968512,
  "created_at" : "2011-10-19 20:45:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126759538689966080",
  "text" : "RT @LSFProgram: \u201CI don't like that man.\u00A0 I must get to know him better.\u00A0\u201C ~Abraham Lincoln",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126758975185235968",
    "text" : "\u201CI don't like that man.\u00A0 I must get to know him better.\u00A0\u201C ~Abraham Lincoln",
    "id" : 126758975185235968,
    "created_at" : "2011-10-19 20:37:49 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 126759538689966080,
  "created_at" : "2011-10-19 20:40:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Attaining Income",
      "screen_name" : "hyperionvoice",
      "indices" : [ 0, 14 ],
      "id_str" : "2186397289",
      "id" : 2186397289
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126758302272073728",
  "geo" : { },
  "id_str" : "126758881828417538",
  "in_reply_to_user_id" : 19301765,
  "text" : "@HyperionVoice The Monsters of Templeton",
  "id" : 126758881828417538,
  "in_reply_to_status_id" : 126758302272073728,
  "created_at" : "2011-10-19 20:37:27 +0000",
  "in_reply_to_screen_name" : "HachetteBooks",
  "in_reply_to_user_id_str" : "19301765",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 12, 23 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126755729964154880",
  "geo" : { },
  "id_str" : "126756969255153665",
  "in_reply_to_user_id" : 39331231,
  "text" : "that lesson @dhammagirl seems to be making its rounds lately : )",
  "id" : 126756969255153665,
  "in_reply_to_status_id" : 126755729964154880,
  "created_at" : "2011-10-19 20:29:51 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126756691982299136",
  "text" : "RT @dhammagirl: Just Remembered that i should never allow myself to become a slave to my emotions.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126755729964154880",
    "text" : "Just Remembered that i should never allow myself to become a slave to my emotions.",
    "id" : 126755729964154880,
    "created_at" : "2011-10-19 20:24:55 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 126756691982299136,
  "created_at" : "2011-10-19 20:28:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jamie Kilstein",
      "screen_name" : "jamiekilstein",
      "indices" : [ 3, 17 ],
      "id_str" : "16960279",
      "id" : 16960279
    }, {
      "name" : "Adam Levine",
      "screen_name" : "adamlevine",
      "indices" : [ 48, 59 ],
      "id_str" : "58528137",
      "id" : 58528137
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126756640669171713",
  "text" : "RT @jamiekilstein: Don't fuck with maroon 5. RT @adamlevine: Dear Fox News, don't play our music on your evil fucking channel ever again ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Adam Levine",
        "screen_name" : "adamlevine",
        "indices" : [ 29, 40 ],
        "id_str" : "58528137",
        "id" : 58528137
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126748561676304384",
    "text" : "Don't fuck with maroon 5. RT @adamlevine: Dear Fox News, don't play our music on your evil fucking channel ever again. Thank you.",
    "id" : 126748561676304384,
    "created_at" : "2011-10-19 19:56:26 +0000",
    "user" : {
      "name" : "Jamie Kilstein",
      "screen_name" : "jamiekilstein",
      "protected" : false,
      "id_str" : "16960279",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/768551088752656388\/3CqYX0Tn_normal.jpg",
      "id" : 16960279,
      "verified" : true
    }
  },
  "id" : 126756640669171713,
  "created_at" : "2011-10-19 20:28:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126742200179630080",
  "geo" : { },
  "id_str" : "126756197142503424",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny LOL ; )",
  "id" : 126756197142503424,
  "in_reply_to_status_id" : 126742200179630080,
  "created_at" : "2011-10-19 20:26:47 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 7, 17 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126753618853511168",
  "text" : "LOL RT @ScottBaio: You guys are zero help. 50\/50 split answers on the flu shot.",
  "id" : 126753618853511168,
  "created_at" : "2011-10-19 20:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Winyan Staz Wakien",
      "screen_name" : "WinyanStaz",
      "indices" : [ 23, 34 ],
      "id_str" : "236268614",
      "id" : 236268614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126745163019190273",
  "text" : "RT @mssuzcatsilver: RT @WinyanStaz: We are moving into a new reality.  Lets not leave anyone, any race, religion, sex or nation behind : ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Winyan Staz Wakien",
        "screen_name" : "WinyanStaz",
        "indices" : [ 3, 14 ],
        "id_str" : "236268614",
        "id" : 236268614
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126744304021553153",
    "text" : "RT @WinyanStaz: We are moving into a new reality.  Lets not leave anyone, any race, religion, sex or nation behind :) We can do this :)",
    "id" : 126744304021553153,
    "created_at" : "2011-10-19 19:39:31 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 126745163019190273,
  "created_at" : "2011-10-19 19:42:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126741454931501056",
  "geo" : { },
  "id_str" : "126743993202651137",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny I shld hv prefaced comment w I dont believe bible literally & think some was re-written in order 2 control the masses.",
  "id" : 126743993202651137,
  "in_reply_to_status_id" : 126741454931501056,
  "created_at" : "2011-10-19 19:38:17 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126738971270201344",
  "text" : "RT @luminanceriver: Laughing raises our vibration to the 7th dimension. Matias d.S.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126738408235208705",
    "text" : "Laughing raises our vibration to the 7th dimension. Matias d.S.",
    "id" : 126738408235208705,
    "created_at" : "2011-10-19 19:16:05 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 126738971270201344,
  "created_at" : "2011-10-19 19:18:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126738588422516737",
  "text" : "RT @stream_enterer: Hated my mind for the deceit when it turned out I wasn't better than any of you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126737777021820928",
    "text" : "Hated my mind for the deceit when it turned out I wasn't better than any of you.",
    "id" : 126737777021820928,
    "created_at" : "2011-10-19 19:13:35 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 126738588422516737,
  "created_at" : "2011-10-19 19:16:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126737063088361472",
  "geo" : { },
  "id_str" : "126738503240388609",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny I don't think he did. He viewed everything with love.",
  "id" : 126738503240388609,
  "in_reply_to_status_id" : 126737063088361472,
  "created_at" : "2011-10-19 19:16:28 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Kate",
      "screen_name" : "RainbowKate",
      "indices" : [ 16, 28 ],
      "id_str" : "20756686",
      "id" : 20756686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126728981507620864",
  "geo" : { },
  "id_str" : "126731042940915712",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver @RainbowKate I am a roly-poly : )",
  "id" : 126731042940915712,
  "in_reply_to_status_id" : 126728981507620864,
  "created_at" : "2011-10-19 18:46:49 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 51, 61 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126730558842740736",
  "text" : "I don't get them. Don't trust they are helpful. RT @ScottBaio: Flu shot or no flu shot?",
  "id" : 126730558842740736,
  "created_at" : "2011-10-19 18:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/p04v7btV",
      "expanded_url" : "http:\/\/ow.ly\/72ygG",
      "display_url" : "ow.ly\/72ygG"
    } ]
  },
  "geo" : { },
  "id_str" : "126727488889036800",
  "text" : "RT @CaroleODell: Couple Married 72 Years Dies Holding Hands http:\/\/t.co\/p04v7btV",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/p04v7btV",
        "expanded_url" : "http:\/\/ow.ly\/72ygG",
        "display_url" : "ow.ly\/72ygG"
      } ]
    },
    "geo" : { },
    "id_str" : "126725813465919489",
    "text" : "Couple Married 72 Years Dies Holding Hands http:\/\/t.co\/p04v7btV",
    "id" : 126725813465919489,
    "created_at" : "2011-10-19 18:26:03 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 126727488889036800,
  "created_at" : "2011-10-19 18:32:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "ThinkProgress",
      "screen_name" : "thinkprogress",
      "indices" : [ 39, 53 ],
      "id_str" : "55355654",
      "id" : 55355654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Cantmakeupthisstuff",
      "indices" : [ 17, 37 ]
    }, {
      "text" : "abortion",
      "indices" : [ 108, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126727008901267456",
  "text" : "RT @ReverendSue: #Cantmakeupthisstuff \"@thinkprogress: GOP Sen pushes radical bill 2 restrict discussion of #abortion over the internet  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "ThinkProgress",
        "screen_name" : "thinkprogress",
        "indices" : [ 22, 36 ],
        "id_str" : "55355654",
        "id" : 55355654
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Cantmakeupthisstuff",
        "indices" : [ 0, 20 ]
      }, {
        "text" : "abortion",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/MHTF1W6g",
        "expanded_url" : "http:\/\/thkpr.gs\/nqoPFs",
        "display_url" : "thkpr.gs\/nqoPFs"
      } ]
    },
    "geo" : { },
    "id_str" : "126726322943832065",
    "text" : "#Cantmakeupthisstuff \"@thinkprogress: GOP Sen pushes radical bill 2 restrict discussion of #abortion over the internet http:\/\/t.co\/MHTF1W6g\"",
    "id" : 126726322943832065,
    "created_at" : "2011-10-19 18:28:04 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 126727008901267456,
  "created_at" : "2011-10-19 18:30:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birding",
      "indices" : [ 70, 78 ]
    }, {
      "text" : "nature",
      "indices" : [ 79, 86 ]
    }, {
      "text" : "photo",
      "indices" : [ 87, 93 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/0b8yKZUC",
      "expanded_url" : "http:\/\/bit.ly\/nbWNTd",
      "display_url" : "bit.ly\/nbWNTd"
    } ]
  },
  "geo" : { },
  "id_str" : "126723167556337665",
  "text" : "RT @KerriFar: She is peeking from the pines ~ http:\/\/t.co\/0b8yKZUC  ~ #birding #nature #photo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birding",
        "indices" : [ 56, 64 ]
      }, {
        "text" : "nature",
        "indices" : [ 65, 72 ]
      }, {
        "text" : "photo",
        "indices" : [ 73, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 32, 52 ],
        "url" : "http:\/\/t.co\/0b8yKZUC",
        "expanded_url" : "http:\/\/bit.ly\/nbWNTd",
        "display_url" : "bit.ly\/nbWNTd"
      } ]
    },
    "geo" : { },
    "id_str" : "126721025684672512",
    "text" : "She is peeking from the pines ~ http:\/\/t.co\/0b8yKZUC  ~ #birding #nature #photo",
    "id" : 126721025684672512,
    "created_at" : "2011-10-19 18:07:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 126723167556337665,
  "created_at" : "2011-10-19 18:15:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookChickCity",
      "screen_name" : "BookChickCity",
      "indices" : [ 3, 17 ],
      "id_str" : "2541818204",
      "id" : 2541818204
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126722752433500161",
  "text" : "RT @BookChickCity: Would any bloggers like to do a guest review for me? Must own a Kindle (or e-reader that takes mobi) and enjoy parano ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126711646386257920",
    "text" : "Would any bloggers like to do a guest review for me? Must own a Kindle (or e-reader that takes mobi) and enjoy paranormal romance :)",
    "id" : 126711646386257920,
    "created_at" : "2011-10-19 17:29:45 +0000",
    "user" : {
      "name" : "Carolyn Storer",
      "screen_name" : "CarolynStorer_",
      "protected" : false,
      "id_str" : "53386271",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790680168083980288\/cBX3bAfk_normal.jpg",
      "id" : 53386271,
      "verified" : false
    }
  },
  "id" : 126722752433500161,
  "created_at" : "2011-10-19 18:13:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126716683741175808",
  "text" : "@SamsaricWarrior sad, I cant even drink anymore.. makes me ill. have enough stomach issues..bleh.",
  "id" : 126716683741175808,
  "created_at" : "2011-10-19 17:49:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126716182983229441",
  "text" : "@SamsaricWarrior yah, yesterday was bad day 4 me.. dunno why. today is better.",
  "id" : 126716182983229441,
  "created_at" : "2011-10-19 17:47:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126715762290343936",
  "text" : "tv commercial that grinds my nerves: AT&T \"should have married John Clark\"",
  "id" : 126715762290343936,
  "created_at" : "2011-10-19 17:46:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126504288791953408",
  "geo" : { },
  "id_str" : "126714505806888960",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes it shows her love triumphing (word?) over her disappointment.",
  "id" : 126714505806888960,
  "in_reply_to_status_id" : 126504288791953408,
  "created_at" : "2011-10-19 17:41:07 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126504288791953408",
  "geo" : { },
  "id_str" : "126714279272525824",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes actually, I like that commercial bcuz yes, she's disappointed yet she still loves her girl as she is.",
  "id" : 126714279272525824,
  "in_reply_to_status_id" : 126504288791953408,
  "created_at" : "2011-10-19 17:40:13 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 24, 37 ],
      "id_str" : "135615040",
      "id" : 135615040
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 38, 51 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 69, 78 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 79, 88 ],
      "id_str" : "14986977",
      "id" : 14986977
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 89, 104 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126713642774302720",
  "text" : "((hugs)) 4 lovely souls @CrystalLewis @DwayneReaves @SamsaricWarrior @Tideliar @Teawench @thesexyatheist",
  "id" : 126713642774302720,
  "created_at" : "2011-10-19 17:37:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 4, 16 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126709738586112000",
  "geo" : { },
  "id_str" : "126711704343150594",
  "in_reply_to_user_id" : 16691399,
  "text" : "lol @fearfuldogs some dog trainers would cringe at how we treat our aussie.. hehe",
  "id" : 126711704343150594,
  "in_reply_to_status_id" : 126709738586112000,
  "created_at" : "2011-10-19 17:29:59 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126700354522972160",
  "geo" : { },
  "id_str" : "126711218328178688",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench ((hugs))",
  "id" : 126711218328178688,
  "in_reply_to_status_id" : 126700354522972160,
  "created_at" : "2011-10-19 17:28:03 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126708018560765953",
  "text" : "you @SamsaricWarrior deserve a better day than that.. reach for the better feeling.. step by step.",
  "id" : 126708018560765953,
  "created_at" : "2011-10-19 17:15:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126696554240282624",
  "text" : "lately babies are a recurring dream theme.. well, a baby (not mine) that I care for temporarily.",
  "id" : 126696554240282624,
  "created_at" : "2011-10-19 16:29:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126693221412777984",
  "text" : "RT @Emmanueldagher: How are you choosing to trust your intuition even more today?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126691853633470465",
    "text" : "How are you choosing to trust your intuition even more today?",
    "id" : 126691853633470465,
    "created_at" : "2011-10-19 16:11:06 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 126693221412777984,
  "created_at" : "2011-10-19 16:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126690316576235520",
  "text" : "there are ppl I like that I follow, yet feel I should unfollow due to neg vibes. conundrum..",
  "id" : 126690316576235520,
  "created_at" : "2011-10-19 16:04:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi Kole",
      "screen_name" : "HeidiKole",
      "indices" : [ 3, 13 ],
      "id_str" : "70890220",
      "id" : 70890220
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 15, 29 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "changethetrend",
      "indices" : [ 52, 67 ]
    }, {
      "text" : "thingswehate",
      "indices" : [ 116, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126689440063172609",
  "text" : "RT @HeidiKole: @CharlesBivona  I think it's time to #changethetrend otherwise we will forever be stuck & attracting #thingswehate #lawof ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 0, 14 ],
        "id_str" : "45254966",
        "id" : 45254966
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "changethetrend",
        "indices" : [ 37, 52 ]
      }, {
        "text" : "thingswehate",
        "indices" : [ 101, 114 ]
      }, {
        "text" : "lawofattraction",
        "indices" : [ 115, 131 ]
      }, {
        "text" : "OWS",
        "indices" : [ 132, 136 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "126685746089308161",
    "geo" : { },
    "id_str" : "126687249277526016",
    "in_reply_to_user_id" : 45254966,
    "text" : "@CharlesBivona  I think it's time to #changethetrend otherwise we will forever be stuck & attracting #thingswehate #lawofattraction #OWS",
    "id" : 126687249277526016,
    "in_reply_to_status_id" : 126685746089308161,
    "created_at" : "2011-10-19 15:52:48 +0000",
    "in_reply_to_screen_name" : "CharlesBivona",
    "in_reply_to_user_id_str" : "45254966",
    "user" : {
      "name" : "Heidi Kole",
      "screen_name" : "HeidiKole",
      "protected" : false,
      "id_str" : "70890220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1732602562\/Heidikolefinal_2_normal.jpg",
      "id" : 70890220,
      "verified" : false
    }
  },
  "id" : 126689440063172609,
  "created_at" : "2011-10-19 16:01:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi Kole",
      "screen_name" : "HeidiKole",
      "indices" : [ 3, 13 ],
      "id_str" : "70890220",
      "id" : 70890220
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 15, 29 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126686180245897216",
  "text" : "RT @HeidiKole: @CharlesBivona When u look@the absence of what u want u cause that vibration-When u look@the presence of what u want u ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 0, 14 ],
        "id_str" : "45254966",
        "id" : 45254966
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "126684823891869696",
    "geo" : { },
    "id_str" : "126685574848454657",
    "in_reply_to_user_id" : 45254966,
    "text" : "@CharlesBivona When u look@the absence of what u want u cause that vibration-When u look@the presence of what u want u cause that vibration",
    "id" : 126685574848454657,
    "in_reply_to_status_id" : 126684823891869696,
    "created_at" : "2011-10-19 15:46:09 +0000",
    "in_reply_to_screen_name" : "CharlesBivona",
    "in_reply_to_user_id_str" : "45254966",
    "user" : {
      "name" : "Heidi Kole",
      "screen_name" : "HeidiKole",
      "protected" : false,
      "id_str" : "70890220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1732602562\/Heidikolefinal_2_normal.jpg",
      "id" : 70890220,
      "verified" : false
    }
  },
  "id" : 126686180245897216,
  "created_at" : "2011-10-19 15:48:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heidi Kole",
      "screen_name" : "HeidiKole",
      "indices" : [ 3, 13 ],
      "id_str" : "70890220",
      "id" : 70890220
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 15, 29 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thingswehate",
      "indices" : [ 62, 75 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126686102978441216",
  "text" : "RT @HeidiKole: @CharlesBivona Perhaps change terminology from #thingswehate 2#thingswewant-when u look@the absence of what u want u prac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 0, 14 ],
        "id_str" : "45254966",
        "id" : 45254966
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thingswehate",
        "indices" : [ 47, 60 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "126683364748038144",
    "geo" : { },
    "id_str" : "126685078553243648",
    "in_reply_to_user_id" : 45254966,
    "text" : "@CharlesBivona Perhaps change terminology from #thingswehate 2#thingswewant-when u look@the absence of what u want u practice that vibration",
    "id" : 126685078553243648,
    "in_reply_to_status_id" : 126683364748038144,
    "created_at" : "2011-10-19 15:44:11 +0000",
    "in_reply_to_screen_name" : "CharlesBivona",
    "in_reply_to_user_id_str" : "45254966",
    "user" : {
      "name" : "Heidi Kole",
      "screen_name" : "HeidiKole",
      "protected" : false,
      "id_str" : "70890220",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1732602562\/Heidikolefinal_2_normal.jpg",
      "id" : 70890220,
      "verified" : false
    }
  },
  "id" : 126686102978441216,
  "created_at" : "2011-10-19 15:48:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "senryu",
      "indices" : [ 75, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126685612672688130",
  "text" : "RT @CoyoteSings: front door \u2022 I open the cage door \u2022 and set myself free | #senryu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "senryu",
        "indices" : [ 58, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126685155871047681",
    "text" : "front door \u2022 I open the cage door \u2022 and set myself free | #senryu",
    "id" : 126685155871047681,
    "created_at" : "2011-10-19 15:44:29 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 126685612672688130,
  "created_at" : "2011-10-19 15:46:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    }, {
      "name" : "Greg S & Candice Lee",
      "screen_name" : "GregSlawson",
      "indices" : [ 23, 35 ],
      "id_str" : "14573183",
      "id" : 14573183
    }, {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 36, 48 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126682985390030848",
  "text" : "RT @SpiritualNurse: RT @GregSlawson @ShipsofSong   \u00BB   \u00BB  Horizons are how far you allow your Consciousness to perceive.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Greg S & Candice Lee",
        "screen_name" : "GregSlawson",
        "indices" : [ 3, 15 ],
        "id_str" : "14573183",
        "id" : 14573183
      }, {
        "name" : "Ships of Song",
        "screen_name" : "ShipsofSong",
        "indices" : [ 16, 28 ],
        "id_str" : "76817286",
        "id" : 76817286
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126682613091012608",
    "text" : "RT @GregSlawson @ShipsofSong   \u00BB   \u00BB  Horizons are how far you allow your Consciousness to perceive.",
    "id" : 126682613091012608,
    "created_at" : "2011-10-19 15:34:23 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 126682985390030848,
  "created_at" : "2011-10-19 15:35:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "monostich",
      "indices" : [ 63, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126680478492278784",
  "text" : "RT @CoyoteSings: sunrise the match that sets the day on fire | #monostich",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "monostich",
        "indices" : [ 46, 56 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126680287383003136",
    "text" : "sunrise the match that sets the day on fire | #monostich",
    "id" : 126680287383003136,
    "created_at" : "2011-10-19 15:25:08 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 126680478492278784,
  "created_at" : "2011-10-19 15:25:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126677904858943488",
  "text" : "RT @TyrusBooks: If we were to do a holiday book giveaway like we did last year with print, would there be significant interest?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126677000512479232",
    "text" : "If we were to do a holiday book giveaway like we did last year with print, would there be significant interest?",
    "id" : 126677000512479232,
    "created_at" : "2011-10-19 15:12:05 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 126677904858943488,
  "created_at" : "2011-10-19 15:15:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126677309657853953",
  "text" : "good morning beautiful ones",
  "id" : 126677309657853953,
  "created_at" : "2011-10-19 15:13:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis Rotella",
      "screen_name" : "tankaqueen",
      "indices" : [ 3, 14 ],
      "id_str" : "159558577",
      "id" : 159558577
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 51, 57 ]
    }, {
      "text" : "micropoetry",
      "indices" : [ 58, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126676947936870401",
  "text" : "RT @tankaqueen: Stepping lightly \/ deer \/ at dusk  #haiku #micropoetry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 35, 41 ]
      }, {
        "text" : "micropoetry",
        "indices" : [ 42, 54 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126446275821453312",
    "text" : "Stepping lightly \/ deer \/ at dusk  #haiku #micropoetry",
    "id" : 126446275821453312,
    "created_at" : "2011-10-18 23:55:16 +0000",
    "user" : {
      "name" : "Alexis Rotella",
      "screen_name" : "tankaqueen",
      "protected" : false,
      "id_str" : "159558577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1408416838\/lipprints_normal.jpg",
      "id" : 159558577,
      "verified" : false
    }
  },
  "id" : 126676947936870401,
  "created_at" : "2011-10-19 15:11:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 0, 11 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126674542138626049",
  "geo" : { },
  "id_str" : "126676246825418754",
  "in_reply_to_user_id" : 67336993,
  "text" : "@TyrusBooks less than 10% print books",
  "id" : 126676246825418754,
  "in_reply_to_status_id" : 126674542138626049,
  "created_at" : "2011-10-19 15:09:05 +0000",
  "in_reply_to_screen_name" : "TyrusBooks",
  "in_reply_to_user_id_str" : "67336993",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole",
      "screen_name" : "carolesthought",
      "indices" : [ 3, 18 ],
      "id_str" : "8473622",
      "id" : 8473622
    }, {
      "name" : "NorthCountry Rambler",
      "screen_name" : "NCntryRambler",
      "indices" : [ 39, 53 ],
      "id_str" : "104981072",
      "id" : 104981072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126473862492856320",
  "text" : "RT @carolesthought: I love it, LOL! RT @NCntryRambler: My idea ~ Why don't we do this like American Idol & vote one candidate off the sh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "NorthCountry Rambler",
        "screen_name" : "NCntryRambler",
        "indices" : [ 19, 33 ],
        "id_str" : "104981072",
        "id" : 104981072
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126473056553152512",
    "text" : "I love it, LOL! RT @NCntryRambler: My idea ~ Why don't we do this like American Idol & vote one candidate off the show after each debate.",
    "id" : 126473056553152512,
    "created_at" : "2011-10-19 01:41:41 +0000",
    "user" : {
      "name" : "Carole",
      "screen_name" : "carolesthought",
      "protected" : false,
      "id_str" : "8473622",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580805790535036929\/jmab8LbB_normal.jpg",
      "id" : 8473622,
      "verified" : false
    }
  },
  "id" : 126473862492856320,
  "created_at" : "2011-10-19 01:44:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Barnett",
      "screen_name" : "planomike",
      "indices" : [ 3, 13 ],
      "id_str" : "22770373",
      "id" : 22770373
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126468518924398592",
  "text" : "RT @planomike: Sin is whatever obscures the soul. \n-Andre Gide",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126468199628804097",
    "text" : "Sin is whatever obscures the soul. \n-Andre Gide",
    "id" : 126468199628804097,
    "created_at" : "2011-10-19 01:22:23 +0000",
    "user" : {
      "name" : "Michael Barnett",
      "screen_name" : "planomike",
      "protected" : false,
      "id_str" : "22770373",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1201244218\/MichaelBarnett_normal.jpg",
      "id" : 22770373,
      "verified" : false
    }
  },
  "id" : 126468518924398592,
  "created_at" : "2011-10-19 01:23:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan H. Cohen",
      "screen_name" : "alanhcohen",
      "indices" : [ 3, 14 ],
      "id_str" : "84404420",
      "id" : 84404420
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126463549252968450",
  "text" : "RT @alanhcohen: Paradox is your point of power.   Embrace wholeness of life.  Let \"either\/or\" become \"both\/and.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "117713670020141057",
    "text" : "Paradox is your point of power.   Embrace wholeness of life.  Let \"either\/or\" become \"both\/and.\"",
    "id" : 117713670020141057,
    "created_at" : "2011-09-24 21:35:00 +0000",
    "user" : {
      "name" : "Alan H. Cohen",
      "screen_name" : "alanhcohen",
      "protected" : false,
      "id_str" : "84404420",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/484904745\/Alan_Cohen_head_shot_web_use_normal.jpg",
      "id" : 84404420,
      "verified" : false
    }
  },
  "id" : 126463549252968450,
  "created_at" : "2011-10-19 01:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126461515174920194",
  "text" : "RT @TyrusBooks: \"Blah blah blah...and a cavalry of rainbow unicorns to patrol the border and there'll be robots with nuclear lazer eyebe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cnndebate",
        "indices" : [ 128, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126460007582666752",
    "text" : "\"Blah blah blah...and a cavalry of rainbow unicorns to patrol the border and there'll be robots with nuclear lazer eyebeams...\" #cnndebate",
    "id" : 126460007582666752,
    "created_at" : "2011-10-19 00:49:49 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 126461515174920194,
  "created_at" : "2011-10-19 00:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126454112052187136",
  "text" : "RT @dhammagirl: Some days,  \n\nI just don't get it.\n\nBut a revelation is always sure to soon reveal itself ... just in time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126452597145088001",
    "text" : "Some days,  \n\nI just don't get it.\n\nBut a revelation is always sure to soon reveal itself ... just in time.",
    "id" : 126452597145088001,
    "created_at" : "2011-10-19 00:20:23 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 126454112052187136,
  "created_at" : "2011-10-19 00:26:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/7mLSQJFQ",
      "expanded_url" : "http:\/\/bit.ly\/rcRTRw",
      "display_url" : "bit.ly\/rcRTRw"
    } ]
  },
  "geo" : { },
  "id_str" : "126443972569739264",
  "text" : "I was prescribed a perfectly ordinary drug....for the treatment of a perfectly ordinary condition. http:\/\/t.co\/7mLSQJFQ",
  "id" : 126443972569739264,
  "created_at" : "2011-10-18 23:46:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Betcher",
      "screen_name" : "JohnBetcher",
      "indices" : [ 3, 15 ],
      "id_str" : "53730065",
      "id" : 53730065
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amwriting",
      "indices" : [ 102, 112 ]
    }, {
      "text" : "IAN1",
      "indices" : [ 113, 118 ]
    }, {
      "text" : "books",
      "indices" : [ 119, 125 ]
    }, {
      "text" : "book",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/arA0sliO",
      "expanded_url" : "http:\/\/selfpublishingcentral.blogspot.com\/2011\/10\/book-giveaways.html",
      "display_url" : "selfpublishingcentral.blogspot.com\/2011\/10\/book-g\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126438368480477185",
  "text" : "RT @JohnBetcher: PLS RT: NEW POST - \"Book Giveaways\" at Self-Publishing Central. http:\/\/t.co\/arA0sliO #amwriting #IAN1 #books #book #rea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amwriting",
        "indices" : [ 85, 95 ]
      }, {
        "text" : "IAN1",
        "indices" : [ 96, 101 ]
      }, {
        "text" : "books",
        "indices" : [ 102, 108 ]
      }, {
        "text" : "book",
        "indices" : [ 109, 114 ]
      }, {
        "text" : "reading",
        "indices" : [ 115, 123 ]
      }, {
        "text" : "selfpub",
        "indices" : [ 124, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 64, 84 ],
        "url" : "http:\/\/t.co\/arA0sliO",
        "expanded_url" : "http:\/\/selfpublishingcentral.blogspot.com\/2011\/10\/book-giveaways.html",
        "display_url" : "selfpublishingcentral.blogspot.com\/2011\/10\/book-g\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "126435065382182913",
    "text" : "PLS RT: NEW POST - \"Book Giveaways\" at Self-Publishing Central. http:\/\/t.co\/arA0sliO #amwriting #IAN1 #books #book #reading #selfpub",
    "id" : 126435065382182913,
    "created_at" : "2011-10-18 23:10:43 +0000",
    "user" : {
      "name" : "John Betcher",
      "screen_name" : "JohnBetcher",
      "protected" : false,
      "id_str" : "53730065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740262527\/John_Grand_Canyon_normal.jpg",
      "id" : 53730065,
      "verified" : false
    }
  },
  "id" : 126438368480477185,
  "created_at" : "2011-10-18 23:23:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126427574564945921",
  "text" : "RT @BerThePinkBunny: A truck carrying copies of Roget`s thesaurus overturned on the highway. Onlookers were `stunned, astonished, bewild ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126426312649867265",
    "text" : "A truck carrying copies of Roget`s thesaurus overturned on the highway. Onlookers were `stunned, astonished, bewildered and overwhelmed`",
    "id" : 126426312649867265,
    "created_at" : "2011-10-18 22:35:56 +0000",
    "user" : {
      "name" : "Bernadette Woodlands",
      "screen_name" : "Ber_TheWoods",
      "protected" : false,
      "id_str" : "206906021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472812338135842816\/KvYZ23-V_normal.jpeg",
      "id" : 206906021,
      "verified" : false
    }
  },
  "id" : 126427574564945921,
  "created_at" : "2011-10-18 22:40:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126403267017179138",
  "geo" : { },
  "id_str" : "126408417261780992",
  "in_reply_to_user_id" : 113483630,
  "text" : "@NelsonFiction christened in Denmark",
  "id" : 126408417261780992,
  "in_reply_to_status_id" : 126403267017179138,
  "created_at" : "2011-10-18 21:24:49 +0000",
  "in_reply_to_screen_name" : "TNZFiction",
  "in_reply_to_user_id_str" : "113483630",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126379126880870400",
  "geo" : { },
  "id_str" : "126402757233098752",
  "in_reply_to_user_id" : 113483630,
  "text" : "@NelsonFiction baptism in Denmark",
  "id" : 126402757233098752,
  "in_reply_to_status_id" : 126379126880870400,
  "created_at" : "2011-10-18 21:02:20 +0000",
  "in_reply_to_screen_name" : "TNZFiction",
  "in_reply_to_user_id_str" : "113483630",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 12, 24 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126390571664281600",
  "geo" : { },
  "id_str" : "126391038150578176",
  "in_reply_to_user_id" : 16691399,
  "text" : "cool beans! @fearfuldogs",
  "id" : 126391038150578176,
  "in_reply_to_status_id" : 126390571664281600,
  "created_at" : "2011-10-18 20:15:46 +0000",
  "in_reply_to_screen_name" : "fearfuldogs",
  "in_reply_to_user_id_str" : "16691399",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126379126880870400",
  "geo" : { },
  "id_str" : "126384846581923840",
  "in_reply_to_user_id" : 113483630,
  "text" : "@NelsonFiction baptised",
  "id" : 126384846581923840,
  "in_reply_to_status_id" : 126379126880870400,
  "created_at" : "2011-10-18 19:51:10 +0000",
  "in_reply_to_screen_name" : "TNZFiction",
  "in_reply_to_user_id_str" : "113483630",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "indices" : [ 3, 14 ],
      "id_str" : "385240011",
      "id" : 385240011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126383919447818240",
  "text" : "RT @newordsnow: Anti-immigration debate tonight. Who can be more insane.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126380679591235584",
    "text" : "Anti-immigration debate tonight. Who can be more insane.",
    "id" : 126380679591235584,
    "created_at" : "2011-10-18 19:34:36 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "protected" : false,
      "id_str" : "385240011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1579459848\/images_normal.jpg",
      "id" : 385240011,
      "verified" : false
    }
  },
  "id" : 126383919447818240,
  "created_at" : "2011-10-18 19:47:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 4, 19 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126382269232447488",
  "geo" : { },
  "id_str" : "126383759581921280",
  "in_reply_to_user_id" : 104029814,
  "text" : "and @stream_enterer how far has it got them...",
  "id" : 126383759581921280,
  "in_reply_to_status_id" : 126382269232447488,
  "created_at" : "2011-10-18 19:46:51 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126383637619945472",
  "text" : "then @SamsaricWarrior WTH do I drink out of?",
  "id" : 126383637619945472,
  "created_at" : "2011-10-18 19:46:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126370192518418433",
  "geo" : { },
  "id_str" : "126370843965140993",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell my gmail seems to work. if I try to send email from a web page it usually does not go through.",
  "id" : 126370843965140993,
  "in_reply_to_status_id" : 126370192518418433,
  "created_at" : "2011-10-18 18:55:31 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126357553587306496",
  "text" : "tired of living w sick stomach...",
  "id" : 126357553587306496,
  "created_at" : "2011-10-18 18:02:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126352147079102465",
  "text" : "the world is not black & white. the world is subjectively perceived by each individual. objective is not possible.",
  "id" : 126352147079102465,
  "created_at" : "2011-10-18 17:41:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126351133911429120",
  "text" : "People want answers.. but guess what? There are none.",
  "id" : 126351133911429120,
  "created_at" : "2011-10-18 17:37:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 10, 19 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126339890932760577",
  "geo" : { },
  "id_str" : "126341329054736384",
  "in_reply_to_user_id" : 14986977,
  "text" : "right now @Teawench I think the whole world is an arrogant ass! sigh",
  "id" : 126341329054736384,
  "in_reply_to_status_id" : 126339890932760577,
  "created_at" : "2011-10-18 16:58:14 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126338123788595200",
  "text" : "RT @morsemusings: You could do NOTHING, assume no LABEL or TITLE and YOU would still be loved -- try it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126337869131423744",
    "text" : "You could do NOTHING, assume no LABEL or TITLE and YOU would still be loved -- try it!",
    "id" : 126337869131423744,
    "created_at" : "2011-10-18 16:44:29 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 126338123788595200,
  "created_at" : "2011-10-18 16:45:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126337677380423681",
  "text" : "btw: does not matter WHO is POTUS.. repub or dem. Politics is all a game.. and it's rigged.",
  "id" : 126337677380423681,
  "created_at" : "2011-10-18 16:43:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126337107559063552",
  "text" : "There is NO winner, ppl!! We all go up or we all go down together.",
  "id" : 126337107559063552,
  "created_at" : "2011-10-18 16:41:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126335841164472321",
  "text" : "Lord, plz help me understand WHY you have me going to bible study. I know lesson in there somewhere.",
  "id" : 126335841164472321,
  "created_at" : "2011-10-18 16:36:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126335594858160128",
  "text" : "no witch or devil costumes.. sigh.",
  "id" : 126335594858160128,
  "created_at" : "2011-10-18 16:35:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126335295967870976",
  "text" : "too much tolerance?? sigh.",
  "id" : 126335295967870976,
  "created_at" : "2011-10-18 16:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126335057915949057",
  "text" : "last week, atheists.. this week, gays.. sigh.",
  "id" : 126335057915949057,
  "created_at" : "2011-10-18 16:33:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arnulfo Wetmore",
      "screen_name" : "ArnulfoWetmore",
      "indices" : [ 16, 31 ],
      "id_str" : "147775330",
      "id" : 147775330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126090882767273984",
  "text" : "RT @betsdew: RT @ArnulfoWetmore: I feel sorry for the man who can&#39;t feel the whip when it is laid on the other man&#39;s back. -Abra ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arnulfo Wetmore",
        "screen_name" : "ArnulfoWetmore",
        "indices" : [ 3, 18 ],
        "id_str" : "147775330",
        "id" : 147775330
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126090245375664128",
    "text" : "RT @ArnulfoWetmore: I feel sorry for the man who can&#39;t feel the whip when it is laid on the other man&#39;s back. -Abraham Lincoln",
    "id" : 126090245375664128,
    "created_at" : "2011-10-18 00:20:31 +0000",
    "user" : {
      "name" : "Betsy Dewey",
      "screen_name" : "BetsyDeweyTX",
      "protected" : false,
      "id_str" : "302720798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3198644348\/e84631196962da998e22f720ca7d3a6f_normal.jpeg",
      "id" : 302720798,
      "verified" : false
    }
  },
  "id" : 126090882767273984,
  "created_at" : "2011-10-18 00:23:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 0, 12 ],
      "id_str" : "118573185",
      "id" : 118573185
    }, {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 13, 21 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "126077640829444096",
  "geo" : { },
  "id_str" : "126078555598766080",
  "in_reply_to_user_id" : 118573185,
  "text" : "@CoyoteSings @SangyeH \u2665 (((grouphug))) \u2665",
  "id" : 126078555598766080,
  "in_reply_to_status_id" : 126077640829444096,
  "created_at" : "2011-10-17 23:34:04 +0000",
  "in_reply_to_screen_name" : "CoyoteSings",
  "in_reply_to_user_id_str" : "118573185",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squirrelers",
      "screen_name" : "squirrelers",
      "indices" : [ 3, 15 ],
      "id_str" : "81271026",
      "id" : 81271026
    }, {
      "name" : "moneycrush",
      "screen_name" : "moneycrush",
      "indices" : [ 73, 84 ],
      "id_str" : "28649627",
      "id" : 28649627
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "passsiveincome",
      "indices" : [ 85, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/Lc7jmjsx",
      "expanded_url" : "http:\/\/bit.ly\/qQznzZ",
      "display_url" : "bit.ly\/qQznzZ"
    } ]
  },
  "geo" : { },
  "id_str" : "126072603831050240",
  "text" : "RT @squirrelers: Passive Income Ideas That Work http:\/\/t.co\/Lc7jmjsx via @moneycrush #passsiveincome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twuffer.com\" rel=\"nofollow\"\u003ETwuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "moneycrush",
        "screen_name" : "moneycrush",
        "indices" : [ 56, 67 ],
        "id_str" : "28649627",
        "id" : 28649627
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "passsiveincome",
        "indices" : [ 68, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/Lc7jmjsx",
        "expanded_url" : "http:\/\/bit.ly\/qQznzZ",
        "display_url" : "bit.ly\/qQznzZ"
      } ]
    },
    "geo" : { },
    "id_str" : "126068983119097856",
    "text" : "Passive Income Ideas That Work http:\/\/t.co\/Lc7jmjsx via @moneycrush #passsiveincome",
    "id" : 126068983119097856,
    "created_at" : "2011-10-17 22:56:02 +0000",
    "user" : {
      "name" : "Squirrelers",
      "screen_name" : "squirrelers",
      "protected" : false,
      "id_str" : "81271026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000692289347\/713c68cde56c1159488f334a769708f8_normal.png",
      "id" : 81271026,
      "verified" : false
    }
  },
  "id" : 126072603831050240,
  "created_at" : "2011-10-17 23:10:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "fransiska damayanti",
      "screen_name" : "sien1975",
      "indices" : [ 24, 33 ],
      "id_str" : "160793314",
      "id" : 160793314
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Photography",
      "indices" : [ 86, 98 ]
    }, {
      "text" : "portraiture",
      "indices" : [ 99, 111 ]
    }, {
      "text" : "nature",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "water",
      "indices" : [ 120, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 65, 85 ],
      "url" : "http:\/\/t.co\/b6zrNNbK",
      "expanded_url" : "http:\/\/www.thedesignwork.com\/amazing-photos-of-reflection-and-mirror-photography\/",
      "display_url" : "thedesignwork.com\/amazing-photos\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126070312671510529",
  "text" : "RT @KerriFar: Wowza! RT @sien1975: Amazing photos of reflections http:\/\/t.co\/b6zrNNbK #Photography #portraiture #nature #water |RT @pene ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.handmark.com\" rel=\"nofollow\"\u003ETweetCaster for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "fransiska damayanti",
        "screen_name" : "sien1975",
        "indices" : [ 10, 19 ],
        "id_str" : "160793314",
        "id" : 160793314
      }, {
        "name" : "penelope beveridge",
        "screen_name" : "penelopephoto",
        "indices" : [ 117, 131 ],
        "id_str" : "35657867",
        "id" : 35657867
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Photography",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "portraiture",
        "indices" : [ 85, 97 ]
      }, {
        "text" : "nature",
        "indices" : [ 98, 105 ]
      }, {
        "text" : "water",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/b6zrNNbK",
        "expanded_url" : "http:\/\/www.thedesignwork.com\/amazing-photos-of-reflection-and-mirror-photography\/",
        "display_url" : "thedesignwork.com\/amazing-photos\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "126069616261873664",
    "text" : "Wowza! RT @sien1975: Amazing photos of reflections http:\/\/t.co\/b6zrNNbK #Photography #portraiture #nature #water |RT @penelopephoto",
    "id" : 126069616261873664,
    "created_at" : "2011-10-17 22:58:33 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 126070312671510529,
  "created_at" : "2011-10-17 23:01:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tim Ward",
      "screen_name" : "timothycward",
      "indices" : [ 3, 16 ],
      "id_str" : "154909956",
      "id" : 154909956
    }, {
      "name" : "One Buck Horror",
      "screen_name" : "OneBuckHorror",
      "indices" : [ 36, 50 ],
      "id_str" : "276631087",
      "id" : 276631087
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OneBuckZombieHorde",
      "indices" : [ 85, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/Vy8dSoT7",
      "expanded_url" : "http:\/\/www.audiotim.com",
      "display_url" : "audiotim.com"
    }, {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/0roRmS1K",
      "expanded_url" : "http:\/\/www.onebuckhorror.com\/horde",
      "display_url" : "onebuckhorror.com\/horde"
    } ]
  },
  "geo" : { },
  "id_str" : "126028468847779840",
  "text" : "RT @timothycward: My interview with @OneBuckHorror is now up on http:\/\/t.co\/Vy8dSoT7 #OneBuckZombieHorde http:\/\/t.co\/0roRmS1K - RT for e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "One Buck Horror",
        "screen_name" : "OneBuckHorror",
        "indices" : [ 18, 32 ],
        "id_str" : "276631087",
        "id" : 276631087
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OneBuckZombieHorde",
        "indices" : [ 67, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/Vy8dSoT7",
        "expanded_url" : "http:\/\/www.audiotim.com",
        "display_url" : "audiotim.com"
      }, {
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/0roRmS1K",
        "expanded_url" : "http:\/\/www.onebuckhorror.com\/horde",
        "display_url" : "onebuckhorror.com\/horde"
      } ]
    },
    "geo" : { },
    "id_str" : "125435792188387329",
    "text" : "My interview with @OneBuckHorror is now up on http:\/\/t.co\/Vy8dSoT7 #OneBuckZombieHorde http:\/\/t.co\/0roRmS1K - RT for ebook giveaway",
    "id" : 125435792188387329,
    "created_at" : "2011-10-16 04:59:58 +0000",
    "user" : {
      "name" : "Tim Ward",
      "screen_name" : "timothycward",
      "protected" : false,
      "id_str" : "154909956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/722458535838224384\/JeVRuA50_normal.jpg",
      "id" : 154909956,
      "verified" : false
    }
  },
  "id" : 126028468847779840,
  "created_at" : "2011-10-17 20:15:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126024577703878656",
  "text" : "RT @CrystalLewis: People will argue over the smallest and stupidest things. Don't believe me? Read the comments on ANY YouTube video.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "126023839372152832",
    "text" : "People will argue over the smallest and stupidest things. Don't believe me? Read the comments on ANY YouTube video.",
    "id" : 126023839372152832,
    "created_at" : "2011-10-17 19:56:39 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 126024577703878656,
  "created_at" : "2011-10-17 19:59:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matt Quinn",
      "screen_name" : "poemblaze",
      "indices" : [ 3, 13 ],
      "id_str" : "114232355",
      "id" : 114232355
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupywallstreet",
      "indices" : [ 82, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/oQRz9yFt",
      "expanded_url" : "http:\/\/www.dailykos.com\/story\/2011\/10\/13\/1025978\/-Not-Part-of-the-99-Youre-Fooling-Yourself",
      "display_url" : "dailykos.com\/story\/2011\/10\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "126023442788139010",
  "text" : "RT @poemblaze: for those who say they aren't part of the 99% http:\/\/t.co\/oQRz9yFt #occupywallstreet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupywallstreet",
        "indices" : [ 67, 84 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/oQRz9yFt",
        "expanded_url" : "http:\/\/www.dailykos.com\/story\/2011\/10\/13\/1025978\/-Not-Part-of-the-99-Youre-Fooling-Yourself",
        "display_url" : "dailykos.com\/story\/2011\/10\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "126022221041897472",
    "text" : "for those who say they aren't part of the 99% http:\/\/t.co\/oQRz9yFt #occupywallstreet",
    "id" : 126022221041897472,
    "created_at" : "2011-10-17 19:50:13 +0000",
    "user" : {
      "name" : "Matt Quinn",
      "screen_name" : "poemblaze",
      "protected" : false,
      "id_str" : "114232355",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771370130898944000\/UHCpJF-N_normal.jpg",
      "id" : 114232355,
      "verified" : false
    }
  },
  "id" : 126023442788139010,
  "created_at" : "2011-10-17 19:55:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "126018865623863298",
  "text" : "I was born wearing rose colored glasses..lol.. and over my dead body will they be removed! : )",
  "id" : 126018865623863298,
  "created_at" : "2011-10-17 19:36:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125720350267949056",
  "geo" : { },
  "id_str" : "126017568690544640",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad focus on the ppl that bring joy and you will see more of them. dont give up!",
  "id" : 126017568690544640,
  "in_reply_to_status_id" : 125720350267949056,
  "created_at" : "2011-10-17 19:31:44 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125986310509957121",
  "text" : "RT @SpiritualNurse: Every decision I make  is a choice between a grievance and a miracle. ~ Deepak Chopra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125985807734546433",
    "text" : "Every decision I make  is a choice between a grievance and a miracle. ~ Deepak Chopra",
    "id" : 125985807734546433,
    "created_at" : "2011-10-17 17:25:31 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 125986310509957121,
  "created_at" : "2011-10-17 17:27:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125985231080669186",
  "geo" : { },
  "id_str" : "125986195892207616",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver does sweet Henry cat come with the soup? ; )",
  "id" : 125986195892207616,
  "in_reply_to_status_id" : 125985231080669186,
  "created_at" : "2011-10-17 17:27:04 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125975285911920643",
  "geo" : { },
  "id_str" : "125975876478312448",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal so glad to hear! : )",
  "id" : 125975876478312448,
  "in_reply_to_status_id" : 125975285911920643,
  "created_at" : "2011-10-17 16:46:04 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shift",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/Wf3kdZpi",
      "expanded_url" : "http:\/\/bit.ly\/aUvZhe",
      "display_url" : "bit.ly\/aUvZhe"
    } ]
  },
  "geo" : { },
  "id_str" : "125974060940263425",
  "text" : "RT @TracyLatz: You can't fly unless you drop anchor on the beliefs that weigh you down!  #shift http:\/\/t.co\/Wf3kdZpi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "shift",
        "indices" : [ 74, 80 ]
      } ],
      "urls" : [ {
        "indices" : [ 81, 101 ],
        "url" : "http:\/\/t.co\/Wf3kdZpi",
        "expanded_url" : "http:\/\/bit.ly\/aUvZhe",
        "display_url" : "bit.ly\/aUvZhe"
      } ]
    },
    "geo" : { },
    "id_str" : "125973815384743936",
    "text" : "You can't fly unless you drop anchor on the beliefs that weigh you down!  #shift http:\/\/t.co\/Wf3kdZpi",
    "id" : 125973815384743936,
    "created_at" : "2011-10-17 16:37:52 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 125974060940263425,
  "created_at" : "2011-10-17 16:38:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125948083107409920",
  "geo" : { },
  "id_str" : "125973967084322816",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott nature & animals have provided me with many clues & inspiration. also reading books. get lots of aha's.",
  "id" : 125973967084322816,
  "in_reply_to_status_id" : 125948083107409920,
  "created_at" : "2011-10-17 16:38:28 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125973592725929985",
  "text" : "@SamsaricWarrior I feel like the cool kid now, thx! ; )",
  "id" : 125973592725929985,
  "created_at" : "2011-10-17 16:36:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/125967799075082240\/photo\/1",
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/kzJVuZPe",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ab-HC71CEAE_srb.jpg",
      "id_str" : "125967799079276545",
      "id" : 125967799079276545,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ab-HC71CEAE_srb.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 765,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/kzJVuZPe"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125970673553252353",
  "text" : "RT @petsalive: Darby the mini horse has arrived! http:\/\/t.co\/kzJVuZPe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/petsalive\/status\/125967799075082240\/photo\/1",
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/kzJVuZPe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ab-HC71CEAE_srb.jpg",
        "id_str" : "125967799079276545",
        "id" : 125967799079276545,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ab-HC71CEAE_srb.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 765,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/kzJVuZPe"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125967799075082240",
    "text" : "Darby the mini horse has arrived! http:\/\/t.co\/kzJVuZPe",
    "id" : 125967799075082240,
    "created_at" : "2011-10-17 16:13:59 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 125970673553252353,
  "created_at" : "2011-10-17 16:25:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125962300011200512",
  "geo" : { },
  "id_str" : "125963663805915136",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves I'll take your word for it..lol ; )",
  "id" : 125963663805915136,
  "in_reply_to_status_id" : 125962300011200512,
  "created_at" : "2011-10-17 15:57:32 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Jenny Winder))) \u2605",
      "screen_name" : "astrojenny",
      "indices" : [ 3, 14 ],
      "id_str" : "36886619",
      "id" : 36886619
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/BfTYtpr8",
      "expanded_url" : "http:\/\/ow.ly\/6ZJ4h",
      "display_url" : "ow.ly\/6ZJ4h"
    } ]
  },
  "geo" : { },
  "id_str" : "125963540430471168",
  "text" : "RT @astrojenny: Ancient 13-Billion-Year-Old Galaxies Observed by VLT \"Time Machine\" http:\/\/t.co\/BfTYtpr8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/BfTYtpr8",
        "expanded_url" : "http:\/\/ow.ly\/6ZJ4h",
        "display_url" : "ow.ly\/6ZJ4h"
      } ]
    },
    "geo" : { },
    "id_str" : "125959601484079105",
    "text" : "Ancient 13-Billion-Year-Old Galaxies Observed by VLT \"Time Machine\" http:\/\/t.co\/BfTYtpr8",
    "id" : 125959601484079105,
    "created_at" : "2011-10-17 15:41:23 +0000",
    "user" : {
      "name" : "(((Jenny Winder))) \u2605",
      "screen_name" : "astrojenny",
      "protected" : false,
      "id_str" : "36886619",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743081230376312832\/DT2WK0Kt_normal.jpg",
      "id" : 36886619,
      "verified" : false
    }
  },
  "id" : 125963540430471168,
  "created_at" : "2011-10-17 15:57:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DeadEndFiction",
      "screen_name" : "DeadEndFiction",
      "indices" : [ 3, 18 ],
      "id_str" : "129790203",
      "id" : 129790203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125958977111588864",
  "text" : "RT @DeadEndFiction: The priest slouched on his sofa, his parish overrun with possessions. Demons grew like fat on his belly. He needed t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125958703479390208",
    "text" : "The priest slouched on his sofa, his parish overrun with possessions. Demons grew like fat on his belly. He needed to get out and exorcise.",
    "id" : 125958703479390208,
    "created_at" : "2011-10-17 15:37:49 +0000",
    "user" : {
      "name" : "DeadEndFiction",
      "screen_name" : "DeadEndFiction",
      "protected" : false,
      "id_str" : "129790203",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1156140184\/tree-halloween_normal.jpg",
      "id" : 129790203,
      "verified" : false
    }
  },
  "id" : 125958977111588864,
  "created_at" : "2011-10-17 15:38:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 43, 48 ]
    }, {
      "text" : "politics",
      "indices" : [ 49, 58 ]
    }, {
      "text" : "religion",
      "indices" : [ 59, 68 ]
    }, {
      "text" : "occupy",
      "indices" : [ 69, 76 ]
    }, {
      "text" : "ows",
      "indices" : [ 77, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125957032724537345",
  "text" : "RT @ReverendSue: Hating creates more hate. #LGBT #politics #religion #occupy #ows",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBT",
        "indices" : [ 26, 31 ]
      }, {
        "text" : "politics",
        "indices" : [ 32, 41 ]
      }, {
        "text" : "religion",
        "indices" : [ 42, 51 ]
      }, {
        "text" : "occupy",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "ows",
        "indices" : [ 60, 64 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125956604574187520",
    "text" : "Hating creates more hate. #LGBT #politics #religion #occupy #ows",
    "id" : 125956604574187520,
    "created_at" : "2011-10-17 15:29:29 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 125957032724537345,
  "created_at" : "2011-10-17 15:31:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125956922070401025",
  "text" : "#ows is not about taking from rich to give to poor. its about not making it impossible 4 ppl to live decently.",
  "id" : 125956922070401025,
  "created_at" : "2011-10-17 15:30:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 24, 35 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 36, 51 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 52, 62 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125953477011705856",
  "text" : "thanks for comments : ) @TrishScott @MartijnLinssen @bend_time",
  "id" : 125953477011705856,
  "created_at" : "2011-10-17 15:17:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125945728433528833",
  "text" : "Had I gone to college, I would have studied psychology and \/ or sciences. very curious about the mind & the world.",
  "id" : 125945728433528833,
  "created_at" : "2011-10-17 14:46:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125945266380611584",
  "text" : "some ppl, @SamsaricWarrior , become so attached to that identity, they dont know how to let go of past.",
  "id" : 125945266380611584,
  "created_at" : "2011-10-17 14:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OutlawPreachers",
      "indices" : [ 104, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125944508792848385",
  "text" : "RT @bcmouser: We may not be able to choose our circumstances, but we are able to choose our responses.\n\n#OutlawPreachers",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OutlawPreachers",
        "indices" : [ 90, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125940913263493120",
    "text" : "We may not be able to choose our circumstances, but we are able to choose our responses.\n\n#OutlawPreachers",
    "id" : 125940913263493120,
    "created_at" : "2011-10-17 14:27:08 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 125944508792848385,
  "created_at" : "2011-10-17 14:41:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/8BLa5kuG",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com\/",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "125943138564059136",
  "text" : "http:\/\/t.co\/8BLa5kuG - comments welcome on my blog : )",
  "id" : 125943138564059136,
  "created_at" : "2011-10-17 14:35:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    }, {
      "name" : "Kathleen Sharp",
      "screen_name" : "KSharpAuthor",
      "indices" : [ 70, 83 ],
      "id_str" : "87031480",
      "id" : 87031480
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/zMLyv9ur",
      "expanded_url" : "http:\/\/ow.ly\/6ZAeP",
      "display_url" : "ow.ly\/6ZAeP"
    } ]
  },
  "geo" : { },
  "id_str" : "125940982238810113",
  "text" : "RT @DuttonBooks: Medical Consumers features a review of BLOOD FEUD by @KSharpAuthor --a \"horrifying\" true story: http:\/\/t.co\/zMLyv9ur",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kathleen Sharp",
        "screen_name" : "KSharpAuthor",
        "indices" : [ 53, 66 ],
        "id_str" : "87031480",
        "id" : 87031480
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/zMLyv9ur",
        "expanded_url" : "http:\/\/ow.ly\/6ZAeP",
        "display_url" : "ow.ly\/6ZAeP"
      } ]
    },
    "geo" : { },
    "id_str" : "125939199911268352",
    "text" : "Medical Consumers features a review of BLOOD FEUD by @KSharpAuthor --a \"horrifying\" true story: http:\/\/t.co\/zMLyv9ur",
    "id" : 125939199911268352,
    "created_at" : "2011-10-17 14:20:19 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 125940982238810113,
  "created_at" : "2011-10-17 14:27:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125940160989888512",
  "text" : "letting myself get drawn into negativity. time to turn around! lol",
  "id" : 125940160989888512,
  "created_at" : "2011-10-17 14:24:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125939589746671617",
  "text" : "learning I need to let ppl be",
  "id" : 125939589746671617,
  "created_at" : "2011-10-17 14:21:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 0, 10 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125937571334340609",
  "geo" : { },
  "id_str" : "125938836952985600",
  "in_reply_to_user_id" : 28136330,
  "text" : "@sandalgal god bless, hope you get some answers.",
  "id" : 125938836952985600,
  "in_reply_to_status_id" : 125937571334340609,
  "created_at" : "2011-10-17 14:18:53 +0000",
  "in_reply_to_screen_name" : "sandalgal",
  "in_reply_to_user_id_str" : "28136330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "movefearlessly",
      "screen_name" : "movefearlessly",
      "indices" : [ 3, 18 ],
      "id_str" : "16274867",
      "id" : 16274867
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125719519166603265",
  "text" : "RT @movefearlessly: The love of liberty is the love of others; the love of power is the love of ourselves. ~ William Hazlitt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125719045495459840",
    "text" : "The love of liberty is the love of others; the love of power is the love of ourselves. ~ William Hazlitt",
    "id" : 125719045495459840,
    "created_at" : "2011-10-16 23:45:30 +0000",
    "user" : {
      "name" : "movefearlessly",
      "screen_name" : "movefearlessly",
      "protected" : false,
      "id_str" : "16274867",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1391906844\/me10_normal.jpg",
      "id" : 16274867,
      "verified" : false
    }
  },
  "id" : 125719519166603265,
  "created_at" : "2011-10-16 23:47:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125714025731469312",
  "geo" : { },
  "id_str" : "125714903557341184",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater awwww.. smooches to the kitty. looks like my ghosty (rip)",
  "id" : 125714903557341184,
  "in_reply_to_status_id" : 125714025731469312,
  "created_at" : "2011-10-16 23:29:03 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125713818105028609",
  "text" : "bleh.. stomach off just a bit. amazing how it saps my will to live.",
  "id" : 125713818105028609,
  "created_at" : "2011-10-16 23:24:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125711858261966848",
  "geo" : { },
  "id_str" : "125712930430926851",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver i'd love to steal Henry \u2665 purrrrrrr",
  "id" : 125712930430926851,
  "in_reply_to_status_id" : 125711858261966848,
  "created_at" : "2011-10-16 23:21:12 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "shelby fero",
      "screen_name" : "shelbyfero",
      "indices" : [ 15, 26 ],
      "id_str" : "35097545",
      "id" : 35097545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125703732590690305",
  "text" : "RT @BestAt: RT @shelbyfero: 6 BILLION people on Earth and I'm me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "shelby fero",
        "screen_name" : "shelbyfero",
        "indices" : [ 3, 14 ],
        "id_str" : "35097545",
        "id" : 35097545
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125702764880855040",
    "text" : "RT @shelbyfero: 6 BILLION people on Earth and I'm me.",
    "id" : 125702764880855040,
    "created_at" : "2011-10-16 22:40:49 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 125703732590690305,
  "created_at" : "2011-10-16 22:44:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125694280672088064",
  "text" : "RT @oshum: We ALL ARE \u2026. looking through the Eyes of God.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125687955988815872",
    "text" : "We ALL ARE \u2026. looking through the Eyes of God.",
    "id" : 125687955988815872,
    "created_at" : "2011-10-16 21:41:58 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 125694280672088064,
  "created_at" : "2011-10-16 22:07:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125672165885489153",
  "text" : "hey @SamsaricWarrior I like how you wave at end of vid ((wavesback))",
  "id" : 125672165885489153,
  "created_at" : "2011-10-16 20:39:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125662136994238465",
  "text" : "RT @gemswinc: Portugal has decriminalized drug use & treats addiction as a health problem. It works. Drug \"wars\" are a futile waste of l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125660046695739392",
    "text" : "Portugal has decriminalized drug use & treats addiction as a health problem. It works. Drug \"wars\" are a futile waste of lives & resources",
    "id" : 125660046695739392,
    "created_at" : "2011-10-16 19:51:04 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 125662136994238465,
  "created_at" : "2011-10-16 19:59:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125658197427101697",
  "text" : "RT @abe_quotes: ...because we know when you do it your reality will flip.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125657959438090240",
    "text" : "...because we know when you do it your reality will flip.",
    "id" : 125657959438090240,
    "created_at" : "2011-10-16 19:42:46 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 125658197427101697,
  "created_at" : "2011-10-16 19:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125658181866229760",
  "text" : "RT @abe_quotes: We're asking u to ignore the reality that's had nearly your undivided attention and to hang your star on your emotions f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125657953935179776",
    "text" : "We're asking u to ignore the reality that's had nearly your undivided attention and to hang your star on your emotions for a little while...",
    "id" : 125657953935179776,
    "created_at" : "2011-10-16 19:42:45 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 125658181866229760,
  "created_at" : "2011-10-16 19:43:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "indices" : [ 3, 14 ],
      "id_str" : "26042748",
      "id" : 26042748
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AbrahamHicks",
      "indices" : [ 87, 100 ]
    }, {
      "text" : "Abraham",
      "indices" : [ 101, 109 ]
    }, {
      "text" : "Hicks",
      "indices" : [ 110, 116 ]
    }, {
      "text" : "LoA",
      "indices" : [ 117, 121 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125658168264110080",
  "text" : "RT @abe_quotes: Faith is finding the vibration without the evidence that backs it up.\n\n#AbrahamHicks #Abraham #Hicks #LoA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETweetie for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AbrahamHicks",
        "indices" : [ 71, 84 ]
      }, {
        "text" : "Abraham",
        "indices" : [ 85, 93 ]
      }, {
        "text" : "Hicks",
        "indices" : [ 94, 100 ]
      }, {
        "text" : "LoA",
        "indices" : [ 101, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125657783357014017",
    "text" : "Faith is finding the vibration without the evidence that backs it up.\n\n#AbrahamHicks #Abraham #Hicks #LoA",
    "id" : 125657783357014017,
    "created_at" : "2011-10-16 19:42:04 +0000",
    "user" : {
      "name" : "abraham hicks quotes",
      "screen_name" : "abe_quotes",
      "protected" : false,
      "id_str" : "26042748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3193947469\/8ba56aa53308e0bacf84a83ac52fc7cc_normal.jpeg",
      "id" : 26042748,
      "verified" : false
    }
  },
  "id" : 125658168264110080,
  "created_at" : "2011-10-16 19:43:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125657253889056769",
  "text" : "RT @DarciaHelle: 111,111,111 x 111,111,111 = 12,345,678,987,654,321",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125655339390615553",
    "text" : "111,111,111 x 111,111,111 = 12,345,678,987,654,321",
    "id" : 125655339390615553,
    "created_at" : "2011-10-16 19:32:22 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 125657253889056769,
  "created_at" : "2011-10-16 19:39:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125654670784991232",
  "text" : "RT @TheEntertainer: Love, that is all. Now go love someone dammit! :-)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125653926413475840",
    "text" : "Love, that is all. Now go love someone dammit! :-)",
    "id" : 125653926413475840,
    "created_at" : "2011-10-16 19:26:45 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 125654670784991232,
  "created_at" : "2011-10-16 19:29:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nature on PBS",
      "screen_name" : "PBSNature",
      "indices" : [ 3, 13 ],
      "id_str" : "10915142",
      "id" : 10915142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/Yn3Ocv2g",
      "expanded_url" : "http:\/\/ow.ly\/6XOn7",
      "display_url" : "ow.ly\/6XOn7"
    } ]
  },
  "geo" : { },
  "id_str" : "125654367415189504",
  "text" : "RT @PBSNature: Crows are members of the Corvidae family, which also includes ravens, magpies, and blue jays. http:\/\/t.co\/Yn3Ocv2g A Murd ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/Yn3Ocv2g",
        "expanded_url" : "http:\/\/ow.ly\/6XOn7",
        "display_url" : "ow.ly\/6XOn7"
      } ]
    },
    "geo" : { },
    "id_str" : "124941336544677888",
    "text" : "Crows are members of the Corvidae family, which also includes ravens, magpies, and blue jays. http:\/\/t.co\/Yn3Ocv2g A Murder of Crows 10\/16",
    "id" : 124941336544677888,
    "created_at" : "2011-10-14 20:15:10 +0000",
    "user" : {
      "name" : "Nature on PBS",
      "screen_name" : "PBSNature",
      "protected" : false,
      "id_str" : "10915142",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/461201605447016448\/NffLTWPK_normal.jpeg",
      "id" : 10915142,
      "verified" : true
    }
  },
  "id" : 125654367415189504,
  "created_at" : "2011-10-16 19:28:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125653773233299456",
  "text" : "RT @SpiritualNurse: Take the first step in faith. You don't have to see the whole staircase, just take the first step. - Martin Luther K ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125650977104723968",
    "text" : "Take the first step in faith. You don't have to see the whole staircase, just take the first step. - Martin Luther King Jr.",
    "id" : 125650977104723968,
    "created_at" : "2011-10-16 19:15:02 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 125653773233299456,
  "created_at" : "2011-10-16 19:26:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125646121686151168",
  "geo" : { },
  "id_str" : "125653115595792385",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny they are too entrenched in literal bible to understand. it's a fear to step into grey area so stay w\/in black\/white.",
  "id" : 125653115595792385,
  "in_reply_to_status_id" : 125646121686151168,
  "created_at" : "2011-10-16 19:23:31 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125634520358719489",
  "geo" : { },
  "id_str" : "125636249439571968",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth yes, I can see the heart! : )",
  "id" : 125636249439571968,
  "in_reply_to_status_id" : 125634520358719489,
  "created_at" : "2011-10-16 18:16:30 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 4, 16 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 70, 82 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBT",
      "indices" : [ 94, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125635928441098241",
  "text" : "hey @VirgoJohnny - I know you're atheist but you might like to follow @ReverendSue who is pro #LGBT equality. She's cool.",
  "id" : 125635928441098241,
  "created_at" : "2011-10-16 18:15:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125625720000094208",
  "geo" : { },
  "id_str" : "125626798305325056",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny but each christian is their own religion so...",
  "id" : 125626798305325056,
  "in_reply_to_status_id" : 125625720000094208,
  "created_at" : "2011-10-16 17:38:57 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "inigo sol",
      "screen_name" : "worldtreeman",
      "indices" : [ 39, 52 ],
      "id_str" : "85400142",
      "id" : 85400142
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125626269881729024",
  "text" : "\"fellow heart walkers\" .. I like that! @worldtreeman",
  "id" : 125626269881729024,
  "created_at" : "2011-10-16 17:36:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125626039580893184",
  "text" : "RT @LSFProgram: The journey of a thousand miles begins with a single step - Lao Tsu",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125625660759740417",
    "text" : "The journey of a thousand miles begins with a single step - Lao Tsu",
    "id" : 125625660759740417,
    "created_at" : "2011-10-16 17:34:26 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 125626039580893184,
  "created_at" : "2011-10-16 17:35:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "indices" : [ 0, 12 ],
      "id_str" : "27426615",
      "id" : 27426615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125625596972777475",
  "geo" : { },
  "id_str" : "125625921599315968",
  "in_reply_to_user_id" : 27426615,
  "text" : "@DaveUrsillo YES, you can re-download it at any time",
  "id" : 125625921599315968,
  "in_reply_to_status_id" : 125625596972777475,
  "created_at" : "2011-10-16 17:35:28 +0000",
  "in_reply_to_screen_name" : "DaveUrsillo",
  "in_reply_to_user_id_str" : "27426615",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125625574537437184",
  "text" : "We are all alone TOGETHER.. so no one is truly alone. I finally came full circle to understand that I am part of everything. How cool!",
  "id" : 125625574537437184,
  "created_at" : "2011-10-16 17:34:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Winyan Staz Wakien",
      "screen_name" : "WinyanStaz",
      "indices" : [ 3, 14 ],
      "id_str" : "236268614",
      "id" : 236268614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125625110622244865",
  "text" : "RT @WinyanStaz: Dear people...dont close you accounts..just re-direct ALL your direct deposts to another bank and spend what is left in  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125623764938530817",
    "text" : "Dear people...dont close you accounts..just re-direct ALL your direct deposts to another bank and spend what is left in the old account..",
    "id" : 125623764938530817,
    "created_at" : "2011-10-16 17:26:54 +0000",
    "user" : {
      "name" : "Winyan Staz Wakien",
      "screen_name" : "WinyanStaz",
      "protected" : false,
      "id_str" : "236268614",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797360690512039936\/pgC7o6eE_normal.jpg",
      "id" : 236268614,
      "verified" : false
    }
  },
  "id" : 125625110622244865,
  "created_at" : "2011-10-16 17:32:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Farah Abou Kharroub",
      "screen_name" : "Farah961",
      "indices" : [ 3, 12 ],
      "id_str" : "23926212",
      "id" : 23926212
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125624931512885249",
  "text" : "RT @Farah961: Twitter looks boring from the outside, But once your inside,its like freaking Narnia.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125610780522594304",
    "text" : "Twitter looks boring from the outside, But once your inside,its like freaking Narnia.",
    "id" : 125610780522594304,
    "created_at" : "2011-10-16 16:35:18 +0000",
    "user" : {
      "name" : "Farah Abou Kharroub",
      "screen_name" : "Farah961",
      "protected" : false,
      "id_str" : "23926212",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666285302109999105\/TjEODEM6_normal.jpg",
      "id" : 23926212,
      "verified" : false
    }
  },
  "id" : 125624931512885249,
  "created_at" : "2011-10-16 17:31:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125623485149097984",
  "text" : "standing alone gives one a lot of time to think..hehe",
  "id" : 125623485149097984,
  "created_at" : "2011-10-16 17:25:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125623295541379072",
  "text" : "blessed or cursed.. I have never fit in to any group so I have always stood alone.",
  "id" : 125623295541379072,
  "created_at" : "2011-10-16 17:25:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125622973305585664",
  "text" : "ppl who align so closely w a group identity do so out of fear.. fear to stand alone.. to be judged.",
  "id" : 125622973305585664,
  "created_at" : "2011-10-16 17:23:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125617712419442688",
  "geo" : { },
  "id_str" : "125620298866360321",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny I guess they don't realize that there ARE gay christians..",
  "id" : 125620298866360321,
  "in_reply_to_status_id" : 125617712419442688,
  "created_at" : "2011-10-16 17:13:07 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 0, 12 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/T2IT1niJ",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "in_reply_to_status_id_str" : "125614686954725376",
  "geo" : { },
  "id_str" : "125616259751620609",
  "in_reply_to_user_id" : 15349954,
  "text" : "@angelaharms oops.. http:\/\/t.co\/T2IT1niJ",
  "id" : 125616259751620609,
  "in_reply_to_status_id" : 125614686954725376,
  "created_at" : "2011-10-16 16:57:04 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125616030633562113",
  "text" : "RT @ShipsofSong: The boundaries of existence is infinity and eternity.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125614997651984386",
    "text" : "The boundaries of existence is infinity and eternity.",
    "id" : 125614997651984386,
    "created_at" : "2011-10-16 16:52:03 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 125616030633562113,
  "created_at" : "2011-10-16 16:56:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125610571998560257",
  "text" : "anger comes from pain. I forget that sometimes when I want to condemn angry ppl. I am sorry.",
  "id" : 125610571998560257,
  "created_at" : "2011-10-16 16:34:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125609587326976000",
  "text" : "Even the worst of us, even the most evil of human beings need love. We can't fly until we learn that.. until we CAN love them.",
  "id" : 125609587326976000,
  "created_at" : "2011-10-16 16:30:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125609007674179584",
  "text" : "Do you dislike me because I don't feel the need to stand up and fight?",
  "id" : 125609007674179584,
  "created_at" : "2011-10-16 16:28:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125608668740845569",
  "text" : "Do you dislike me because I am not an atheist? not a christian?",
  "id" : 125608668740845569,
  "created_at" : "2011-10-16 16:26:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125608507914465280",
  "text" : "Do you dislike me because I believe LOVE is the answer to any question?",
  "id" : 125608507914465280,
  "created_at" : "2011-10-16 16:26:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125608388511010816",
  "text" : "Do you dislike me because I believe that there is more to life than what we see? something beyond our 5 senses?",
  "id" : 125608388511010816,
  "created_at" : "2011-10-16 16:25:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125607086519361536",
  "text" : "Isn't it sacrilegious to think you need to fight for God? He is all powerful. Live your life. Follow your heart. He'll take care of rest.",
  "id" : 125607086519361536,
  "created_at" : "2011-10-16 16:20:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125604732067782656",
  "text" : "bated breath, bated breath, bated breath, bated breath ..",
  "id" : 125604732067782656,
  "created_at" : "2011-10-16 16:11:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Freeman",
      "screen_name" : "LilithsPriest",
      "indices" : [ 0, 14 ],
      "id_str" : "30038832",
      "id" : 30038832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125603954464792579",
  "geo" : { },
  "id_str" : "125604331142643712",
  "in_reply_to_user_id" : 30038832,
  "text" : "@LilithsPriest oh lord.. im usually good w spelling.. lol. thanks 4 correction! : )",
  "id" : 125604331142643712,
  "in_reply_to_status_id" : 125603954464792579,
  "created_at" : "2011-10-16 16:09:40 +0000",
  "in_reply_to_screen_name" : "LilithsPriest",
  "in_reply_to_user_id_str" : "30038832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125602984322277376",
  "text" : "for those who wait with baited breath..lol.. a new post on my blog!",
  "id" : 125602984322277376,
  "created_at" : "2011-10-16 16:04:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 81, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125602137588776960",
  "text" : "we cannot come to resolution when both sides totally misunderstand each other... #ows",
  "id" : 125602137588776960,
  "created_at" : "2011-10-16 16:00:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordPress.com",
      "screen_name" : "wordpressdotcom",
      "indices" : [ 37, 53 ],
      "id_str" : "823905",
      "id" : 823905
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/0EYmDg6p",
      "expanded_url" : "http:\/\/wp.me\/pIwKH-9I",
      "display_url" : "wp.me\/pIwKH-9I"
    } ]
  },
  "geo" : { },
  "id_str" : "125594555327324160",
  "text" : "We Can Fly http:\/\/t.co\/0EYmDg6p \/via @wordpressdotcom",
  "id" : 125594555327324160,
  "created_at" : "2011-10-16 15:30:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125583901514153985",
  "text" : "RT @PinarAkal1: Be a rainbow in someone's cloud. ~Maya Angelou",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125583590200324096",
    "text" : "Be a rainbow in someone's cloud. ~Maya Angelou",
    "id" : 125583590200324096,
    "created_at" : "2011-10-16 14:47:15 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 125583901514153985,
  "created_at" : "2011-10-16 14:48:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125583666272415744",
  "text" : "RT @JohnCali: Spend more time focused upon your dream than upon the reality. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125582529792188416",
    "text" : "Spend more time focused upon your dream than upon the reality. ~ Abraham",
    "id" : 125582529792188416,
    "created_at" : "2011-10-16 14:43:02 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 125583666272415744,
  "created_at" : "2011-10-16 14:47:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125580416215285760",
  "text" : "fat free creamer should not exist...",
  "id" : 125580416215285760,
  "created_at" : "2011-10-16 14:34:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 0, 14 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125407343625244673",
  "geo" : { },
  "id_str" : "125408060167569408",
  "in_reply_to_user_id" : 113395189,
  "text" : "@ThisBlueWorld lol.. same with our girl! (and heaven forbid we touch anything up there!)",
  "id" : 125408060167569408,
  "in_reply_to_status_id" : 125407343625244673,
  "created_at" : "2011-10-16 03:09:46 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 0, 14 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125406765624991744",
  "geo" : { },
  "id_str" : "125407677135323136",
  "in_reply_to_user_id" : 113395189,
  "text" : "@ThisBlueWorld sounds just like the one we got for our 16yo for xmas. got full over full. she loves it!",
  "id" : 125407677135323136,
  "in_reply_to_status_id" : 125406765624991744,
  "created_at" : "2011-10-16 03:08:14 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125383980433408000",
  "text" : "sending @tragic_pizza big ((hugs))",
  "id" : 125383980433408000,
  "created_at" : "2011-10-16 01:34:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 16, 26 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TheHandmaid",
      "indices" : [ 33, 45 ]
    }, {
      "text" : "MargaretAtwood",
      "indices" : [ 55, 70 ]
    }, {
      "text" : "occupyWallStreet",
      "indices" : [ 101, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125376930802434048",
  "text" : "RT @SangyeH: RT @JALpalyul: READ #TheHandmaid'sTale by #MargaretAtwood. This is what is happening if #occupyWallStreet fails. Don't fail ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 3, 13 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TheHandmaid",
        "indices" : [ 20, 32 ]
      }, {
        "text" : "MargaretAtwood",
        "indices" : [ 42, 57 ]
      }, {
        "text" : "occupyWallStreet",
        "indices" : [ 88, 105 ]
      }, {
        "text" : "ROAR",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125375985657978880",
    "text" : "RT @JALpalyul: READ #TheHandmaid'sTale by #MargaretAtwood. This is what is happening if #occupyWallStreet fails. Don't fail. Read and #ROAR!",
    "id" : 125375985657978880,
    "created_at" : "2011-10-16 01:02:19 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 125376930802434048,
  "created_at" : "2011-10-16 01:06:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125369202604384258",
  "text" : "RT @DeepakChopra: Science is objective measurement of subjective experience .Which is more real , the  experience of wetness or the form ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125367404078440451",
    "text" : "Science is objective measurement of subjective experience .Which is more real , the  experience of wetness or the formula H2O ?",
    "id" : 125367404078440451,
    "created_at" : "2011-10-16 00:28:13 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 125369202604384258,
  "created_at" : "2011-10-16 00:35:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125357970551873536",
  "text" : "had a \"date\" w hubs. went to a store & dinner at McD's. no dog.",
  "id" : 125357970551873536,
  "created_at" : "2011-10-15 23:50:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125350790096371712",
  "geo" : { },
  "id_str" : "125357617475358720",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny wow.. I mean.. really? really? cain cain go away",
  "id" : 125357617475358720,
  "in_reply_to_status_id" : 125350790096371712,
  "created_at" : "2011-10-15 23:49:19 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liza Sabater",
      "screen_name" : "blogdiva",
      "indices" : [ 3, 12 ],
      "id_str" : "820694",
      "id" : 820694
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OWS",
      "indices" : [ 61, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125286424265228288",
  "text" : "RT @blogdiva: BREAKING : 20 CITIBANK CUSTOMERS (who are also #OWS activists) have been arrested at 555 LaGuardia NYC after trying to clo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OWS",
        "indices" : [ 47, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125285159091191808",
    "text" : "BREAKING : 20 CITIBANK CUSTOMERS (who are also #OWS activists) have been arrested at 555 LaGuardia NYC after trying to close their accounts",
    "id" : 125285159091191808,
    "created_at" : "2011-10-15 19:01:24 +0000",
    "user" : {
      "name" : "Liza Sabater",
      "screen_name" : "blogdiva",
      "protected" : false,
      "id_str" : "820694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796419614460608514\/PdDR_jtb_normal.jpg",
      "id" : 820694,
      "verified" : false
    }
  },
  "id" : 125286424265228288,
  "created_at" : "2011-10-15 19:06:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125285596909408256",
  "geo" : { },
  "id_str" : "125286000695066624",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes awww.. I'm sorry she did that...",
  "id" : 125286000695066624,
  "in_reply_to_status_id" : 125285596909408256,
  "created_at" : "2011-10-15 19:04:44 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125284680319762432",
  "text" : "@SamsaricWarrior lessons...",
  "id" : 125284680319762432,
  "created_at" : "2011-10-15 18:59:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125283853978972160",
  "text" : "@SamsaricWarrior I think about it a lot. Very curious about the other side! : )",
  "id" : 125283853978972160,
  "created_at" : "2011-10-15 18:56:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "neatorama",
      "screen_name" : "neatorama",
      "indices" : [ 3, 13 ],
      "id_str" : "14512559",
      "id" : 14512559
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/QZzIHrfg",
      "expanded_url" : "http:\/\/www.neatorama.com\/2007\/10\/27\/the-kenova-pumpkin-house\/",
      "display_url" : "neatorama.com\/2007\/10\/27\/the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125270216774127616",
  "text" : "RT @neatorama - The Kenova Pumpkin House http:\/\/t.co\/QZzIHrfg",
  "id" : 125270216774127616,
  "created_at" : "2011-10-15 18:02:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Book Sake",
      "screen_name" : "booksake",
      "indices" : [ 7, 16 ],
      "id_str" : "116799604",
      "id" : 116799604
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125262562035105792",
  "text" : "I love @booksake book rating system.. ROFL.. best I've ever seen! :D",
  "id" : 125262562035105792,
  "created_at" : "2011-10-15 17:31:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Renee Vincent",
      "screen_name" : "ReneeVincent",
      "indices" : [ 3, 16 ],
      "id_str" : "28201422",
      "id" : 28201422
    }, {
      "name" : "Karen Stivali",
      "screen_name" : "karenstivali",
      "indices" : [ 67, 80 ],
      "id_str" : "224817622",
      "id" : 224817622
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125255534399078400",
  "text" : "RT @ReneeVincent: We are still talking about books right? hahah RT @karenstivali: sometimes long is better, other times u just want a qu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Karen Stivali",
        "screen_name" : "karenstivali",
        "indices" : [ 49, 62 ],
        "id_str" : "224817622",
        "id" : 224817622
      }, {
        "name" : "Keri Ford",
        "screen_name" : "KeriFord",
        "indices" : [ 127, 136 ],
        "id_str" : "26495424",
        "id" : 26495424
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125255172980092929",
    "text" : "We are still talking about books right? hahah RT @karenstivali: sometimes long is better, other times u just want a quickie ;) @KeriFord",
    "id" : 125255172980092929,
    "created_at" : "2011-10-15 17:02:15 +0000",
    "user" : {
      "name" : "Renee Vincent",
      "screen_name" : "ReneeVincent",
      "protected" : false,
      "id_str" : "28201422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/456205675463315456\/6DPjzqGG_normal.png",
      "id" : 28201422,
      "verified" : false
    }
  },
  "id" : 125255534399078400,
  "created_at" : "2011-10-15 17:03:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125251759420608513",
  "text" : "RT @TheEntertainer: Success is a CHOICE. You decide what your want for your life, otherwise it will be decided for you by others",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125251618991120385",
    "text" : "Success is a CHOICE. You decide what your want for your life, otherwise it will be decided for you by others",
    "id" : 125251618991120385,
    "created_at" : "2011-10-15 16:48:07 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 125251759420608513,
  "created_at" : "2011-10-15 16:48:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "125250027886088192",
  "geo" : { },
  "id_str" : "125251629833392128",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott hahaha : )",
  "id" : 125251629833392128,
  "in_reply_to_status_id" : 125250027886088192,
  "created_at" : "2011-10-15 16:48:10 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 3, 13 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/aZuXEZKL",
      "expanded_url" : "http:\/\/www.truth-out.org\/occupy-wall-street-live-stream-video\/1318560715",
      "display_url" : "truth-out.org\/occupy-wall-st\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "125251363486695424",
  "text" : "RT @bend_time: http:\/\/t.co\/aZuXEZKL look at all the peaceful people. you go, species!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/aZuXEZKL",
        "expanded_url" : "http:\/\/www.truth-out.org\/occupy-wall-street-live-stream-video\/1318560715",
        "display_url" : "truth-out.org\/occupy-wall-st\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "125250907758796801",
    "text" : "http:\/\/t.co\/aZuXEZKL look at all the peaceful people. you go, species!",
    "id" : 125250907758796801,
    "created_at" : "2011-10-15 16:45:18 +0000",
    "user" : {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "protected" : false,
      "id_str" : "48215218",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800365891355430912\/5FpT5mgt_normal.jpg",
      "id" : 48215218,
      "verified" : false
    }
  },
  "id" : 125251363486695424,
  "created_at" : "2011-10-15 16:47:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125251069105283072",
  "text" : "I wonder what happened to Carmen from UK. I hope she's well. I miss her tweets. last known account @InfantileAdult",
  "id" : 125251069105283072,
  "created_at" : "2011-10-15 16:45:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "indices" : [ 3, 16 ],
      "id_str" : "47618028",
      "id" : 47618028
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125247673723928576",
  "text" : "RT @BeasBookNook: The cat ate 2 hours ago but is he convinced he's starving. Le sigh.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125247540353441792",
    "text" : "The cat ate 2 hours ago but is he convinced he's starving. Le sigh.",
    "id" : 125247540353441792,
    "created_at" : "2011-10-15 16:31:55 +0000",
    "user" : {
      "name" : "BeasBookNook",
      "screen_name" : "BeasBookNook",
      "protected" : false,
      "id_str" : "47618028",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/785149965953855488\/6vITPI2C_normal.jpg",
      "id" : 47618028,
      "verified" : false
    }
  },
  "id" : 125247673723928576,
  "created_at" : "2011-10-15 16:32:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125238904197615618",
  "text" : "we all have our POV for a reason.. combo of factors. we need to look beyond the label and see the person.. the person who just wants peace.",
  "id" : 125238904197615618,
  "created_at" : "2011-10-15 15:57:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125238525682647040",
  "text" : "so tired of ppl fighting w each other.. christians, atheists, hunters, vegetarians, conservatives, liberals...",
  "id" : 125238525682647040,
  "created_at" : "2011-10-15 15:56:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125237855361564672",
  "text" : "so much easier for me to attach to animals than ppl. for a long time, thought that meant I didnt like ppl. but realized not true.",
  "id" : 125237855361564672,
  "created_at" : "2011-10-15 15:53:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125237364846116864",
  "text" : "I am so sad about Pete the Moose and so disappointed in Vermont.",
  "id" : 125237364846116864,
  "created_at" : "2011-10-15 15:51:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125236964747251713",
  "text" : "Is that a cry for ATTENTION? lol",
  "id" : 125236964747251713,
  "created_at" : "2011-10-15 15:49:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125236422788648960",
  "text" : "I think everyone put me on their \"ignore\" list... sigh.",
  "id" : 125236422788648960,
  "created_at" : "2011-10-15 15:47:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 78, 84 ]
    }, {
      "text" : "religion",
      "indices" : [ 85, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125040334550990849",
  "text" : "RT @betsdew: When you realize that God is Love, then religion makes no sense. #quote #religion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 65, 71 ]
      }, {
        "text" : "religion",
        "indices" : [ 72, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125038532719951872",
    "text" : "When you realize that God is Love, then religion makes no sense. #quote #religion",
    "id" : 125038532719951872,
    "created_at" : "2011-10-15 02:41:23 +0000",
    "user" : {
      "name" : "Betsy Dewey",
      "screen_name" : "BetsyDeweyTX",
      "protected" : false,
      "id_str" : "302720798",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3198644348\/e84631196962da998e22f720ca7d3a6f_normal.jpeg",
      "id" : 302720798,
      "verified" : false
    }
  },
  "id" : 125040334550990849,
  "created_at" : "2011-10-15 02:48:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "indices" : [ 0, 12 ],
      "id_str" : "32585384",
      "id" : 32585384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124993417154535424",
  "geo" : { },
  "id_str" : "125017960216674305",
  "in_reply_to_user_id" : 32585384,
  "text" : "@intuitivedm I am watching part 1.. \"here to help humans evolve\"(paraphrasing you).. beautiful.",
  "id" : 125017960216674305,
  "in_reply_to_status_id" : 124993417154535424,
  "created_at" : "2011-10-15 01:19:39 +0000",
  "in_reply_to_screen_name" : "intuitivedm",
  "in_reply_to_user_id_str" : "32585384",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "indices" : [ 3, 15 ],
      "id_str" : "32585384",
      "id" : 32585384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/80Gl5e5K",
      "expanded_url" : "http:\/\/bit.ly\/n0Wq4N",
      "display_url" : "bit.ly\/n0Wq4N"
    } ]
  },
  "geo" : { },
  "id_str" : "125017508129419264",
  "text" : "RT @intuitivedm: Have you seen part II of my interview with AfterlifeTV . com? http:\/\/t.co\/80Gl5e5K It's all about Animals and the Other ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/80Gl5e5K",
        "expanded_url" : "http:\/\/bit.ly\/n0Wq4N",
        "display_url" : "bit.ly\/n0Wq4N"
      } ]
    },
    "geo" : { },
    "id_str" : "124993417154535424",
    "text" : "Have you seen part II of my interview with AfterlifeTV . com? http:\/\/t.co\/80Gl5e5K It's all about Animals and the Other Side...",
    "id" : 124993417154535424,
    "created_at" : "2011-10-14 23:42:07 +0000",
    "user" : {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "protected" : false,
      "id_str" : "32585384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509424532495429633\/3M8ImHNe_normal.jpeg",
      "id" : 32585384,
      "verified" : false
    }
  },
  "id" : 125017508129419264,
  "created_at" : "2011-10-15 01:17:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125015533438500864",
  "text" : "RT @TheEntertainer: It doesn't mean sh*t what anyone thinks about you, Just Do You anyway.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125014390830403584",
    "text" : "It doesn't mean sh*t what anyone thinks about you, Just Do You anyway.",
    "id" : 125014390830403584,
    "created_at" : "2011-10-15 01:05:28 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 125015533438500864,
  "created_at" : "2011-10-15 01:10:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125015297676673025",
  "text" : "RT @TheEntertainer: A lot of people DON'T want you to succeed, because they don't want to see themselves for the truth of playing small...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "125014785040457728",
    "text" : "A lot of people DON'T want you to succeed, because they don't want to see themselves for the truth of playing small...",
    "id" : 125014785040457728,
    "created_at" : "2011-10-15 01:07:02 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 125015297676673025,
  "created_at" : "2011-10-15 01:09:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "125007539724238849",
  "text" : "Look at the damn log in your eye, ppl! (I can't..there's a damn log in my eye..)",
  "id" : 125007539724238849,
  "created_at" : "2011-10-15 00:38:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 16, 36 ],
      "url" : "http:\/\/t.co\/srkig80j",
      "expanded_url" : "http:\/\/www.lifewithcats.tv\/2011\/10\/14\/teleporting-cat\/",
      "display_url" : "lifewithcats.tv\/2011\/10\/14\/tel\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124992062696325120",
  "text" : "Teleporting Cat http:\/\/t.co\/srkig80j",
  "id" : 124992062696325120,
  "created_at" : "2011-10-14 23:36:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124964281660878848",
  "geo" : { },
  "id_str" : "124966806170513408",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth awwwwww!! so sweet",
  "id" : 124966806170513408,
  "in_reply_to_status_id" : 124964281660878848,
  "created_at" : "2011-10-14 21:56:23 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/Rt8P05jx",
      "expanded_url" : "http:\/\/WCAX.COM",
      "display_url" : "WCAX.COM"
    }, {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/Ti9r0Hf8",
      "expanded_url" : "http:\/\/bit.ly\/o9KyJ7",
      "display_url" : "bit.ly\/o9KyJ7"
    } ]
  },
  "geo" : { },
  "id_str" : "124956655216635905",
  "text" : "Pete the Moose dead - http:\/\/t.co\/Rt8P05jx Local Vermont News, Weather and Sports-: http:\/\/t.co\/Ti9r0Hf8",
  "id" : 124956655216635905,
  "created_at" : "2011-10-14 21:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 3, 17 ],
      "id_str" : "15855422",
      "id" : 15855422
    }, {
      "name" : "Mariel Hemingway",
      "screen_name" : "MarielHemingway",
      "indices" : [ 28, 44 ],
      "id_str" : "20086998",
      "id" : 20086998
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "dog",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124954216757346304",
  "text" : "RT @MelodyLeaLamb: Nice! RT @MarielHemingway: Great new book coming out 4 #dog lovers Write your dog a letter & U could B in book w\/ me: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mariel Hemingway",
        "screen_name" : "MarielHemingway",
        "indices" : [ 9, 25 ],
        "id_str" : "20086998",
        "id" : 20086998
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "dog",
        "indices" : [ 55, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124950106867892224",
    "text" : "Nice! RT @MarielHemingway: Great new book coming out 4 #dog lovers Write your dog a letter & U could B in book w\/ me: www.alettertomydog.com",
    "id" : 124950106867892224,
    "created_at" : "2011-10-14 20:50:01 +0000",
    "user" : {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "protected" : false,
      "id_str" : "15855422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94236021\/NewPic_normal.JPG",
      "id" : 15855422,
      "verified" : false
    }
  },
  "id" : 124954216757346304,
  "created_at" : "2011-10-14 21:06:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "indices" : [ 3, 17 ],
      "id_str" : "15855422",
      "id" : 15855422
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rescue",
      "indices" : [ 65, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 84, 104 ],
      "url" : "http:\/\/t.co\/JvxsPT54",
      "expanded_url" : "http:\/\/on.fb.me\/qR1p9D",
      "display_url" : "on.fb.me\/qR1p9D"
    } ]
  },
  "geo" : { },
  "id_str" : "124954120489680897",
  "text" : "RT @MelodyLeaLamb: Please help us find out who killed \"Luna\" the #rescue horse~&gt; http:\/\/t.co\/JvxsPT54 (Plz RT )",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rescue",
        "indices" : [ 46, 53 ]
      } ],
      "urls" : [ {
        "indices" : [ 65, 85 ],
        "url" : "http:\/\/t.co\/JvxsPT54",
        "expanded_url" : "http:\/\/on.fb.me\/qR1p9D",
        "display_url" : "on.fb.me\/qR1p9D"
      } ]
    },
    "geo" : { },
    "id_str" : "124950164053049344",
    "text" : "Please help us find out who killed \"Luna\" the #rescue horse~&gt; http:\/\/t.co\/JvxsPT54 (Plz RT )",
    "id" : 124950164053049344,
    "created_at" : "2011-10-14 20:50:15 +0000",
    "user" : {
      "name" : "Melody Lea Lamb",
      "screen_name" : "MelodyLeaLamb",
      "protected" : false,
      "id_str" : "15855422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/94236021\/NewPic_normal.JPG",
      "id" : 15855422,
      "verified" : false
    }
  },
  "id" : 124954120489680897,
  "created_at" : "2011-10-14 21:05:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/FCGOraAK",
      "expanded_url" : "http:\/\/bit.ly\/qfbRhN",
      "display_url" : "bit.ly\/qfbRhN"
    } ]
  },
  "geo" : { },
  "id_str" : "124931474909708288",
  "text" : "RT @Moonrust: Every Squirrel's Dream http:\/\/t.co\/FCGOraAK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/FCGOraAK",
        "expanded_url" : "http:\/\/bit.ly\/qfbRhN",
        "display_url" : "bit.ly\/qfbRhN"
      } ]
    },
    "geo" : { },
    "id_str" : "124928372806660096",
    "text" : "Every Squirrel's Dream http:\/\/t.co\/FCGOraAK",
    "id" : 124928372806660096,
    "created_at" : "2011-10-14 19:23:39 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 124931474909708288,
  "created_at" : "2011-10-14 19:35:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124919321439903744",
  "text" : "RT @Matth3ous: Some people say 'It's the economy, stupid!\". I say: \"The economy IS stupid.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124919100043575296",
    "text" : "Some people say 'It's the economy, stupid!\". I say: \"The economy IS stupid.\"",
    "id" : 124919100043575296,
    "created_at" : "2011-10-14 18:46:48 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 124919321439903744,
  "created_at" : "2011-10-14 18:47:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "indices" : [ 3, 18 ],
      "id_str" : "24616866",
      "id" : 24616866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124918556545646593",
  "text" : "RT @andrewtshaffer: Email from car dealership: \"Your car salesman is no longer with us. We're here to help though.\" OMG IS HE DEAD OR WHAT.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124917806918672384",
    "text" : "Email from car dealership: \"Your car salesman is no longer with us. We're here to help though.\" OMG IS HE DEAD OR WHAT.",
    "id" : 124917806918672384,
    "created_at" : "2011-10-14 18:41:40 +0000",
    "user" : {
      "name" : "Andrew Shaffer",
      "screen_name" : "andrewtshaffer",
      "protected" : false,
      "id_str" : "24616866",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798184019326365696\/Pv56h_bX_normal.jpg",
      "id" : 24616866,
      "verified" : true
    }
  },
  "id" : 124918556545646593,
  "created_at" : "2011-10-14 18:44:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124906895336157184",
  "text" : "RT @LSFProgram: In Living Stress Free\u2122, recreation isn\u2019t a privilege but a natural part of living a stress free balanced life.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124906041820459008",
    "text" : "In Living Stress Free\u2122, recreation isn\u2019t a privilege but a natural part of living a stress free balanced life.",
    "id" : 124906041820459008,
    "created_at" : "2011-10-14 17:54:55 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 124906895336157184,
  "created_at" : "2011-10-14 17:58:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CosmicConsciousness",
      "indices" : [ 18, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124905712278179841",
  "text" : "RT @DeepakChopra: #CosmicConsciousness  There is only one religion & it is the religion of love",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CosmicConsciousness",
        "indices" : [ 0, 20 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124905132377915392",
    "text" : "#CosmicConsciousness  There is only one religion & it is the religion of love",
    "id" : 124905132377915392,
    "created_at" : "2011-10-14 17:51:18 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 124905712278179841,
  "created_at" : "2011-10-14 17:53:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124903259377893376",
  "text" : "RT @UndertheNeonSky: We worry about what a child will become tomorrow, yet we forget that he is someone today. Stacia Tauscher",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124901659540336640",
    "text" : "We worry about what a child will become tomorrow, yet we forget that he is someone today. Stacia Tauscher",
    "id" : 124901659540336640,
    "created_at" : "2011-10-14 17:37:30 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 124903259377893376,
  "created_at" : "2011-10-14 17:43:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124902229869215745",
  "text" : "RT @GeneDoucette: Wait, Alabama has an illegal-immigrant law? ALABAMA?  Why the hell would anybody want to sneak into Alabama??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124901256455131136",
    "text" : "Wait, Alabama has an illegal-immigrant law? ALABAMA?  Why the hell would anybody want to sneak into Alabama??",
    "id" : 124901256455131136,
    "created_at" : "2011-10-14 17:35:54 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 124902229869215745,
  "created_at" : "2011-10-14 17:39:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124900028539088896",
  "text" : "RT @Buddhaworld: stop looking for answers, life is the answer.buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124895384639246336",
    "text" : "stop looking for answers, life is the answer.buddha volko.",
    "id" : 124895384639246336,
    "created_at" : "2011-10-14 17:12:34 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 124900028539088896,
  "created_at" : "2011-10-14 17:31:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Nature Maven",
      "screen_name" : "NatureMaven",
      "indices" : [ 17, 29 ],
      "id_str" : "72591655",
      "id" : 72591655
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124889219888988160",
  "text" : "RT @KerriFar: RT @NatureMaven: On Oct 9, three whooping cranes started an ultralight-led migration from Wisconsin to Florida: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Nature Maven",
        "screen_name" : "NatureMaven",
        "indices" : [ 3, 15 ],
        "id_str" : "72591655",
        "id" : 72591655
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 133, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/RVvrQ9rk",
        "expanded_url" : "http:\/\/ow.ly\/6Xx0I",
        "display_url" : "ow.ly\/6Xx0I"
      } ]
    },
    "geo" : { },
    "id_str" : "124883213335265280",
    "text" : "RT @NatureMaven: On Oct 9, three whooping cranes started an ultralight-led migration from Wisconsin to Florida: http:\/\/t.co\/RVvrQ9rk #birds",
    "id" : 124883213335265280,
    "created_at" : "2011-10-14 16:24:12 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 124889219888988160,
  "created_at" : "2011-10-14 16:48:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124857568525942784",
  "text" : "RT @GraveStomper: Just for today, approach the world like a kid: no shame, no guilt, playful and generous, hopeful and enthusiastic.  In ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124857273783828481",
    "text" : "Just for today, approach the world like a kid: no shame, no guilt, playful and generous, hopeful and enthusiastic.  In essence, divine.",
    "id" : 124857273783828481,
    "created_at" : "2011-10-14 14:41:08 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 124857568525942784,
  "created_at" : "2011-10-14 14:42:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124856664506642434",
  "text" : "RT @UndertheNeonSky: Try viewing everyone who comes into your life as a teacher.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124856489037922304",
    "text" : "Try viewing everyone who comes into your life as a teacher.",
    "id" : 124856489037922304,
    "created_at" : "2011-10-14 14:38:01 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 124856664506642434,
  "created_at" : "2011-10-14 14:38:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124855363353837571",
  "text" : "RT @bunnybuddhism: There is a strong link between bunniness and tolerance; less prejudice means greater bunniness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124854904819941376",
    "text" : "There is a strong link between bunniness and tolerance; less prejudice means greater bunniness.",
    "id" : 124854904819941376,
    "created_at" : "2011-10-14 14:31:43 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 124855363353837571,
  "created_at" : "2011-10-14 14:33:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u773C \u559D\u9053",
      "screen_name" : "MkPkr",
      "indices" : [ 17, 23 ],
      "id_str" : "3027057580",
      "id" : 3027057580
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 48, 68 ],
      "url" : "http:\/\/t.co\/rkJzGwfv",
      "expanded_url" : "http:\/\/bit.ly\/qceJ9g",
      "display_url" : "bit.ly\/qceJ9g"
    } ]
  },
  "geo" : { },
  "id_str" : "124851154529161216",
  "text" : "LOL.. I want. RT @mkpkr: Having fun with siri.. http:\/\/t.co\/rkJzGwfv",
  "id" : 124851154529161216,
  "created_at" : "2011-10-14 14:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Aine Belton",
      "screen_name" : "AineBelton",
      "indices" : [ 17, 28 ],
      "id_str" : "24859536",
      "id" : 24859536
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124850555507056641",
  "text" : "RT @JohnCali: RT @AineBelton: You are valuable because you exist. Not because of what you do or what you have done, but simp\u2026 (cont) htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Aine Belton",
        "screen_name" : "AineBelton",
        "indices" : [ 3, 14 ],
        "id_str" : "24859536",
        "id" : 24859536
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/JWW2q0pB",
        "expanded_url" : "http:\/\/deck.ly\/~MzVji",
        "display_url" : "deck.ly\/~MzVji"
      } ]
    },
    "geo" : { },
    "id_str" : "124849532663107584",
    "text" : "RT @AineBelton: You are valuable because you exist. Not because of what you do or what you have done, but simp\u2026 (cont) http:\/\/t.co\/JWW2q0pB",
    "id" : 124849532663107584,
    "created_at" : "2011-10-14 14:10:22 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 124850555507056641,
  "created_at" : "2011-10-14 14:14:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OWS",
      "indices" : [ 19, 23 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124850421985587201",
  "text" : "RT @CharlesBivona: #OWS UPS Store 118A Fulton st #205 New York, NY, 10038 \/ Water jugs, winter clothes, 4G wifi hotspots, durable laptop ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OWS",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "NeedsOfTheOccupiers",
        "indices" : [ 119, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124849695334993920",
    "text" : "#OWS UPS Store 118A Fulton st #205 New York, NY, 10038 \/ Water jugs, winter clothes, 4G wifi hotspots, durable laptops #NeedsOfTheOccupiers",
    "id" : 124849695334993920,
    "created_at" : "2011-10-14 14:11:01 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 124850421985587201,
  "created_at" : "2011-10-14 14:13:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124846498608463873",
  "text" : "RT @DrRus: Morning Mindbender Answer: 51% of women admit to thinking about \"punching out a co-worker\" as opposed to only 39% of men who  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124839604212862976",
    "text" : "Morning Mindbender Answer: 51% of women admit to thinking about \"punching out a co-worker\" as opposed to only 39% of men who think about it.",
    "id" : 124839604212862976,
    "created_at" : "2011-10-14 13:30:55 +0000",
    "user" : {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "protected" : false,
      "id_str" : "11006552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2998045873\/401a4460295cb0375428b8b577bd2249_normal.jpeg",
      "id" : 11006552,
      "verified" : false
    }
  },
  "id" : 124846498608463873,
  "created_at" : "2011-10-14 13:58:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124846382459789312",
  "text" : "@SamsaricWarrior hehe.. im getting practice on that this am!",
  "id" : 124846382459789312,
  "created_at" : "2011-10-14 13:57:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124845665682587648",
  "text" : "IM the parent.. if we choose to keep her home.. its our choice. egads.",
  "id" : 124845665682587648,
  "created_at" : "2011-10-14 13:55:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124845442583375873",
  "text" : "the school nurse makes me nervous.. ugh. I dislike calling her but DD doesn't like having to bring in notes.",
  "id" : 124845442583375873,
  "created_at" : "2011-10-14 13:54:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "indices" : [ 3, 12 ],
      "id_str" : "11575102",
      "id" : 11575102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 134 ],
      "url" : "http:\/\/t.co\/RK2Vph33",
      "expanded_url" : "http:\/\/www.carolinawaterfowlrescue.com\/rawhide.htm",
      "display_url" : "carolinawaterfowlrescue.com\/rawhide.htm"
    } ]
  },
  "geo" : { },
  "id_str" : "124634471277412352",
  "text" : "RT @tifotter: Please consider donating to help this duck and another, deliberately tortured before being rescued: http:\/\/t.co\/RK2Vph33",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 120 ],
        "url" : "http:\/\/t.co\/RK2Vph33",
        "expanded_url" : "http:\/\/www.carolinawaterfowlrescue.com\/rawhide.htm",
        "display_url" : "carolinawaterfowlrescue.com\/rawhide.htm"
      } ]
    },
    "geo" : { },
    "id_str" : "124632797804638209",
    "text" : "Please consider donating to help this duck and another, deliberately tortured before being rescued: http:\/\/t.co\/RK2Vph33",
    "id" : 124632797804638209,
    "created_at" : "2011-10-13 23:49:09 +0000",
    "user" : {
      "name" : "TifOtter",
      "screen_name" : "tifotter",
      "protected" : false,
      "id_str" : "11575102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/579777071850737664\/0bwnd0kt_normal.jpg",
      "id" : 11575102,
      "verified" : false
    }
  },
  "id" : 124634471277412352,
  "created_at" : "2011-10-13 23:55:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "Injustice Facts",
      "screen_name" : "InjusticeFacts",
      "indices" : [ 97, 112 ],
      "id_str" : "299413847",
      "id" : 299413847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gop",
      "indices" : [ 77, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124583957323984896",
  "text" : "RT @VirgoJohnny: It's called commission &amp; its one of the cornerstones of #gop capitalism. RT @InjusticeFacts Dick Cheney (cont) http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Injustice Facts",
        "screen_name" : "InjusticeFacts",
        "indices" : [ 80, 95 ],
        "id_str" : "299413847",
        "id" : 299413847
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gop",
        "indices" : [ 60, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/zB9wfybz",
        "expanded_url" : "http:\/\/tl.gd\/dk2md6",
        "display_url" : "tl.gd\/dk2md6"
      } ]
    },
    "geo" : { },
    "id_str" : "124578080265207808",
    "text" : "It's called commission &amp; its one of the cornerstones of #gop capitalism. RT @InjusticeFacts Dick Cheney (cont) http:\/\/t.co\/zB9wfybz",
    "id" : 124578080265207808,
    "created_at" : "2011-10-13 20:11:43 +0000",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 124583957323984896,
  "created_at" : "2011-10-13 20:35:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124579149976309762",
  "text" : "RT @mssuzcatsilver: 3d people... media hype\/governments\/ haarp etc want to be in control, take away your power YES your power, by keepin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124578894962638848",
    "text" : "3d people... media hype\/governments\/ haarp etc want to be in control, take away your power YES your power, by keeping YOU scared & small",
    "id" : 124578894962638848,
    "created_at" : "2011-10-13 20:14:57 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 124579149976309762,
  "created_at" : "2011-10-13 20:15:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 120, 125 ]
    }, {
      "text" : "suzcat",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124572990422786048",
  "text" : "RT @mssuzcatsilver: Supporting and empowering people IS the way forward, be kind to everyone you meet & bless them with #love #suzcat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 100, 105 ]
      }, {
        "text" : "suzcat",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124572563618803712",
    "text" : "Supporting and empowering people IS the way forward, be kind to everyone you meet & bless them with #love #suzcat",
    "id" : 124572563618803712,
    "created_at" : "2011-10-13 19:49:48 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 124572990422786048,
  "created_at" : "2011-10-13 19:51:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124572887733633024",
  "text" : "waiting for hubs to come back in. want him to get me soup from store.",
  "id" : 124572887733633024,
  "created_at" : "2011-10-13 19:51:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124570418416861185",
  "text" : "watching JAIL. female officer is very kind.",
  "id" : 124570418416861185,
  "created_at" : "2011-10-13 19:41:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "indices" : [ 3, 15 ],
      "id_str" : "45674330",
      "id" : 45674330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124569846762569728",
  "text" : "RT @oceanshaman: \"Heaven is where whn u arrive every dog u hv ever loved comes running to greet you wagging its tail\" ~ Cynthia Rylant c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124568478987464704",
    "text" : "\"Heaven is where whn u arrive every dog u hv ever loved comes running to greet you wagging its tail\" ~ Cynthia Rylant cc @News3David",
    "id" : 124568478987464704,
    "created_at" : "2011-10-13 19:33:34 +0000",
    "user" : {
      "name" : "GRAY",
      "screen_name" : "oceanshaman",
      "protected" : false,
      "id_str" : "45674330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675825917944549380\/s1onEWok_normal.jpg",
      "id" : 45674330,
      "verified" : false
    }
  },
  "id" : 124569846762569728,
  "created_at" : "2011-10-13 19:39:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Catherine Soliman",
      "screen_name" : "namilos",
      "indices" : [ 3, 11 ],
      "id_str" : "22486679",
      "id" : 22486679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124566309236244483",
  "text" : "RT @namilos: resetting my default settings to ... 'Happy'",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124565671215513600",
    "text" : "resetting my default settings to ... 'Happy'",
    "id" : 124565671215513600,
    "created_at" : "2011-10-13 19:22:24 +0000",
    "user" : {
      "name" : "Catherine Soliman",
      "screen_name" : "namilos",
      "protected" : false,
      "id_str" : "22486679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/617853521522659328\/09IDXjvP_normal.jpg",
      "id" : 22486679,
      "verified" : false
    }
  },
  "id" : 124566309236244483,
  "created_at" : "2011-10-13 19:24:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "gratitude",
      "indices" : [ 88, 98 ]
    }, {
      "text" : "grace",
      "indices" : [ 100, 106 ]
    }, {
      "text" : "appreciation",
      "indices" : [ 111, 124 ]
    }, {
      "text" : "suzcat",
      "indices" : [ 125, 132 ]
    }, {
      "text" : "quote",
      "indices" : [ 133, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124566307726303232",
  "text" : "RT @mssuzcatsilver: Affirmation:  I am open to abundance of all kinds, I accept it with #gratitude, #grace and #appreciation #suzcat #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "gratitude",
        "indices" : [ 68, 78 ]
      }, {
        "text" : "grace",
        "indices" : [ 80, 86 ]
      }, {
        "text" : "appreciation",
        "indices" : [ 91, 104 ]
      }, {
        "text" : "suzcat",
        "indices" : [ 105, 112 ]
      }, {
        "text" : "quote",
        "indices" : [ 113, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124566019216908288",
    "text" : "Affirmation:  I am open to abundance of all kinds, I accept it with #gratitude, #grace and #appreciation #suzcat #quote",
    "id" : 124566019216908288,
    "created_at" : "2011-10-13 19:23:47 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 124566307726303232,
  "created_at" : "2011-10-13 19:24:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124561963534651392",
  "geo" : { },
  "id_str" : "124565107018698753",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott thats on my Kindle waiting TBR..lol",
  "id" : 124565107018698753,
  "in_reply_to_status_id" : 124561963534651392,
  "created_at" : "2011-10-13 19:20:10 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124527378784464897",
  "geo" : { },
  "id_str" : "124527621282340864",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts LOL",
  "id" : 124527621282340864,
  "in_reply_to_status_id" : 124527378784464897,
  "created_at" : "2011-10-13 16:51:13 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "indices" : [ 3, 14 ],
      "id_str" : "22041124",
      "id" : 22041124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124519026855645188",
  "text" : "RT @PinarAkal1: When the sun rises, it rises for Everyone.  ~Aldous Huxley",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124518426558476289",
    "text" : "When the sun rises, it rises for Everyone.  ~Aldous Huxley",
    "id" : 124518426558476289,
    "created_at" : "2011-10-13 16:14:40 +0000",
    "user" : {
      "name" : "Pinar Akal",
      "screen_name" : "PinarAkal1",
      "protected" : false,
      "id_str" : "22041124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2795601408\/145262d083e89f196d1dceb29e8dd03e_normal.png",
      "id" : 22041124,
      "verified" : false
    }
  },
  "id" : 124519026855645188,
  "created_at" : "2011-10-13 16:17:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124514382305693696",
  "geo" : { },
  "id_str" : "124518445780971520",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench I love rebels..lol",
  "id" : 124518445780971520,
  "in_reply_to_status_id" : 124514382305693696,
  "created_at" : "2011-10-13 16:14:45 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124511087851872257",
  "text" : "@SamsaricWarrior but I dont want anyone to get in. thats the point! lol",
  "id" : 124511087851872257,
  "created_at" : "2011-10-13 15:45:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "124509741618704385",
  "geo" : { },
  "id_str" : "124510757349113856",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott I was never so happy than when my Ghosty returned after days. unfort. had to put down a day later. ((hugs))",
  "id" : 124510757349113856,
  "in_reply_to_status_id" : 124509741618704385,
  "created_at" : "2011-10-13 15:44:12 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 42, 57 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124509866957082624",
  "text" : "RT @DeepakChopra: Its puzzling to me that @RichardDawkins and other rabid atheists emotionally and vehemently attack a God they don't be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Dawkins",
        "screen_name" : "RichardDawkins",
        "indices" : [ 24, 39 ],
        "id_str" : "15143478",
        "id" : 15143478
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124507902168936448",
    "text" : "Its puzzling to me that @RichardDawkins and other rabid atheists emotionally and vehemently attack a God they don't believe in",
    "id" : 124507902168936448,
    "created_at" : "2011-10-13 15:32:51 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 124509866957082624,
  "created_at" : "2011-10-13 15:40:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/TreZ2OPz",
      "expanded_url" : "http:\/\/www.vetstreet.com\/learn\/going-home-popular-animal-author-jon-katz-explores-pet-loss-and-grief-in-his-new-book",
      "display_url" : "vetstreet.com\/learn\/going-ho\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124497916021833728",
  "text" : "Going Home: Popular Animal Author Jon Katz Explores Pet Loss and Grief in His New Book - Vetstreet http:\/\/t.co\/TreZ2OPz",
  "id" : 124497916021833728,
  "created_at" : "2011-10-13 14:53:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 22, 42 ],
      "url" : "http:\/\/t.co\/4OsOZbB1",
      "expanded_url" : "http:\/\/www.ontfin.com\/Word\/moose-from-algonquin\/",
      "display_url" : "ontfin.com\/Word\/moose-fro\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124482942205566976",
  "text" : "Moose from Algonquin: http:\/\/t.co\/4OsOZbB1",
  "id" : 124482942205566976,
  "created_at" : "2011-10-13 13:53:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/n1cyf56X",
      "expanded_url" : "http:\/\/www.ontfin.com\/Word\/american-bison-twin-calves\/",
      "display_url" : "ontfin.com\/Word\/american-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124482170906624000",
  "text" : "cute! American Bison twin calves: http:\/\/t.co\/n1cyf56X",
  "id" : 124482170906624000,
  "created_at" : "2011-10-13 13:50:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 49 ],
      "url" : "http:\/\/t.co\/VfvrbcnY",
      "expanded_url" : "http:\/\/www.ontfin.com\/Word\/beaver-dam-at-dusk\/",
      "display_url" : "ontfin.com\/Word\/beaver-da\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "124481944217075712",
  "text" : "serene - Beaver Dam at Dusk: http:\/\/t.co\/VfvrbcnY",
  "id" : 124481944217075712,
  "created_at" : "2011-10-13 13:49:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "indices" : [ 3, 13 ],
      "id_str" : "14428947",
      "id" : 14428947
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124280221766651904",
  "text" : "RT @bcmystery: The little girl at the table next to me is reading off my screen. She just told her mom I was \"typing bad words, like the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124279812146737153",
    "text" : "The little girl at the table next to me is reading off my screen. She just told her mom I was \"typing bad words, like the F one.\"",
    "id" : 124279812146737153,
    "created_at" : "2011-10-13 00:26:30 +0000",
    "user" : {
      "name" : "Bill Cameron",
      "screen_name" : "bcmystery",
      "protected" : false,
      "id_str" : "14428947",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791739839972376576\/t_GonWGl_normal.jpg",
      "id" : 14428947,
      "verified" : true
    }
  },
  "id" : 124280221766651904,
  "created_at" : "2011-10-13 00:28:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124226647451910145",
  "text" : "@SamsaricWarrior me, neither! ((highfive))",
  "id" : 124226647451910145,
  "created_at" : "2011-10-12 20:55:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124193136791650304",
  "text" : "RT @mssuzcatsilver: ...The Christian Mysteries by Tanis Helliwell\nLet\u2019s turn our attention to the question of \u201CWhat are the (cont) http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/y8E4VUi2",
        "expanded_url" : "http:\/\/tl.gd\/djg32k",
        "display_url" : "tl.gd\/djg32k"
      } ]
    },
    "geo" : { },
    "id_str" : "124188958769954816",
    "text" : "...The Christian Mysteries by Tanis Helliwell\nLet\u2019s turn our attention to the question of \u201CWhat are the (cont) http:\/\/t.co\/y8E4VUi2",
    "id" : 124188958769954816,
    "created_at" : "2011-10-12 18:25:29 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 124193136791650304,
  "created_at" : "2011-10-12 18:42:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124188631874289665",
  "text" : "RT @CoyoteSings: If you don't like your story, crumple it up and toss it out. You are not the paper. You are the pen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124187465228619776",
    "text" : "If you don't like your story, crumple it up and toss it out. You are not the paper. You are the pen.",
    "id" : 124187465228619776,
    "created_at" : "2011-10-12 18:19:33 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 124188631874289665,
  "created_at" : "2011-10-12 18:24:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124183979845877760",
  "text" : "some ppl think life \"should\" be hard..hmm..",
  "id" : 124183979845877760,
  "created_at" : "2011-10-12 18:05:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 24, 37 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FabulousFreaks",
      "indices" : [ 66, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/HEu7Qq66",
      "expanded_url" : "http:\/\/gplus.to\/abfabgab",
      "display_url" : "gplus.to\/abfabgab"
    } ]
  },
  "geo" : { },
  "id_str" : "124179636992217088",
  "text" : "http:\/\/t.co\/HEu7Qq66 RT @GraveStomper: Digging google+ any of you #FabulousFreaks there?",
  "id" : 124179636992217088,
  "created_at" : "2011-10-12 17:48:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AngelsTeach",
      "screen_name" : "AngelsTeach",
      "indices" : [ 3, 15 ],
      "id_str" : "16266830",
      "id" : 16266830
    }, {
      "name" : "Richard Grey",
      "screen_name" : "NHTGPSY",
      "indices" : [ 20, 28 ],
      "id_str" : "17283154",
      "id" : 17283154
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124175925108670464",
  "text" : "RT @AngelsTeach: RT @nhtgpsy: Non-acceptance of change causes suffering.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Grey",
        "screen_name" : "NHTGPSY",
        "indices" : [ 3, 11 ],
        "id_str" : "17283154",
        "id" : 17283154
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124175701317402624",
    "text" : "RT @nhtgpsy: Non-acceptance of change causes suffering.",
    "id" : 124175701317402624,
    "created_at" : "2011-10-12 17:32:48 +0000",
    "user" : {
      "name" : "AngelsTeach",
      "screen_name" : "AngelsTeach",
      "protected" : false,
      "id_str" : "16266830",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/403101394\/NinaRoe_normal.jpg",
      "id" : 16266830,
      "verified" : false
    }
  },
  "id" : 124175925108670464,
  "created_at" : "2011-10-12 17:33:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Vasquez",
      "screen_name" : "RamsesTMagnum",
      "indices" : [ 3, 17 ],
      "id_str" : "59030247",
      "id" : 59030247
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124167042298425344",
  "text" : "RT @RamsesTMagnum: Why would anyone have a mid-life crisis at 40, when they could, instead, have it at 50, and live to be 100?! It's sim ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124164085318295552",
    "text" : "Why would anyone have a mid-life crisis at 40, when they could, instead, have it at 50, and live to be 100?! It's simple math people!",
    "id" : 124164085318295552,
    "created_at" : "2011-10-12 16:46:39 +0000",
    "user" : {
      "name" : "Paul Vasquez",
      "screen_name" : "RamsesTMagnum",
      "protected" : false,
      "id_str" : "59030247",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795411218169151488\/voXoOtQm_normal.jpg",
      "id" : 59030247,
      "verified" : false
    }
  },
  "id" : 124167042298425344,
  "created_at" : "2011-10-12 16:58:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "indices" : [ 3, 13 ],
      "id_str" : "28136330",
      "id" : 28136330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "google",
      "indices" : [ 45, 52 ]
    }, {
      "text" : "justsaying",
      "indices" : [ 98, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124165645721026562",
  "text" : "RT @sandalgal: Okay, the Gumby waving on the #google homepage is really starting to freak me out. #justsaying",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "google",
        "indices" : [ 30, 37 ]
      }, {
        "text" : "justsaying",
        "indices" : [ 83, 94 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124165031138037760",
    "text" : "Okay, the Gumby waving on the #google homepage is really starting to freak me out. #justsaying",
    "id" : 124165031138037760,
    "created_at" : "2011-10-12 16:50:24 +0000",
    "user" : {
      "name" : "Tegan Silanskas",
      "screen_name" : "sandalgal",
      "protected" : false,
      "id_str" : "28136330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/647663137345290240\/Iek2J-8O_normal.jpg",
      "id" : 28136330,
      "verified" : false
    }
  },
  "id" : 124165645721026562,
  "created_at" : "2011-10-12 16:52:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ReadingRomances",
      "screen_name" : "ReadingRomances",
      "indices" : [ 3, 19 ],
      "id_str" : "286746495",
      "id" : 286746495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124163277897998336",
  "text" : "RT @ReadingRomances: 4 romance books giveaways going on at the blog right now! Did I mention there's also a giveaway hop?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124161937297780736",
    "text" : "4 romance books giveaways going on at the blog right now! Did I mention there's also a giveaway hop?",
    "id" : 124161937297780736,
    "created_at" : "2011-10-12 16:38:07 +0000",
    "user" : {
      "name" : "ReadingRomances",
      "screen_name" : "ReadingRomances",
      "protected" : false,
      "id_str" : "286746495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/754416612434903044\/fsaHoTBk_normal.jpg",
      "id" : 286746495,
      "verified" : false
    }
  },
  "id" : 124163277897998336,
  "created_at" : "2011-10-12 16:43:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 3, 15 ],
      "id_str" : "40585382",
      "id" : 40585382
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "equality",
      "indices" : [ 59, 68 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124139788717658112",
  "text" : "RT @ReverendSue: Why make others miserable by denying them #equality? Is power over another an honorable way to creating happiness for y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "equality",
        "indices" : [ 42, 51 ]
      }, {
        "text" : "religion",
        "indices" : [ 128, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124138292877856770",
    "text" : "Why make others miserable by denying them #equality? Is power over another an honorable way to creating happiness for yourself? #religion",
    "id" : 124138292877856770,
    "created_at" : "2011-10-12 15:04:10 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 124139788717658112,
  "created_at" : "2011-10-12 15:10:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124139607930572801",
  "text" : "RT @knittingknots: Money from Nothing: How Private Banks Create Money and Ideas for Reform of the Monetary System by James Robertson htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ows",
        "indices" : [ 135, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/FwpQLaYk",
        "expanded_url" : "http:\/\/www.yesmagazine.org\/issues\/the-new-economy\/money-from-nothing-supplying-money-should-be-a-public-service?ica=Tweet&icl=ShareBar_Art_UR",
        "display_url" : "yesmagazine.org\/issues\/the-new\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "124139020065312768",
    "text" : "Money from Nothing: How Private Banks Create Money and Ideas for Reform of the Monetary System by James Robertson http:\/\/t.co\/FwpQLaYk #ows",
    "id" : 124139020065312768,
    "created_at" : "2011-10-12 15:07:03 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 124139607930572801,
  "created_at" : "2011-10-12 15:09:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124136505533935616",
  "text" : "RT @GraveStomper: Where your mind goes your energy flows: is your life going to a positive or negative place?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124135325260980224",
    "text" : "Where your mind goes your energy flows: is your life going to a positive or negative place?",
    "id" : 124135325260980224,
    "created_at" : "2011-10-12 14:52:22 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 124136505533935616,
  "created_at" : "2011-10-12 14:57:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124120253474160640",
  "text" : "\"We are excepting donations for the American Cancer Society\" &lt;&lt; on front page of school district website",
  "id" : 124120253474160640,
  "created_at" : "2011-10-12 13:52:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124117068831399936",
  "text" : "if they put animals out there.. that would please me. esp if donkeys!",
  "id" : 124117068831399936,
  "created_at" : "2011-10-12 13:39:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124116667344228352",
  "text" : "cant wait for ppl in my backyard to go away!",
  "id" : 124116667344228352,
  "created_at" : "2011-10-12 13:38:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "124115961040207874",
  "text" : "RT @DrRus: Morning Mindbender Answer: A \"potato peeler\" is the #1 kitchen item people get hurt by.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "124114946089947136",
    "text" : "Morning Mindbender Answer: A \"potato peeler\" is the #1 kitchen item people get hurt by.",
    "id" : 124114946089947136,
    "created_at" : "2011-10-12 13:31:23 +0000",
    "user" : {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "protected" : false,
      "id_str" : "11006552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2998045873\/401a4460295cb0375428b8b577bd2249_normal.jpeg",
      "id" : 11006552,
      "verified" : false
    }
  },
  "id" : 124115961040207874,
  "created_at" : "2011-10-12 13:35:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123951231973593088",
  "geo" : { },
  "id_str" : "124115707809116160",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I'm apolitical.. but that just tickled me! : )",
  "id" : 124115707809116160,
  "in_reply_to_status_id" : 123951231973593088,
  "created_at" : "2011-10-12 13:34:25 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Tom Reynolds",
      "screen_name" : "Beregond",
      "indices" : [ 20, 29 ],
      "id_str" : "14898452",
      "id" : 14898452
    }, {
      "name" : "Phineas Fahrquar",
      "screen_name" : "irishspy",
      "indices" : [ 34, 43 ],
      "id_str" : "16931849",
      "id" : 16931849
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123935937989312512",
  "text" : "RT @CaroleODell: RT @beregond: RT @irishspy: I will vote for the candidate who promises to release the kraken.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Reynolds",
        "screen_name" : "Beregond",
        "indices" : [ 3, 12 ],
        "id_str" : "14898452",
        "id" : 14898452
      }, {
        "name" : "Phineas Fahrquar",
        "screen_name" : "irishspy",
        "indices" : [ 17, 26 ],
        "id_str" : "16931849",
        "id" : 16931849
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123934619392409601",
    "text" : "RT @beregond: RT @irishspy: I will vote for the candidate who promises to release the kraken.",
    "id" : 123934619392409601,
    "created_at" : "2011-10-12 01:34:50 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 123935937989312512,
  "created_at" : "2011-10-12 01:40:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/9oXzlrwm",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2011\/10\/emotional-reunion-for-lost-dog-and-owner\/",
      "display_url" : "lifewithdogs.tv\/2011\/10\/emotio\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "123923150835679232",
  "text" : "Emotional Reunion for Lost Dog and Owner http:\/\/t.co\/9oXzlrwm via @nigelbugger",
  "id" : 123923150835679232,
  "created_at" : "2011-10-12 00:49:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 67, 87 ],
      "url" : "http:\/\/t.co\/HHdX14TH",
      "expanded_url" : "http:\/\/j.mp\/r73nb4",
      "display_url" : "j.mp\/r73nb4"
    } ]
  },
  "geo" : { },
  "id_str" : "123836966193213440",
  "text" : "A corollary to Godwin\u2019s Law and problematic conceptions of justice http:\/\/t.co\/HHdX14TH",
  "id" : 123836966193213440,
  "created_at" : "2011-10-11 19:06:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnn",
      "indices" : [ 44, 48 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/mOHo57F7",
      "expanded_url" : "http:\/\/www.cnn.com\/2011\/10\/11\/opinion\/granderson-air-travel-absurdity\/index.html",
      "display_url" : "cnn.com\/2011\/10\/11\/opi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "123810385139728388",
  "text" : "TSA on lookout for big hair and snow globes #cnn http:\/\/t.co\/mOHo57F7",
  "id" : 123810385139728388,
  "created_at" : "2011-10-11 17:21:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 125, 133 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/LfEUNvFD",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=eaDS3yktLlY&feature=share",
      "display_url" : "youtube.com\/watch?v=eaDS3y\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "123740652252037120",
  "text" : "Check this video out -- Moves Like Jagger - Peter Hollens - Acappella Cover (feat. Savannah Oute... http:\/\/t.co\/LfEUNvFD via @youtube",
  "id" : 123740652252037120,
  "created_at" : "2011-10-11 12:44:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Atira Zeoli",
      "screen_name" : "zeoligirl",
      "indices" : [ 3, 13 ],
      "id_str" : "15005170",
      "id" : 15005170
    }, {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 15, 25 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FACT",
      "indices" : [ 26, 31 ]
    }, {
      "text" : "hunger",
      "indices" : [ 73, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123499075818627072",
  "text" : "RT @zeoligirl: @JALpalyul #FACT: $30 billion\/yr = $ required 2 end world #hunger, OR about as much as world spends on military every 8 d ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jetsunma Ahkon Lhamo",
        "screen_name" : "JALpalyul",
        "indices" : [ 0, 10 ],
        "id_str" : "75137401",
        "id" : 75137401
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FACT",
        "indices" : [ 11, 16 ]
      }, {
        "text" : "hunger",
        "indices" : [ 58, 65 ]
      }, {
        "text" : "FOODnotWAR",
        "indices" : [ 125, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123498877839085569",
    "in_reply_to_user_id" : 75137401,
    "text" : "@JALpalyul #FACT: $30 billion\/yr = $ required 2 end world #hunger, OR about as much as world spends on military every 8 days #FOODnotWAR",
    "id" : 123498877839085569,
    "created_at" : "2011-10-10 20:43:21 +0000",
    "in_reply_to_screen_name" : "JALpalyul",
    "in_reply_to_user_id_str" : "75137401",
    "user" : {
      "name" : "Atira Zeoli",
      "screen_name" : "zeoligirl",
      "protected" : false,
      "id_str" : "15005170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/633985786\/twitterProfilePhoto_normal.jpg",
      "id" : 15005170,
      "verified" : false
    }
  },
  "id" : 123499075818627072,
  "created_at" : "2011-10-10 20:44:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ninethousandone",
      "screen_name" : "icpchad",
      "indices" : [ 3, 11 ],
      "id_str" : "16603994",
      "id" : 16603994
    }, {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 16, 30 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Retweet",
      "indices" : [ 32, 40 ]
    }, {
      "text" : "OWS",
      "indices" : [ 127, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123496314574086144",
  "text" : "RT @icpchad: RT @CharlesBivona: #Retweet if you think the entire U.S. government is owned and run by a few mega-rich families. #OWS Twit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Charles Bivona",
        "screen_name" : "CharlesBivona",
        "indices" : [ 3, 17 ],
        "id_str" : "45254966",
        "id" : 45254966
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Retweet",
        "indices" : [ 19, 27 ]
      }, {
        "text" : "OWS",
        "indices" : [ 114, 118 ]
      }, {
        "text" : "occupy",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123495710938238976",
    "text" : "RT @CharlesBivona: #Retweet if you think the entire U.S. government is owned and run by a few mega-rich families. #OWS Twitter Poll #occupy",
    "id" : 123495710938238976,
    "created_at" : "2011-10-10 20:30:46 +0000",
    "user" : {
      "name" : "ninethousandone",
      "screen_name" : "icpchad",
      "protected" : false,
      "id_str" : "16603994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681887434\/modernman533_normal.jpg",
      "id" : 16603994,
      "verified" : false
    }
  },
  "id" : 123496314574086144,
  "created_at" : "2011-10-10 20:33:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123474814898933761",
  "geo" : { },
  "id_str" : "123475737742290944",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes you are not responsible for her actions only your actions. Be kind but you dont have to let her \"use\" you : )",
  "id" : 123475737742290944,
  "in_reply_to_status_id" : 123474814898933761,
  "created_at" : "2011-10-10 19:11:24 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123475264876445696",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes my mom could irritate me to no end.. but when I realized it was her way of coping, I relaxed. noticed she became less neg.",
  "id" : 123475264876445696,
  "created_at" : "2011-10-10 19:09:31 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    }, {
      "name" : "Katrina Mauro",
      "screen_name" : "KatrinaMauro",
      "indices" : [ 14, 27 ],
      "id_str" : "151493155",
      "id" : 151493155
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123469141708513280",
  "geo" : { },
  "id_str" : "123474532865540097",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes @KatrinaMauro since you have to finish.. go w attitude that your being there helps her in some way",
  "id" : 123474532865540097,
  "in_reply_to_status_id" : 123469141708513280,
  "created_at" : "2011-10-10 19:06:37 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/dD7biveV",
      "expanded_url" : "http:\/\/bit.ly\/rfBnwm",
      "display_url" : "bit.ly\/rfBnwm"
    } ]
  },
  "geo" : { },
  "id_str" : "123465638441271296",
  "text" : "I like this! &gt;&gt; Gungor: Love and Justice - http:\/\/t.co\/dD7biveV",
  "id" : 123465638441271296,
  "created_at" : "2011-10-10 18:31:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Matthew Paul Turner",
      "screen_name" : "JesusNeedsNewPR",
      "indices" : [ 12, 28 ],
      "id_str" : "727580030084251648",
      "id" : 727580030084251648
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/CNXNwDJ4",
      "expanded_url" : "http:\/\/goo.gl\/fb\/qCsFv",
      "display_url" : "goo.gl\/fb\/qCsFv"
    } ]
  },
  "geo" : { },
  "id_str" : "123460362212343808",
  "text" : "((puke)) RT @JesusNeedsNewPR: Mark Driscoll: \u2018God Hates You\u2019 http:\/\/t.co\/CNXNwDJ4",
  "id" : 123460362212343808,
  "created_at" : "2011-10-10 18:10:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "indices" : [ 3, 17 ],
      "id_str" : "8833312",
      "id" : 8833312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/5N8Ji3hg",
      "expanded_url" : "http:\/\/bit.ly\/pMSgBi",
      "display_url" : "bit.ly\/pMSgBi"
    } ]
  },
  "geo" : { },
  "id_str" : "123457087157178369",
  "text" : "RT @MicheleKnight: http:\/\/t.co\/5N8Ji3hg is there a super civilisation living in a black hole?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/5N8Ji3hg",
        "expanded_url" : "http:\/\/bit.ly\/pMSgBi",
        "display_url" : "bit.ly\/pMSgBi"
      } ]
    },
    "geo" : { },
    "id_str" : "123454651780694016",
    "text" : "http:\/\/t.co\/5N8Ji3hg is there a super civilisation living in a black hole?",
    "id" : 123454651780694016,
    "created_at" : "2011-10-10 17:47:37 +0000",
    "user" : {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "protected" : false,
      "id_str" : "8833312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616164060292337664\/DM_Io58r_normal.jpg",
      "id" : 8833312,
      "verified" : false
    }
  },
  "id" : 123457087157178369,
  "created_at" : "2011-10-10 17:57:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "indices" : [ 3, 17 ],
      "id_str" : "8833312",
      "id" : 8833312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/6tmWypU1",
      "expanded_url" : "http:\/\/bbc.in\/oVrU9A",
      "display_url" : "bbc.in\/oVrU9A"
    } ]
  },
  "geo" : { },
  "id_str" : "123455885048692736",
  "text" : "RT @MicheleKnight: BBC News - Brain 'rejects negative thoughts' http:\/\/t.co\/6tmWypU1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/6tmWypU1",
        "expanded_url" : "http:\/\/bbc.in\/oVrU9A",
        "display_url" : "bbc.in\/oVrU9A"
      } ]
    },
    "geo" : { },
    "id_str" : "123454888112963584",
    "text" : "BBC News - Brain 'rejects negative thoughts' http:\/\/t.co\/6tmWypU1",
    "id" : 123454888112963584,
    "created_at" : "2011-10-10 17:48:33 +0000",
    "user" : {
      "name" : "Michele Knight",
      "screen_name" : "MicheleKnight",
      "protected" : false,
      "id_str" : "8833312",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/616164060292337664\/DM_Io58r_normal.jpg",
      "id" : 8833312,
      "verified" : false
    }
  },
  "id" : 123455885048692736,
  "created_at" : "2011-10-10 17:52:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123447874519441408",
  "text" : "RT @ShipsofSong: Your job as the candle is to simply shine in the darkness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123447188184498176",
    "text" : "Your job as the candle is to simply shine in the darkness.",
    "id" : 123447188184498176,
    "created_at" : "2011-10-10 17:17:57 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 123447874519441408,
  "created_at" : "2011-10-10 17:20:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123447475196538880",
  "text" : "RT @JosephRanseth: My friend ripped the passenger seat out of his car, and bought a Porsche steering wheel so he could play video ga htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/instagram.com\" rel=\"nofollow\"\u003EInstagram\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/H2Rk8Oa5",
        "expanded_url" : "http:\/\/instagr.am\/p\/PvBmA\/",
        "display_url" : "instagr.am\/p\/PvBmA\/"
      } ]
    },
    "geo" : { },
    "id_str" : "123446903693246464",
    "text" : "My friend ripped the passenger seat out of his car, and bought a Porsche steering wheel so he could play video ga http:\/\/t.co\/H2Rk8Oa5",
    "id" : 123446903693246464,
    "created_at" : "2011-10-10 17:16:50 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 123447475196538880,
  "created_at" : "2011-10-10 17:19:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123447184447385600",
  "text" : "RT @SamsaricWarrior: If you approach obstacles as lessons you will look for what you can learn from them, instead of who to blame for them.",
  "id" : 123447184447385600,
  "created_at" : "2011-10-10 17:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    }, {
      "name" : "Melissa Cooper",
      "screen_name" : "revmelissa",
      "indices" : [ 17, 28 ],
      "id_str" : "69358301",
      "id" : 69358301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/8eOi26sL",
      "expanded_url" : "http:\/\/wp.me\/pCBU1-f2",
      "display_url" : "wp.me\/pCBU1-f2"
    } ]
  },
  "geo" : { },
  "id_str" : "123445629929259008",
  "text" : "RT @bcmouser: RT @revmelissa: What if Jesus Didn't Die for Me? - Guest Blogger: Joy Wilson http:\/\/t.co\/8eOi26sL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Melissa Cooper",
        "screen_name" : "revmelissa",
        "indices" : [ 3, 14 ],
        "id_str" : "69358301",
        "id" : 69358301
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 77, 97 ],
        "url" : "http:\/\/t.co\/8eOi26sL",
        "expanded_url" : "http:\/\/wp.me\/pCBU1-f2",
        "display_url" : "wp.me\/pCBU1-f2"
      } ]
    },
    "geo" : { },
    "id_str" : "123434998903746561",
    "text" : "RT @revmelissa: What if Jesus Didn't Die for Me? - Guest Blogger: Joy Wilson http:\/\/t.co\/8eOi26sL",
    "id" : 123434998903746561,
    "created_at" : "2011-10-10 16:29:31 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 123445629929259008,
  "created_at" : "2011-10-10 17:11:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    }, {
      "name" : "Joseph Allen Stone 3",
      "screen_name" : "beehivechampion",
      "indices" : [ 77, 93 ],
      "id_str" : "223409014",
      "id" : 223409014
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123421105984782336",
  "text" : "RT @bcmouser: What makes one person \"beautiful\" and another person not? \/via @beehivechampion &lt;- it's a choice. One chooses to see be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joseph Allen Stone 3",
        "screen_name" : "beehivechampion",
        "indices" : [ 63, 79 ],
        "id_str" : "223409014",
        "id" : 223409014
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123420765927378944",
    "text" : "What makes one person \"beautiful\" and another person not? \/via @beehivechampion &lt;- it's a choice. One chooses to see beauty or not.",
    "id" : 123420765927378944,
    "created_at" : "2011-10-10 15:32:58 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 123421105984782336,
  "created_at" : "2011-10-10 15:34:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123417850999357440",
  "text" : "RT @TrishScott: I'm a Nowist.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123416866952716288",
    "text" : "I'm a Nowist.",
    "id" : 123416866952716288,
    "created_at" : "2011-10-10 15:17:28 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 123417850999357440,
  "created_at" : "2011-10-10 15:21:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123412267713839104",
  "text" : "it's like a light flickering in my brain.. glimpses of understanding",
  "id" : 123412267713839104,
  "created_at" : "2011-10-10 14:59:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123164119057694720",
  "text" : "DD is going to be Shadow the Hedgehog from the Sonic games.",
  "id" : 123164119057694720,
  "created_at" : "2011-10-09 22:33:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123163866602549248",
  "text" : "DD & BFF are working on Halloween costume. They are laughing : )",
  "id" : 123163866602549248,
  "created_at" : "2011-10-09 22:32:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 3, 12 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123148086167093249",
  "geo" : { },
  "id_str" : "123148758593708032",
  "in_reply_to_user_id" : 24500414,
  "text" : "oh @BCBerrie you are so cruel!",
  "id" : 123148758593708032,
  "in_reply_to_status_id" : 123148086167093249,
  "created_at" : "2011-10-09 21:32:06 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 32, 43 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123141228647813121",
  "text" : "RT @ZachsMind: cuz it's fun! RT @moosebegab: WHY are you giving attention to ppl to just don't get it..?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 17, 28 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123138632105213952",
    "text" : "cuz it's fun! RT @moosebegab: WHY are you giving attention to ppl to just don't get it..?",
    "id" : 123138632105213952,
    "created_at" : "2011-10-09 20:51:52 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 123141228647813121,
  "created_at" : "2011-10-09 21:02:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123138632105213952",
  "geo" : { },
  "id_str" : "123140158580207616",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind ahhh.. someone does read my tweets..hehe!",
  "id" : 123140158580207616,
  "in_reply_to_status_id" : 123138632105213952,
  "created_at" : "2011-10-09 20:57:56 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123139762025537538",
  "text" : "and, of course, that is what MY ego is doing with this rant..LOL",
  "id" : 123139762025537538,
  "created_at" : "2011-10-09 20:56:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123139591111852033",
  "text" : "your ego is shouting \"look at me, look at me!\"",
  "id" : 123139591111852033,
  "created_at" : "2011-10-09 20:55:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123139412866510848",
  "text" : "while I might agree with your concepts, I don't agree with your methods of trying to get your point across.",
  "id" : 123139412866510848,
  "created_at" : "2011-10-09 20:54:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123138467705262081",
  "text" : "you are just going to attract more of the same type of ppl and argue until blue in face.",
  "id" : 123138467705262081,
  "created_at" : "2011-10-09 20:51:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123138310301421569",
  "text" : "I mean really. WHY are you giving attention to ppl to just don't get it. Move on. You're efforts can be better spent elsewhere!",
  "id" : 123138310301421569,
  "created_at" : "2011-10-09 20:50:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123137856620339200",
  "text" : "I see arguing in my stream. Ppl trying to debate ppl flinging mud at each other. It's not going to get them anywhere.",
  "id" : 123137856620339200,
  "created_at" : "2011-10-09 20:48:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123115435079110656",
  "text" : "hubs & DD are working on DD's costume today",
  "id" : 123115435079110656,
  "created_at" : "2011-10-09 19:19:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 0, 9 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123088043136647171",
  "geo" : { },
  "id_str" : "123089511738646528",
  "in_reply_to_user_id" : 24500414,
  "text" : "@BCBerrie omg... ((drool))",
  "id" : 123089511738646528,
  "in_reply_to_status_id" : 123088043136647171,
  "created_at" : "2011-10-09 17:36:41 +0000",
  "in_reply_to_screen_name" : "BCBawnee",
  "in_reply_to_user_id_str" : "24500414",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123078807224725504",
  "text" : "RT @LSFProgram: Wisdom begins in wonder.  Socrates",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123078558854807552",
    "text" : "Wisdom begins in wonder.  Socrates",
    "id" : 123078558854807552,
    "created_at" : "2011-10-09 16:53:09 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 123078807224725504,
  "created_at" : "2011-10-09 16:54:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 0, 15 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "123060099752267777",
  "geo" : { },
  "id_str" : "123066239881986048",
  "in_reply_to_user_id" : 104029814,
  "text" : "@stream_enterer LOL good question! : )",
  "id" : 123066239881986048,
  "in_reply_to_status_id" : 123060099752267777,
  "created_at" : "2011-10-09 16:04:12 +0000",
  "in_reply_to_screen_name" : "stream_enterer",
  "in_reply_to_user_id_str" : "104029814",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "Dr. Rudy Tanzi",
      "screen_name" : "RudyTanzi",
      "indices" : [ 101, 111 ],
      "id_str" : "321507436",
      "id" : 321507436
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/5NT5dG5D",
      "expanded_url" : "http:\/\/bit.ly\/o9MfTD",
      "display_url" : "bit.ly\/o9MfTD"
    } ]
  },
  "geo" : { },
  "id_str" : "123065754731036674",
  "text" : "RT @DeepakChopra: The entangled mind  and the universe . A conversation with Harvard neuroscientist  @rudytanzi  http:\/\/t.co\/5NT5dG5D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Rudy Tanzi",
        "screen_name" : "RudyTanzi",
        "indices" : [ 83, 93 ],
        "id_str" : "321507436",
        "id" : 321507436
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/5NT5dG5D",
        "expanded_url" : "http:\/\/bit.ly\/o9MfTD",
        "display_url" : "bit.ly\/o9MfTD"
      } ]
    },
    "geo" : { },
    "id_str" : "123038478991757312",
    "text" : "The entangled mind  and the universe . A conversation with Harvard neuroscientist  @rudytanzi  http:\/\/t.co\/5NT5dG5D",
    "id" : 123038478991757312,
    "created_at" : "2011-10-09 14:13:53 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 123065754731036674,
  "created_at" : "2011-10-09 16:02:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123055130319929345",
  "text" : "RT @LSFProgram: Welcome to the stress free zone!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123054384585256960",
    "text" : "Welcome to the stress free zone!",
    "id" : 123054384585256960,
    "created_at" : "2011-10-09 15:17:06 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 123055130319929345,
  "created_at" : "2011-10-09 15:20:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123055022446620674",
  "text" : "Cancel your subscription to \"Reality.\" It does not exist.",
  "id" : 123055022446620674,
  "created_at" : "2011-10-09 15:19:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "indices" : [ 3, 18 ],
      "id_str" : "96152195",
      "id" : 96152195
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123048289900822528",
  "text" : "RT @luminanceriver: Create the kind of world that you want to live in.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "123047187180560384",
    "text" : "Create the kind of world that you want to live in.",
    "id" : 123047187180560384,
    "created_at" : "2011-10-09 14:48:30 +0000",
    "user" : {
      "name" : "Oneness On Earth",
      "screen_name" : "luminanceriver",
      "protected" : false,
      "id_str" : "96152195",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569779763\/gratitude_normal.jpg",
      "id" : 96152195,
      "verified" : false
    }
  },
  "id" : 123048289900822528,
  "created_at" : "2011-10-09 14:52:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123048169197154304",
  "text" : "Follow @SamsaricWarrior for gaming, buddhism, photos, kindness, funny, nature, wisdom, family.",
  "id" : 123048169197154304,
  "created_at" : "2011-10-09 14:52:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123046274810384385",
  "text" : "@SamsaricWarrior a lot of them are authors, kindle accts and ppl who just add ppl. maybe 50-100 are those who I know or communicate with.",
  "id" : 123046274810384385,
  "created_at" : "2011-10-09 14:44:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123038170626523136",
  "text" : "the pigeons were cooing. what a beautiful sound. some had feathery feet.",
  "id" : 123038170626523136,
  "created_at" : "2011-10-09 14:12:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123037824386732033",
  "text" : "kissed by a baby cow yesterday. he was sooo sweet. gorgeous eyes.",
  "id" : 123037824386732033,
  "created_at" : "2011-10-09 14:11:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "123036656331784192",
  "text" : "@SamsaricWarrior Ive got 900 but (usually) only get replies when I speak directly to someone.",
  "id" : 123036656331784192,
  "created_at" : "2011-10-09 14:06:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "indices" : [ 3, 15 ],
      "id_str" : "32585384",
      "id" : 32585384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122841829992443904",
  "text" : "RT @intuitivedm: Sweepstakes to win a pet psychic reading w\/ a psychic from Bob Olson's \"Best Psychic Mediums\" list bit.ly\/oDXaJM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122839246649307137",
    "text" : "Sweepstakes to win a pet psychic reading w\/ a psychic from Bob Olson's \"Best Psychic Mediums\" list bit.ly\/oDXaJM",
    "id" : 122839246649307137,
    "created_at" : "2011-10-09 01:02:13 +0000",
    "user" : {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "protected" : false,
      "id_str" : "32585384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509424532495429633\/3M8ImHNe_normal.jpeg",
      "id" : 32585384,
      "verified" : false
    }
  },
  "id" : 122841829992443904,
  "created_at" : "2011-10-09 01:12:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "indices" : [ 3, 14 ],
      "id_str" : "385240011",
      "id" : 385240011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122836560944168960",
  "text" : "RT @newordsnow: For 7 days I have not been able to log into my \"real\"Twitter site: Wylieknowords.(Not blocked) Someone help me.Invalid s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122531066136379393",
    "text" : "For 7 days I have not been able to log into my \"real\"Twitter site: Wylieknowords.(Not blocked) Someone help me.Invalid security?443?browser?",
    "id" : 122531066136379393,
    "created_at" : "2011-10-08 04:37:37 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "protected" : false,
      "id_str" : "385240011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1579459848\/images_normal.jpg",
      "id" : 385240011,
      "verified" : false
    }
  },
  "id" : 122836560944168960,
  "created_at" : "2011-10-09 00:51:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "indices" : [ 3, 14 ],
      "id_str" : "385240011",
      "id" : 385240011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122836237643038720",
  "text" : "RT @newordsnow: 9 days not been able to log into Wylieknowords. Twitter Support said to change my password. How the hell can I without l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122791743929335808",
    "text" : "9 days not been able to log into Wylieknowords. Twitter Support said to change my password. How the hell can I without log in? PLEASE HELP.",
    "id" : 122791743929335808,
    "created_at" : "2011-10-08 21:53:27 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "protected" : false,
      "id_str" : "385240011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1579459848\/images_normal.jpg",
      "id" : 385240011,
      "verified" : false
    }
  },
  "id" : 122836237643038720,
  "created_at" : "2011-10-09 00:50:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "indices" : [ 3, 14 ],
      "id_str" : "385240011",
      "id" : 385240011
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122836071817031680",
  "text" : "RT @newordsnow: It has been 9 days since I could log into Wylieknowords--My \"real\" Twitter site. Would some SuperGeek help me. (Twitter  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122813224973373440",
    "text" : "It has been 9 days since I could log into Wylieknowords--My \"real\" Twitter site. Would some SuperGeek help me. (Twitter has no phone number)",
    "id" : 122813224973373440,
    "created_at" : "2011-10-08 23:18:49 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "newordsnow",
      "protected" : false,
      "id_str" : "385240011",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1579459848\/images_normal.jpg",
      "id" : 385240011,
      "verified" : false
    }
  },
  "id" : 122836071817031680,
  "created_at" : "2011-10-09 00:49:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122708899521499136",
  "text" : "RT @mssuzcatsilver: we ALL need to shine our light into every dark corner, on every 3d soul; on negative people\/media hype\/politicians # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lightworkers",
        "indices" : [ 115, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122707901814013953",
    "text" : "we ALL need to shine our light into every dark corner, on every 3d soul; on negative people\/media hype\/politicians #lightworkers plz RT",
    "id" : 122707901814013953,
    "created_at" : "2011-10-08 16:20:18 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 122708899521499136,
  "created_at" : "2011-10-08 16:24:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Kathleen Rossi",
      "screen_name" : "WishUFree",
      "indices" : [ 17, 27 ],
      "id_str" : "224422495",
      "id" : 224422495
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122455160596332544",
  "text" : "RT @JohnCali: RT @WishUFree: Love is the answer to everything.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kathleen Rossi",
        "screen_name" : "WishUFree",
        "indices" : [ 3, 13 ],
        "id_str" : "224422495",
        "id" : 224422495
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122454921806233601",
    "text" : "RT @WishUFree: Love is the answer to everything.",
    "id" : 122454921806233601,
    "created_at" : "2011-10-07 23:35:03 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 122455160596332544,
  "created_at" : "2011-10-07 23:36:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lis Wiehl",
      "screen_name" : "LisWiehl",
      "indices" : [ 85, 94 ],
      "id_str" : "28264799",
      "id" : 28264799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122429286350209024",
  "text" : "RT @NelsonFiction: only 1 more hour to win our FRIDAY FREEBEE! Giving away a copy of @LisWiehl 's supernatural thriller Waking Hours tod ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Lis Wiehl",
        "screen_name" : "LisWiehl",
        "indices" : [ 66, 75 ],
        "id_str" : "28264799",
        "id" : 28264799
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122426621587234816",
    "text" : "only 1 more hour to win our FRIDAY FREEBEE! Giving away a copy of @LisWiehl 's supernatural thriller Waking Hours today. Retweet to win!",
    "id" : 122426621587234816,
    "created_at" : "2011-10-07 21:42:35 +0000",
    "user" : {
      "name" : "TNZFiction",
      "screen_name" : "TNZFiction",
      "protected" : false,
      "id_str" : "113483630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3476074316\/bb1f0680a3472e1f316fb930048ce35d_normal.jpeg",
      "id" : 113483630,
      "verified" : false
    }
  },
  "id" : 122429286350209024,
  "created_at" : "2011-10-07 21:53:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Consortium Books",
      "screen_name" : "ConsortiumBooks",
      "indices" : [ 0, 16 ],
      "id_str" : "29465972",
      "id" : 29465972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122402914303098880",
  "geo" : { },
  "id_str" : "122403470845288449",
  "in_reply_to_user_id" : 29465972,
  "text" : "@ConsortiumBooks I did DM on 10\/05 and you replied : )",
  "id" : 122403470845288449,
  "in_reply_to_status_id" : 122402914303098880,
  "created_at" : "2011-10-07 20:10:36 +0000",
  "in_reply_to_screen_name" : "ConsortiumBooks",
  "in_reply_to_user_id_str" : "29465972",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122401837361016832",
  "geo" : { },
  "id_str" : "122402826285621250",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH oh dear Ani-La.. ((bighugs)) sending healing thoughts to you",
  "id" : 122402826285621250,
  "in_reply_to_status_id" : 122401837361016832,
  "created_at" : "2011-10-07 20:08:02 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 20, 30 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/xRDekrdA",
      "expanded_url" : "http:\/\/yfrog.com\/h7dpoauj",
      "display_url" : "yfrog.com\/h7dpoauj"
    } ]
  },
  "geo" : { },
  "id_str" : "122397342921007104",
  "text" : "umm.. ghost dog? RT @ScottBaio: http:\/\/t.co\/xRDekrdA",
  "id" : 122397342921007104,
  "created_at" : "2011-10-07 19:46:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Philosophers quotes",
      "screen_name" : "philo_quotes",
      "indices" : [ 27, 40 ],
      "id_str" : "110794236",
      "id" : 110794236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122396131094306816",
  "text" : "RT @Matth3ous: Ironic. \uE231RT @philo_quotes Beware of the person of one book. ~ Saint Thomas Aquinas",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Philosophers quotes",
        "screen_name" : "philo_quotes",
        "indices" : [ 12, 25 ],
        "id_str" : "110794236",
        "id" : 110794236
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122395674640781312",
    "text" : "Ironic. \uE231RT @philo_quotes Beware of the person of one book. ~ Saint Thomas Aquinas",
    "id" : 122395674640781312,
    "created_at" : "2011-10-07 19:39:37 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 122396131094306816,
  "created_at" : "2011-10-07 19:41:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122319716420304896",
  "text" : "so... last night looking at the moon I thought \"the moon loves me and I love the moon\"",
  "id" : 122319716420304896,
  "created_at" : "2011-10-07 14:37:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Trinity de Guzman",
      "screen_name" : "TrinitydeGuzman",
      "indices" : [ 3, 19 ],
      "id_str" : "39382173",
      "id" : 39382173
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122317410165473280",
  "text" : "RT @TrinitydeGuzman: Never give up, even when it seems hopeless",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122306184605741057",
    "text" : "Never give up, even when it seems hopeless",
    "id" : 122306184605741057,
    "created_at" : "2011-10-07 13:44:01 +0000",
    "user" : {
      "name" : "Trinity de Guzman",
      "screen_name" : "TrinitydeGuzman",
      "protected" : false,
      "id_str" : "39382173",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531576311152517121\/BTSzT5pC_normal.jpeg",
      "id" : 39382173,
      "verified" : false
    }
  },
  "id" : 122317410165473280,
  "created_at" : "2011-10-07 14:28:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 30, 38 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/1UaW8ga6",
      "expanded_url" : "http:\/\/youtu.be\/03xXkYpNRls?a",
      "display_url" : "youtu.be\/03xXkYpNRls?a"
    } ]
  },
  "geo" : { },
  "id_str" : "122315137364402176",
  "text" : "RT @mssuzcatsilver: I liked a @YouTube video http:\/\/t.co\/1UaW8ga6 Abraham-Hicks:  Allowing Your Financial Abundance",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 10, 18 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/1UaW8ga6",
        "expanded_url" : "http:\/\/youtu.be\/03xXkYpNRls?a",
        "display_url" : "youtu.be\/03xXkYpNRls?a"
      } ]
    },
    "geo" : { },
    "id_str" : "122313280365666304",
    "text" : "I liked a @YouTube video http:\/\/t.co\/1UaW8ga6 Abraham-Hicks:  Allowing Your Financial Abundance",
    "id" : 122313280365666304,
    "created_at" : "2011-10-07 14:12:13 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 122315137364402176,
  "created_at" : "2011-10-07 14:19:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122314688037007360",
  "text" : "why is it I can understand some ppl's POV and not others?",
  "id" : 122314688037007360,
  "created_at" : "2011-10-07 14:17:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 0, 14 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122308338590560256",
  "geo" : { },
  "id_str" : "122313998145298432",
  "in_reply_to_user_id" : 45254966,
  "text" : "@CharlesBivona I just don't get the anti-protesters...",
  "id" : 122313998145298432,
  "in_reply_to_status_id" : 122308338590560256,
  "created_at" : "2011-10-07 14:15:04 +0000",
  "in_reply_to_screen_name" : "CharlesBivona",
  "in_reply_to_user_id_str" : "45254966",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lucas Landherr",
      "screen_name" : "danteshepherd",
      "indices" : [ 3, 17 ],
      "id_str" : "15221364",
      "id" : 15221364
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "122308153911160833",
  "text" : "RT @danteshepherd: Bumper sticker this morning: \"If you don't get Him, you don't get it!\"  So . . . does that mean if I kidnap God, I wi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "122307258616000513",
    "text" : "Bumper sticker this morning: \"If you don't get Him, you don't get it!\"  So . . . does that mean if I kidnap God, I win a prize?",
    "id" : 122307258616000513,
    "created_at" : "2011-10-07 13:48:17 +0000",
    "user" : {
      "name" : "Lucas Landherr",
      "screen_name" : "danteshepherd",
      "protected" : false,
      "id_str" : "15221364",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793601733167644672\/3_5bAala_normal.jpg",
      "id" : 15221364,
      "verified" : false
    }
  },
  "id" : 122308153911160833,
  "created_at" : "2011-10-07 13:51:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jan",
      "screen_name" : "bringsdogtowork",
      "indices" : [ 3, 19 ],
      "id_str" : "43400955",
      "id" : 43400955
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "tcot",
      "indices" : [ 123, 128 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/1ZoJipLg",
      "expanded_url" : "http:\/\/usat.ly\/ngulBc",
      "display_url" : "usat.ly\/ngulBc"
    } ]
  },
  "geo" : { },
  "id_str" : "122307854303633408",
  "text" : "RT @bringsdogtowork: Feds order all Calif. medical-marijuana outlets to close http:\/\/t.co\/1ZoJipLg No word on other states #tcot",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 102, 107 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/1ZoJipLg",
        "expanded_url" : "http:\/\/usat.ly\/ngulBc",
        "display_url" : "usat.ly\/ngulBc"
      } ]
    },
    "geo" : { },
    "id_str" : "122086788826267652",
    "text" : "Feds order all Calif. medical-marijuana outlets to close http:\/\/t.co\/1ZoJipLg No word on other states #tcot",
    "id" : 122086788826267652,
    "created_at" : "2011-10-06 23:12:13 +0000",
    "user" : {
      "name" : "Jan",
      "screen_name" : "bringsdogtowork",
      "protected" : false,
      "id_str" : "43400955",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2076050895\/dukes_normal.jpg",
      "id" : 43400955,
      "verified" : false
    }
  },
  "id" : 122307854303633408,
  "created_at" : "2011-10-07 13:50:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122122534798884864",
  "geo" : { },
  "id_str" : "122125037032583168",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem have a good time..lol ; )",
  "id" : 122125037032583168,
  "in_reply_to_status_id" : 122122534798884864,
  "created_at" : "2011-10-07 01:44:12 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TwitPic",
      "screen_name" : "TwitPic",
      "indices" : [ 64, 72 ],
      "id_str" : "12925072",
      "id" : 12925072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aww",
      "indices" : [ 18, 22 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 59 ],
      "url" : "http:\/\/t.co\/4rzvgrfh",
      "expanded_url" : "http:\/\/twitpic.com\/6w8lte",
      "display_url" : "twitpic.com\/6w8lte"
    } ]
  },
  "geo" : { },
  "id_str" : "122123778351312896",
  "text" : "RT @GlamGirl_007: #aww squirrel & baby http:\/\/t.co\/4rzvgrfh via @twitpic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TwitPic",
        "screen_name" : "TwitPic",
        "indices" : [ 46, 54 ],
        "id_str" : "12925072",
        "id" : 12925072
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "aww",
        "indices" : [ 0, 4 ]
      } ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/4rzvgrfh",
        "expanded_url" : "http:\/\/twitpic.com\/6w8lte",
        "display_url" : "twitpic.com\/6w8lte"
      } ]
    },
    "geo" : { },
    "id_str" : "122122953298161664",
    "text" : "#aww squirrel & baby http:\/\/t.co\/4rzvgrfh via @twitpic",
    "id" : 122122953298161664,
    "created_at" : "2011-10-07 01:35:55 +0000",
    "user" : {
      "name" : "kitty berting",
      "screen_name" : "GlamKitty_007",
      "protected" : false,
      "id_str" : "157445370",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/635516254162305024\/OiRuv8fb_normal.jpg",
      "id" : 157445370,
      "verified" : false
    }
  },
  "id" : 122123778351312896,
  "created_at" : "2011-10-07 01:39:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "John B.",
      "screen_name" : "dendroica",
      "indices" : [ 34, 44 ],
      "id_str" : "10238542",
      "id" : 10238542
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 89 ],
      "url" : "http:\/\/t.co\/ndB9w5p7",
      "expanded_url" : "http:\/\/flic.kr\/p\/atv9Gq",
      "display_url" : "flic.kr\/p\/atv9Gq"
    } ]
  },
  "geo" : { },
  "id_str" : "122056649581137921",
  "text" : "RT @KerriFar: Awesome capture! RT @dendroica: Mating Pearl Crescents http:\/\/t.co\/ndB9w5p7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "John B.",
        "screen_name" : "dendroica",
        "indices" : [ 20, 30 ],
        "id_str" : "10238542",
        "id" : 10238542
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/ndB9w5p7",
        "expanded_url" : "http:\/\/flic.kr\/p\/atv9Gq",
        "display_url" : "flic.kr\/p\/atv9Gq"
      } ]
    },
    "geo" : { },
    "id_str" : "122053553585012736",
    "text" : "Awesome capture! RT @dendroica: Mating Pearl Crescents http:\/\/t.co\/ndB9w5p7",
    "id" : 122053553585012736,
    "created_at" : "2011-10-06 21:00:09 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 122056649581137921,
  "created_at" : "2011-10-06 21:12:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "122009316495589377",
  "geo" : { },
  "id_str" : "122009872136019968",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench ROFL : )",
  "id" : 122009872136019968,
  "in_reply_to_status_id" : 122009316495589377,
  "created_at" : "2011-10-06 18:06:35 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Honey Badger",
      "screen_name" : "BronxZooHBadger",
      "indices" : [ 3, 19 ],
      "id_str" : "273624512",
      "id" : 273624512
    }, {
      "name" : "Kombiz Lavasany",
      "screen_name" : "kombiz",
      "indices" : [ 58, 65 ],
      "id_str" : "7040852",
      "id" : 7040852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/XAc5hgRd",
      "expanded_url" : "http:\/\/bit.ly\/nb4fs8",
      "display_url" : "bit.ly\/nb4fs8"
    } ]
  },
  "geo" : { },
  "id_str" : "122009009506095104",
  "text" : "RT @BronxZooHBadger: Think again. http:\/\/t.co\/XAc5hgRd RT @kombiz Apparently - Squirrel penis and NSFW do not actually drive up clicks o ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kombiz Lavasany",
        "screen_name" : "kombiz",
        "indices" : [ 37, 44 ],
        "id_str" : "7040852",
        "id" : 7040852
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 13, 33 ],
        "url" : "http:\/\/t.co\/XAc5hgRd",
        "expanded_url" : "http:\/\/bit.ly\/nb4fs8",
        "display_url" : "bit.ly\/nb4fs8"
      } ]
    },
    "geo" : { },
    "id_str" : "122007299610001408",
    "text" : "Think again. http:\/\/t.co\/XAc5hgRd RT @kombiz Apparently - Squirrel penis and NSFW do not actually drive up clicks on twitter...",
    "id" : 122007299610001408,
    "created_at" : "2011-10-06 17:56:21 +0000",
    "user" : {
      "name" : "The Honey Badger",
      "screen_name" : "BronxZooHBadger",
      "protected" : false,
      "id_str" : "273624512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598524575\/honey_badger_normal.jpg",
      "id" : 273624512,
      "verified" : false
    }
  },
  "id" : 122009009506095104,
  "created_at" : "2011-10-06 18:03:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 3, 15 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OccupyWallStreet",
      "indices" : [ 116, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121998332519399424",
  "text" : "RT @CoyoteSings: I don't see my country crumbling. I see my country finally waking up. \"We The People\" are the 99%. #OccupyWallStreet",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OccupyWallStreet",
        "indices" : [ 99, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121997049305645056",
    "text" : "I don't see my country crumbling. I see my country finally waking up. \"We The People\" are the 99%. #OccupyWallStreet",
    "id" : 121997049305645056,
    "created_at" : "2011-10-06 17:15:37 +0000",
    "user" : {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "protected" : false,
      "id_str" : "118573185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776886342261157888\/YZH4OM4-_normal.jpg",
      "id" : 118573185,
      "verified" : false
    }
  },
  "id" : 121998332519399424,
  "created_at" : "2011-10-06 17:20:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "SagesandScientists",
      "screen_name" : "SagesScientists",
      "indices" : [ 33, 49 ],
      "id_str" : "4569640454",
      "id" : 4569640454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121992583248482304",
  "text" : "RT @DeepakChopra: Supporting! RT @SagesScientists Trust in the future, which is full of infinite possibilities. Don't fall prey to short ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SagesandScientists",
        "screen_name" : "SagesScientists",
        "indices" : [ 15, 31 ],
        "id_str" : "4569640454",
        "id" : 4569640454
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121987233258536961",
    "text" : "Supporting! RT @SagesScientists Trust in the future, which is full of infinite possibilities. Don't fall prey to short-term setbacks.",
    "id" : 121987233258536961,
    "created_at" : "2011-10-06 16:36:37 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 121992583248482304,
  "created_at" : "2011-10-06 16:57:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121991857491288064",
  "text" : "RT @parkstepp: \"It\u2019s a free country, but: I need a license to drive, a license to work, a permit to protest, a permit...\" http:\/\/t.co\/AJ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/AJ0DHGw8",
        "expanded_url" : "http:\/\/tumblr.com\/xjw53myiee",
        "display_url" : "tumblr.com\/xjw53myiee"
      } ]
    },
    "geo" : { },
    "id_str" : "121991034916962306",
    "text" : "\"It\u2019s a free country, but: I need a license to drive, a license to work, a permit to protest, a permit...\" http:\/\/t.co\/AJ0DHGw8",
    "id" : 121991034916962306,
    "created_at" : "2011-10-06 16:51:43 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 121991857491288064,
  "created_at" : "2011-10-06 16:54:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121976374868189185",
  "text" : "@SamsaricWarrior thx 4 metta.. I need all I can get.. LOL",
  "id" : 121976374868189185,
  "created_at" : "2011-10-06 15:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RBRfDB",
      "screen_name" : "ReadersRights",
      "indices" : [ 3, 17 ],
      "id_str" : "262817156",
      "id" : 262817156
    }, {
      "name" : "Radical Reference",
      "screen_name" : "RadReference",
      "indices" : [ 82, 95 ],
      "id_str" : "82898734",
      "id" : 82898734
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "occupywallstreet",
      "indices" : [ 64, 81 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/GScrV909",
      "expanded_url" : "http:\/\/radicalreference.info\/blogs\/%5Buser-raw%5D\/rad-ref-occupy-wall-street",
      "display_url" : "radicalreference.info\/blogs\/%5Buser-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "121972154639200256",
  "text" : "RT @ReadersRights: Librarians for Sharing! http:\/\/t.co\/GScrV909 #occupywallstreet @RadReference",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Radical Reference",
        "screen_name" : "RadReference",
        "indices" : [ 63, 76 ],
        "id_str" : "82898734",
        "id" : 82898734
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "occupywallstreet",
        "indices" : [ 45, 62 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/GScrV909",
        "expanded_url" : "http:\/\/radicalreference.info\/blogs\/%5Buser-raw%5D\/rad-ref-occupy-wall-street",
        "display_url" : "radicalreference.info\/blogs\/%5Buser-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "121971383549960193",
    "text" : "Librarians for Sharing! http:\/\/t.co\/GScrV909 #occupywallstreet @RadReference",
    "id" : 121971383549960193,
    "created_at" : "2011-10-06 15:33:38 +0000",
    "user" : {
      "name" : "RBRfDB",
      "screen_name" : "ReadersRights",
      "protected" : false,
      "id_str" : "262817156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1267165096\/DRM_PNG_600_Over_normal.png",
      "id" : 262817156,
      "verified" : false
    }
  },
  "id" : 121972154639200256,
  "created_at" : "2011-10-06 15:36:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/vvu7pKsq",
      "expanded_url" : "http:\/\/su.pr\/19R3JW",
      "display_url" : "su.pr\/19R3JW"
    } ]
  },
  "geo" : { },
  "id_str" : "121971822815232000",
  "text" : "RT @dailygalaxy: A \"Third Realm\"? --Alien Technology Could Exist That's Beyond Matter http:\/\/t.co\/vvu7pKsq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.stumbleupon.com\/\" rel=\"nofollow\"\u003EStumbleUpon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/vvu7pKsq",
        "expanded_url" : "http:\/\/su.pr\/19R3JW",
        "display_url" : "su.pr\/19R3JW"
      } ]
    },
    "geo" : { },
    "id_str" : "121970318117056513",
    "text" : "A \"Third Realm\"? --Alien Technology Could Exist That's Beyond Matter http:\/\/t.co\/vvu7pKsq",
    "id" : 121970318117056513,
    "created_at" : "2011-10-06 15:29:24 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 121971822815232000,
  "created_at" : "2011-10-06 15:35:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121967649281421312",
  "text" : "geez, ppl.. death is not a tragedy. dying with your music inside of you.. that's a tragedy. We ALL die at some point of something!",
  "id" : 121967649281421312,
  "created_at" : "2011-10-06 15:18:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121967084585496576",
  "text" : "@SamsaricWarrior you're always in some kind of trouble, aren't you? ; ) - sending healing thoughts for nerve.",
  "id" : 121967084585496576,
  "created_at" : "2011-10-06 15:16:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Jacob",
      "screen_name" : "ReActivateDNA",
      "indices" : [ 23, 37 ],
      "id_str" : "362639301",
      "id" : 362639301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KNOW",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121951495192190976",
  "text" : "RT @mssuzcatsilver: RT @ReActivateDNA: \"Believe\" carries a vibration of uncertainty.  Be your \"Truth.\" Speak it. & #KNOW it!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jacob",
        "screen_name" : "ReActivateDNA",
        "indices" : [ 3, 17 ],
        "id_str" : "362639301",
        "id" : 362639301
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KNOW",
        "indices" : [ 95, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121941056404197376",
    "text" : "RT @ReActivateDNA: \"Believe\" carries a vibration of uncertainty.  Be your \"Truth.\" Speak it. & #KNOW it!",
    "id" : 121941056404197376,
    "created_at" : "2011-10-06 13:33:08 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 121951495192190976,
  "created_at" : "2011-10-06 14:14:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rich Brodsky",
      "screen_name" : "atomicskunk",
      "indices" : [ 3, 15 ],
      "id_str" : "20956390",
      "id" : 20956390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121775730190331904",
  "text" : "RT @atomicskunk: \"Don't let the noise of others' opinions drown out your own inner voice.\" ~ Steve Jobs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121774372003393536",
    "text" : "\"Don't let the noise of others' opinions drown out your own inner voice.\" ~ Steve Jobs",
    "id" : 121774372003393536,
    "created_at" : "2011-10-06 02:30:47 +0000",
    "user" : {
      "name" : "Rich Brodsky",
      "screen_name" : "atomicskunk",
      "protected" : false,
      "id_str" : "20956390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1178181797\/newskunkalbum3notextteaser_normal.jpg",
      "id" : 20956390,
      "verified" : false
    }
  },
  "id" : 121775730190331904,
  "created_at" : "2011-10-06 02:36:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/a0QJfoME",
      "expanded_url" : "http:\/\/angelaharms.com\/2011\/shameless\/",
      "display_url" : "angelaharms.com\/2011\/shameless\/"
    } ]
  },
  "geo" : { },
  "id_str" : "121769302247481344",
  "text" : "RT @angelaharms: A blog about hurting, and hurting less. http:\/\/t.co\/a0QJfoME",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/a0QJfoME",
        "expanded_url" : "http:\/\/angelaharms.com\/2011\/shameless\/",
        "display_url" : "angelaharms.com\/2011\/shameless\/"
      } ]
    },
    "geo" : { },
    "id_str" : "121764385600450560",
    "text" : "A blog about hurting, and hurting less. http:\/\/t.co\/a0QJfoME",
    "id" : 121764385600450560,
    "created_at" : "2011-10-06 01:51:06 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 121769302247481344,
  "created_at" : "2011-10-06 02:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 16, 30 ],
      "id_str" : "28863804",
      "id" : 28863804
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 43, 51 ],
      "id_str" : "783214",
      "id" : 783214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/7EFdTwPw",
      "expanded_url" : "http:\/\/www.facebook.com\/norvell.w.jones",
      "display_url" : "facebook.com\/norvell.w.jones"
    }, {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/M5dOdjZs",
      "expanded_url" : "http:\/\/www.knowords.com",
      "display_url" : "knowords.com"
    } ]
  },
  "geo" : { },
  "id_str" : "121766400137240576",
  "text" : "Can anyone help @Wylieknowords get back on @Twitter ? http:\/\/t.co\/7EFdTwPw \/ http:\/\/t.co\/M5dOdjZs",
  "id" : 121766400137240576,
  "created_at" : "2011-10-06 01:59:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 16, 30 ],
      "id_str" : "28863804",
      "id" : 28863804
    }, {
      "name" : "Twitter",
      "screen_name" : "twitter",
      "indices" : [ 43, 51 ],
      "id_str" : "783214",
      "id" : 783214
    }, {
      "name" : "Twitter Support",
      "screen_name" : "Support",
      "indices" : [ 110, 118 ],
      "id_str" : "17874544",
      "id" : 17874544
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121765805640790016",
  "text" : "Can anyone help @Wylieknowords get back on @Twitter ? He cannot access his account 4 days. Has not heard from @Support",
  "id" : 121765805640790016,
  "created_at" : "2011-10-06 01:56:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "indices" : [ 0, 9 ],
      "id_str" : "48164887",
      "id" : 48164887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121746396276723712",
  "geo" : { },
  "id_str" : "121752799364132864",
  "in_reply_to_user_id" : 48164887,
  "text" : "@amoz1939 humanity is that crow",
  "id" : 121752799364132864,
  "in_reply_to_status_id" : 121746396276723712,
  "created_at" : "2011-10-06 01:05:04 +0000",
  "in_reply_to_screen_name" : "amoz1939",
  "in_reply_to_user_id_str" : "48164887",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "indices" : [ 3, 12 ],
      "id_str" : "48164887",
      "id" : 48164887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "haiku",
      "indices" : [ 90, 96 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121752603112640512",
  "text" : "RT @amoz1939: after a cold night ~crow stretching its wings to feel ~warm rays of the sun #haiku",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "haiku",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121746396276723712",
    "text" : "after a cold night ~crow stretching its wings to feel ~warm rays of the sun #haiku",
    "id" : 121746396276723712,
    "created_at" : "2011-10-06 00:39:37 +0000",
    "user" : {
      "name" : "Amoz Tan",
      "screen_name" : "amoz1939",
      "protected" : false,
      "id_str" : "48164887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775135706238758913\/cwiqEl_8_normal.jpg",
      "id" : 48164887,
      "verified" : false
    }
  },
  "id" : 121752603112640512,
  "created_at" : "2011-10-06 01:04:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "indices" : [ 3, 18 ],
      "id_str" : "43012495",
      "id" : 43012495
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ThankYouSteve",
      "indices" : [ 121, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121752158533197824",
  "text" : "RT @abandontheherd: Wow, the twitter stream is overflowing with love for Steve Jobs. Now that's a beautiful send off:))) #ThankYouSteve",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ThankYouSteve",
        "indices" : [ 101, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121748316802392066",
    "text" : "Wow, the twitter stream is overflowing with love for Steve Jobs. Now that's a beautiful send off:))) #ThankYouSteve",
    "id" : 121748316802392066,
    "created_at" : "2011-10-06 00:47:15 +0000",
    "user" : {
      "name" : "Marilyn Guadagnino",
      "screen_name" : "abandontheherd",
      "protected" : false,
      "id_str" : "43012495",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/531519108890640384\/lCK06Tl7_normal.jpeg",
      "id" : 43012495,
      "verified" : false
    }
  },
  "id" : 121752158533197824,
  "created_at" : "2011-10-06 01:02:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121704936764485632",
  "text" : "RT @JacksonPearce: Oh twitter. You guys are ENABLERS. Which is why I love you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121704361570213888",
    "text" : "Oh twitter. You guys are ENABLERS. Which is why I love you.",
    "id" : 121704361570213888,
    "created_at" : "2011-10-05 21:52:35 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 121704936764485632,
  "created_at" : "2011-10-05 21:54:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "loa",
      "indices" : [ 121, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121701728138694656",
  "text" : "RT @SpiritualNurse: A continuing exploration of the problem will prevent you from finding the solution. ~ Abraham-Hicks  #loa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loa",
        "indices" : [ 101, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121700889022050304",
    "text" : "A continuing exploration of the problem will prevent you from finding the solution. ~ Abraham-Hicks  #loa",
    "id" : 121700889022050304,
    "created_at" : "2011-10-05 21:38:47 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 121701728138694656,
  "created_at" : "2011-10-05 21:42:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121668127930068992",
  "text" : "I wish ppl wouldnt use \"born this way\" regarding being gay. so are serial killers.  we are ALL born a specific way.",
  "id" : 121668127930068992,
  "created_at" : "2011-10-05 19:28:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121666620153282561",
  "text" : "the past week or so my knees hurt. I'm too young for this!!",
  "id" : 121666620153282561,
  "created_at" : "2011-10-05 19:22:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121650777344319488",
  "text" : "RT @brandonrofl: Everyone has their own reality",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121648006931030016",
    "text" : "Everyone has their own reality",
    "id" : 121648006931030016,
    "created_at" : "2011-10-05 18:08:39 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 121650777344319488,
  "created_at" : "2011-10-05 18:19:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "indices" : [ 3, 19 ],
      "id_str" : "198263966",
      "id" : 198263966
    }, {
      "name" : "Edith Levy",
      "screen_name" : "Edithlevy21",
      "indices" : [ 50, 62 ],
      "id_str" : "172465164",
      "id" : 172465164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 100, 120 ],
      "url" : "http:\/\/t.co\/jImdebiO",
      "expanded_url" : "http:\/\/wp.me\/p1AFRw-aS",
      "display_url" : "wp.me\/p1AFRw-aS"
    } ]
  },
  "geo" : { },
  "id_str" : "121641862892224513",
  "text" : "RT @ToadHollowPhoto: Best raccoon photo, EVER! RT @Edithlevy21: New blog post today - Rocky Raccoon http:\/\/t.co\/jImdebiO \/via @wordpress ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Edith Levy",
        "screen_name" : "Edithlevy21",
        "indices" : [ 29, 41 ],
        "id_str" : "172465164",
        "id" : 172465164
      }, {
        "name" : "WordPress.com",
        "screen_name" : "wordpressdotcom",
        "indices" : [ 105, 121 ],
        "id_str" : "823905",
        "id" : 823905
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 99 ],
        "url" : "http:\/\/t.co\/jImdebiO",
        "expanded_url" : "http:\/\/wp.me\/p1AFRw-aS",
        "display_url" : "wp.me\/p1AFRw-aS"
      } ]
    },
    "geo" : { },
    "id_str" : "121641643442057217",
    "text" : "Best raccoon photo, EVER! RT @Edithlevy21: New blog post today - Rocky Raccoon http:\/\/t.co\/jImdebiO \/via @wordpressdotcom",
    "id" : 121641643442057217,
    "created_at" : "2011-10-05 17:43:22 +0000",
    "user" : {
      "name" : "Toad Hollow Photo",
      "screen_name" : "ToadHollowPhoto",
      "protected" : false,
      "id_str" : "198263966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000614203123\/fa9ea2dd2da15f9aa5a4c27436564d50_normal.jpeg",
      "id" : 198263966,
      "verified" : false
    }
  },
  "id" : 121641862892224513,
  "created_at" : "2011-10-05 17:44:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121628269190721536",
  "geo" : { },
  "id_str" : "121628520022683649",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver LOL",
  "id" : 121628520022683649,
  "in_reply_to_status_id" : 121628269190721536,
  "created_at" : "2011-10-05 16:51:13 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "indices" : [ 3, 15 ],
      "id_str" : "17210956",
      "id" : 17210956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121624776849633280",
  "text" : "RT @kempruffner: Life is too short to worry about how short life is",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tweetspinner.com\/\" rel=\"nofollow\"\u003ETweet Spinner\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121624493453099008",
    "text" : "Life is too short to worry about how short life is",
    "id" : 121624493453099008,
    "created_at" : "2011-10-05 16:35:13 +0000",
    "user" : {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "protected" : false,
      "id_str" : "17210956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63757772\/china_bike_normal.jpg",
      "id" : 17210956,
      "verified" : false
    }
  },
  "id" : 121624776849633280,
  "created_at" : "2011-10-05 16:36:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121624357851238401",
  "text" : "RT @brandonrofl: Life is short, but love grows tall. And lies know nothing, but truth knows all",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121621682753507328",
    "text" : "Life is short, but love grows tall. And lies know nothing, but truth knows all",
    "id" : 121621682753507328,
    "created_at" : "2011-10-05 16:24:03 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 121624357851238401,
  "created_at" : "2011-10-05 16:34:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121605567553867776",
  "text" : "the knots are coming undone. ppl are seeing the illusion that has been portayed as reality for so long. hurray!",
  "id" : 121605567553867776,
  "created_at" : "2011-10-05 15:20:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121603509631201280",
  "geo" : { },
  "id_str" : "121604577358397441",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver it is very beautiful!",
  "id" : 121604577358397441,
  "in_reply_to_status_id" : 121603509631201280,
  "created_at" : "2011-10-05 15:16:05 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121602541309001728",
  "geo" : { },
  "id_str" : "121603066255507456",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver what is on front? a pretty design or something specific?",
  "id" : 121603066255507456,
  "in_reply_to_status_id" : 121602541309001728,
  "created_at" : "2011-10-05 15:10:04 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121602385570316289",
  "text" : "RT @JohnCali: Asking \"Why is this happening?\" can only disempower you. Asking \"What do I want to make of this?\" does exactl\u2026 (cont) http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/ZLs7v7rb",
        "expanded_url" : "http:\/\/deck.ly\/~XFOIE",
        "display_url" : "deck.ly\/~XFOIE"
      } ]
    },
    "geo" : { },
    "id_str" : "121601201497325568",
    "text" : "Asking \"Why is this happening?\" can only disempower you. Asking \"What do I want to make of this?\" does exactl\u2026 (cont) http:\/\/t.co\/ZLs7v7rb",
    "id" : 121601201497325568,
    "created_at" : "2011-10-05 15:02:40 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 121602385570316289,
  "created_at" : "2011-10-05 15:07:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121602248995377152",
  "text" : "RT @JohnCali: Your primary goal in life is to feel good....~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121601303909642241",
    "text" : "Your primary goal in life is to feel good....~ Abraham",
    "id" : 121601303909642241,
    "created_at" : "2011-10-05 15:03:04 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 121602248995377152,
  "created_at" : "2011-10-05 15:06:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Trudeau",
      "screen_name" : "KevinTrudeau",
      "indices" : [ 3, 16 ],
      "id_str" : "17198504",
      "id" : 17198504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 93, 113 ],
      "url" : "http:\/\/t.co\/oVijI7Tr",
      "expanded_url" : "http:\/\/fb.me\/1c5ZJRZeT",
      "display_url" : "fb.me\/1c5ZJRZeT"
    } ]
  },
  "geo" : { },
  "id_str" : "121602113175420930",
  "text" : "RT @KevinTrudeau: Millions Of Bees In Florida Drop Dead In One Day, Are Pesticides To Blame? http:\/\/t.co\/oVijI7Tr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 75, 95 ],
        "url" : "http:\/\/t.co\/oVijI7Tr",
        "expanded_url" : "http:\/\/fb.me\/1c5ZJRZeT",
        "display_url" : "fb.me\/1c5ZJRZeT"
      } ]
    },
    "geo" : { },
    "id_str" : "121601694286102530",
    "text" : "Millions Of Bees In Florida Drop Dead In One Day, Are Pesticides To Blame? http:\/\/t.co\/oVijI7Tr",
    "id" : 121601694286102530,
    "created_at" : "2011-10-05 15:04:37 +0000",
    "user" : {
      "name" : "Kevin Trudeau",
      "screen_name" : "KevinTrudeau",
      "protected" : false,
      "id_str" : "17198504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/93095715\/Kevin-Trudeau_normal.jpg",
      "id" : 17198504,
      "verified" : false
    }
  },
  "id" : 121602113175420930,
  "created_at" : "2011-10-05 15:06:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121601602653138944",
  "text" : "RT @JohnCali: When you offer a vibration, the Universal forces are working in concert...to satisfy you. You really are the center of the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121600839851839489",
    "text" : "When you offer a vibration, the Universal forces are working in concert...to satisfy you. You really are the center of the Universe.~Abraham",
    "id" : 121600839851839489,
    "created_at" : "2011-10-05 15:01:14 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 121601602653138944,
  "created_at" : "2011-10-05 15:04:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "indices" : [ 19, 31 ],
      "id_str" : "40585382",
      "id" : 40585382
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 32, 44 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 45, 56 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 57, 69 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 70, 82 ],
      "id_str" : "90733366",
      "id" : 90733366
    }, {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 83, 94 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 95, 110 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 120, 129 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WW",
      "indices" : [ 15, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121597074981658625",
  "text" : "I follow these #WW @ReverendSue @CaroleODell @mimismutts @mindymayhem @AlisynGayle @TrishScott @mssuzcatsilver @XNutsyX @WahminSC \u2665",
  "id" : 121597074981658625,
  "created_at" : "2011-10-05 14:46:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    }, {
      "name" : "Irrespective Keith",
      "screen_name" : "keithr34",
      "indices" : [ 16, 25 ],
      "id_str" : "2876526385",
      "id" : 2876526385
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121583812919570432",
  "text" : "RT @TyrusBooks: @keithr34 I'm reading so much negative stuff, and it's tempting to give into that, but that's exactly what the bastards  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Irrespective Keith",
        "screen_name" : "keithr34",
        "indices" : [ 0, 9 ],
        "id_str" : "2876526385",
        "id" : 2876526385
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "121575626447659009",
    "geo" : { },
    "id_str" : "121575928882147328",
    "in_reply_to_user_id" : 14720302,
    "text" : "@keithr34 I'm reading so much negative stuff, and it's tempting to give into that, but that's exactly what the bastards want. So I won't.",
    "id" : 121575928882147328,
    "in_reply_to_status_id" : 121575626447659009,
    "created_at" : "2011-10-05 13:22:14 +0000",
    "in_reply_to_screen_name" : "Keith_Rawson_",
    "in_reply_to_user_id_str" : "14720302",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 121583812919570432,
  "created_at" : "2011-10-05 13:53:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121375361589194752",
  "text" : "@SamsaricWarrior what brought that on?",
  "id" : 121375361589194752,
  "created_at" : "2011-10-05 00:05:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121347999027830784",
  "text" : "I'm watching Big Rich Texas. I feel dirty...",
  "id" : 121347999027830784,
  "created_at" : "2011-10-04 22:16:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121335757003698176",
  "text" : "watching a show called Sperm Donor. This man has 70+ children.",
  "id" : 121335757003698176,
  "created_at" : "2011-10-04 21:27:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121335516200304640",
  "text" : "flu shot commercials everywhere.. NO THANK YOU!!",
  "id" : 121335516200304640,
  "created_at" : "2011-10-04 21:26:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Kate",
      "screen_name" : "RainbowKate",
      "indices" : [ 23, 35 ],
      "id_str" : "20756686",
      "id" : 20756686
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121335221965697024",
  "text" : "RT @mssuzcatsilver: RT @RainbowKate: Vegetables are a must on a diet.  I suggest carrot cake, zucchini bread, and pumpkin pie.  ~Jim Davis",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate",
        "screen_name" : "RainbowKate",
        "indices" : [ 3, 15 ],
        "id_str" : "20756686",
        "id" : 20756686
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121328689748258816",
    "text" : "RT @RainbowKate: Vegetables are a must on a diet.  I suggest carrot cake, zucchini bread, and pumpkin pie.  ~Jim Davis",
    "id" : 121328689748258816,
    "created_at" : "2011-10-04 20:59:48 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 121335221965697024,
  "created_at" : "2011-10-04 21:25:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The QI Elves",
      "screen_name" : "qikipedia",
      "indices" : [ 3, 13 ],
      "id_str" : "22151193",
      "id" : 22151193
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121307177448259586",
  "text" : "RT @qikipedia: A Libyan hospital treated a BBC Reporter for appendicitis - they refused payment and instead asked for BBC pens & mugs ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/yeaMCStD",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/ariel\/15168779",
        "display_url" : "bbc.co.uk\/ariel\/15168779"
      } ]
    },
    "geo" : { },
    "id_str" : "121260981207842816",
    "text" : "A Libyan hospital treated a BBC Reporter for appendicitis - they refused payment and instead asked for BBC pens & mugs http:\/\/t.co\/yeaMCStD",
    "id" : 121260981207842816,
    "created_at" : "2011-10-04 16:30:45 +0000",
    "user" : {
      "name" : "The QI Elves",
      "screen_name" : "qikipedia",
      "protected" : false,
      "id_str" : "22151193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549435855962513408\/RAEeXuVF_normal.png",
      "id" : 22151193,
      "verified" : true
    }
  },
  "id" : 121307177448259586,
  "created_at" : "2011-10-04 19:34:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121305982742700032",
  "geo" : { },
  "id_str" : "121306383340666880",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver its better to just get it out of your system than let it smolder and drip out.",
  "id" : 121306383340666880,
  "in_reply_to_status_id" : 121305982742700032,
  "created_at" : "2011-10-04 19:31:10 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jen",
      "screen_name" : "MyBrownNewfies",
      "indices" : [ 3, 18 ],
      "id_str" : "213161870",
      "id" : 213161870
    }, {
      "name" : "Pup Fan",
      "screen_name" : "wantmorepuppies",
      "indices" : [ 79, 95 ],
      "id_str" : "176802502",
      "id" : 176802502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/1RkfJnpw",
      "expanded_url" : "http:\/\/twrt.me\/ljifw2",
      "display_url" : "twrt.me\/ljifw2"
    } ]
  },
  "geo" : { },
  "id_str" : "121296428327899136",
  "text" : "RT @MyBrownNewfies: We're gonna need a bigger bowl... http:\/\/t.co\/1RkfJnpw via @wantmorepuppies",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/triberr.com\" rel=\"nofollow\"\u003ETriberr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pup Fan",
        "screen_name" : "wantmorepuppies",
        "indices" : [ 59, 75 ],
        "id_str" : "176802502",
        "id" : 176802502
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/1RkfJnpw",
        "expanded_url" : "http:\/\/twrt.me\/ljifw2",
        "display_url" : "twrt.me\/ljifw2"
      } ]
    },
    "geo" : { },
    "id_str" : "121295811551309824",
    "text" : "We're gonna need a bigger bowl... http:\/\/t.co\/1RkfJnpw via @wantmorepuppies",
    "id" : 121295811551309824,
    "created_at" : "2011-10-04 18:49:09 +0000",
    "user" : {
      "name" : "Jen",
      "screen_name" : "MyBrownNewfies",
      "protected" : false,
      "id_str" : "213161870",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000365475755\/208bcb9c6985d9a32fff83387a4379a9_normal.jpeg",
      "id" : 213161870,
      "verified" : false
    }
  },
  "id" : 121296428327899136,
  "created_at" : "2011-10-04 18:51:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penguin Books",
      "screen_name" : "PenguinPbks",
      "indices" : [ 0, 12 ],
      "id_str" : "735512676990849025",
      "id" : 735512676990849025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "121269888533807105",
  "geo" : { },
  "id_str" : "121270395826479106",
  "in_reply_to_user_id" : 23484629,
  "text" : "@PenguinPbks Because what you read matters.",
  "id" : 121270395826479106,
  "in_reply_to_status_id" : 121269888533807105,
  "created_at" : "2011-10-04 17:08:10 +0000",
  "in_reply_to_screen_name" : "PenguinBooks",
  "in_reply_to_user_id_str" : "23484629",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 56, 71 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121268013826711553",
  "text" : "still trying to figure out and over 1\/2 way mark o-O RT @richarddoetsch: \u265EWhat were you born to do?",
  "id" : 121268013826711553,
  "created_at" : "2011-10-04 16:58:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121266882836836352",
  "text" : "omg'ness.. they're hugging me now (at bible study) lol",
  "id" : 121266882836836352,
  "created_at" : "2011-10-04 16:54:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "121034724197142528",
  "text" : "RT @dhammagirl: The world needs a download of patience and compassion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "121026575817916416",
    "text" : "The world needs a download of patience and compassion",
    "id" : 121026575817916416,
    "created_at" : "2011-10-04 00:59:18 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 121034724197142528,
  "created_at" : "2011-10-04 01:31:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Consortium Books",
      "screen_name" : "ConsortiumBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "29465972",
      "id" : 29465972
    }, {
      "name" : "Val McDermid",
      "screen_name" : "valmcdermid",
      "indices" : [ 23, 35 ],
      "id_str" : "26523408",
      "id" : 26523408
    }, {
      "name" : "Mystery Scene Mag",
      "screen_name" : "MysteryScene",
      "indices" : [ 55, 68 ],
      "id_str" : "28801508",
      "id" : 28801508
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "trickofthedark",
      "indices" : [ 90, 105 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120968234924126208",
  "text" : "RT @ConsortiumBooks: . @valmcdermid is on the cover of @MysteryScene! We've got copies of #trickofthedark to give away. Tweet us if you  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Val McDermid",
        "screen_name" : "valmcdermid",
        "indices" : [ 2, 14 ],
        "id_str" : "26523408",
        "id" : 26523408
      }, {
        "name" : "Mystery Scene Mag",
        "screen_name" : "MysteryScene",
        "indices" : [ 34, 47 ],
        "id_str" : "28801508",
        "id" : 28801508
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "trickofthedark",
        "indices" : [ 69, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120955404372029440",
    "text" : ". @valmcdermid is on the cover of @MysteryScene! We've got copies of #trickofthedark to give away. Tweet us if you want to win!",
    "id" : 120955404372029440,
    "created_at" : "2011-10-03 20:16:30 +0000",
    "user" : {
      "name" : "Consortium Books",
      "screen_name" : "ConsortiumBooks",
      "protected" : false,
      "id_str" : "29465972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/446736652581351424\/2ANSRsOV_normal.jpeg",
      "id" : 29465972,
      "verified" : false
    }
  },
  "id" : 120968234924126208,
  "created_at" : "2011-10-03 21:07:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120958946335932416",
  "geo" : { },
  "id_str" : "120960140412338176",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles hubby's the cleaner, not me, so when he cleans.. things usually get ugly..lol",
  "id" : 120960140412338176,
  "in_reply_to_status_id" : 120958946335932416,
  "created_at" : "2011-10-03 20:35:19 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melissa Foster",
      "screen_name" : "Melissa_Foster",
      "indices" : [ 3, 18 ],
      "id_str" : "27873266",
      "id" : 27873266
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120959905292230656",
  "text" : "RT @Melissa_Foster: Help CHASING AMANDA get to #1 and win free ebooks. Giving away 25 if it hits #1 on Amazon this week! http:\/\/t.co\/sSu ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/sSuw6KY5",
        "expanded_url" : "http:\/\/amzn.to\/oIZiVb",
        "display_url" : "amzn.to\/oIZiVb"
      } ]
    },
    "geo" : { },
    "id_str" : "120958759697788928",
    "text" : "Help CHASING AMANDA get to #1 and win free ebooks. Giving away 25 if it hits #1 on Amazon this week! http:\/\/t.co\/sSuw6KY5 Pls RT",
    "id" : 120958759697788928,
    "created_at" : "2011-10-03 20:29:50 +0000",
    "user" : {
      "name" : "Melissa Foster",
      "screen_name" : "Melissa_Foster",
      "protected" : false,
      "id_str" : "27873266",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2596088900\/tqkuamg9t83n7r614gg3_normal.jpeg",
      "id" : 27873266,
      "verified" : false
    }
  },
  "id" : 120959905292230656,
  "created_at" : "2011-10-03 20:34:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120957305041862656",
  "geo" : { },
  "id_str" : "120957981683748864",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles same for me when hubby cleans..lol",
  "id" : 120957981683748864,
  "in_reply_to_status_id" : 120957305041862656,
  "created_at" : "2011-10-03 20:26:44 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120956918339616769",
  "text" : "humans are ever-changing beings. you can't apply absolute values to that.",
  "id" : 120956918339616769,
  "created_at" : "2011-10-03 20:22:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120955424546623489",
  "text" : "justice is a weird thing. I don't like justice. It's not..hmm.. equal.. for everyone. There's no way to spit out exact answer.",
  "id" : 120955424546623489,
  "created_at" : "2011-10-03 20:16:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120950745892786176",
  "text" : "ppl are discovering what they thought was real and steady is not.",
  "id" : 120950745892786176,
  "created_at" : "2011-10-03 19:57:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "givefearlessly",
      "indices" : [ 110, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/0umRoQOs",
      "expanded_url" : "http:\/\/networkedblogs.com\/nTS1X",
      "display_url" : "networkedblogs.com\/nTS1X"
    } ]
  },
  "geo" : { },
  "id_str" : "120946838927978496",
  "text" : "RT @grouchypuppy: RIP Kodiak from The Herd: http:\/\/t.co\/0umRoQOs Hard news to read but a reminder of how dogs #givefearlessly and #influ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "givefearlessly",
        "indices" : [ 92, 107 ]
      }, {
        "text" : "influencepositively",
        "indices" : [ 112, 132 ]
      } ],
      "urls" : [ {
        "indices" : [ 26, 46 ],
        "url" : "http:\/\/t.co\/0umRoQOs",
        "expanded_url" : "http:\/\/networkedblogs.com\/nTS1X",
        "display_url" : "networkedblogs.com\/nTS1X"
      } ]
    },
    "geo" : { },
    "id_str" : "120944098168406017",
    "text" : "RIP Kodiak from The Herd: http:\/\/t.co\/0umRoQOs Hard news to read but a reminder of how dogs #givefearlessly and #influencepositively",
    "id" : 120944098168406017,
    "created_at" : "2011-10-03 19:31:34 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 120946838927978496,
  "created_at" : "2011-10-03 19:42:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/w3VnkDsD",
      "expanded_url" : "http:\/\/www.tv.com\/shows\/csi-crime-scene-investigation\/unfriendly-skies-9248\/",
      "display_url" : "tv.com\/shows\/csi-crim\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120940791077158913",
  "text" : "http:\/\/t.co\/w3VnkDsD",
  "id" : 120940791077158913,
  "created_at" : "2011-10-03 19:18:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120937938715541504",
  "text" : "turned out he had brain infection. ppl assumed he was being a jerk but he was sick. and they killed him in a frenzy.",
  "id" : 120937938715541504,
  "created_at" : "2011-10-03 19:07:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120937548993409025",
  "text" : "csi: that's the problem. no one thought what is was like to be the victim. (paraphrasing) man on flight went crazy, was killed.",
  "id" : 120937548993409025,
  "created_at" : "2011-10-03 19:05:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120931896615120896",
  "text" : "so... I poked myself in the stomach w a giant screwdriver. prob get a nice bruise..hehe",
  "id" : 120931896615120896,
  "created_at" : "2011-10-03 18:43:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    }, {
      "name" : "Picture Cool",
      "screen_name" : "picturecool",
      "indices" : [ 84, 96 ],
      "id_str" : "46152541",
      "id" : 46152541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120911240888455169",
  "text" : "RT @ThisBlueWorld: Oh yes, they do, and 2nd is a youngin, see the velvety horns! RT @picturecool: Didn't know moose came this big. #phot ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Picture Cool",
        "screen_name" : "picturecool",
        "indices" : [ 65, 77 ],
        "id_str" : "46152541",
        "id" : 46152541
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 112, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/I7gjB22I",
        "expanded_url" : "http:\/\/bit.ly\/pGEKiK",
        "display_url" : "bit.ly\/pGEKiK"
      } ]
    },
    "geo" : { },
    "id_str" : "120910318745563136",
    "text" : "Oh yes, they do, and 2nd is a youngin, see the velvety horns! RT @picturecool: Didn't know moose came this big. #photo http:\/\/t.co\/I7gjB22I",
    "id" : 120910318745563136,
    "created_at" : "2011-10-03 17:17:21 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 120911240888455169,
  "created_at" : "2011-10-03 17:21:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "SagesandScientists",
      "screen_name" : "SagesScientists",
      "indices" : [ 38, 54 ],
      "id_str" : "4569640454",
      "id" : 4569640454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120907793371893760",
  "text" : "RT @DeepakChopra: Supporting this! RT @SagesScientists A true friend accepts who you are without judging you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SagesandScientists",
        "screen_name" : "SagesScientists",
        "indices" : [ 20, 36 ],
        "id_str" : "4569640454",
        "id" : 4569640454
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120907536680501250",
    "text" : "Supporting this! RT @SagesScientists A true friend accepts who you are without judging you.",
    "id" : 120907536680501250,
    "created_at" : "2011-10-03 17:06:17 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 120907793371893760,
  "created_at" : "2011-10-03 17:07:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/PNgBGBRt",
      "expanded_url" : "http:\/\/tinyurl.com\/3jd92dc",
      "display_url" : "tinyurl.com\/3jd92dc"
    } ]
  },
  "geo" : { },
  "id_str" : "120907467000512514",
  "text" : "RT @JeremyCShipp: Could you please help me spread the word about this free monster anthology? http:\/\/t.co\/PNgBGBRt #kindle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 97, 104 ]
      } ],
      "urls" : [ {
        "indices" : [ 76, 96 ],
        "url" : "http:\/\/t.co\/PNgBGBRt",
        "expanded_url" : "http:\/\/tinyurl.com\/3jd92dc",
        "display_url" : "tinyurl.com\/3jd92dc"
      } ]
    },
    "geo" : { },
    "id_str" : "120905587440627712",
    "text" : "Could you please help me spread the word about this free monster anthology? http:\/\/t.co\/PNgBGBRt #kindle",
    "id" : 120905587440627712,
    "created_at" : "2011-10-03 16:58:33 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 120907467000512514,
  "created_at" : "2011-10-03 17:06:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    }, {
      "name" : "Mindy Kaling",
      "screen_name" : "mindykaling",
      "indices" : [ 116, 128 ],
      "id_str" : "23544596",
      "id" : 23544596
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120899062705823744",
  "text" : "RT @brandonrofl: \"So many people I work with\u2014famous actors, accomplished writers\u2014were overlooked in high school.\" - @mindykaling you're  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mindy Kaling",
        "screen_name" : "mindykaling",
        "indices" : [ 99, 111 ],
        "id_str" : "23544596",
        "id" : 23544596
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120898206749044736",
    "text" : "\"So many people I work with\u2014famous actors, accomplished writers\u2014were overlooked in high school.\" - @mindykaling you're awesome",
    "id" : 120898206749044736,
    "created_at" : "2011-10-03 16:29:13 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 120899062705823744,
  "created_at" : "2011-10-03 16:32:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squirrelers",
      "screen_name" : "squirrelers",
      "indices" : [ 3, 15 ],
      "id_str" : "81271026",
      "id" : 81271026
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/7Ou5DkIq",
      "expanded_url" : "http:\/\/bit.ly\/qjXdsn",
      "display_url" : "bit.ly\/qjXdsn"
    } ]
  },
  "geo" : { },
  "id_str" : "120897048252923905",
  "text" : "RT @squirrelers: Squirrelers October Giveaway: $75 in Prizes http:\/\/t.co\/7Ou5DkIq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/7Ou5DkIq",
        "expanded_url" : "http:\/\/bit.ly\/qjXdsn",
        "display_url" : "bit.ly\/qjXdsn"
      } ]
    },
    "geo" : { },
    "id_str" : "120895550513086464",
    "text" : "Squirrelers October Giveaway: $75 in Prizes http:\/\/t.co\/7Ou5DkIq",
    "id" : 120895550513086464,
    "created_at" : "2011-10-03 16:18:40 +0000",
    "user" : {
      "name" : "Squirrelers",
      "screen_name" : "squirrelers",
      "protected" : false,
      "id_str" : "81271026",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000692289347\/713c68cde56c1159488f334a769708f8_normal.png",
      "id" : 81271026,
      "verified" : false
    }
  },
  "id" : 120897048252923905,
  "created_at" : "2011-10-03 16:24:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "juliette owens",
      "screen_name" : "wildwitchyju",
      "indices" : [ 25, 38 ],
      "id_str" : "67346912",
      "id" : 67346912
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "crow",
      "indices" : [ 39, 44 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/vXmRYZog",
      "expanded_url" : "http:\/\/everypictellsastory.wordpress.com\/2011\/10\/03\/misty-magical-mornings\/",
      "display_url" : "everypictellsastory.wordpress.com\/2011\/10\/03\/mis\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120892376842637313",
  "text" : "http:\/\/t.co\/vXmRYZog  by @wildwitchyju #crow",
  "id" : 120892376842637313,
  "created_at" : "2011-10-03 16:06:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120887165700931584",
  "text" : "RT @dailygalaxy: \"Spacetime has No Time Dimension\" -- Radical Theory Claims that Time is Not the 4th Dimension (Today's Most Popular) ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.typepad.com\/\" rel=\"nofollow\"\u003ETypePad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/6lkx8AuF",
        "expanded_url" : "http:\/\/bit.ly\/qb9wdy",
        "display_url" : "bit.ly\/qb9wdy"
      } ]
    },
    "geo" : { },
    "id_str" : "120770084158451712",
    "text" : "\"Spacetime has No Time Dimension\" -- Radical Theory Claims that Time is Not the 4th Dimension (Today's Most Popular) http:\/\/t.co\/6lkx8AuF",
    "id" : 120770084158451712,
    "created_at" : "2011-10-03 08:00:06 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 120887165700931584,
  "created_at" : "2011-10-03 15:45:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The DSH",
      "screen_name" : "davidscotthay",
      "indices" : [ 29, 43 ],
      "id_str" : "2669840034",
      "id" : 2669840034
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120880654048178176",
  "text" : "I really loved your portayal @DavidScottHay of Lucifer in \"Fall\" - I look forward to book 2",
  "id" : 120880654048178176,
  "created_at" : "2011-10-03 15:19:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "moose",
      "indices" : [ 21, 27 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/T9yHlfFS",
      "expanded_url" : "http:\/\/stewartstick.wordpress.com\/2011\/10\/02\/algonquin-park-fall-moose\/",
      "display_url" : "stewartstick.wordpress.com\/2011\/10\/02\/alg\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "120878911834963968",
  "text" : "http:\/\/t.co\/T9yHlfFS #moose",
  "id" : 120878911834963968,
  "created_at" : "2011-10-03 15:12:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120618649781403649",
  "text" : "RT @GraveStomper: One of the biggest problems with humans is they show timidity when they should show courage and arrogance when they sh ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120610773096611840",
    "text" : "One of the biggest problems with humans is they show timidity when they should show courage and arrogance when they should show humility.",
    "id" : 120610773096611840,
    "created_at" : "2011-10-02 21:27:03 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 120618649781403649,
  "created_at" : "2011-10-02 21:58:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/LlP9B5Ww",
      "expanded_url" : "http:\/\/bit.ly\/n6nYoS",
      "display_url" : "bit.ly\/n6nYoS"
    } ]
  },
  "geo" : { },
  "id_str" : "120549719993888768",
  "text" : "RT @Moonrust: 5 Real Animal Friendships Straight Out Of A Disney Movie http:\/\/t.co\/LlP9B5Ww",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nibirutech.com\/mobilerss-google-reader-iphone.html\" rel=\"nofollow\"\u003EMobileRSS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/LlP9B5Ww",
        "expanded_url" : "http:\/\/bit.ly\/n6nYoS",
        "display_url" : "bit.ly\/n6nYoS"
      } ]
    },
    "geo" : { },
    "id_str" : "120548284036165632",
    "text" : "5 Real Animal Friendships Straight Out Of A Disney Movie http:\/\/t.co\/LlP9B5Ww",
    "id" : 120548284036165632,
    "created_at" : "2011-10-02 17:18:45 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 120549719993888768,
  "created_at" : "2011-10-02 17:24:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Bidinotto",
      "screen_name" : "RobertBidinotto",
      "indices" : [ 3, 19 ],
      "id_str" : "318649497",
      "id" : 318649497
    }, {
      "name" : "rsullivan9597",
      "screen_name" : "rsullivan9597",
      "indices" : [ 117, 131 ],
      "id_str" : "18405263",
      "id" : 18405263
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AUTHORS",
      "indices" : [ 21, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/0LPWoiBf",
      "expanded_url" : "http:\/\/bit.ly\/nrf83y",
      "display_url" : "bit.ly\/nrf83y"
    } ]
  },
  "geo" : { },
  "id_str" : "120546407592640512",
  "text" : "RT @RobertBidinotto: #AUTHORS BUSINESS CARDS: http:\/\/t.co\/0LPWoiBf GREAT INFO on where to get 'em, how to use 'em by @rsullivan9597. #in ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "rsullivan9597",
        "screen_name" : "rsullivan9597",
        "indices" : [ 96, 110 ],
        "id_str" : "18405263",
        "id" : 18405263
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AUTHORS",
        "indices" : [ 0, 8 ]
      }, {
        "text" : "indieauthors",
        "indices" : [ 112, 125 ]
      }, {
        "text" : "IAN1",
        "indices" : [ 126, 131 ]
      }, {
        "text" : "selfpub",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 25, 45 ],
        "url" : "http:\/\/t.co\/0LPWoiBf",
        "expanded_url" : "http:\/\/bit.ly\/nrf83y",
        "display_url" : "bit.ly\/nrf83y"
      } ]
    },
    "geo" : { },
    "id_str" : "120326162927976448",
    "text" : "#AUTHORS BUSINESS CARDS: http:\/\/t.co\/0LPWoiBf GREAT INFO on where to get 'em, how to use 'em by @rsullivan9597. #indieauthors #IAN1 #selfpub",
    "id" : 120326162927976448,
    "created_at" : "2011-10-02 02:36:07 +0000",
    "user" : {
      "name" : "Robert Bidinotto",
      "screen_name" : "RobertBidinotto",
      "protected" : false,
      "id_str" : "318649497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653227113126891520\/k_Zckvb4_normal.jpg",
      "id" : 318649497,
      "verified" : false
    }
  },
  "id" : 120546407592640512,
  "created_at" : "2011-10-02 17:11:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fort Lauderdale Sun",
      "screen_name" : "FtLauderdaleSun",
      "indices" : [ 3, 19 ],
      "id_str" : "61352185",
      "id" : 61352185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/wEAoHr2X",
      "expanded_url" : "http:\/\/ftlauderdalesun.com\/wp\/?p=5204",
      "display_url" : "ftlauderdalesun.com\/wp\/?p=5204"
    } ]
  },
  "geo" : { },
  "id_str" : "120539802608205824",
  "text" : "RT @FtLauderdaleSun: : : Photoblog : All things bright and beautiful : Oct 1st http:\/\/t.co\/wEAoHr2X",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ftlauderdalesun.com\/wp\/\" rel=\"nofollow\"\u003EFtLauderdaleSun\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/wEAoHr2X",
        "expanded_url" : "http:\/\/ftlauderdalesun.com\/wp\/?p=5204",
        "display_url" : "ftlauderdalesun.com\/wp\/?p=5204"
      } ]
    },
    "geo" : { },
    "id_str" : "120158341459755008",
    "text" : ": : Photoblog : All things bright and beautiful : Oct 1st http:\/\/t.co\/wEAoHr2X",
    "id" : 120158341459755008,
    "created_at" : "2011-10-01 15:29:15 +0000",
    "user" : {
      "name" : "Fort Lauderdale Sun",
      "screen_name" : "FtLauderdaleSun",
      "protected" : false,
      "id_str" : "61352185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1520363852\/trees_normal.jpg",
      "id" : 61352185,
      "verified" : false
    }
  },
  "id" : 120539802608205824,
  "created_at" : "2011-10-02 16:45:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120536374582575104",
  "text" : "RT @SheilaWalsh: Four women on my flight got into a fight for overhead luggage space...not pretty",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120533543855202304",
    "text" : "Four women on my flight got into a fight for overhead luggage space...not pretty",
    "id" : 120533543855202304,
    "created_at" : "2011-10-02 16:20:10 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 120536374582575104,
  "created_at" : "2011-10-02 16:31:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alan S Hochman Photo",
      "screen_name" : "Photobug52",
      "indices" : [ 3, 14 ],
      "id_str" : "90379242",
      "id" : 90379242
    }, {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 103, 115 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birding",
      "indices" : [ 51, 59 ]
    }, {
      "text" : "birds",
      "indices" : [ 60, 66 ]
    }, {
      "text" : "egrets",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "reddish",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "egret",
      "indices" : [ 84, 90 ]
    }, {
      "text" : "birding",
      "indices" : [ 91, 99 ]
    } ],
    "urls" : [ {
      "indices" : [ 30, 50 ],
      "url" : "http:\/\/t.co\/7lU0WUQV",
      "expanded_url" : "http:\/\/bit.ly\/mc25vK",
      "display_url" : "bit.ly\/mc25vK"
    } ]
  },
  "geo" : { },
  "id_str" : "120531781614182400",
  "text" : "RT @Photobug52: Reddish Egret http:\/\/t.co\/7lU0WUQV #birding #birds #egrets #reddish #egret #birding cc:@CaroleODell",
  "id" : 120531781614182400,
  "created_at" : "2011-10-02 16:13:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120515404538970112",
  "text" : "RT @JohnCali: If I feel angry at anyone, I will see if what I dislike in the person actually exists in me. ~ Deepak Chopra",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120514705369468929",
    "text" : "If I feel angry at anyone, I will see if what I dislike in the person actually exists in me. ~ Deepak Chopra",
    "id" : 120514705369468929,
    "created_at" : "2011-10-02 15:05:19 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 120515404538970112,
  "created_at" : "2011-10-02 15:08:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sniffly Kitty",
      "screen_name" : "snifflykitty0",
      "indices" : [ 0, 14 ],
      "id_str" : "202826045",
      "id" : 202826045
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "120513430527541249",
  "geo" : { },
  "id_str" : "120514383339208705",
  "in_reply_to_user_id" : 202826045,
  "text" : "@snifflykitty0 \"lockdown\" looks good. added to my wishlist.",
  "id" : 120514383339208705,
  "in_reply_to_status_id" : 120513430527541249,
  "created_at" : "2011-10-02 15:04:02 +0000",
  "in_reply_to_screen_name" : "snifflykitty0",
  "in_reply_to_user_id_str" : "202826045",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 3, 15 ],
      "id_str" : "51880276",
      "id" : 51880276
    }, {
      "name" : "RUTH BUZZI",
      "screen_name" : "Ruth_A_Buzzi",
      "indices" : [ 20, 33 ],
      "id_str" : "206506117",
      "id" : 206506117
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120513421736296449",
  "text" : "RT @VirgoJohnny: RT @Ruth_A_Buzzi I have no problem with caffeine.  But I have a rather serious problem without it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "RUTH BUZZI",
        "screen_name" : "Ruth_A_Buzzi",
        "indices" : [ 3, 16 ],
        "id_str" : "206506117",
        "id" : 206506117
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120512933498331137",
    "text" : "RT @Ruth_A_Buzzi I have no problem with caffeine.  But I have a rather serious problem without it.",
    "id" : 120512933498331137,
    "created_at" : "2011-10-02 14:58:17 +0000",
    "user" : {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "protected" : false,
      "id_str" : "51880276",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799741402037030916\/0N5lLVnO_normal.jpg",
      "id" : 51880276,
      "verified" : false
    }
  },
  "id" : 120513421736296449,
  "created_at" : "2011-10-02 15:00:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120512725855121408",
  "text" : "RT @GraveStomper: Inevitably it all turns to dust.  Only the insane obsess  and fight over dust.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120507997297451008",
    "text" : "Inevitably it all turns to dust.  Only the insane obsess  and fight over dust.",
    "id" : 120507997297451008,
    "created_at" : "2011-10-02 14:38:40 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 120512725855121408,
  "created_at" : "2011-10-02 14:57:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "indices" : [ 3, 15 ],
      "id_str" : "27426615",
      "id" : 27426615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120506718089261057",
  "text" : "RT @DaveUrsillo: Just paid $6.47 for a coffee called The Zombie Killer. If it doesn't gimme superpowers, my wallet and I will be pretty  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120506082958389248",
    "text" : "Just paid $6.47 for a coffee called The Zombie Killer. If it doesn't gimme superpowers, my wallet and I will be pretty bummed.",
    "id" : 120506082958389248,
    "created_at" : "2011-10-02 14:31:03 +0000",
    "user" : {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "protected" : false,
      "id_str" : "27426615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730048048202715137\/3hzFy3qT_normal.jpg",
      "id" : 27426615,
      "verified" : false
    }
  },
  "id" : 120506718089261057,
  "created_at" : "2011-10-02 14:33:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/uICFn9O0",
      "expanded_url" : "http:\/\/bit.ly\/pVgVb7",
      "display_url" : "bit.ly\/pVgVb7"
    } ]
  },
  "geo" : { },
  "id_str" : "120504722011598851",
  "text" : "\"I would just act like it was my brother who was going to be on that gurney, and then I would cook,\" Price said. http:\/\/t.co\/uICFn9O0",
  "id" : 120504722011598851,
  "created_at" : "2011-10-02 14:25:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    }, {
      "name" : "Rebecca Bodnar",
      "screen_name" : "eddiejean23",
      "indices" : [ 31, 43 ],
      "id_str" : "285763926",
      "id" : 285763926
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120314203700600833",
  "text" : "RT @GaribaldiRous: It's me! RT @eddiejean23 @iheartjimmynet My friend just saw THIS at a restaurant in Kyle, Tx http:\/\/t.co\/R7KtNuaL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rebecca Bodnar",
        "screen_name" : "eddiejean23",
        "indices" : [ 12, 24 ],
        "id_str" : "285763926",
        "id" : 285763926
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/R7KtNuaL",
        "expanded_url" : "http:\/\/twitpic.com\/6tql5e",
        "display_url" : "twitpic.com\/6tql5e"
      } ]
    },
    "geo" : { },
    "id_str" : "120313758110326785",
    "text" : "It's me! RT @eddiejean23 @iheartjimmynet My friend just saw THIS at a restaurant in Kyle, Tx http:\/\/t.co\/R7KtNuaL",
    "id" : 120313758110326785,
    "created_at" : "2011-10-02 01:46:49 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 120314203700600833,
  "created_at" : "2011-10-02 01:48:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Che  Butter Jones",
      "screen_name" : "OccupyTheHood",
      "indices" : [ 3, 17 ],
      "id_str" : "379936422",
      "id" : 379936422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120285093611831296",
  "text" : "RT @OccupyTheHood: Look on TV... what do you see? you see that The Revolution will NOT be televised! We ARE our OWN reporters!!\n#OccupyW ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OccupyWallSt",
        "indices" : [ 109, 122 ]
      }, {
        "text" : "OccupyTheHood",
        "indices" : [ 123, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "120281650373468160",
    "text" : "Look on TV... what do you see? you see that The Revolution will NOT be televised! We ARE our OWN reporters!!\n#OccupyWallSt\n#OccupyTheHood",
    "id" : 120281650373468160,
    "created_at" : "2011-10-01 23:39:14 +0000",
    "user" : {
      "name" : "Che  Butter Jones",
      "screen_name" : "OccupyTheHood",
      "protected" : false,
      "id_str" : "379936422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770801622725365762\/Nn0Txhbv_normal.jpg",
      "id" : 379936422,
      "verified" : false
    }
  },
  "id" : 120285093611831296,
  "created_at" : "2011-10-01 23:52:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Philosophers quotes",
      "screen_name" : "philo_quotes",
      "indices" : [ 3, 16 ],
      "id_str" : "110794236",
      "id" : 110794236
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/U9gFWB48",
      "expanded_url" : "http:\/\/bit.ly\/philq",
      "display_url" : "bit.ly\/philq"
    } ]
  },
  "geo" : { },
  "id_str" : "120282045854392321",
  "text" : "RT @philo_quotes: Science is nothing but perception. ~ Plato http:\/\/t.co\/U9gFWB48",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/philosophical-quotes.com\/\" rel=\"nofollow\"\u003EPhilosophical Quotes\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/U9gFWB48",
        "expanded_url" : "http:\/\/bit.ly\/philq",
        "display_url" : "bit.ly\/philq"
      } ]
    },
    "geo" : { },
    "id_str" : "120280339045298176",
    "text" : "Science is nothing but perception. ~ Plato http:\/\/t.co\/U9gFWB48",
    "id" : 120280339045298176,
    "created_at" : "2011-10-01 23:34:02 +0000",
    "user" : {
      "name" : "Philosophers quotes",
      "screen_name" : "philo_quotes",
      "protected" : false,
      "id_str" : "110794236",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671918965\/rodin_normal.jpg",
      "id" : 110794236,
      "verified" : false
    }
  },
  "id" : 120282045854392321,
  "created_at" : "2011-10-01 23:40:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120264479236825088",
  "text" : "waiting for hubby to come home and feed me",
  "id" : 120264479236825088,
  "created_at" : "2011-10-01 22:31:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle Zink",
      "screen_name" : "ProphecyPress",
      "indices" : [ 3, 17 ],
      "id_str" : "160989697",
      "id" : 160989697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120258019706675200",
  "text" : "RT @ProphecyPress: If you're a librarian, library representative, or lover of libraries  or just spread the word, you can win free books ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/75mIIbXt",
        "expanded_url" : "http:\/\/bit.ly\/oChhpp",
        "display_url" : "bit.ly\/oChhpp"
      } ]
    },
    "geo" : { },
    "id_str" : "120253013075046400",
    "text" : "If you're a librarian, library representative, or lover of libraries  or just spread the word, you can win free books! http:\/\/t.co\/75mIIbXt",
    "id" : 120253013075046400,
    "created_at" : "2011-10-01 21:45:27 +0000",
    "user" : {
      "name" : "Michelle Zink",
      "screen_name" : "ProphecyPress",
      "protected" : false,
      "id_str" : "160989697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1876273997\/Temp_normal.jpg",
      "id" : 160989697,
      "verified" : false
    }
  },
  "id" : 120258019706675200,
  "created_at" : "2011-10-01 22:05:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120239032428011520",
  "text" : "I want to feel good again..like I did for 4-5 months straight.",
  "id" : 120239032428011520,
  "created_at" : "2011-10-01 20:49:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alexis Rotella",
      "screen_name" : "tankaqueen",
      "indices" : [ 3, 14 ],
      "id_str" : "159558577",
      "id" : 159558577
    }, {
      "name" : "Coyote (Roary)",
      "screen_name" : "CoyoteSings",
      "indices" : [ 16, 28 ],
      "id_str" : "118573185",
      "id" : 118573185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120184236073435136",
  "text" : "RT @tankaqueen: @CoyoteSings move beyond the fear; that's why you're here",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Coyote (Roary)",
        "screen_name" : "CoyoteSings",
        "indices" : [ 0, 12 ],
        "id_str" : "118573185",
        "id" : 118573185
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "120181269010194432",
    "geo" : { },
    "id_str" : "120183088507650048",
    "in_reply_to_user_id" : 118573185,
    "text" : "@CoyoteSings move beyond the fear; that's why you're here",
    "id" : 120183088507650048,
    "in_reply_to_status_id" : 120181269010194432,
    "created_at" : "2011-10-01 17:07:35 +0000",
    "in_reply_to_screen_name" : "CoyoteSings",
    "in_reply_to_user_id_str" : "118573185",
    "user" : {
      "name" : "Alexis Rotella",
      "screen_name" : "tankaqueen",
      "protected" : false,
      "id_str" : "159558577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1408416838\/lipprints_normal.jpg",
      "id" : 159558577,
      "verified" : false
    }
  },
  "id" : 120184236073435136,
  "created_at" : "2011-10-01 17:12:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120173259206557696",
  "text" : "the ghosts are having something garlicky today",
  "id" : 120173259206557696,
  "created_at" : "2011-10-01 16:28:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120169587764498435",
  "text" : "good convo with @tragic_pizza .. he's good for my aura. : ) (hint: everyone should follow him!)",
  "id" : 120169587764498435,
  "created_at" : "2011-10-01 16:13:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120164598052700161",
  "text" : "@tragic_pizza like time.. it's always now.",
  "id" : 120164598052700161,
  "created_at" : "2011-10-01 15:54:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 138 ],
      "url" : "http:\/\/t.co\/axiG01Bq",
      "expanded_url" : "http:\/\/tinyurl.com\/3wzvd7l",
      "display_url" : "tinyurl.com\/3wzvd7l"
    } ]
  },
  "geo" : { },
  "id_str" : "120163734139318272",
  "text" : "RT @Soulseedzforall: Every act of love sheds light on the world. Love most where it is most needed, beginning within. http:\/\/t.co\/axiG01Bq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/axiG01Bq",
        "expanded_url" : "http:\/\/tinyurl.com\/3wzvd7l",
        "display_url" : "tinyurl.com\/3wzvd7l"
      } ]
    },
    "geo" : { },
    "id_str" : "120162947057197058",
    "text" : "Every act of love sheds light on the world. Love most where it is most needed, beginning within. http:\/\/t.co\/axiG01Bq",
    "id" : 120162947057197058,
    "created_at" : "2011-10-01 15:47:33 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 120163734139318272,
  "created_at" : "2011-10-01 15:50:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120163652002250753",
  "text" : "@tragic_pizza I love St Therese story because she says the little things count.",
  "id" : 120163652002250753,
  "created_at" : "2011-10-01 15:50:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120162103377133568",
  "text" : "@tragic_pizza like the player that fills in..lol. hmm...",
  "id" : 120162103377133568,
  "created_at" : "2011-10-01 15:44:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120161893276061698",
  "text" : "me \"I'm bored, I'm hungry, I'm sad.\" DD: \"well, then stop being those things.\"",
  "id" : 120161893276061698,
  "created_at" : "2011-10-01 15:43:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120160808524189696",
  "text" : "@tragic_pizza I envy your passion, your feeling of purpose. spent my life looking for purpose and still looking.",
  "id" : 120160808524189696,
  "created_at" : "2011-10-01 15:39:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120160402108710913",
  "text" : "why am I watching Law & Order? .. so bored.",
  "id" : 120160402108710913,
  "created_at" : "2011-10-01 15:37:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120160118313730048",
  "text" : "@tragic_pizza Happy Saturday you Curmudgeon you : )",
  "id" : 120160118313730048,
  "created_at" : "2011-10-01 15:36:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120146468223983616",
  "text" : "hubby has left for the day. I am sad.",
  "id" : 120146468223983616,
  "created_at" : "2011-10-01 14:42:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aSoulMan",
      "screen_name" : "aSoulMan",
      "indices" : [ 3, 12 ],
      "id_str" : "158367253",
      "id" : 158367253
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120143865897431041",
  "text" : "RT @aSoulMan: Photo: Every Warrior of the Light has felt afraid of going into battle. Every Warrior of the Light has, at... http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 110, 129 ],
        "url" : "http:\/\/t.co\/g0SgUNo",
        "expanded_url" : "http:\/\/tumblr.com\/xjg4k91ue0",
        "display_url" : "tumblr.com\/xjg4k91ue0"
      } ]
    },
    "geo" : { },
    "id_str" : "111558518766702592",
    "text" : "Photo: Every Warrior of the Light has felt afraid of going into battle. Every Warrior of the Light has, at... http:\/\/t.co\/g0SgUNo",
    "id" : 111558518766702592,
    "created_at" : "2011-09-07 21:56:38 +0000",
    "user" : {
      "name" : "aSoulMan",
      "screen_name" : "aSoulMan",
      "protected" : false,
      "id_str" : "158367253",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625600632406310912\/CBICVvZI_normal.jpg",
      "id" : 158367253,
      "verified" : false
    }
  },
  "id" : 120143865897431041,
  "created_at" : "2011-10-01 14:31:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bean",
      "screen_name" : "IMBeanz",
      "indices" : [ 3, 11 ],
      "id_str" : "205562164",
      "id" : 205562164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "120143682950283264",
  "text" : "RT @IMBeanz: If you sit quietly and listen, you can hear the hum of your sanity slowly slipping away.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "112624704719831040",
    "text" : "If you sit quietly and listen, you can hear the hum of your sanity slowly slipping away.",
    "id" : 112624704719831040,
    "created_at" : "2011-09-10 20:33:16 +0000",
    "user" : {
      "name" : "Bean",
      "screen_name" : "IMBeanz",
      "protected" : false,
      "id_str" : "205562164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/572561066527363073\/iMcuBrfX_normal.jpeg",
      "id" : 205562164,
      "verified" : false
    }
  },
  "id" : 120143682950283264,
  "created_at" : "2011-10-01 14:31:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]