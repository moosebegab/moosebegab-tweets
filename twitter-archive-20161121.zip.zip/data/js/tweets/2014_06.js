Grailbird.data.tweets_2014_06 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483761621915820032",
  "text" : "i didnt have a friend to \"kidnap\" me and take me out..lol",
  "id" : 483761621915820032,
  "created_at" : "2014-06-30 23:58:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483759835926630400",
  "text" : "this is new for me. this worrying about DD while she's out with peers. But its good for her, I know.",
  "id" : 483759835926630400,
  "created_at" : "2014-06-30 23:51:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483759408296390656",
  "text" : "both DD and BFF grad HS last Sat. her BFF has friends from school she hangs out with while DD is homebody.",
  "id" : 483759408296390656,
  "created_at" : "2014-06-30 23:50:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483759027113840640",
  "text" : "so DD's BFF stopped by and took DD out last night and again tonight. this is new. DD usually doesnt go out..",
  "id" : 483759027113840640,
  "created_at" : "2014-06-30 23:48:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 52, 59 ]
    }, {
      "text" : "HobbyLobby",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483734516951822336",
  "text" : "how do you define \"deeply held religious beliefs\"?? #SCOTUS #HobbyLobby",
  "id" : 483734516951822336,
  "created_at" : "2014-06-30 22:11:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "indices" : [ 3, 19 ],
      "id_str" : "20245651",
      "id" : 20245651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483732991886102528",
  "text" : "RT @eScottNicholson: I'm guessing my health plan won't cover these pentagram hoop penile implants.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483729903171690497",
    "text" : "I'm guessing my health plan won't cover these pentagram hoop penile implants.",
    "id" : 483729903171690497,
    "created_at" : "2014-06-30 21:52:50 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 483732991886102528,
  "created_at" : "2014-06-30 22:05:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle (Poptart)",
      "screen_name" : "TheKyleConrad",
      "indices" : [ 0, 14 ],
      "id_str" : "18867490",
      "id" : 18867490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483710186126077952",
  "geo" : { },
  "id_str" : "483713698058338305",
  "in_reply_to_user_id" : 18867490,
  "text" : "@TheKyleConrad yay!! love my AC.",
  "id" : 483713698058338305,
  "in_reply_to_status_id" : 483710186126077952,
  "created_at" : "2014-06-30 20:48:27 +0000",
  "in_reply_to_screen_name" : "TheKyleConrad",
  "in_reply_to_user_id_str" : "18867490",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/knittingknots\/status\/483711630841085955\/photo\/1",
      "indices" : [ 90, 112 ],
      "url" : "http:\/\/t.co\/284IiKOW5i",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrZuLEICcAA_VFD.jpg",
      "id_str" : "483695146353979392",
      "id" : 483695146353979392,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrZuLEICcAA_VFD.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 128,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 506
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 506
      } ],
      "display_url" : "pic.twitter.com\/284IiKOW5i"
    } ],
    "hashtags" : [ {
      "text" : "UniteBlue",
      "indices" : [ 19, 29 ]
    }, {
      "text" : "WarOnWomen",
      "indices" : [ 30, 41 ]
    }, {
      "text" : "BoycottHobbyLobby",
      "indices" : [ 42, 60 ]
    }, {
      "text" : "boycottantibirthcontrolers",
      "indices" : [ 62, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483713218578112514",
  "text" : "RT @knittingknots: #UniteBlue #WarOnWomen #BoycottHobbyLobby  #boycottantibirthcontrolers http:\/\/t.co\/284IiKOW5i",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/knittingknots\/status\/483711630841085955\/photo\/1",
        "indices" : [ 71, 93 ],
        "url" : "http:\/\/t.co\/284IiKOW5i",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrZuLEICcAA_VFD.jpg",
        "id_str" : "483695146353979392",
        "id" : 483695146353979392,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrZuLEICcAA_VFD.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 128,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 506
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 506
        } ],
        "display_url" : "pic.twitter.com\/284IiKOW5i"
      } ],
      "hashtags" : [ {
        "text" : "UniteBlue",
        "indices" : [ 0, 10 ]
      }, {
        "text" : "WarOnWomen",
        "indices" : [ 11, 22 ]
      }, {
        "text" : "BoycottHobbyLobby",
        "indices" : [ 23, 41 ]
      }, {
        "text" : "boycottantibirthcontrolers",
        "indices" : [ 43, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483711630841085955",
    "text" : "#UniteBlue #WarOnWomen #BoycottHobbyLobby  #boycottantibirthcontrolers http:\/\/t.co\/284IiKOW5i",
    "id" : 483711630841085955,
    "created_at" : "2014-06-30 20:40:14 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 483713218578112514,
  "created_at" : "2014-06-30 20:46:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 120, 127 ]
    }, {
      "text" : "HobbyLobby",
      "indices" : [ 128, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483702428013830144",
  "text" : "what if Jehovahs owned corp wanted to not provide blood transfusion or Scientology not provide meds for schitzophrenia? #SCOTUS #HobbyLobby",
  "id" : 483702428013830144,
  "created_at" : "2014-06-30 20:03:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Greg Mischio",
      "screen_name" : "gregmischio",
      "indices" : [ 3, 15 ],
      "id_str" : "856993662",
      "id" : 856993662
    }, {
      "name" : "Monday Blogs",
      "screen_name" : "MondayBlogs",
      "indices" : [ 103, 115 ],
      "id_str" : "952136526",
      "id" : 952136526
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Mondayblogs",
      "indices" : [ 90, 102 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/x0Ln9TS710",
      "expanded_url" : "http:\/\/ow.ly\/yBebV",
      "display_url" : "ow.ly\/yBebV"
    } ]
  },
  "geo" : { },
  "id_str" : "483680651619491840",
  "text" : "RT @gregmischio: My blog now modeled after US health care system.  http:\/\/t.co\/x0Ln9TS710 #Mondayblogs @mondayblogs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Monday Blogs",
        "screen_name" : "MondayBlogs",
        "indices" : [ 86, 98 ],
        "id_str" : "952136526",
        "id" : 952136526
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Mondayblogs",
        "indices" : [ 73, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/x0Ln9TS710",
        "expanded_url" : "http:\/\/ow.ly\/yBebV",
        "display_url" : "ow.ly\/yBebV"
      } ]
    },
    "geo" : { },
    "id_str" : "483611533638119424",
    "text" : "My blog now modeled after US health care system.  http:\/\/t.co\/x0Ln9TS710 #Mondayblogs @mondayblogs",
    "id" : 483611533638119424,
    "created_at" : "2014-06-30 14:02:29 +0000",
    "user" : {
      "name" : "Greg Mischio",
      "screen_name" : "gregmischio",
      "protected" : false,
      "id_str" : "856993662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000410964151\/4e4629c2cd3832520ce306eb2634ca04_normal.png",
      "id" : 856993662,
      "verified" : false
    }
  },
  "id" : 483680651619491840,
  "created_at" : "2014-06-30 18:37:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "UMA",
      "screen_name" : "UMABird",
      "indices" : [ 3, 11 ],
      "id_str" : "72644540",
      "id" : 72644540
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUSRules",
      "indices" : [ 108, 120 ]
    }, {
      "text" : "SCOTUS",
      "indices" : [ 121, 128 ]
    }, {
      "text" : "ACA",
      "indices" : [ 129, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483680028635308033",
  "text" : "RT @UMABird: I'm starting a new religion. Our sole belief is that buying private health insurance is a sin. #SCOTUSRules #SCOTUS #ACA #Reli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUSRules",
        "indices" : [ 95, 107 ]
      }, {
        "text" : "SCOTUS",
        "indices" : [ 108, 115 ]
      }, {
        "text" : "ACA",
        "indices" : [ 116, 120 ]
      }, {
        "text" : "ReligiousFreedom",
        "indices" : [ 121, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483636341066842113",
    "text" : "I'm starting a new religion. Our sole belief is that buying private health insurance is a sin. #SCOTUSRules #SCOTUS #ACA #ReligiousFreedom",
    "id" : 483636341066842113,
    "created_at" : "2014-06-30 15:41:03 +0000",
    "user" : {
      "name" : "UMA",
      "screen_name" : "UMABird",
      "protected" : false,
      "id_str" : "72644540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2164603730\/ushasari_normal.jpg",
      "id" : 72644540,
      "verified" : false
    }
  },
  "id" : 483680028635308033,
  "created_at" : "2014-06-30 18:34:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483652901705760768",
  "text" : "RT @RustBeltRebel: i mean, what we're talking abt here is a showdown over who controls religious narratives and dogma in the US.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483652157007478784",
    "text" : "i mean, what we're talking abt here is a showdown over who controls religious narratives and dogma in the US.",
    "id" : 483652157007478784,
    "created_at" : "2014-06-30 16:43:54 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 483652901705760768,
  "created_at" : "2014-06-30 16:46:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483651100944252928",
  "text" : "DH and I watched The Vagina Monologues last night.. very cool. My mom did a performance of it several yrs ago.",
  "id" : 483651100944252928,
  "created_at" : "2014-06-30 16:39:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "Sally Jewell",
      "screen_name" : "SecretaryJewell",
      "indices" : [ 15, 31 ],
      "id_str" : "1342861723",
      "id" : 1342861723
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "conservation",
      "indices" : [ 42, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 100, 122 ],
      "url" : "http:\/\/t.co\/gqVYMdkrKS",
      "expanded_url" : "http:\/\/on.doi.gov\/1v9Cdu5",
      "display_url" : "on.doi.gov\/1v9Cdu5"
    } ]
  },
  "geo" : { },
  "id_str" : "483649709567770624",
  "text" : "RT @Interior: .@SecretaryJewell announces #conservation success story in down-listing of wood stork http:\/\/t.co\/gqVYMdkrKS http:\/\/t.co\/k5DS\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sally Jewell",
        "screen_name" : "SecretaryJewell",
        "indices" : [ 1, 17 ],
        "id_str" : "1342861723",
        "id" : 1342861723
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/482197414187507713\/photo\/1",
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/k5DSxM4cCs",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEb_hhCMAAz7TE.jpg",
        "id_str" : "482197413247987712",
        "id" : 482197413247987712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEb_hhCMAAz7TE.jpg",
        "sizes" : [ {
          "h" : 457,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 259,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 780,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 780,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/k5DSxM4cCs"
      } ],
      "hashtags" : [ {
        "text" : "conservation",
        "indices" : [ 28, 41 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 108 ],
        "url" : "http:\/\/t.co\/gqVYMdkrKS",
        "expanded_url" : "http:\/\/on.doi.gov\/1v9Cdu5",
        "display_url" : "on.doi.gov\/1v9Cdu5"
      } ]
    },
    "geo" : { },
    "id_str" : "482197414187507713",
    "text" : ".@SecretaryJewell announces #conservation success story in down-listing of wood stork http:\/\/t.co\/gqVYMdkrKS http:\/\/t.co\/k5DSxM4cCs",
    "id" : 482197414187507713,
    "created_at" : "2014-06-26 16:23:16 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 483649709567770624,
  "created_at" : "2014-06-30 16:34:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Martin",
      "screen_name" : "ve3sz",
      "indices" : [ 3, 9 ],
      "id_str" : "128322873",
      "id" : 128322873
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ve3sz\/status\/481487776190193665\/photo\/1",
      "indices" : [ 79, 101 ],
      "url" : "http:\/\/t.co\/sgpS5ZWH43",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq6WlMcCAAEmtVn.jpg",
      "id_str" : "481487775913345025",
      "id" : 481487775913345025,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq6WlMcCAAEmtVn.jpg",
      "sizes" : [ {
        "h" : 313,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 178,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 802,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/sgpS5ZWH43"
    } ],
    "hashtags" : [ {
      "text" : "grebe",
      "indices" : [ 48, 54 ]
    }, {
      "text" : "birds",
      "indices" : [ 55, 61 ]
    }, {
      "text" : "birdphotography",
      "indices" : [ 62, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483649525609811968",
  "text" : "RT @ve3sz: Red-necked Grebe family feeding time\n#grebe #birds #birdphotography http:\/\/t.co\/sgpS5ZWH43",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ve3sz\/status\/481487776190193665\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/sgpS5ZWH43",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq6WlMcCAAEmtVn.jpg",
        "id_str" : "481487775913345025",
        "id" : 481487775913345025,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq6WlMcCAAEmtVn.jpg",
        "sizes" : [ {
          "h" : 313,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 178,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 802,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/sgpS5ZWH43"
      } ],
      "hashtags" : [ {
        "text" : "grebe",
        "indices" : [ 37, 43 ]
      }, {
        "text" : "birds",
        "indices" : [ 44, 50 ]
      }, {
        "text" : "birdphotography",
        "indices" : [ 51, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481487776190193665",
    "text" : "Red-necked Grebe family feeding time\n#grebe #birds #birdphotography http:\/\/t.co\/sgpS5ZWH43",
    "id" : 481487776190193665,
    "created_at" : "2014-06-24 17:23:26 +0000",
    "user" : {
      "name" : "Scott Martin",
      "screen_name" : "ve3sz",
      "protected" : false,
      "id_str" : "128322873",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/473283697526185984\/KRLQp-JK_normal.jpeg",
      "id" : 128322873,
      "verified" : false
    }
  },
  "id" : 483649525609811968,
  "created_at" : "2014-06-30 16:33:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "indices" : [ 3, 18 ],
      "id_str" : "46822887",
      "id" : 46822887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 124, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483646278115393537",
  "text" : "RT @AngryBlackLady: Also, at what point are we going to discuss the prioritizing of Christianity over every other religion? #HobbyLobby #SC\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 104, 115 ]
      }, {
        "text" : "SCOTUS",
        "indices" : [ 116, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483624868349370369",
    "text" : "Also, at what point are we going to discuss the prioritizing of Christianity over every other religion? #HobbyLobby #SCOTUS",
    "id" : 483624868349370369,
    "created_at" : "2014-06-30 14:55:28 +0000",
    "user" : {
      "name" : "Imani Gandied Yams",
      "screen_name" : "AngryBlackLady",
      "protected" : false,
      "id_str" : "46822887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790644001330171904\/E3uUevS__normal.jpg",
      "id" : 46822887,
      "verified" : true
    }
  },
  "id" : 483646278115393537,
  "created_at" : "2014-06-30 16:20:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dan Arel",
      "screen_name" : "danarel",
      "indices" : [ 3, 11 ],
      "id_str" : "11994002",
      "id" : 11994002
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483644522211991553",
  "text" : "RT @danarel: The Christian Right is loving todays Hobby Lobby ruling.\n\nJust wait until one of them gets a Muslim boss.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483636290508689408",
    "text" : "The Christian Right is loving todays Hobby Lobby ruling.\n\nJust wait until one of them gets a Muslim boss.",
    "id" : 483636290508689408,
    "created_at" : "2014-06-30 15:40:51 +0000",
    "user" : {
      "name" : "Dan Arel",
      "screen_name" : "danarel",
      "protected" : false,
      "id_str" : "11994002",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695653919834267648\/PBUEr0D7_normal.png",
      "id" : 11994002,
      "verified" : true
    }
  },
  "id" : 483644522211991553,
  "created_at" : "2014-06-30 16:13:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((Abacus)))",
      "screen_name" : "Iale2014",
      "indices" : [ 3, 12 ],
      "id_str" : "2327243994",
      "id" : 2327243994
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 51, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483642203210674176",
  "text" : "RT @Iale2014: Those who think the biggest issue in #HobbyLobby is contraception are wrong.\n\nIt's corporations being enabled to force religi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 37, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483638650878832640",
    "text" : "Those who think the biggest issue in #HobbyLobby is contraception are wrong.\n\nIt's corporations being enabled to force religion on employees",
    "id" : 483638650878832640,
    "created_at" : "2014-06-30 15:50:14 +0000",
    "user" : {
      "name" : "(((Abacus)))",
      "screen_name" : "Iale2014",
      "protected" : false,
      "id_str" : "2327243994",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/431131047648964608\/AwVmgujU_normal.jpeg",
      "id" : 2327243994,
      "verified" : false
    }
  },
  "id" : 483642203210674176,
  "created_at" : "2014-06-30 16:04:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maverick\u2122",
      "screen_name" : "spooney35",
      "indices" : [ 3, 13 ],
      "id_str" : "67095221",
      "id" : 67095221
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 25, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483641622383448064",
  "text" : "RT @spooney35: Lets See: #HobbyLobby Invests In Abortion Pill Manufacturers. China imports where Birth Control is Govt.. funded http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 10, 21 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/qr5gCftuvE",
        "expanded_url" : "http:\/\/www.huffingtonpost.com\/2014\/04\/01\/hobby-lobby-invests-in-em_n_5070279.html",
        "display_url" : "huffingtonpost.com\/2014\/04\/01\/hob\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483638817703067648",
    "text" : "Lets See: #HobbyLobby Invests In Abortion Pill Manufacturers. China imports where Birth Control is Govt.. funded http:\/\/t.co\/qr5gCftuvE",
    "id" : 483638817703067648,
    "created_at" : "2014-06-30 15:50:54 +0000",
    "user" : {
      "name" : "Maverick\u2122",
      "screen_name" : "spooney35",
      "protected" : false,
      "id_str" : "67095221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763102692688343041\/_qjQlkBd_normal.jpg",
      "id" : 67095221,
      "verified" : false
    }
  },
  "id" : 483641622383448064,
  "created_at" : "2014-06-30 16:02:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 0, 13 ],
      "id_str" : "25221139",
      "id" : 25221139
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "483639563558985729",
  "geo" : { },
  "id_str" : "483641282024058880",
  "in_reply_to_user_id" : 25221139,
  "text" : "@PisseArtiste love Canadians. ((fistbump))",
  "id" : 483641282024058880,
  "in_reply_to_status_id" : 483639563558985729,
  "created_at" : "2014-06-30 16:00:41 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483638177962270721",
  "text" : "RT @micahjmurray: \"Exercise of religion\" should be prayer, service, evangelism. Not deciding what others do w\/ their money\/insurance. #Reli\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ReligiousFreedom",
        "indices" : [ 116, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483626117840900098",
    "text" : "\"Exercise of religion\" should be prayer, service, evangelism. Not deciding what others do w\/ their money\/insurance. #ReligiousFreedom",
    "id" : 483626117840900098,
    "created_at" : "2014-06-30 15:00:26 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 483638177962270721,
  "created_at" : "2014-06-30 15:48:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CG",
      "screen_name" : "cginpvd",
      "indices" : [ 3, 11 ],
      "id_str" : "751059605191593984",
      "id" : 751059605191593984
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "singlepayer",
      "indices" : [ 42, 54 ]
    }, {
      "text" : "SCOTUS",
      "indices" : [ 123, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483637890220437504",
  "text" : "RT @cginpvd: Yet more reasons why we need #singlepayer in the US. Employer should have NO SAY in treatment. ANY treatment. #SCOTUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "singlepayer",
        "indices" : [ 29, 41 ]
      }, {
        "text" : "SCOTUS",
        "indices" : [ 110, 117 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483624894249586690",
    "text" : "Yet more reasons why we need #singlepayer in the US. Employer should have NO SAY in treatment. ANY treatment. #SCOTUS",
    "id" : 483624894249586690,
    "created_at" : "2014-06-30 14:55:34 +0000",
    "user" : {
      "name" : "C. Monkey \uD83D\uDE4A",
      "screen_name" : "seamonkeyphd",
      "protected" : false,
      "id_str" : "939460070",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/751062959263129600\/slG83n2c_normal.jpg",
      "id" : 939460070,
      "verified" : false
    }
  },
  "id" : 483637890220437504,
  "created_at" : "2014-06-30 15:47:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Laura",
      "screen_name" : "laurarme",
      "indices" : [ 3, 12 ],
      "id_str" : "74479566",
      "id" : 74479566
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 90, 102 ]
    }, {
      "text" : "corporationsarentpeople",
      "indices" : [ 103, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483637373347954688",
  "text" : "RT @laurarme: I still don't understand why my employer needs to be tied to my healthcare. #SinglePayer #corporationsarentpeople",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 76, 88 ]
      }, {
        "text" : "corporationsarentpeople",
        "indices" : [ 89, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483624824699625472",
    "text" : "I still don't understand why my employer needs to be tied to my healthcare. #SinglePayer #corporationsarentpeople",
    "id" : 483624824699625472,
    "created_at" : "2014-06-30 14:55:18 +0000",
    "user" : {
      "name" : "Laura",
      "screen_name" : "laurarme",
      "protected" : false,
      "id_str" : "74479566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000575890364\/476dfcf8d16ac90da223e2c5aabaaca7_normal.jpeg",
      "id" : 74479566,
      "verified" : false
    }
  },
  "id" : 483637373347954688,
  "created_at" : "2014-06-30 15:45:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "indices" : [ 3, 15 ],
      "id_str" : "23034673",
      "id" : 23034673
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/EgbGoNzCV2",
      "expanded_url" : "http:\/\/www.patheos.com\/blogs\/friendlyatheist\/2014\/06\/30\/supreme-court-rules-on-hobby-lobby-case-corporations-somehow-have-religion-beliefs\/",
      "display_url" : "patheos.com\/blogs\/friendly\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483637161741123584",
  "text" : "RT @hemantmehta: What are church\/state separation group saying about Hobby Lobby? Check it out: http:\/\/t.co\/EgbGoNzCV2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/EgbGoNzCV2",
        "expanded_url" : "http:\/\/www.patheos.com\/blogs\/friendlyatheist\/2014\/06\/30\/supreme-court-rules-on-hobby-lobby-case-corporations-somehow-have-religion-beliefs\/",
        "display_url" : "patheos.com\/blogs\/friendly\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483626548847976448",
    "text" : "What are church\/state separation group saying about Hobby Lobby? Check it out: http:\/\/t.co\/EgbGoNzCV2",
    "id" : 483626548847976448,
    "created_at" : "2014-06-30 15:02:09 +0000",
    "user" : {
      "name" : "Hemant Mehta",
      "screen_name" : "hemantmehta",
      "protected" : false,
      "id_str" : "23034673",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3393754882\/07184fa9526af00257538d818b6f72f7_normal.jpeg",
      "id" : 23034673,
      "verified" : true
    }
  },
  "id" : 483637161741123584,
  "created_at" : "2014-06-30 15:44:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ali Taylor",
      "screen_name" : "Ali_Again",
      "indices" : [ 3, 13 ],
      "id_str" : "257954079",
      "id" : 257954079
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 32, 44 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483637041335263232",
  "text" : "RT @Ali_Again: Can we just have #SinglePayer for goodness' sake? Then nobody has to worry if a corporation's religious freedom will trump t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 17, 29 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483626277618712576",
    "text" : "Can we just have #SinglePayer for goodness' sake? Then nobody has to worry if a corporation's religious freedom will trump their own.",
    "id" : 483626277618712576,
    "created_at" : "2014-06-30 15:01:04 +0000",
    "user" : {
      "name" : "Ali Taylor",
      "screen_name" : "Ali_Again",
      "protected" : false,
      "id_str" : "257954079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000558452040\/df528ae723fac7838387790b9909a472_normal.jpeg",
      "id" : 257954079,
      "verified" : false
    }
  },
  "id" : 483637041335263232,
  "created_at" : "2014-06-30 15:43:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ACLU National",
      "screen_name" : "ACLU",
      "indices" : [ 3, 8 ],
      "id_str" : "13393052",
      "id" : 13393052
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SCOTUS",
      "indices" : [ 27, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483636691853660160",
  "text" : "RT @ACLU: Never before has #SCOTUS said employers can use their religious beliefs to deny employees a benefit they are guaranteed by law to\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SCOTUS",
        "indices" : [ 17, 24 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483625019713806336",
    "text" : "Never before has #SCOTUS said employers can use their religious beliefs to deny employees a benefit they are guaranteed by law to receive.",
    "id" : 483625019713806336,
    "created_at" : "2014-06-30 14:56:04 +0000",
    "user" : {
      "name" : "ACLU National",
      "screen_name" : "ACLU",
      "protected" : false,
      "id_str" : "13393052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798183260681596928\/OX587BVC_normal.jpg",
      "id" : 13393052,
      "verified" : true
    }
  },
  "id" : 483636691853660160,
  "created_at" : "2014-06-30 15:42:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jill Filipovic",
      "screen_name" : "JillFilipovic",
      "indices" : [ 3, 17 ],
      "id_str" : "16378093",
      "id" : 16378093
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483635303198896128",
  "text" : "RT @JillFilipovic: #HobbyLobby is so opposed to contraception, they invest in the companies that make it, so they can make $$$. http:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 0, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/K8Rrs06uHo",
        "expanded_url" : "http:\/\/www.motherjones.com\/politics\/2014\/04\/hobby-lobby-retirement-plan-invested-emergency-contraception-and-abortion-drug-makers",
        "display_url" : "motherjones.com\/politics\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483622320401952769",
    "text" : "#HobbyLobby is so opposed to contraception, they invest in the companies that make it, so they can make $$$. http:\/\/t.co\/K8Rrs06uHo",
    "id" : 483622320401952769,
    "created_at" : "2014-06-30 14:45:21 +0000",
    "user" : {
      "name" : "Jill Filipovic",
      "screen_name" : "JillFilipovic",
      "protected" : false,
      "id_str" : "16378093",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791533015004577792\/tHODupl8_normal.jpg",
      "id" : 16378093,
      "verified" : true
    }
  },
  "id" : 483635303198896128,
  "created_at" : "2014-06-30 15:36:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tina Dupuy",
      "screen_name" : "TinaDupuy",
      "indices" : [ 3, 13 ],
      "id_str" : "14326805",
      "id" : 14326805
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483635146730397697",
  "text" : "RT @TinaDupuy: As long as Hobby Lobby can still invest in pharma companies that make birth control with their conscience intact...http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/1mQtjEqIjv",
        "expanded_url" : "http:\/\/www.motherjones.com\/politics\/2014\/04\/hobby-lobby-retirement-plan-invested-emergency-contraception-and-abortion-drug-makers",
        "display_url" : "motherjones.com\/politics\/2014\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483626098454843394",
    "text" : "As long as Hobby Lobby can still invest in pharma companies that make birth control with their conscience intact...http:\/\/t.co\/1mQtjEqIjv",
    "id" : 483626098454843394,
    "created_at" : "2014-06-30 15:00:21 +0000",
    "user" : {
      "name" : "Tina Dupuy",
      "screen_name" : "TinaDupuy",
      "protected" : false,
      "id_str" : "14326805",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/460449787192438787\/-fe62q3h_normal.png",
      "id" : 14326805,
      "verified" : true
    }
  },
  "id" : 483635146730397697,
  "created_at" : "2014-06-30 15:36:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483634867737858049",
  "text" : "RT @TheChristianLft: Here's a solution to the birth control issue. Nationalize the entire health care system, like every other... http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/ADzP6qZrYh",
        "expanded_url" : "http:\/\/fb.me\/2X6DllrCo",
        "display_url" : "fb.me\/2X6DllrCo"
      } ]
    },
    "geo" : { },
    "id_str" : "483627292913324033",
    "text" : "Here's a solution to the birth control issue. Nationalize the entire health care system, like every other... http:\/\/t.co\/ADzP6qZrYh",
    "id" : 483627292913324033,
    "created_at" : "2014-06-30 15:05:06 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 483634867737858049,
  "created_at" : "2014-06-30 15:35:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "indices" : [ 3, 8 ],
      "id_str" : "48081662",
      "id" : 48081662
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SinglePayer",
      "indices" : [ 124, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483634325804417024",
  "text" : "RT @PNHP: What kind of health care you receive shouldn't be at the mercy of your employer, but between you and your doctor. #SinglePayer #H\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SinglePayer",
        "indices" : [ 114, 126 ]
      }, {
        "text" : "HobbyLobby",
        "indices" : [ 127, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483626665256697856",
    "text" : "What kind of health care you receive shouldn't be at the mercy of your employer, but between you and your doctor. #SinglePayer #HobbyLobby",
    "id" : 483626665256697856,
    "created_at" : "2014-06-30 15:02:37 +0000",
    "user" : {
      "name" : "PNHP",
      "screen_name" : "PNHP",
      "protected" : false,
      "id_str" : "48081662",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477486688315273216\/dyjtedMO_normal.jpeg",
      "id" : 48081662,
      "verified" : false
    }
  },
  "id" : 483634325804417024,
  "created_at" : "2014-06-30 15:33:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "indices" : [ 3, 17 ],
      "id_str" : "1067293117",
      "id" : 1067293117
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 31, 42 ]
    }, {
      "text" : "SinglePayer",
      "indices" : [ 67, 79 ]
    }, {
      "text" : "MedicareForAll",
      "indices" : [ 80, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483634109512548353",
  "text" : "RT @AllOnMedicare: If you want #HobbyLobby out of your bedroom...\n\n#SinglePayer #MedicareForAll...\n\nis the solution.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 12, 23 ]
      }, {
        "text" : "SinglePayer",
        "indices" : [ 48, 60 ]
      }, {
        "text" : "MedicareForAll",
        "indices" : [ 61, 76 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483627885924982785",
    "text" : "If you want #HobbyLobby out of your bedroom...\n\n#SinglePayer #MedicareForAll...\n\nis the solution.",
    "id" : 483627885924982785,
    "created_at" : "2014-06-30 15:07:28 +0000",
    "user" : {
      "name" : "All On Medicare",
      "screen_name" : "AllOnMedicare",
      "protected" : false,
      "id_str" : "1067293117",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3075992449\/5f090dc70e7f4d448bb84c069c1fa75a_normal.jpeg",
      "id" : 1067293117,
      "verified" : false
    }
  },
  "id" : 483634109512548353,
  "created_at" : "2014-06-30 15:32:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Williams",
      "screen_name" : "KWilliams1984",
      "indices" : [ 3, 17 ],
      "id_str" : "22653799",
      "id" : 22653799
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "HobbyLobby",
      "indices" : [ 19, 30 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483633887927488513",
  "text" : "RT @KWilliams1984: #HobbyLobby is NOT a religious institution; therefore, they have NO right forcing their \"religious beliefs\" upon ANYONE!\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "HobbyLobby",
        "indices" : [ 0, 11 ]
      }, {
        "text" : "BadForBusiness",
        "indices" : [ 121, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483628197209473024",
    "text" : "#HobbyLobby is NOT a religious institution; therefore, they have NO right forcing their \"religious beliefs\" upon ANYONE! #BadForBusiness",
    "id" : 483628197209473024,
    "created_at" : "2014-06-30 15:08:42 +0000",
    "user" : {
      "name" : "Kenny Williams",
      "screen_name" : "KWilliams1984",
      "protected" : false,
      "id_str" : "22653799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787397284766056448\/RVgZVZvO_normal.jpg",
      "id" : 22653799,
      "verified" : false
    }
  },
  "id" : 483633887927488513,
  "created_at" : "2014-06-30 15:31:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483292246855282688",
  "text" : "it's annoying but ppl (or groups) I don't agree with can and do make valid points regarding the other side.",
  "id" : 483292246855282688,
  "created_at" : "2014-06-29 16:53:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "indices" : [ 3, 15 ],
      "id_str" : "409492415",
      "id" : 409492415
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/483239951761674240\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/YPo2XBvu1H",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrTQHZcCEAAYPfL.jpg",
      "id_str" : "483239885541609472",
      "id" : 483239885541609472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrTQHZcCEAAYPfL.jpg",
      "sizes" : [ {
        "h" : 268,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 473,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 808,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 878,
        "resize" : "fit",
        "w" : 1113
      } ],
      "display_url" : "pic.twitter.com\/YPo2XBvu1H"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483276174567555073",
  "text" : "RT @Coyotetooth: Behind the Scenes:  Grooming. http:\/\/t.co\/YPo2XBvu1H",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/483239951761674240\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/YPo2XBvu1H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrTQHZcCEAAYPfL.jpg",
        "id_str" : "483239885541609472",
        "id" : 483239885541609472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrTQHZcCEAAYPfL.jpg",
        "sizes" : [ {
          "h" : 268,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 473,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 808,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 878,
          "resize" : "fit",
          "w" : 1113
        } ],
        "display_url" : "pic.twitter.com\/YPo2XBvu1H"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483239951761674240",
    "text" : "Behind the Scenes:  Grooming. http:\/\/t.co\/YPo2XBvu1H",
    "id" : 483239951761674240,
    "created_at" : "2014-06-29 13:25:57 +0000",
    "user" : {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "protected" : false,
      "id_str" : "409492415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502871900054642688\/RlK3naNt_normal.jpeg",
      "id" : 409492415,
      "verified" : false
    }
  },
  "id" : 483276174567555073,
  "created_at" : "2014-06-29 15:49:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "indices" : [ 3, 16 ],
      "id_str" : "25221139",
      "id" : 25221139
    }, {
      "name" : "AlterNet",
      "screen_name" : "AlterNet",
      "indices" : [ 19, 28 ],
      "id_str" : "18851248",
      "id" : 18851248
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/xIY0tcNbAY",
      "expanded_url" : "http:\/\/ow.ly\/yyUJa",
      "display_url" : "ow.ly\/yyUJa"
    } ]
  },
  "geo" : { },
  "id_str" : "483266002520510464",
  "text" : "RT @PisseArtiste: \u201C@AlterNet: Why Are the Government and Big Pharma Ignoring the Heroin Addiction Vaccine?\n http:\/\/t.co\/xIY0tcNbAY\u201D This is\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "AlterNet",
        "screen_name" : "AlterNet",
        "indices" : [ 1, 10 ],
        "id_str" : "18851248",
        "id" : 18851248
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/xIY0tcNbAY",
        "expanded_url" : "http:\/\/ow.ly\/yyUJa",
        "display_url" : "ow.ly\/yyUJa"
      } ]
    },
    "in_reply_to_status_id_str" : "483252358516731905",
    "geo" : { },
    "id_str" : "483253711863824384",
    "in_reply_to_user_id" : 18851248,
    "text" : "\u201C@AlterNet: Why Are the Government and Big Pharma Ignoring the Heroin Addiction Vaccine?\n http:\/\/t.co\/xIY0tcNbAY\u201D This is interesting.",
    "id" : 483253711863824384,
    "in_reply_to_status_id" : 483252358516731905,
    "created_at" : "2014-06-29 14:20:37 +0000",
    "in_reply_to_screen_name" : "AlterNet",
    "in_reply_to_user_id_str" : "18851248",
    "user" : {
      "name" : "Random Bystander",
      "screen_name" : "PisseArtiste",
      "protected" : false,
      "id_str" : "25221139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/664654604899065856\/SzoIRGrF_normal.jpg",
      "id" : 25221139,
      "verified" : false
    }
  },
  "id" : 483266002520510464,
  "created_at" : "2014-06-29 15:09:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483263873496002560",
  "text" : "RT @ZachsMind: voting is the world's worst perpetual motion machine. It doesn't solve anything, but ppl keep insisting it does and that kee\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483259144455979008",
    "text" : "voting is the world's worst perpetual motion machine. It doesn't solve anything, but ppl keep insisting it does and that keeps it going.",
    "id" : 483259144455979008,
    "created_at" : "2014-06-29 14:42:13 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 483263873496002560,
  "created_at" : "2014-06-29 15:01:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483263776167182336",
  "text" : "RT @ZachsMind: there really isn't a way to do this. we keep the voting crap going cuz it grants us the illusion we're perpetually doing som\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483259024985440256",
    "text" : "there really isn't a way to do this. we keep the voting crap going cuz it grants us the illusion we're perpetually doing something useful.",
    "id" : 483259024985440256,
    "created_at" : "2014-06-29 14:41:44 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 483263776167182336,
  "created_at" : "2014-06-29 15:00:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "indices" : [ 3, 16 ],
      "id_str" : "580857186",
      "id" : 580857186
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/483258997139836928\/photo\/1",
      "indices" : [ 18, 40 ],
      "url" : "http:\/\/t.co\/goFdkg2zPa",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrThf1KIcAA86QD.jpg",
      "id_str" : "483258996997255168",
      "id" : 483258996997255168,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrThf1KIcAA86QD.jpg",
      "sizes" : [ {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 337,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 683
      }, {
        "h" : 384,
        "resize" : "fit",
        "w" : 683
      } ],
      "display_url" : "pic.twitter.com\/goFdkg2zPa"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483263759788421121",
  "text" : "RT @Elverojaguar: http:\/\/t.co\/goFdkg2zPa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Elverojaguar\/status\/483258997139836928\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/goFdkg2zPa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrThf1KIcAA86QD.jpg",
        "id_str" : "483258996997255168",
        "id" : 483258996997255168,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrThf1KIcAA86QD.jpg",
        "sizes" : [ {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 337,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 683
        }, {
          "h" : 384,
          "resize" : "fit",
          "w" : 683
        } ],
        "display_url" : "pic.twitter.com\/goFdkg2zPa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "483258997139836928",
    "text" : "http:\/\/t.co\/goFdkg2zPa",
    "id" : 483258997139836928,
    "created_at" : "2014-06-29 14:41:38 +0000",
    "user" : {
      "name" : "The Cult Cat",
      "screen_name" : "Elverojaguar",
      "protected" : false,
      "id_str" : "580857186",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/435705831280373760\/8CXtaxen_normal.jpeg",
      "id" : 580857186,
      "verified" : false
    }
  },
  "id" : 483263759788421121,
  "created_at" : "2014-06-29 15:00:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mermaiden",
      "screen_name" : "Forever_Myth",
      "indices" : [ 3, 16 ],
      "id_str" : "2324704606",
      "id" : 2324704606
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Forever_Myth\/status\/482250373353463808\/photo\/1",
      "indices" : [ 37, 59 ],
      "url" : "http:\/\/t.co\/4paciQqCSt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFMKK5IUAA7HIA.jpg",
      "id_str" : "482250372711731200",
      "id" : 482250372711731200,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFMKK5IUAA7HIA.jpg",
      "sizes" : [ {
        "h" : 504,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 889,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 691
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 691
      } ],
      "display_url" : "pic.twitter.com\/4paciQqCSt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483053144180420609",
  "text" : "RT @Forever_Myth: Corgi &amp; faerie http:\/\/t.co\/4paciQqCSt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Forever_Myth\/status\/482250373353463808\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/4paciQqCSt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFMKK5IUAA7HIA.jpg",
        "id_str" : "482250372711731200",
        "id" : 482250372711731200,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFMKK5IUAA7HIA.jpg",
        "sizes" : [ {
          "h" : 504,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 889,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 691
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 691
        } ],
        "display_url" : "pic.twitter.com\/4paciQqCSt"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482250373353463808",
    "text" : "Corgi &amp; faerie http:\/\/t.co\/4paciQqCSt",
    "id" : 482250373353463808,
    "created_at" : "2014-06-26 19:53:43 +0000",
    "user" : {
      "name" : "Mermaiden",
      "screen_name" : "Forever_Myth",
      "protected" : false,
      "id_str" : "2324704606",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/430806321160404992\/317uSWhf_normal.jpeg",
      "id" : 2324704606,
      "verified" : false
    }
  },
  "id" : 483053144180420609,
  "created_at" : "2014-06-29 01:03:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "indices" : [ 3, 19 ],
      "id_str" : "191110048",
      "id" : 191110048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/vpqfe9PK4Y",
      "expanded_url" : "http:\/\/www.sciencethrillers.com\/2014\/the-lablit-list-expanded-by-40-titles\/",
      "display_url" : "sciencethrillers.com\/2014\/the-labli\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483052054739288064",
  "text" : "RT @ScienceThriller: The LabLit List expanded by 40 titles http:\/\/t.co\/vpqfe9PK4Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/vpqfe9PK4Y",
        "expanded_url" : "http:\/\/www.sciencethrillers.com\/2014\/the-lablit-list-expanded-by-40-titles\/",
        "display_url" : "sciencethrillers.com\/2014\/the-labli\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "483051779681030144",
    "text" : "The LabLit List expanded by 40 titles http:\/\/t.co\/vpqfe9PK4Y",
    "id" : 483051779681030144,
    "created_at" : "2014-06-29 00:58:13 +0000",
    "user" : {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "protected" : false,
      "id_str" : "191110048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509554102632587264\/zmyDrP9j_normal.jpeg",
      "id" : 191110048,
      "verified" : false
    }
  },
  "id" : 483052054739288064,
  "created_at" : "2014-06-29 00:59:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FDA",
      "indices" : [ 13, 17 ]
    }, {
      "text" : "mercury",
      "indices" : [ 25, 33 ]
    }, {
      "text" : "vaccines",
      "indices" : [ 94, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/JdyHE68qon",
      "expanded_url" : "http:\/\/bit.ly\/x0mGK9",
      "display_url" : "bit.ly\/x0mGK9"
    } ]
  },
  "geo" : { },
  "id_str" : "483040066910969856",
  "text" : "RT @drbloem: #FDA admits #mercury in cosmetic products is extremely toxic - so how is it safe #vaccines? http:\/\/t.co\/JdyHE68qon",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FDA",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "mercury",
        "indices" : [ 12, 20 ]
      }, {
        "text" : "vaccines",
        "indices" : [ 81, 90 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 114 ],
        "url" : "http:\/\/t.co\/JdyHE68qon",
        "expanded_url" : "http:\/\/bit.ly\/x0mGK9",
        "display_url" : "bit.ly\/x0mGK9"
      } ]
    },
    "geo" : { },
    "id_str" : "483037709133709312",
    "text" : "#FDA admits #mercury in cosmetic products is extremely toxic - so how is it safe #vaccines? http:\/\/t.co\/JdyHE68qon",
    "id" : 483037709133709312,
    "created_at" : "2014-06-29 00:02:18 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 483040066910969856,
  "created_at" : "2014-06-29 00:11:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/HRRipZ6Efh",
      "expanded_url" : "http:\/\/www.calgaryherald.com\/touch\/story.html?id=9978442",
      "display_url" : "calgaryherald.com\/touch\/story.ht\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "483038944980766720",
  "text" : "Calgary doctor refuses to prescribe birth control over moral beliefs http:\/\/t.co\/HRRipZ6Efh",
  "id" : 483038944980766720,
  "created_at" : "2014-06-29 00:07:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "483035882140598273",
  "text" : "it was a good day.",
  "id" : 483035882140598273,
  "created_at" : "2014-06-28 23:55:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482874511335776256",
  "text" : "Today's the day. DD HS graduation.",
  "id" : 482874511335776256,
  "created_at" : "2014-06-28 13:13:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "indices" : [ 3, 17 ],
      "id_str" : "80073299",
      "id" : 80073299
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Alaskachic907\/status\/482556327709769729\/photo\/1",
      "indices" : [ 94, 116 ],
      "url" : "http:\/\/t.co\/SZuwARcJLE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrJia8ACcAAaH8A.jpg",
      "id_str" : "482556325004472320",
      "id" : 482556325004472320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrJia8ACcAAaH8A.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 266,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1605,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 803,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 470,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/SZuwARcJLE"
    } ],
    "hashtags" : [ {
      "text" : "moose",
      "indices" : [ 48, 54 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 55, 64 ]
    }, {
      "text" : "alaska",
      "indices" : [ 65, 72 ]
    }, {
      "text" : "nature",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "photography",
      "indices" : [ 81, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482561954343444480",
  "text" : "RT @Alaskachic907: Mama tending to her babies.  #moose #wildlife #alaska #nature #photography http:\/\/t.co\/SZuwARcJLE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Alaskachic907\/status\/482556327709769729\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/SZuwARcJLE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrJia8ACcAAaH8A.jpg",
        "id_str" : "482556325004472320",
        "id" : 482556325004472320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrJia8ACcAAaH8A.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 266,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1605,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 803,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 470,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/SZuwARcJLE"
      } ],
      "hashtags" : [ {
        "text" : "moose",
        "indices" : [ 29, 35 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 36, 45 ]
      }, {
        "text" : "alaska",
        "indices" : [ 46, 53 ]
      }, {
        "text" : "nature",
        "indices" : [ 54, 61 ]
      }, {
        "text" : "photography",
        "indices" : [ 62, 74 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482556327709769729",
    "text" : "Mama tending to her babies.  #moose #wildlife #alaska #nature #photography http:\/\/t.co\/SZuwARcJLE",
    "id" : 482556327709769729,
    "created_at" : "2014-06-27 16:09:28 +0000",
    "user" : {
      "name" : "Nancy Stewart",
      "screen_name" : "Alaskachic907",
      "protected" : false,
      "id_str" : "80073299",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760585201395245056\/PApWQ2Xd_normal.jpg",
      "id" : 80073299,
      "verified" : false
    }
  },
  "id" : 482561954343444480,
  "created_at" : "2014-06-27 16:31:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "indices" : [ 3, 17 ],
      "id_str" : "20349823",
      "id" : 20349823
    }, {
      "name" : "reason",
      "screen_name" : "reason",
      "indices" : [ 109, 116 ],
      "id_str" : "16467567",
      "id" : 16467567
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "PhilipKHoward",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482561266074935296",
  "text" : "RT @FreeRangeKids: Kindergartener Pulls Down Pants, Forced to Sign 'Sexual Misconduct' Confession.  My piece @Reason. #PhilipKHoward http:\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "reason",
        "screen_name" : "reason",
        "indices" : [ 90, 97 ],
        "id_str" : "16467567",
        "id" : 16467567
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "PhilipKHoward",
        "indices" : [ 99, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/MK6dJcfQXa",
        "expanded_url" : "http:\/\/bit.ly\/UQzYku",
        "display_url" : "bit.ly\/UQzYku"
      } ]
    },
    "geo" : { },
    "id_str" : "482559277891334144",
    "text" : "Kindergartener Pulls Down Pants, Forced to Sign 'Sexual Misconduct' Confession.  My piece @Reason. #PhilipKHoward http:\/\/t.co\/MK6dJcfQXa",
    "id" : 482559277891334144,
    "created_at" : "2014-06-27 16:21:12 +0000",
    "user" : {
      "name" : "Lenore Skenazy",
      "screen_name" : "FreeRangeKids",
      "protected" : false,
      "id_str" : "20349823",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459750066748526593\/gx8BRhuq_normal.jpeg",
      "id" : 20349823,
      "verified" : false
    }
  },
  "id" : 482561266074935296,
  "created_at" : "2014-06-27 16:29:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sarcasm",
      "screen_name" : "OneMoreJoke",
      "indices" : [ 3, 15 ],
      "id_str" : "547607608",
      "id" : 547607608
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OneMoreJoke\/status\/482546528460865537\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/QgYjaUnyZd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrJZgsdCMAAkMJa.jpg",
      "id_str" : "482546528305688576",
      "id" : 482546528305688576,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrJZgsdCMAAkMJa.jpg",
      "sizes" : [ {
        "h" : 538,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 494
      }, {
        "h" : 370,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 538,
        "resize" : "fit",
        "w" : 494
      } ],
      "display_url" : "pic.twitter.com\/QgYjaUnyZd"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482553332607623169",
  "text" : "RT @OneMoreJoke: Can't stop laughing :) Brilliant! http:\/\/t.co\/QgYjaUnyZd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OneMoreJoke\/status\/482546528460865537\/photo\/1",
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/QgYjaUnyZd",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrJZgsdCMAAkMJa.jpg",
        "id_str" : "482546528305688576",
        "id" : 482546528305688576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrJZgsdCMAAkMJa.jpg",
        "sizes" : [ {
          "h" : 538,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 494
        }, {
          "h" : 370,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 494
        } ],
        "display_url" : "pic.twitter.com\/QgYjaUnyZd"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482546528460865537",
    "text" : "Can't stop laughing :) Brilliant! http:\/\/t.co\/QgYjaUnyZd",
    "id" : 482546528460865537,
    "created_at" : "2014-06-27 15:30:32 +0000",
    "user" : {
      "name" : "Sarcasm",
      "screen_name" : "OneMoreJoke",
      "protected" : false,
      "id_str" : "547607608",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/449963727803019265\/6bVecz-Z_normal.png",
      "id" : 547607608,
      "verified" : false
    }
  },
  "id" : 482553332607623169,
  "created_at" : "2014-06-27 15:57:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robert Jeffery",
      "screen_name" : "jeffery_robert",
      "indices" : [ 3, 18 ],
      "id_str" : "450123141",
      "id" : 450123141
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jeffery_robert\/status\/482462696773025792\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/84s46vKu9m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrINQ_QCUAE5_my.jpg",
      "id_str" : "482462695589826561",
      "id" : 482462695589826561,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrINQ_QCUAE5_my.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/84s46vKu9m"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/jeffery_robert\/status\/482462696773025792\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/84s46vKu9m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrINRAGCEAA0Qdu.jpg",
      "id_str" : "482462695816302592",
      "id" : 482462695816302592,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrINRAGCEAA0Qdu.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/84s46vKu9m"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/jeffery_robert\/status\/482462696773025792\/photo\/1",
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/84s46vKu9m",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrINQ9iCUAArND6.jpg",
      "id_str" : "482462695128453120",
      "id" : 482462695128453120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrINQ9iCUAArND6.jpg",
      "sizes" : [ {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 682,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/84s46vKu9m"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482546760980508672",
  "text" : "RT @jeffery_robert: Mommy &amp; Daddy with baby in the rain!\uD83D\uDE0A\u2614\uFE0F http:\/\/t.co\/84s46vKu9m",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jeffery_robert\/status\/482462696773025792\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/84s46vKu9m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrINQ_QCUAE5_my.jpg",
        "id_str" : "482462695589826561",
        "id" : 482462695589826561,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrINQ_QCUAE5_my.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/84s46vKu9m"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/jeffery_robert\/status\/482462696773025792\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/84s46vKu9m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrINRAGCEAA0Qdu.jpg",
        "id_str" : "482462695816302592",
        "id" : 482462695816302592,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrINRAGCEAA0Qdu.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/84s46vKu9m"
      }, {
        "expanded_url" : "https:\/\/twitter.com\/jeffery_robert\/status\/482462696773025792\/photo\/1",
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/84s46vKu9m",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrINQ9iCUAArND6.jpg",
        "id_str" : "482462695128453120",
        "id" : 482462695128453120,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrINQ9iCUAArND6.jpg",
        "sizes" : [ {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 682,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/84s46vKu9m"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482462696773025792",
    "text" : "Mommy &amp; Daddy with baby in the rain!\uD83D\uDE0A\u2614\uFE0F http:\/\/t.co\/84s46vKu9m",
    "id" : 482462696773025792,
    "created_at" : "2014-06-27 09:57:25 +0000",
    "user" : {
      "name" : "Robert Jeffery",
      "screen_name" : "jeffery_robert",
      "protected" : false,
      "id_str" : "450123141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/469390081586118656\/tv572TqU_normal.jpeg",
      "id" : 450123141,
      "verified" : false
    }
  },
  "id" : 482546760980508672,
  "created_at" : "2014-06-27 15:31:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle (Poptart)",
      "screen_name" : "TheKyleConrad",
      "indices" : [ 0, 14 ],
      "id_str" : "18867490",
      "id" : 18867490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482488390571802624",
  "geo" : { },
  "id_str" : "482542846344327170",
  "in_reply_to_user_id" : 18867490,
  "text" : "@TheKyleConrad Good morning to you! : )",
  "id" : 482542846344327170,
  "in_reply_to_status_id" : 482488390571802624,
  "created_at" : "2014-06-27 15:15:54 +0000",
  "in_reply_to_screen_name" : "TheKyleConrad",
  "in_reply_to_user_id_str" : "18867490",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482526957616111617",
  "text" : "do what you love.. what if you dont have any passions??",
  "id" : 482526957616111617,
  "created_at" : "2014-06-27 14:12:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Griffin",
      "screen_name" : "GriffinWildlife",
      "indices" : [ 3, 19 ],
      "id_str" : "467845902",
      "id" : 467845902
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GriffinWildlife\/status\/480759356590657537\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/TbsmuMBOfm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqwAFgpIEAAYSrb.jpg",
      "id_str" : "480759354883575808",
      "id" : 480759354883575808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqwAFgpIEAAYSrb.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 533,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/TbsmuMBOfm"
    } ],
    "hashtags" : [ {
      "text" : "teammoth",
      "indices" : [ 74, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482526535392694273",
  "text" : "RT @GriffinWildlife: Another of the Elephant Hawk Moth from this morning. #teammoth http:\/\/t.co\/TbsmuMBOfm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GriffinWildlife\/status\/480759356590657537\/photo\/1",
        "indices" : [ 63, 85 ],
        "url" : "http:\/\/t.co\/TbsmuMBOfm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqwAFgpIEAAYSrb.jpg",
        "id_str" : "480759354883575808",
        "id" : 480759354883575808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqwAFgpIEAAYSrb.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 533,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/TbsmuMBOfm"
      } ],
      "hashtags" : [ {
        "text" : "teammoth",
        "indices" : [ 53, 62 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480759356590657537",
    "text" : "Another of the Elephant Hawk Moth from this morning. #teammoth http:\/\/t.co\/TbsmuMBOfm",
    "id" : 480759356590657537,
    "created_at" : "2014-06-22 17:08:57 +0000",
    "user" : {
      "name" : "Chris Griffin",
      "screen_name" : "GriffinWildlife",
      "protected" : false,
      "id_str" : "467845902",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/669493477219151873\/05iufdL2_normal.jpg",
      "id" : 467845902,
      "verified" : false
    }
  },
  "id" : 482526535392694273,
  "created_at" : "2014-06-27 14:11:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/1My3trDyKj",
      "expanded_url" : "http:\/\/watermarkitapp.com\/",
      "display_url" : "watermarkitapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482526467130011648",
  "text" : "RT @BromptonBadger: Mother Mallard vs Egyptian Goose who got too close to her chicks. The Mallard won the day. http:\/\/t.co\/1My3trDyKj http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BromptonBadger\/status\/469166154330951680\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/f0urHuLeOC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BoLQIaXIAAAgOzb.jpg",
        "id_str" : "469166154133798912",
        "id" : 469166154133798912,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BoLQIaXIAAAgOzb.jpg",
        "sizes" : [ {
          "h" : 231,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 697,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 697,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/f0urHuLeOC"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/1My3trDyKj",
        "expanded_url" : "http:\/\/watermarkitapp.com\/",
        "display_url" : "watermarkitapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "469166154330951680",
    "text" : "Mother Mallard vs Egyptian Goose who got too close to her chicks. The Mallard won the day. http:\/\/t.co\/1My3trDyKj http:\/\/t.co\/f0urHuLeOC",
    "id" : 469166154330951680,
    "created_at" : "2014-05-21 17:21:42 +0000",
    "user" : {
      "name" : "Mick.B.",
      "screen_name" : "BirdingBadger",
      "protected" : false,
      "id_str" : "416315549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466315930386325505\/VtmsiEDI_normal.jpeg",
      "id" : 416315549,
      "verified" : false
    }
  },
  "id" : 482526467130011648,
  "created_at" : "2014-06-27 14:10:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "2BirdBrainz",
      "screen_name" : "2BirdBrainz",
      "indices" : [ 3, 15 ],
      "id_str" : "1416237422",
      "id" : 1416237422
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/2BirdBrainz\/status\/482195234248347648\/photo\/1",
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/2PDe9zA8Of",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEaAe-CUAEE-bL.jpg",
      "id_str" : "482195230720937985",
      "id" : 482195230720937985,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEaAe-CUAEE-bL.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 242,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 730,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/2PDe9zA8Of"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482526290814046208",
  "text" : "RT @2BirdBrainz: Anyone else in the mood for adorable baby sparrows?? :-))) http:\/\/t.co\/2PDe9zA8Of",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/2BirdBrainz\/status\/482195234248347648\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/2PDe9zA8Of",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEaAe-CUAEE-bL.jpg",
        "id_str" : "482195230720937985",
        "id" : 482195230720937985,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEaAe-CUAEE-bL.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 242,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 730,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/2PDe9zA8Of"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482195234248347648",
    "text" : "Anyone else in the mood for adorable baby sparrows?? :-))) http:\/\/t.co\/2PDe9zA8Of",
    "id" : 482195234248347648,
    "created_at" : "2014-06-26 16:14:37 +0000",
    "user" : {
      "name" : "2BirdBrainz",
      "screen_name" : "2BirdBrainz",
      "protected" : false,
      "id_str" : "1416237422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/731000663824420869\/8i9ZwLgb_normal.jpg",
      "id" : 1416237422,
      "verified" : false
    }
  },
  "id" : 482526290814046208,
  "created_at" : "2014-06-27 14:10:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "indices" : [ 3, 15 ],
      "id_str" : "18761076",
      "id" : 18761076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/uTGoVlZ9Ur",
      "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/Android\/The+Room+2\/news.asp?c=60296",
      "display_url" : "pocketgamer.co.uk\/r\/Android\/The+\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482520250705915904",
  "text" : "RT @PocketGamer: The Room 2, Sonic 2, and Loco Motors are all free in Amazon's App Store Bundle right now - http:\/\/t.co\/uTGoVlZ9Ur http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PocketGamer\/status\/482504940565561344\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/BhKOD8U1gW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrIzr6BCcAAEAcz.jpg",
        "id_str" : "482504939483066368",
        "id" : 482504939483066368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrIzr6BCcAAEAcz.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 750,
          "resize" : "fit",
          "w" : 1500
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BhKOD8U1gW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/uTGoVlZ9Ur",
        "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/Android\/The+Room+2\/news.asp?c=60296",
        "display_url" : "pocketgamer.co.uk\/r\/Android\/The+\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482504940565561344",
    "text" : "The Room 2, Sonic 2, and Loco Motors are all free in Amazon's App Store Bundle right now - http:\/\/t.co\/uTGoVlZ9Ur http:\/\/t.co\/BhKOD8U1gW",
    "id" : 482504940565561344,
    "created_at" : "2014-06-27 12:45:17 +0000",
    "user" : {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "protected" : false,
      "id_str" : "18761076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479184281449660417\/JEbx7R5G_normal.jpeg",
      "id" : 18761076,
      "verified" : false
    }
  },
  "id" : 482520250705915904,
  "created_at" : "2014-06-27 13:46:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482516174756773889",
  "text" : "RT @RustBeltRebel: UN Response on Detroit: Disconnecting water from people who cannot pay \u2013 an affront to human rights, say UN experts: htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 139 ],
        "url" : "http:\/\/t.co\/fcvcAmERHF",
        "expanded_url" : "http:\/\/www.unog.ch\/80256EDD006B9C2E\/(httpNewsByYear_en)\/0BC1110A17B3FC11C1257D02004C8FF9?OpenDocument",
        "display_url" : "unog.ch\/80256EDD006B9C\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481973859596238849",
    "text" : "UN Response on Detroit: Disconnecting water from people who cannot pay \u2013 an affront to human rights, say UN experts: http:\/\/t.co\/fcvcAmERHF",
    "id" : 481973859596238849,
    "created_at" : "2014-06-26 01:34:57 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 482516174756773889,
  "created_at" : "2014-06-27 13:29:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/donnalouxxooxx\/status\/482507684436930563\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/Gwe6qIiUsY",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrI2LoTCUAAl6Wq.jpg",
      "id_str" : "482507683505786880",
      "id" : 482507683505786880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrI2LoTCUAAl6Wq.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Gwe6qIiUsY"
    } ],
    "hashtags" : [ {
      "text" : "CNN",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "Older",
      "indices" : [ 49, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 64, 86 ],
      "url" : "http:\/\/t.co\/N7Fxvtct1q",
      "expanded_url" : "http:\/\/ac360.blogs.cnn.com\/2014\/06\/26\/ridiculist-an-ode-to-older-ladies-and-saggy-breasts-that-droop-from-my-chest\/",
      "display_url" : "ac360.blogs.cnn.com\/2014\/06\/26\/rid\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482515517358346240",
  "text" : "RT @donnalouxxooxx: #CNN's Anderson Cooper &lt;3 #Older Ladies! http:\/\/t.co\/N7Fxvtct1q http:\/\/t.co\/Gwe6qIiUsY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/donnalouxxooxx\/status\/482507684436930563\/photo\/1",
        "indices" : [ 67, 89 ],
        "url" : "http:\/\/t.co\/Gwe6qIiUsY",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrI2LoTCUAAl6Wq.jpg",
        "id_str" : "482507683505786880",
        "id" : 482507683505786880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrI2LoTCUAAl6Wq.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Gwe6qIiUsY"
      } ],
      "hashtags" : [ {
        "text" : "CNN",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "Older",
        "indices" : [ 29, 35 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 66 ],
        "url" : "http:\/\/t.co\/N7Fxvtct1q",
        "expanded_url" : "http:\/\/ac360.blogs.cnn.com\/2014\/06\/26\/ridiculist-an-ode-to-older-ladies-and-saggy-breasts-that-droop-from-my-chest\/",
        "display_url" : "ac360.blogs.cnn.com\/2014\/06\/26\/rid\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482507684436930563",
    "text" : "#CNN's Anderson Cooper &lt;3 #Older Ladies! http:\/\/t.co\/N7Fxvtct1q http:\/\/t.co\/Gwe6qIiUsY",
    "id" : 482507684436930563,
    "created_at" : "2014-06-27 12:56:11 +0000",
    "user" : {
      "name" : "donnalou stevens",
      "screen_name" : "donnaloustevens",
      "protected" : false,
      "id_str" : "222689047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468133045581524992\/FXvsdOQf_normal.jpeg",
      "id" : 222689047,
      "verified" : false
    }
  },
  "id" : 482515517358346240,
  "created_at" : "2014-06-27 13:27:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.twitlonger.com\" rel=\"nofollow\"\u003ETwitlonger\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/dVF84p8okt",
      "expanded_url" : "http:\/\/tl.gd\/n_1s29dq2",
      "display_url" : "tl.gd\/n_1s29dq2"
    } ]
  },
  "geo" : { },
  "id_str" : "482507543692861440",
  "text" : "\"It\u2019s just that so many of us are invisible because we do not contribute in neurotypically loud, societally (cont) http:\/\/t.co\/dVF84p8okt",
  "id" : 482507543692861440,
  "created_at" : "2014-06-27 12:55:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Center for Inquiry",
      "screen_name" : "center4inquiry",
      "indices" : [ 3, 18 ],
      "id_str" : "20950239",
      "id" : 20950239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/2M8TSUribl",
      "expanded_url" : "http:\/\/www.theguardian.com\/world\/2014\/jun\/27\/sudanese-woman-meriam-ibrahim-safe-well-us-embassy",
      "display_url" : "theguardian.com\/world\/2014\/jun\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482504863410974720",
  "text" : "RT @center4inquiry: Sudanese woman Meriam Ibrahim 'safe and well' in US embassy http:\/\/t.co\/2M8TSUribl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 82 ],
        "url" : "http:\/\/t.co\/2M8TSUribl",
        "expanded_url" : "http:\/\/www.theguardian.com\/world\/2014\/jun\/27\/sudanese-woman-meriam-ibrahim-safe-well-us-embassy",
        "display_url" : "theguardian.com\/world\/2014\/jun\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482503547221602304",
    "text" : "Sudanese woman Meriam Ibrahim 'safe and well' in US embassy http:\/\/t.co\/2M8TSUribl",
    "id" : 482503547221602304,
    "created_at" : "2014-06-27 12:39:44 +0000",
    "user" : {
      "name" : "Center for Inquiry",
      "screen_name" : "center4inquiry",
      "protected" : false,
      "id_str" : "20950239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458696355515359232\/cRFpn7uM_normal.png",
      "id" : 20950239,
      "verified" : true
    }
  },
  "id" : 482504863410974720,
  "created_at" : "2014-06-27 12:44:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Center for Inquiry",
      "screen_name" : "center4inquiry",
      "indices" : [ 3, 18 ],
      "id_str" : "20950239",
      "id" : 20950239
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/center4inquiry\/status\/482253811332157440\/photo\/1",
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/cKWb4W4n1A",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFPSKcCUAA_DYl.png",
      "id_str" : "482253808563539968",
      "id" : 482253808563539968,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFPSKcCUAA_DYl.png",
      "sizes" : [ {
        "h" : 598,
        "resize" : "fit",
        "w" : 438
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 464,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 438
      }, {
        "h" : 598,
        "resize" : "fit",
        "w" : 438
      } ],
      "display_url" : "pic.twitter.com\/cKWb4W4n1A"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/ceaMRmJIqX",
      "expanded_url" : "http:\/\/action.centerforinquiry.net\/site\/MessageViewer?em_id=52101.0",
      "display_url" : "action.centerforinquiry.net\/site\/MessageVi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "482492831097839617",
  "text" : "RT @center4inquiry: EPIC: CFI Calls Out Saudi Arabia at UN Human Rights Council  http:\/\/t.co\/ceaMRmJIqX http:\/\/t.co\/cKWb4W4n1A",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/center4inquiry\/status\/482253811332157440\/photo\/1",
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/cKWb4W4n1A",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrFPSKcCUAA_DYl.png",
        "id_str" : "482253808563539968",
        "id" : 482253808563539968,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrFPSKcCUAA_DYl.png",
        "sizes" : [ {
          "h" : 598,
          "resize" : "fit",
          "w" : 438
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 464,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 438
        }, {
          "h" : 598,
          "resize" : "fit",
          "w" : 438
        } ],
        "display_url" : "pic.twitter.com\/cKWb4W4n1A"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 61, 83 ],
        "url" : "http:\/\/t.co\/ceaMRmJIqX",
        "expanded_url" : "http:\/\/action.centerforinquiry.net\/site\/MessageViewer?em_id=52101.0",
        "display_url" : "action.centerforinquiry.net\/site\/MessageVi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "482253811332157440",
    "text" : "EPIC: CFI Calls Out Saudi Arabia at UN Human Rights Council  http:\/\/t.co\/ceaMRmJIqX http:\/\/t.co\/cKWb4W4n1A",
    "id" : 482253811332157440,
    "created_at" : "2014-06-26 20:07:23 +0000",
    "user" : {
      "name" : "Center for Inquiry",
      "screen_name" : "center4inquiry",
      "protected" : false,
      "id_str" : "20950239",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458696355515359232\/cRFpn7uM_normal.png",
      "id" : 20950239,
      "verified" : true
    }
  },
  "id" : 482492831097839617,
  "created_at" : "2014-06-27 11:57:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Religious Freedom",
      "screen_name" : "FreedomReligion",
      "indices" : [ 3, 19 ],
      "id_str" : "2176299018",
      "id" : 2176299018
    }, {
      "name" : "Center for Inquiry",
      "screen_name" : "center4inquiry",
      "indices" : [ 48, 63 ],
      "id_str" : "20950239",
      "id" : 20950239
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482478599941799938",
  "text" : "RT @FreedomReligion: Proud that Canada defended @center4inquiry right to speak in Human Rights Council on Raif Badawi case today.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Center for Inquiry",
        "screen_name" : "center4inquiry",
        "indices" : [ 27, 42 ],
        "id_str" : "20950239",
        "id" : 20950239
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481123408240205825",
    "text" : "Proud that Canada defended @center4inquiry right to speak in Human Rights Council on Raif Badawi case today.",
    "id" : 481123408240205825,
    "created_at" : "2014-06-23 17:15:34 +0000",
    "user" : {
      "name" : "Religious Freedom",
      "screen_name" : "FreedomReligion",
      "protected" : false,
      "id_str" : "2176299018",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/732621647446966273\/xTJ__fk2_normal.jpg",
      "id" : 2176299018,
      "verified" : true
    }
  },
  "id" : 482478599941799938,
  "created_at" : "2014-06-27 11:00:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "indices" : [ 3, 15 ],
      "id_str" : "26747105",
      "id" : 26747105
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482335720376246272",
  "text" : "RT @DharmaTalks: Our True Self resides in the Source &amp; we know it when we do something from true love, or in those aha moments of light and\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482335141109313536",
    "text" : "Our True Self resides in the Source &amp; we know it when we do something from true love, or in those aha moments of light and insight",
    "id" : 482335141109313536,
    "created_at" : "2014-06-27 01:30:33 +0000",
    "user" : {
      "name" : "David Bennett",
      "screen_name" : "DharmaTalks",
      "protected" : false,
      "id_str" : "26747105",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000602948214\/57b1dbf25e9888f5be7a5411488e94a0_normal.jpeg",
      "id" : 26747105,
      "verified" : false
    }
  },
  "id" : 482335720376246272,
  "created_at" : "2014-06-27 01:32:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "indices" : [ 3, 13 ],
      "id_str" : "41457590",
      "id" : 41457590
    }, {
      "name" : "Diana Augustin",
      "screen_name" : "thejenwilkinson",
      "indices" : [ 29, 45 ],
      "id_str" : "793908379672461312",
      "id" : 793908379672461312
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Joja7eNHd7",
      "expanded_url" : "https:\/\/twitter.com\/thejenwilkinson\/status\/482318027468185601\/photo\/1",
      "display_url" : "pic.twitter.com\/Joja7eNHd7"
    } ]
  },
  "geo" : { },
  "id_str" : "482334403599667200",
  "text" : "RT @38harmony: love it :) RT @thejenwilkinson: Play http:\/\/t.co\/Joja7eNHd7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Diana Augustin",
        "screen_name" : "thejenwilkinson",
        "indices" : [ 14, 30 ],
        "id_str" : "793908379672461312",
        "id" : 793908379672461312
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 59 ],
        "url" : "http:\/\/t.co\/Joja7eNHd7",
        "expanded_url" : "https:\/\/twitter.com\/thejenwilkinson\/status\/482318027468185601\/photo\/1",
        "display_url" : "pic.twitter.com\/Joja7eNHd7"
      } ]
    },
    "geo" : { },
    "id_str" : "482318340871180289",
    "text" : "love it :) RT @thejenwilkinson: Play http:\/\/t.co\/Joja7eNHd7",
    "id" : 482318340871180289,
    "created_at" : "2014-06-27 00:23:48 +0000",
    "user" : {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "protected" : false,
      "id_str" : "41457590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1671334755\/2-HH-5-27-7_normal.jpg",
      "id" : 41457590,
      "verified" : false
    }
  },
  "id" : 482334403599667200,
  "created_at" : "2014-06-27 01:27:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482329602832867328",
  "text" : "@AutisticBird i dont drive as much now but sometimes.. im afraid my brain will mix the red and green lights.",
  "id" : 482329602832867328,
  "created_at" : "2014-06-27 01:08:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482329215300153344",
  "text" : "@AutisticBird i have a lot of times where I cant find the right word I want and get help from hubby.",
  "id" : 482329215300153344,
  "created_at" : "2014-06-27 01:07:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle (Poptart)",
      "screen_name" : "TheKyleConrad",
      "indices" : [ 0, 14 ],
      "id_str" : "18867490",
      "id" : 18867490
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482324480711458816",
  "geo" : { },
  "id_str" : "482328252157943810",
  "in_reply_to_user_id" : 18867490,
  "text" : "@TheKyleConrad @AutisticBird been awhile since I played but was fun. DD loves spin skip-bo.",
  "id" : 482328252157943810,
  "in_reply_to_status_id" : 482324480711458816,
  "created_at" : "2014-06-27 01:03:11 +0000",
  "in_reply_to_screen_name" : "TheKyleConrad",
  "in_reply_to_user_id_str" : "18867490",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482327896753598464",
  "text" : "@AutisticBird this happens to me with music occasionally where I dont hear the tune.. just noise then my brain kicks in and I hear it.",
  "id" : 482327896753598464,
  "created_at" : "2014-06-27 01:01:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "America Tonight",
      "screen_name" : "AmericaTonight",
      "indices" : [ 3, 18 ],
      "id_str" : "1447394395",
      "id" : 1447394395
    }, {
      "name" : "National Aquarium",
      "screen_name" : "NatlAquarium",
      "indices" : [ 77, 90 ],
      "id_str" : "18907371",
      "id" : 18907371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/oqGse13wBt",
      "expanded_url" : "http:\/\/alj.am\/1v9CfCt",
      "display_url" : "alj.am\/1v9CfCt"
    } ]
  },
  "geo" : { },
  "id_str" : "482297331442651136",
  "text" : "RT @AmericaTonight: Are dolphins too smart &amp; special to be kept captive? @NatlAquarium's CEO thinks they might be. http:\/\/t.co\/oqGse13wBt h\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Aquarium",
        "screen_name" : "NatlAquarium",
        "indices" : [ 57, 70 ],
        "id_str" : "18907371",
        "id" : 18907371
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AmericaTonight\/status\/482217170638999553\/photo\/1",
        "indices" : [ 122, 144 ],
        "url" : "http:\/\/t.co\/WIRQVsRX5H",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEt9idIQAA_UC0.jpg",
        "id_str" : "482217170349604864",
        "id" : 482217170349604864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEt9idIQAA_UC0.jpg",
        "sizes" : [ {
          "h" : 640,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 883,
          "resize" : "fit",
          "w" : 1413
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 375,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 212,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/WIRQVsRX5H"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/oqGse13wBt",
        "expanded_url" : "http:\/\/alj.am\/1v9CfCt",
        "display_url" : "alj.am\/1v9CfCt"
      } ]
    },
    "geo" : { },
    "id_str" : "482217170638999553",
    "text" : "Are dolphins too smart &amp; special to be kept captive? @NatlAquarium's CEO thinks they might be. http:\/\/t.co\/oqGse13wBt http:\/\/t.co\/WIRQVsRX5H",
    "id" : 482217170638999553,
    "created_at" : "2014-06-26 17:41:47 +0000",
    "user" : {
      "name" : "America Tonight",
      "screen_name" : "AmericaTonight",
      "protected" : false,
      "id_str" : "1447394395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/563085983646629888\/rI-cYGvU_normal.jpeg",
      "id" : 1447394395,
      "verified" : true
    }
  },
  "id" : 482297331442651136,
  "created_at" : "2014-06-26 23:00:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Mottram",
      "screen_name" : "CWWRYAN",
      "indices" : [ 0, 8 ],
      "id_str" : "2802003406",
      "id" : 2802003406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482215121469841408",
  "geo" : { },
  "id_str" : "482217156130521088",
  "in_reply_to_user_id" : 272369448,
  "text" : "@CWWRyan so sweet! &lt;3",
  "id" : 482217156130521088,
  "in_reply_to_status_id" : 482215121469841408,
  "created_at" : "2014-06-26 17:41:43 +0000",
  "in_reply_to_screen_name" : "Swanwhisperer",
  "in_reply_to_user_id_str" : "272369448",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryan Mottram",
      "screen_name" : "CWWRYAN",
      "indices" : [ 3, 11 ],
      "id_str" : "2802003406",
      "id" : 2802003406
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482215948942716929",
  "text" : "RT @CWWRyan: Myself the Swan Whisperer at Swan-watch HQ with about 60 Mute Swans , we only have 8 to 11 , they all gone breed http:\/\/t.co\/P\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CWWRyan\/status\/482215121469841408\/photo\/1",
        "indices" : [ 113, 135 ],
        "url" : "http:\/\/t.co\/Ptqg7EVguN",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrEsGKfIgAEd1Ui.jpg",
        "id_str" : "482215119511126017",
        "id" : 482215119511126017,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrEsGKfIgAEd1Ui.jpg",
        "sizes" : [ {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 423,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/Ptqg7EVguN"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482215121469841408",
    "text" : "Myself the Swan Whisperer at Swan-watch HQ with about 60 Mute Swans , we only have 8 to 11 , they all gone breed http:\/\/t.co\/Ptqg7EVguN",
    "id" : 482215121469841408,
    "created_at" : "2014-06-26 17:33:38 +0000",
    "user" : {
      "name" : "Wildlifeloverforever",
      "screen_name" : "Swanwhisperer",
      "protected" : false,
      "id_str" : "272369448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791573032808644608\/wYUEGx_F_normal.jpg",
      "id" : 272369448,
      "verified" : false
    }
  },
  "id" : 482215948942716929,
  "created_at" : "2014-06-26 17:36:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris Maytag",
      "screen_name" : "cpm5280",
      "indices" : [ 3, 11 ],
      "id_str" : "17947700",
      "id" : 17947700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482197462757568512",
  "text" : "RT @cpm5280: As much as I get fed up with people who complain about \"political correctness,\" I get pretty fed up with it myself. FFS, let p\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482193355833487362",
    "text" : "As much as I get fed up with people who complain about \"political correctness,\" I get pretty fed up with it myself. FFS, let people be.",
    "id" : 482193355833487362,
    "created_at" : "2014-06-26 16:07:09 +0000",
    "user" : {
      "name" : "Chris Maytag",
      "screen_name" : "cpm5280",
      "protected" : false,
      "id_str" : "17947700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796485463758360577\/cpVrGHw__normal.jpg",
      "id" : 17947700,
      "verified" : false
    }
  },
  "id" : 482197462757568512,
  "created_at" : "2014-06-26 16:23:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "482188904276426752",
  "geo" : { },
  "id_str" : "482191843581370368",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides or at least not conversing with me..lol",
  "id" : 482191843581370368,
  "in_reply_to_status_id" : 482188904276426752,
  "created_at" : "2014-06-26 16:01:08 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 3, 16 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482191587112255488",
  "text" : "RT @Charmantides: Thats my favorite ancient greek joke \"Barber asks how would you like your haircut? In silence\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482188904276426752",
    "text" : "Thats my favorite ancient greek joke \"Barber asks how would you like your haircut? In silence\".",
    "id" : 482188904276426752,
    "created_at" : "2014-06-26 15:49:28 +0000",
    "user" : {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "protected" : false,
      "id_str" : "257273626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/576343780594360321\/xMS37JZT_normal.jpeg",
      "id" : 257273626,
      "verified" : false
    }
  },
  "id" : 482191587112255488,
  "created_at" : "2014-06-26 16:00:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 3, 17 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "RedefineSodomy",
      "indices" : [ 83, 98 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/dMUccxWF4i",
      "expanded_url" : "http:\/\/redefinesodomy.com\/",
      "display_url" : "redefinesodomy.com"
    } ]
  },
  "geo" : { },
  "id_str" : "482191329233879040",
  "text" : "RT @UnfundieXians: This was the guilt of your sister Sodom: http:\/\/t.co\/dMUccxWF4i\n#RedefineSodomy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "RedefineSodomy",
        "indices" : [ 64, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/dMUccxWF4i",
        "expanded_url" : "http:\/\/redefinesodomy.com\/",
        "display_url" : "redefinesodomy.com"
      } ]
    },
    "geo" : { },
    "id_str" : "482188933527109632",
    "text" : "This was the guilt of your sister Sodom: http:\/\/t.co\/dMUccxWF4i\n#RedefineSodomy",
    "id" : 482188933527109632,
    "created_at" : "2014-06-26 15:49:35 +0000",
    "user" : {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "protected" : false,
      "id_str" : "780850862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000612253854\/d369ca7c4cc3d27a5fe05ca11521b685_normal.jpeg",
      "id" : 780850862,
      "verified" : false
    }
  },
  "id" : 482191329233879040,
  "created_at" : "2014-06-26 15:59:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Olivas",
      "screen_name" : "steveolivas",
      "indices" : [ 3, 15 ],
      "id_str" : "714822626",
      "id" : 714822626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482189615961346053",
  "text" : "RT @steveolivas: I don't have so much of a \"beach body\" as I do a \"beach ball body.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482161074855104512",
    "text" : "I don't have so much of a \"beach body\" as I do a \"beach ball body.\"",
    "id" : 482161074855104512,
    "created_at" : "2014-06-26 13:58:53 +0000",
    "user" : {
      "name" : "Steve Olivas",
      "screen_name" : "steveolivas",
      "protected" : false,
      "id_str" : "714822626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2429912435\/image_normal.jpg",
      "id" : 714822626,
      "verified" : false
    }
  },
  "id" : 482189615961346053,
  "created_at" : "2014-06-26 15:52:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/482185623282155520\/photo\/1",
      "indices" : [ 49, 71 ],
      "url" : "http:\/\/t.co\/U5kRUyki12",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrERRA8IMAASnzr.jpg",
      "id_str" : "482185619112996864",
      "id" : 482185619112996864,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrERRA8IMAASnzr.jpg",
      "sizes" : [ {
        "h" : 402,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 764
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 228,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 512,
        "resize" : "fit",
        "w" : 764
      } ],
      "display_url" : "pic.twitter.com\/U5kRUyki12"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482188318885425152",
  "text" : "RT @jacqueduncalf: \"Well if that's how you feel\" http:\/\/t.co\/U5kRUyki12",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/482185623282155520\/photo\/1",
        "indices" : [ 30, 52 ],
        "url" : "http:\/\/t.co\/U5kRUyki12",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrERRA8IMAASnzr.jpg",
        "id_str" : "482185619112996864",
        "id" : 482185619112996864,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrERRA8IMAASnzr.jpg",
        "sizes" : [ {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 764
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 764
        } ],
        "display_url" : "pic.twitter.com\/U5kRUyki12"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482185623282155520",
    "text" : "\"Well if that's how you feel\" http:\/\/t.co\/U5kRUyki12",
    "id" : 482185623282155520,
    "created_at" : "2014-06-26 15:36:25 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 482188318885425152,
  "created_at" : "2014-06-26 15:47:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482186691617116160",
  "text" : "RT @dailygalaxy: 'The Youngness Paradox' --\"Explains Why SETI has Not Found any Signals from Extraterrestrial Civilizations\u201D http:\/\/t.co\/ig\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 130 ],
        "url" : "http:\/\/t.co\/igYnMhbzpC",
        "expanded_url" : "http:\/\/dailygalaxy.com",
        "display_url" : "dailygalaxy.com"
      } ]
    },
    "geo" : { },
    "id_str" : "482183932905930753",
    "text" : "'The Youngness Paradox' --\"Explains Why SETI has Not Found any Signals from Extraterrestrial Civilizations\u201D http:\/\/t.co\/igYnMhbzpC",
    "id" : 482183932905930753,
    "created_at" : "2014-06-26 15:29:42 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 482186691617116160,
  "created_at" : "2014-06-26 15:40:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "indices" : [ 3, 18 ],
      "id_str" : "18538833",
      "id" : 18538833
    }, {
      "name" : "Victorena Minchew",
      "screen_name" : "Merleliz",
      "indices" : [ 107, 116 ],
      "id_str" : "1713587065",
      "id" : 1713587065
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ZeitgeistGhost\/status\/481964210260156417\/photo\/1",
      "indices" : [ 84, 106 ],
      "url" : "http:\/\/t.co\/fZrznEV9QM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BrBH5RoCEAA5kJb.jpg",
      "id_str" : "481964209438068736",
      "id" : 481964209438068736,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrBH5RoCEAA5kJb.jpg",
      "sizes" : [ {
        "h" : 535,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 303,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 535,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/fZrznEV9QM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482183294495096832",
  "text" : "RT @ZeitgeistGhost: I want what the Founders wanted , try reading it  it this time: http:\/\/t.co\/fZrznEV9QM @Merleliz @jelkel25 @PaxNostrum",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Victorena Minchew",
        "screen_name" : "Merleliz",
        "indices" : [ 87, 96 ],
        "id_str" : "1713587065",
        "id" : 1713587065
      }, {
        "name" : "Saturnius",
        "screen_name" : "PaxNostrum",
        "indices" : [ 107, 118 ],
        "id_str" : "2197106143",
        "id" : 2197106143
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZeitgeistGhost\/status\/481964210260156417\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/fZrznEV9QM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrBH5RoCEAA5kJb.jpg",
        "id_str" : "481964209438068736",
        "id" : 481964209438068736,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrBH5RoCEAA5kJb.jpg",
        "sizes" : [ {
          "h" : 535,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 303,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 535,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/fZrznEV9QM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "482181174245474306",
    "geo" : { },
    "id_str" : "482183097467686912",
    "in_reply_to_user_id" : 1713587065,
    "text" : "I want what the Founders wanted , try reading it  it this time: http:\/\/t.co\/fZrznEV9QM @Merleliz @jelkel25 @PaxNostrum",
    "id" : 482183097467686912,
    "in_reply_to_status_id" : 482181174245474306,
    "created_at" : "2014-06-26 15:26:23 +0000",
    "in_reply_to_screen_name" : "Merleliz",
    "in_reply_to_user_id_str" : "1713587065",
    "user" : {
      "name" : "Middle Class Warrior",
      "screen_name" : "ZeitgeistGhost",
      "protected" : false,
      "id_str" : "18538833",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723226265231073280\/V1JNPziL_normal.jpg",
      "id" : 18538833,
      "verified" : false
    }
  },
  "id" : 482183294495096832,
  "created_at" : "2014-06-26 15:27:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 3, 16 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "482178549311213568",
  "text" : "RT @JoshuaDamnIt: \"This time we should send our own kids.\" - no politicians talking about invading Iraq again",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "482177176406867969",
    "text" : "\"This time we should send our own kids.\" - no politicians talking about invading Iraq again",
    "id" : 482177176406867969,
    "created_at" : "2014-06-26 15:02:51 +0000",
    "user" : {
      "name" : "\uD83C\uDF84Joshua \u2603\uFE0F",
      "screen_name" : "ALifeRelentless",
      "protected" : false,
      "id_str" : "197910360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770384906639724544\/mN91OZP1_normal.jpg",
      "id" : 197910360,
      "verified" : false
    }
  },
  "id" : 482178549311213568,
  "created_at" : "2014-06-26 15:08:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr Simon R R Atkins",
      "screen_name" : "DrSimonAtkins",
      "indices" : [ 3, 17 ],
      "id_str" : "262418358",
      "id" : 262418358
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/5pUjbTeff2",
      "expanded_url" : "http:\/\/buff.ly\/Tslo1H",
      "display_url" : "buff.ly\/Tslo1H"
    } ]
  },
  "geo" : { },
  "id_str" : "482166948315156480",
  "text" : "RT @DrSimonAtkins: Is the concept of 'free will' an illusion? http:\/\/t.co\/5pUjbTeff2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/5pUjbTeff2",
        "expanded_url" : "http:\/\/buff.ly\/Tslo1H",
        "display_url" : "buff.ly\/Tslo1H"
      } ]
    },
    "geo" : { },
    "id_str" : "482162630845825024",
    "text" : "Is the concept of 'free will' an illusion? http:\/\/t.co\/5pUjbTeff2",
    "id" : 482162630845825024,
    "created_at" : "2014-06-26 14:05:04 +0000",
    "user" : {
      "name" : "Dr Simon R R Atkins",
      "screen_name" : "DrSimonAtkins",
      "protected" : false,
      "id_str" : "262418358",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727308573668171776\/GWfZTWm2_normal.jpg",
      "id" : 262418358,
      "verified" : false
    }
  },
  "id" : 482166948315156480,
  "created_at" : "2014-06-26 14:22:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Bowler",
      "screen_name" : "RichardBowler1",
      "indices" : [ 3, 18 ],
      "id_str" : "553323788",
      "id" : 553323788
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RichardBowler1\/status\/481868890109382656\/photo\/1",
      "indices" : [ 110, 132 ],
      "url" : "http:\/\/t.co\/rGMncx0aMx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_xMwBCMAEt4nZ.jpg",
      "id_str" : "481868886501896193",
      "id" : 481868886501896193,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_xMwBCMAEt4nZ.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 681,
        "resize" : "fit",
        "w" : 1020
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/rGMncx0aMx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481956665038614530",
  "text" : "RT @RichardBowler1: I reckon the flycatcher chicks could fledge tomorrow, been great watching them this week. http:\/\/t.co\/rGMncx0aMx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RichardBowler1\/status\/481868890109382656\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/rGMncx0aMx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_xMwBCMAEt4nZ.jpg",
        "id_str" : "481868886501896193",
        "id" : 481868886501896193,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_xMwBCMAEt4nZ.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 681,
          "resize" : "fit",
          "w" : 1020
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/rGMncx0aMx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481868890109382656",
    "text" : "I reckon the flycatcher chicks could fledge tomorrow, been great watching them this week. http:\/\/t.co\/rGMncx0aMx",
    "id" : 481868890109382656,
    "created_at" : "2014-06-25 18:37:50 +0000",
    "user" : {
      "name" : "Richard Bowler",
      "screen_name" : "RichardBowler1",
      "protected" : false,
      "id_str" : "553323788",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681757270745587712\/RfB32azg_normal.png",
      "id" : 553323788,
      "verified" : false
    }
  },
  "id" : 481956665038614530,
  "created_at" : "2014-06-26 00:26:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481941170138796032",
  "text" : "RT @AnAmericanMonk: Spirit Works Publishing has just released 'A Metaphysical Interpretation of the Bible' now available via Amazon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481940226613706752",
    "text" : "Spirit Works Publishing has just released 'A Metaphysical Interpretation of the Bible' now available via Amazon.",
    "id" : 481940226613706752,
    "created_at" : "2014-06-25 23:21:18 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 481941170138796032,
  "created_at" : "2014-06-25 23:25:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/Gfa1vwmvaG",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/Tll",
      "display_url" : "omgf.ac\/ts\/Tll"
    } ]
  },
  "geo" : { },
  "id_str" : "481910785552023552",
  "text" : "RT @OMGFacts: There's An Island Where Happy Pigs Swim Everywhere. And It's As Adorable As It Sounds --&gt; http:\/\/t.co\/Gfa1vwmvaG http:\/\/t.co\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/postcron.com\" rel=\"nofollow\"\u003EPostcron App\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OMGFacts\/status\/481908624772829184\/photo\/1",
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/OVkvccl7fk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BrAVVzpIEAAII6B.jpg",
        "id_str" : "481908624512782336",
        "id" : 481908624512782336,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BrAVVzpIEAAII6B.jpg",
        "sizes" : [ {
          "h" : 315,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 691
        }, {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 363,
          "resize" : "fit",
          "w" : 691
        } ],
        "display_url" : "pic.twitter.com\/OVkvccl7fk"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Gfa1vwmvaG",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/Tll",
        "display_url" : "omgf.ac\/ts\/Tll"
      } ]
    },
    "geo" : { },
    "id_str" : "481908624772829184",
    "text" : "There's An Island Where Happy Pigs Swim Everywhere. And It's As Adorable As It Sounds --&gt; http:\/\/t.co\/Gfa1vwmvaG http:\/\/t.co\/OVkvccl7fk",
    "id" : 481908624772829184,
    "created_at" : "2014-06-25 21:15:44 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 481910785552023552,
  "created_at" : "2014-06-25 21:24:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Lantz",
      "screen_name" : "paullantz",
      "indices" : [ 3, 13 ],
      "id_str" : "191180518",
      "id" : 191180518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 114, 136 ],
      "url" : "http:\/\/t.co\/JST5nlGjl7",
      "expanded_url" : "http:\/\/natpo.st\/1mbl1zd",
      "display_url" : "natpo.st\/1mbl1zd"
    } ]
  },
  "geo" : { },
  "id_str" : "481891152132448256",
  "text" : "RT @paullantz: Detroit begins cutting off water to 150,000 residents, prompting appeal to United Nations for help http:\/\/t.co\/JST5nlGjl7 vi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Financial Post",
        "screen_name" : "financialpost",
        "indices" : [ 126, 140 ],
        "id_str" : "14216681",
        "id" : 14216681
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 121 ],
        "url" : "http:\/\/t.co\/JST5nlGjl7",
        "expanded_url" : "http:\/\/natpo.st\/1mbl1zd",
        "display_url" : "natpo.st\/1mbl1zd"
      } ]
    },
    "geo" : { },
    "id_str" : "481505609351561216",
    "text" : "Detroit begins cutting off water to 150,000 residents, prompting appeal to United Nations for help http:\/\/t.co\/JST5nlGjl7 via @financialpost",
    "id" : 481505609351561216,
    "created_at" : "2014-06-24 18:34:17 +0000",
    "user" : {
      "name" : "Paul Lantz",
      "screen_name" : "paullantz",
      "protected" : false,
      "id_str" : "191180518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000277701740\/0363830f29ae6299d7c6c6ece72fc145_normal.jpeg",
      "id" : 191180518,
      "verified" : false
    }
  },
  "id" : 481891152132448256,
  "created_at" : "2014-06-25 20:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Lantz",
      "screen_name" : "paullantz",
      "indices" : [ 3, 13 ],
      "id_str" : "191180518",
      "id" : 191180518
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481890801497018369",
  "text" : "RT @paullantz: Do ravens have a preference for a particular kind of lard? Light hearted non-scientific study from Moosonee. http:\/\/t.co\/P08\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/P08ykrMfTL",
        "expanded_url" : "http:\/\/paullantz.smugmug.com\/Birds\/Raven-Lard-Preference\/23853651_gP6RBF#!i=1933873557&k=bxdTDPJ",
        "display_url" : "paullantz.smugmug.com\/Birds\/Raven-La\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481885493622083585",
    "text" : "Do ravens have a preference for a particular kind of lard? Light hearted non-scientific study from Moosonee. http:\/\/t.co\/P08ykrMfTL",
    "id" : 481885493622083585,
    "created_at" : "2014-06-25 19:43:49 +0000",
    "user" : {
      "name" : "Paul Lantz",
      "screen_name" : "paullantz",
      "protected" : false,
      "id_str" : "191180518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000277701740\/0363830f29ae6299d7c6c6ece72fc145_normal.jpeg",
      "id" : 191180518,
      "verified" : false
    }
  },
  "id" : 481890801497018369,
  "created_at" : "2014-06-25 20:04:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481888548195270657",
  "text" : "jeeezus.. ppl are so judgmental. think they have the answers.. just do this or just dont do that.. WTF??",
  "id" : 481888548195270657,
  "created_at" : "2014-06-25 19:55:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diana LaFleur",
      "screen_name" : "zacsquiggles",
      "indices" : [ 3, 16 ],
      "id_str" : "2243880164",
      "id" : 2243880164
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481881125749399553",
  "text" : "RT @zacsquiggles: \"@TiL_ou: Hello... http:\/\/t.co\/U8Et6GRnZk\"Come on in, the water's warm!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android Tablets\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/TiL_ou\/status\/481458519674466304\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/U8Et6GRnZk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq578X4IQAAD0-V.jpg",
        "id_str" : "481458487307026432",
        "id" : 481458487307026432,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq578X4IQAAD0-V.jpg",
        "sizes" : [ {
          "h" : 947,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 947,
          "resize" : "fit",
          "w" : 599
        }, {
          "h" : 538,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 947,
          "resize" : "fit",
          "w" : 599
        } ],
        "display_url" : "pic.twitter.com\/U8Et6GRnZk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481470021730705409",
    "text" : "\"@TiL_ou: Hello... http:\/\/t.co\/U8Et6GRnZk\"Come on in, the water's warm!\"",
    "id" : 481470021730705409,
    "created_at" : "2014-06-24 16:12:53 +0000",
    "user" : {
      "name" : "Diana LaFleur",
      "screen_name" : "zacsquiggles",
      "protected" : false,
      "id_str" : "2243880164",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419509553366310912\/EtJKcO9e_normal.jpeg",
      "id" : 2243880164,
      "verified" : false
    }
  },
  "id" : 481881125749399553,
  "created_at" : "2014-06-25 19:26:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481878166869274624",
  "text" : "@weakSquare hate? strong word. cool pic with and without the astro. circle.",
  "id" : 481878166869274624,
  "created_at" : "2014-06-25 19:14:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WaterIsAHumanRIght",
      "indices" : [ 27, 46 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481869386018349056",
  "text" : "RT @RustBeltRebel: because #WaterIsAHumanRIght, I mean, like, right? Don't we all, like, know that?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WaterIsAHumanRIght",
        "indices" : [ 8, 27 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481863553939304449",
    "text" : "because #WaterIsAHumanRIght, I mean, like, right? Don't we all, like, know that?",
    "id" : 481863553939304449,
    "created_at" : "2014-06-25 18:16:38 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 481869386018349056,
  "created_at" : "2014-06-25 18:39:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "wandering Mind",
      "screen_name" : "_PositiveSoul",
      "indices" : [ 3, 17 ],
      "id_str" : "707355255",
      "id" : 707355255
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481867824298606592",
  "text" : "RT @_PositiveSoul: love is my religion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481860657109676032",
    "text" : "love is my religion",
    "id" : 481860657109676032,
    "created_at" : "2014-06-25 18:05:07 +0000",
    "user" : {
      "name" : "wandering Mind",
      "screen_name" : "_PositiveSoul",
      "protected" : false,
      "id_str" : "707355255",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634458034056642560\/lV64MLda_normal.jpg",
      "id" : 707355255,
      "verified" : false
    }
  },
  "id" : 481867824298606592,
  "created_at" : "2014-06-25 18:33:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481867170138161154",
  "geo" : { },
  "id_str" : "481867714663694336",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny well, then we wouldn't have a thing to worry about cuz we'd all be dead. what's wrong with that?",
  "id" : 481867714663694336,
  "in_reply_to_status_id" : 481867170138161154,
  "created_at" : "2014-06-25 18:33:10 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481855079129964544",
  "text" : "my compassion has grown.. but it still lacks. i just have to continue striving for more.",
  "id" : 481855079129964544,
  "created_at" : "2014-06-25 17:42:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WaterIsAHumanRight",
      "indices" : [ 78, 97 ]
    }, {
      "text" : "WaterIsLove",
      "indices" : [ 98, 110 ]
    }, {
      "text" : "DetroitWaterWeek",
      "indices" : [ 111, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481854617790083075",
  "text" : "RT @RustBeltRebel: Human Rights always come before a balanced budget. Always. #WaterIsAHumanRight #WaterIsLove #DetroitWaterWeek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WaterIsAHumanRight",
        "indices" : [ 59, 78 ]
      }, {
        "text" : "WaterIsLove",
        "indices" : [ 79, 91 ]
      }, {
        "text" : "DetroitWaterWeek",
        "indices" : [ 92, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481854328186368000",
    "text" : "Human Rights always come before a balanced budget. Always. #WaterIsAHumanRight #WaterIsLove #DetroitWaterWeek",
    "id" : 481854328186368000,
    "created_at" : "2014-06-25 17:39:58 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 481854617790083075,
  "created_at" : "2014-06-25 17:41:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481854475427016704",
  "text" : "there was a time i thought i was very compassionate.. til i realized how much compassion i lacked.",
  "id" : 481854475427016704,
  "created_at" : "2014-06-25 17:40:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenny van Leeuwen",
      "screen_name" : "BoswachterJenny",
      "indices" : [ 3, 19 ],
      "id_str" : "586422441",
      "id" : 586422441
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Leidschendammerhout",
      "indices" : [ 32, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481853991614025729",
  "text" : "RT @BoswachterJenny: Kalfjes in #Leidschendammerhout laten zich goed zien. Als je in de file staat op de A4, kijk dan eens uit het raam htt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BoswachterJenny\/status\/481685547539517440\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/5m6HVZPWJh",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq9Kc49CYAAKTf4.jpg",
        "id_str" : "481685545337118720",
        "id" : 481685545337118720,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq9Kc49CYAAKTf4.jpg",
        "sizes" : [ {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/5m6HVZPWJh"
      } ],
      "hashtags" : [ {
        "text" : "Leidschendammerhout",
        "indices" : [ 11, 31 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481685547539517440",
    "text" : "Kalfjes in #Leidschendammerhout laten zich goed zien. Als je in de file staat op de A4, kijk dan eens uit het raam http:\/\/t.co\/5m6HVZPWJh",
    "id" : 481685547539517440,
    "created_at" : "2014-06-25 06:29:18 +0000",
    "user" : {
      "name" : "Jenny van Leeuwen",
      "screen_name" : "BoswachterJenny",
      "protected" : false,
      "id_str" : "586422441",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000853649195\/cd76620dc131c7ac97844281c2c954a6_normal.jpeg",
      "id" : 586422441,
      "verified" : false
    }
  },
  "id" : 481853991614025729,
  "created_at" : "2014-06-25 17:38:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 3, 15 ],
      "id_str" : "298992506",
      "id" : 298992506
    }, {
      "name" : "james irving",
      "screen_name" : "jamesirvingUk",
      "indices" : [ 20, 34 ],
      "id_str" : "1694196368",
      "id" : 1694196368
    }, {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "indices" : [ 36, 48 ],
      "id_str" : "298992506",
      "id" : 298992506
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jamesirvingUk\/status\/480310481719414784\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/UhbgcxUoWW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqpn1fZCQAAyxgM.jpg",
      "id_str" : "480310478925611008",
      "id" : 480310478925611008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqpn1fZCQAAyxgM.jpg",
      "sizes" : [ {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/UhbgcxUoWW"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481853717633699842",
  "text" : "RT @wildlife_uk: RT @jamesirvingUk: @wildlife_uk caught this shot just by chance http:\/\/t.co\/UhbgcxUoWW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "james irving",
        "screen_name" : "jamesirvingUk",
        "indices" : [ 3, 17 ],
        "id_str" : "1694196368",
        "id" : 1694196368
      }, {
        "name" : "Wildlife Sightings",
        "screen_name" : "wildlife_uk",
        "indices" : [ 19, 31 ],
        "id_str" : "298992506",
        "id" : 298992506
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jamesirvingUk\/status\/480310481719414784\/photo\/1",
        "indices" : [ 64, 86 ],
        "url" : "http:\/\/t.co\/UhbgcxUoWW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqpn1fZCQAAyxgM.jpg",
        "id_str" : "480310478925611008",
        "id" : 480310478925611008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqpn1fZCQAAyxgM.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/UhbgcxUoWW"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "480310481719414784",
    "geo" : { },
    "id_str" : "480669031918497792",
    "in_reply_to_user_id" : 1694196368,
    "text" : "RT @jamesirvingUk: @wildlife_uk caught this shot just by chance http:\/\/t.co\/UhbgcxUoWW",
    "id" : 480669031918497792,
    "in_reply_to_status_id" : 480310481719414784,
    "created_at" : "2014-06-22 11:10:02 +0000",
    "in_reply_to_screen_name" : "jamesirvingUk",
    "in_reply_to_user_id_str" : "1694196368",
    "user" : {
      "name" : "Wildlife Sightings",
      "screen_name" : "wildlife_uk",
      "protected" : false,
      "id_str" : "298992506",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/543830606543478784\/DvQW3ag9_normal.png",
      "id" : 298992506,
      "verified" : false
    }
  },
  "id" : 481853717633699842,
  "created_at" : "2014-06-25 17:37:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 0, 14 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481851785238175744",
  "geo" : { },
  "id_str" : "481853292750704640",
  "in_reply_to_user_id" : 2382724914,
  "text" : "@RustBeltRebel ironic how she had the hippie flower hair ring but very unhippie attitude : (",
  "id" : 481853292750704640,
  "in_reply_to_status_id" : 481851785238175744,
  "created_at" : "2014-06-25 17:35:52 +0000",
  "in_reply_to_screen_name" : "RustBeltRebel",
  "in_reply_to_user_id_str" : "2382724914",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fan of Arizona",
      "screen_name" : "fanofnmtn",
      "indices" : [ 3, 13 ],
      "id_str" : "2239643690",
      "id" : 2239643690
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/fanofnmtn\/status\/481841515807784961\/photo\/1",
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/aOrCrjGrnk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_YTi2CAAEihbR.jpg",
      "id_str" : "481841515434475521",
      "id" : 481841515434475521,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_YTi2CAAEihbR.jpg",
      "sizes" : [ {
        "h" : 1174,
        "resize" : "fit",
        "w" : 1536
      }, {
        "h" : 459,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 783,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/aOrCrjGrnk"
    } ],
    "hashtags" : [ {
      "text" : "Arizona",
      "indices" : [ 46, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481852997937278976",
  "text" : "RT @fanofnmtn: Oh, are you still there? Robin #Arizona http:\/\/t.co\/aOrCrjGrnk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/fanofnmtn\/status\/481841515807784961\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/aOrCrjGrnk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_YTi2CAAEihbR.jpg",
        "id_str" : "481841515434475521",
        "id" : 481841515434475521,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_YTi2CAAEihbR.jpg",
        "sizes" : [ {
          "h" : 1174,
          "resize" : "fit",
          "w" : 1536
        }, {
          "h" : 459,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 783,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/aOrCrjGrnk"
      } ],
      "hashtags" : [ {
        "text" : "Arizona",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481841515807784961",
    "text" : "Oh, are you still there? Robin #Arizona http:\/\/t.co\/aOrCrjGrnk",
    "id" : 481841515807784961,
    "created_at" : "2014-06-25 16:49:04 +0000",
    "user" : {
      "name" : "Fan of Arizona",
      "screen_name" : "fanofnmtn",
      "protected" : false,
      "id_str" : "2239643690",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759847075118915584\/ph0eD_X6_normal.jpg",
      "id" : 2239643690,
      "verified" : false
    }
  },
  "id" : 481852997937278976,
  "created_at" : "2014-06-25 17:34:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WaterIsAHumanRight",
      "indices" : [ 107, 126 ]
    }, {
      "text" : "WaterIsLove",
      "indices" : [ 127, 139 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481852797449547776",
  "text" : "RT @RustBeltRebel: I want all the money that pays for wars to go towards paying for water for all. because #WaterIsAHumanRight #WaterIsLove\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "WaterIsAHumanRight",
        "indices" : [ 88, 107 ]
      }, {
        "text" : "WaterIsLove",
        "indices" : [ 108, 120 ]
      }, {
        "text" : "DetroitWater",
        "indices" : [ 121, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481852098313609217",
    "text" : "I want all the money that pays for wars to go towards paying for water for all. because #WaterIsAHumanRight #WaterIsLove #DetroitWater",
    "id" : 481852098313609217,
    "created_at" : "2014-06-25 17:31:07 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 481852797449547776,
  "created_at" : "2014-06-25 17:33:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 0, 14 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481844006679478273",
  "geo" : { },
  "id_str" : "481849809230262272",
  "in_reply_to_user_id" : 2382724914,
  "text" : "@RustBeltRebel they have no clue. they are too far removed to understand. i see a spark with the gal in black top, tho (2nd from left.)",
  "id" : 481849809230262272,
  "in_reply_to_status_id" : 481844006679478273,
  "created_at" : "2014-06-25 17:22:01 +0000",
  "in_reply_to_screen_name" : "RustBeltRebel",
  "in_reply_to_user_id_str" : "2382724914",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481849050208022530",
  "text" : "RT @RustBeltRebel: what it is: video of white folks w\/focus on four white women in detroit talking abt the water situation. http:\/\/t.co\/qIA\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/qIAYiRQl7j",
        "expanded_url" : "http:\/\/vimeo.com\/99054879",
        "display_url" : "vimeo.com\/99054879"
      } ]
    },
    "geo" : { },
    "id_str" : "481844006679478273",
    "text" : "what it is: video of white folks w\/focus on four white women in detroit talking abt the water situation. http:\/\/t.co\/qIAYiRQl7j",
    "id" : 481844006679478273,
    "created_at" : "2014-06-25 16:58:58 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 481849050208022530,
  "created_at" : "2014-06-25 17:19:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "indices" : [ 3, 17 ],
      "id_str" : "2382724914",
      "id" : 2382724914
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481847566397501440",
  "text" : "RT @RustBeltRebel: that they're saying all this in front of a water based art installation that is spewing out god knows how many tons of w\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481844528375025665",
    "text" : "that they're saying all this in front of a water based art installation that is spewing out god knows how many tons of water a day...",
    "id" : 481844528375025665,
    "created_at" : "2014-06-25 17:01:02 +0000",
    "user" : {
      "name" : "RustBelt Rebel",
      "screen_name" : "RustBeltRebel",
      "protected" : false,
      "id_str" : "2382724914",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443149760053006337\/QiFm_35u_normal.jpeg",
      "id" : 2382724914,
      "verified" : false
    }
  },
  "id" : 481847566397501440,
  "created_at" : "2014-06-25 17:13:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/HpqaVtvjQR",
      "expanded_url" : "http:\/\/redemptionpictures.com\/2014\/06\/25\/unlearning-christianity\/",
      "display_url" : "redemptionpictures.com\/2014\/06\/25\/unl\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481847222552641536",
  "text" : "RT @micahjmurray: NEW POST: \"Unlearning Christianity\" http:\/\/t.co\/HpqaVtvjQR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 36, 58 ],
        "url" : "http:\/\/t.co\/HpqaVtvjQR",
        "expanded_url" : "http:\/\/redemptionpictures.com\/2014\/06\/25\/unlearning-christianity\/",
        "display_url" : "redemptionpictures.com\/2014\/06\/25\/unl\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481845545775149057",
    "text" : "NEW POST: \"Unlearning Christianity\" http:\/\/t.co\/HpqaVtvjQR",
    "id" : 481845545775149057,
    "created_at" : "2014-06-25 17:05:05 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 481847222552641536,
  "created_at" : "2014-06-25 17:11:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 0, 12 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481815738345603072",
  "geo" : { },
  "id_str" : "481836334344978433",
  "in_reply_to_user_id" : 299804123,
  "text" : "@ZwartblesIE LMAO :D @ThePlushGourmet",
  "id" : 481836334344978433,
  "in_reply_to_status_id" : 481815738345603072,
  "created_at" : "2014-06-25 16:28:28 +0000",
  "in_reply_to_screen_name" : "ZwartblesIE",
  "in_reply_to_user_id_str" : "299804123",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "indices" : [ 3, 15 ],
      "id_str" : "299804123",
      "id" : 299804123
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/481815738345603072\/photo\/1",
      "indices" : [ 44, 66 ],
      "url" : "http:\/\/t.co\/400jwnzeAv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_A28-CQAEjRSk.jpg",
      "id_str" : "481815735463723009",
      "id" : 481815735463723009,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_A28-CQAEjRSk.jpg",
      "sizes" : [ {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 480,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/400jwnzeAv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481836214710841345",
  "text" : "RT @ZwartblesIE: What more need I say...... http:\/\/t.co\/400jwnzeAv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ZwartblesIE\/status\/481815738345603072\/photo\/1",
        "indices" : [ 27, 49 ],
        "url" : "http:\/\/t.co\/400jwnzeAv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_A28-CQAEjRSk.jpg",
        "id_str" : "481815735463723009",
        "id" : 481815735463723009,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_A28-CQAEjRSk.jpg",
        "sizes" : [ {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 480,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/400jwnzeAv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481815738345603072",
    "text" : "What more need I say...... http:\/\/t.co\/400jwnzeAv",
    "id" : 481815738345603072,
    "created_at" : "2014-06-25 15:06:38 +0000",
    "user" : {
      "name" : "Zwartbles Ireland",
      "screen_name" : "ZwartblesIE",
      "protected" : false,
      "id_str" : "299804123",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1356447255\/z1f_normal.jpg",
      "id" : 299804123,
      "verified" : false
    }
  },
  "id" : 481836214710841345,
  "created_at" : "2014-06-25 16:28:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 3, 16 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JoshuaDamnIt\/status\/481819781835026432\/photo\/1",
      "indices" : [ 73, 95 ],
      "url" : "http:\/\/t.co\/usHPBOm0BG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_EiPAIUAAJJxU.jpg",
      "id_str" : "481819777573605376",
      "id" : 481819777573605376,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_EiPAIUAAJJxU.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 531,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/usHPBOm0BG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481836070196084737",
  "text" : "RT @JoshuaDamnIt: Mornin, earthlings. Let's take another spin, shall we? http:\/\/t.co\/usHPBOm0BG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JoshuaDamnIt\/status\/481819781835026432\/photo\/1",
        "indices" : [ 55, 77 ],
        "url" : "http:\/\/t.co\/usHPBOm0BG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_EiPAIUAAJJxU.jpg",
        "id_str" : "481819777573605376",
        "id" : 481819777573605376,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_EiPAIUAAJJxU.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 531,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/usHPBOm0BG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481819781835026432",
    "text" : "Mornin, earthlings. Let's take another spin, shall we? http:\/\/t.co\/usHPBOm0BG",
    "id" : 481819781835026432,
    "created_at" : "2014-06-25 15:22:42 +0000",
    "user" : {
      "name" : "\uD83C\uDF84Joshua \u2603\uFE0F",
      "screen_name" : "ALifeRelentless",
      "protected" : false,
      "id_str" : "197910360",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770384906639724544\/mN91OZP1_normal.jpg",
      "id" : 197910360,
      "verified" : false
    }
  },
  "id" : 481836070196084737,
  "created_at" : "2014-06-25 16:27:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0440\u043D\u0435\u0435\u0432\u0435\u0446 \u0411\u043E\u0433\u0434\u0430\u043D",
      "screen_name" : "JoshuaDamnIt",
      "indices" : [ 0, 13 ],
      "id_str" : "2833588102",
      "id" : 2833588102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481819781835026432",
  "geo" : { },
  "id_str" : "481836040110366720",
  "in_reply_to_user_id" : 197910360,
  "text" : "@JoshuaDamnIt Good morning, Sir!",
  "id" : 481836040110366720,
  "in_reply_to_status_id" : 481819781835026432,
  "created_at" : "2014-06-25 16:27:18 +0000",
  "in_reply_to_screen_name" : "ALifeRelentless",
  "in_reply_to_user_id_str" : "197910360",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "miraculous",
      "indices" : [ 27, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481830487682342913",
  "text" : "RT @Emmanueldagher: Have a #miraculous day!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "miraculous",
        "indices" : [ 7, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481826092534083585",
    "text" : "Have a #miraculous day!",
    "id" : 481826092534083585,
    "created_at" : "2014-06-25 15:47:47 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 481830487682342913,
  "created_at" : "2014-06-25 16:05:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teresa",
      "screen_name" : "tkpsky",
      "indices" : [ 3, 10 ],
      "id_str" : "727458925",
      "id" : 727458925
    }, {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 70, 86 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/tkpsky\/status\/481826518096564224\/photo\/1",
      "indices" : [ 102, 124 ],
      "url" : "http:\/\/t.co\/Oc2mpuLSnw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_KqkWCIAIVhQc.jpg",
      "id_str" : "481826517811339266",
      "id" : 481826517811339266,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_KqkWCIAIVhQc.jpg",
      "sizes" : [ {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 338,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 576,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 191,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/Oc2mpuLSnw"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481830201488195584",
  "text" : "RT @tkpsky: Maybe my favorite part of A Year of Biblical Womanhood by @rachelheldevans\u2014 Eshet chayil! http:\/\/t.co\/Oc2mpuLSnw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rachel Held Evans",
        "screen_name" : "rachelheldevans",
        "indices" : [ 58, 74 ],
        "id_str" : "14211946",
        "id" : 14211946
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/tkpsky\/status\/481826518096564224\/photo\/1",
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/Oc2mpuLSnw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq_KqkWCIAIVhQc.jpg",
        "id_str" : "481826517811339266",
        "id" : 481826517811339266,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq_KqkWCIAIVhQc.jpg",
        "sizes" : [ {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 576,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 191,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/Oc2mpuLSnw"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481826518096564224",
    "text" : "Maybe my favorite part of A Year of Biblical Womanhood by @rachelheldevans\u2014 Eshet chayil! http:\/\/t.co\/Oc2mpuLSnw",
    "id" : 481826518096564224,
    "created_at" : "2014-06-25 15:49:28 +0000",
    "user" : {
      "name" : "Teresa",
      "screen_name" : "tkpsky",
      "protected" : false,
      "id_str" : "727458925",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/712679349854543872\/JCDb7tcK_normal.jpg",
      "id" : 727458925,
      "verified" : false
    }
  },
  "id" : 481830201488195584,
  "created_at" : "2014-06-25 16:04:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USFWS Refuge System",
      "screen_name" : "USFWSRefuges",
      "indices" : [ 3, 16 ],
      "id_str" : "39633235",
      "id" : 39633235
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Refuge",
      "indices" : [ 96, 103 ]
    } ],
    "urls" : [ {
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/fq47nyPSFM",
      "expanded_url" : "http:\/\/on.fb.me\/1lPFRZh",
      "display_url" : "on.fb.me\/1lPFRZh"
    } ]
  },
  "geo" : { },
  "id_str" : "481829988568559616",
  "text" : "RT @USFWSRefuges: Porcupines are slow moving, don\u2019t see clearly. Watch funny video from Necedah #Refuge, WI: http:\/\/t.co\/fq47nyPSFM http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USFWSRefuges\/status\/481801993887838208\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/7nVYVWNUlc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq-0XE8CIAEzuZd.jpg",
        "id_str" : "481801993707462657",
        "id" : 481801993707462657,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq-0XE8CIAEzuZd.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 425,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/7nVYVWNUlc"
      } ],
      "hashtags" : [ {
        "text" : "Refuge",
        "indices" : [ 78, 85 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 113 ],
        "url" : "http:\/\/t.co\/fq47nyPSFM",
        "expanded_url" : "http:\/\/on.fb.me\/1lPFRZh",
        "display_url" : "on.fb.me\/1lPFRZh"
      } ]
    },
    "geo" : { },
    "id_str" : "481801993887838208",
    "text" : "Porcupines are slow moving, don\u2019t see clearly. Watch funny video from Necedah #Refuge, WI: http:\/\/t.co\/fq47nyPSFM http:\/\/t.co\/7nVYVWNUlc",
    "id" : 481801993887838208,
    "created_at" : "2014-06-25 14:12:01 +0000",
    "user" : {
      "name" : "USFWS Refuge System",
      "screen_name" : "USFWSRefuges",
      "protected" : false,
      "id_str" : "39633235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/472085172523790336\/UepMoXZA_normal.jpeg",
      "id" : 39633235,
      "verified" : true
    }
  },
  "id" : 481829988568559616,
  "created_at" : "2014-06-25 16:03:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anarcho Anon",
      "screen_name" : "AnarchoAnon",
      "indices" : [ 3, 15 ],
      "id_str" : "497092794",
      "id" : 497092794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Stingray",
      "indices" : [ 75, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 131 ],
      "url" : "https:\/\/t.co\/GcokwQLUUS",
      "expanded_url" : "https:\/\/www.techdirt.com\/articles\/20140620\/10271327635\/new-emails-show-that-feds-instructed-police-to-lie-about-using-stingray-mobile-phone-snooping.shtml",
      "display_url" : "techdirt.com\/articles\/20140\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481819948872761344",
  "text" : "RT @AnarchoAnon: New Emails Show Feds Instructed Police To Lie About Using #Stingray Mobile Phone Snooping: https:\/\/t.co\/GcokwQLUUS http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/AnarchoAnon\/status\/481066465487900672\/photo\/1",
        "indices" : [ 115, 137 ],
        "url" : "http:\/\/t.co\/8lrg2tpQYe",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0XZqbCcAAeG7t.png",
        "id_str" : "481066464850374656",
        "id" : 481066464850374656,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0XZqbCcAAeG7t.png",
        "sizes" : [ {
          "h" : 350,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 350,
          "resize" : "fit",
          "w" : 550
        }, {
          "h" : 216,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/8lrg2tpQYe"
      } ],
      "hashtags" : [ {
        "text" : "Stingray",
        "indices" : [ 58, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 91, 114 ],
        "url" : "https:\/\/t.co\/GcokwQLUUS",
        "expanded_url" : "https:\/\/www.techdirt.com\/articles\/20140620\/10271327635\/new-emails-show-that-feds-instructed-police-to-lie-about-using-stingray-mobile-phone-snooping.shtml",
        "display_url" : "techdirt.com\/articles\/20140\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481066465487900672",
    "text" : "New Emails Show Feds Instructed Police To Lie About Using #Stingray Mobile Phone Snooping: https:\/\/t.co\/GcokwQLUUS http:\/\/t.co\/8lrg2tpQYe",
    "id" : 481066465487900672,
    "created_at" : "2014-06-23 13:29:17 +0000",
    "user" : {
      "name" : "Anarcho Anon",
      "screen_name" : "AnarchoAnon",
      "protected" : false,
      "id_str" : "497092794",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/510310466938085376\/hnEMqoB4_normal.jpeg",
      "id" : 497092794,
      "verified" : false
    }
  },
  "id" : 481819948872761344,
  "created_at" : "2014-06-25 15:23:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481819706681065474",
  "text" : "RT @DeepakChopra: Surrender means not giving in to another, but giving in to love. Check out our new meditation app at http:\/\/t.co\/4yxwawra\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.deepakchopra.com\" rel=\"nofollow\"\u003EDeepak Chopra\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ananda",
        "indices" : [ 124, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/4yxwawra9F",
        "expanded_url" : "http:\/\/bit.ly\/DC_Ananda",
        "display_url" : "bit.ly\/DC_Ananda"
      } ]
    },
    "geo" : { },
    "id_str" : "481812976848994304",
    "text" : "Surrender means not giving in to another, but giving in to love. Check out our new meditation app at http:\/\/t.co\/4yxwawra9F #ananda",
    "id" : 481812976848994304,
    "created_at" : "2014-06-25 14:55:39 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 481819706681065474,
  "created_at" : "2014-06-25 15:22:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Rohr, OFM",
      "screen_name" : "RichardRohrOFM",
      "indices" : [ 3, 18 ],
      "id_str" : "399080466",
      "id" : 399080466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481813066447732737",
  "text" : "RT @RichardRohrOFM: You must step back from your compulsive identification and unquestioned attachment to yourself to be truly conscious.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481806745787195393",
    "text" : "You must step back from your compulsive identification and unquestioned attachment to yourself to be truly conscious.",
    "id" : 481806745787195393,
    "created_at" : "2014-06-25 14:30:54 +0000",
    "user" : {
      "name" : "Richard Rohr, OFM",
      "screen_name" : "RichardRohrOFM",
      "protected" : false,
      "id_str" : "399080466",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/569930543957942272\/TXCMulVA_normal.jpeg",
      "id" : 399080466,
      "verified" : false
    }
  },
  "id" : 481813066447732737,
  "created_at" : "2014-06-25 14:56:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "My Virtual Gallery \u00AE",
      "screen_name" : "MightyWitch",
      "indices" : [ 3, 15 ],
      "id_str" : "370750920",
      "id" : 370750920
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MightyWitch\/status\/477633660460736512\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/SG1NEdXyEm",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqDlSE7IYAA1yNY.jpg",
      "id_str" : "477633659223433216",
      "id" : 477633659223433216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqDlSE7IYAA1yNY.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 408,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1228,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 1508,
        "resize" : "fit",
        "w" : 1257
      } ],
      "display_url" : "pic.twitter.com\/SG1NEdXyEm"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481606537882771457",
  "text" : "RT @MightyWitch: Cat Balloon to your House by Natsuo Ikegami. http:\/\/t.co\/SG1NEdXyEm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MightyWitch\/status\/477633660460736512\/photo\/1",
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/SG1NEdXyEm",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqDlSE7IYAA1yNY.jpg",
        "id_str" : "477633659223433216",
        "id" : 477633659223433216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqDlSE7IYAA1yNY.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 408,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1228,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 1508,
          "resize" : "fit",
          "w" : 1257
        } ],
        "display_url" : "pic.twitter.com\/SG1NEdXyEm"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477633660460736512",
    "text" : "Cat Balloon to your House by Natsuo Ikegami. http:\/\/t.co\/SG1NEdXyEm",
    "id" : 477633660460736512,
    "created_at" : "2014-06-14 02:08:33 +0000",
    "user" : {
      "name" : "My Virtual Gallery \u00AE",
      "screen_name" : "MightyWitch",
      "protected" : false,
      "id_str" : "370750920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787180374917013504\/AmzVSTa3_normal.jpg",
      "id" : 370750920,
      "verified" : false
    }
  },
  "id" : 481606537882771457,
  "created_at" : "2014-06-25 01:15:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charmantides",
      "screen_name" : "Charmantides",
      "indices" : [ 0, 13 ],
      "id_str" : "257273626",
      "id" : 257273626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481598582404161537",
  "geo" : { },
  "id_str" : "481606381653344257",
  "in_reply_to_user_id" : 257273626,
  "text" : "@Charmantides : )",
  "id" : 481606381653344257,
  "in_reply_to_status_id" : 481598582404161537,
  "created_at" : "2014-06-25 01:14:43 +0000",
  "in_reply_to_screen_name" : "Charmantides",
  "in_reply_to_user_id_str" : "257273626",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "indices" : [ 3, 15 ],
      "id_str" : "31282286",
      "id" : 31282286
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "CorporateWelfare",
      "indices" : [ 89, 106 ]
    }, {
      "text" : "Tweko",
      "indices" : [ 124, 130 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481606177193594880",
  "text" : "RT @TheOracle13: Half of Detroit cannot pay water bills and getting water shut off.  Yet #CorporateWelfare is flush w\/cash.\n#Tweko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CorporateWelfare",
        "indices" : [ 72, 89 ]
      }, {
        "text" : "Tweko",
        "indices" : [ 107, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481598691086573569",
    "text" : "Half of Detroit cannot pay water bills and getting water shut off.  Yet #CorporateWelfare is flush w\/cash.\n#Tweko",
    "id" : 481598691086573569,
    "created_at" : "2014-06-25 00:44:10 +0000",
    "user" : {
      "name" : "Namaste",
      "screen_name" : "TheOracle13",
      "protected" : false,
      "id_str" : "31282286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000193430025\/51a36dc543f19f65cae87a675430f597_normal.jpeg",
      "id" : 31282286,
      "verified" : false
    }
  },
  "id" : 481606177193594880,
  "created_at" : "2014-06-25 01:13:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bird Photographer",
      "screen_name" : "birdphotoman",
      "indices" : [ 3, 16 ],
      "id_str" : "74139677",
      "id" : 74139677
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/birdphotoman\/status\/481539287687516161\/photo\/1",
      "indices" : [ 83, 105 ],
      "url" : "http:\/\/t.co\/Nvkk3QPViC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq7Fbe8CEAA5hNL.jpg",
      "id_str" : "481539286127218688",
      "id" : 481539286127218688,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq7Fbe8CEAA5hNL.jpg",
      "sizes" : [ {
        "h" : 539,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 305,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 776,
        "resize" : "fit",
        "w" : 864
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "display_url" : "pic.twitter.com\/Nvkk3QPViC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481605638443634689",
  "text" : "RT @birdphotoman: Wren.......and there's nothing wrong with being a little Chubby. http:\/\/t.co\/Nvkk3QPViC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/birdphotoman\/status\/481539287687516161\/photo\/1",
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/Nvkk3QPViC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq7Fbe8CEAA5hNL.jpg",
        "id_str" : "481539286127218688",
        "id" : 481539286127218688,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq7Fbe8CEAA5hNL.jpg",
        "sizes" : [ {
          "h" : 539,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 305,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 776,
          "resize" : "fit",
          "w" : 864
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        } ],
        "display_url" : "pic.twitter.com\/Nvkk3QPViC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481539287687516161",
    "text" : "Wren.......and there's nothing wrong with being a little Chubby. http:\/\/t.co\/Nvkk3QPViC",
    "id" : 481539287687516161,
    "created_at" : "2014-06-24 20:48:07 +0000",
    "user" : {
      "name" : "Bird Photographer",
      "screen_name" : "birdphotoman",
      "protected" : false,
      "id_str" : "74139677",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519707312\/bluebird_normal.jpg",
      "id" : 74139677,
      "verified" : false
    }
  },
  "id" : 481605638443634689,
  "created_at" : "2014-06-25 01:11:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andybirdingkent",
      "screen_name" : "misecretlife",
      "indices" : [ 3, 16 ],
      "id_str" : "2292219964",
      "id" : 2292219964
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/misecretlife\/status\/481013249681686528\/photo\/1",
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/2JBcH2zasb",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqzm9agCAAAUWag.jpg",
      "id_str" : "481013202981879808",
      "id" : 481013202981879808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqzm9agCAAAUWag.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 575
      }, {
        "h" : 605,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/2JBcH2zasb"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481588785310748672",
  "text" : "RT @misecretlife: This was taken with my phone Motorola g http:\/\/t.co\/2JBcH2zasb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/misecretlife\/status\/481013249681686528\/photo\/1",
        "indices" : [ 40, 62 ],
        "url" : "http:\/\/t.co\/2JBcH2zasb",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqzm9agCAAAUWag.jpg",
        "id_str" : "481013202981879808",
        "id" : 481013202981879808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqzm9agCAAAUWag.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 575
        }, {
          "h" : 605,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/2JBcH2zasb"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481013249681686528",
    "text" : "This was taken with my phone Motorola g http:\/\/t.co\/2JBcH2zasb",
    "id" : 481013249681686528,
    "created_at" : "2014-06-23 09:57:50 +0000",
    "user" : {
      "name" : "andybirdingkent",
      "screen_name" : "misecretlife",
      "protected" : false,
      "id_str" : "2292219964",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/681585536935555074\/tr-GVzVh_normal.jpg",
      "id" : 2292219964,
      "verified" : false
    }
  },
  "id" : 481588785310748672,
  "created_at" : "2014-06-25 00:04:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481583210628141057",
  "geo" : { },
  "id_str" : "481586756605603840",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen LOL.. DD loves Tumblr. she's always laughing, reading it off to me or showing pics.",
  "id" : 481586756605603840,
  "in_reply_to_status_id" : 481583210628141057,
  "created_at" : "2014-06-24 23:56:44 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    }, {
      "name" : "goodreads",
      "screen_name" : "goodreads",
      "indices" : [ 43, 53 ],
      "id_str" : "15898172",
      "id" : 15898172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481578118507790337",
  "text" : "RT @ChickenJen: time is running out on the @goodreads giveaway of \"The Songbird of Sovereign.\" Sign up here before June 30 https:\/\/t.co\/opt\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "goodreads",
        "screen_name" : "goodreads",
        "indices" : [ 27, 37 ],
        "id_str" : "15898172",
        "id" : 15898172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 130 ],
        "url" : "https:\/\/t.co\/optTeA8NfC",
        "expanded_url" : "https:\/\/www.goodreads.com\/book\/show\/21842445-the-songbird-of-sovereign",
        "display_url" : "goodreads.com\/book\/show\/2184\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481566268060094464",
    "text" : "time is running out on the @goodreads giveaway of \"The Songbird of Sovereign.\" Sign up here before June 30 https:\/\/t.co\/optTeA8NfC",
    "id" : 481566268060094464,
    "created_at" : "2014-06-24 22:35:20 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 481578118507790337,
  "created_at" : "2014-06-24 23:22:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/donnalouxxooxx\/status\/481569037306961920\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/Zu1iDrlLI3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq7gfHSCYAAznc7.jpg",
      "id_str" : "481569035310489600",
      "id" : 481569035310489600,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq7gfHSCYAAznc7.jpg",
      "sizes" : [ {
        "h" : 1360,
        "resize" : "fit",
        "w" : 1688
      }, {
        "h" : 483,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 274,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 825,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Zu1iDrlLI3"
    } ],
    "hashtags" : [ {
      "text" : "Older",
      "indices" : [ 44, 50 ]
    }, {
      "text" : "Ladies",
      "indices" : [ 51, 58 ]
    } ],
    "urls" : [ {
      "indices" : [ 89, 112 ],
      "url" : "https:\/\/t.co\/vQLXl9aEQe",
      "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/418425358\/if-i-were-enlightened",
      "display_url" : "kickstarter.com\/projects\/41842\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481577730538889216",
  "text" : "RT @donnalouxxooxx: If U &lt;3 &amp; shared #Older #Ladies, wud U help kickstart others? https:\/\/t.co\/vQLXl9aEQe http:\/\/t.co\/Zu1iDrlLI3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/donnalouxxooxx\/status\/481569037306961920\/photo\/1",
        "indices" : [ 93, 115 ],
        "url" : "http:\/\/t.co\/Zu1iDrlLI3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq7gfHSCYAAznc7.jpg",
        "id_str" : "481569035310489600",
        "id" : 481569035310489600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq7gfHSCYAAznc7.jpg",
        "sizes" : [ {
          "h" : 1360,
          "resize" : "fit",
          "w" : 1688
        }, {
          "h" : 483,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 274,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 825,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Zu1iDrlLI3"
      } ],
      "hashtags" : [ {
        "text" : "Older",
        "indices" : [ 24, 30 ]
      }, {
        "text" : "Ladies",
        "indices" : [ 31, 38 ]
      } ],
      "urls" : [ {
        "indices" : [ 69, 92 ],
        "url" : "https:\/\/t.co\/vQLXl9aEQe",
        "expanded_url" : "https:\/\/www.kickstarter.com\/projects\/418425358\/if-i-were-enlightened",
        "display_url" : "kickstarter.com\/projects\/41842\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481569037306961920",
    "text" : "If U &lt;3 &amp; shared #Older #Ladies, wud U help kickstart others? https:\/\/t.co\/vQLXl9aEQe http:\/\/t.co\/Zu1iDrlLI3",
    "id" : 481569037306961920,
    "created_at" : "2014-06-24 22:46:20 +0000",
    "user" : {
      "name" : "donnalou stevens",
      "screen_name" : "donnaloustevens",
      "protected" : false,
      "id_str" : "222689047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468133045581524992\/FXvsdOQf_normal.jpeg",
      "id" : 222689047,
      "verified" : false
    }
  },
  "id" : 481577730538889216,
  "created_at" : "2014-06-24 23:20:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff Titelius",
      "screen_name" : "JeffTitelius",
      "indices" : [ 3, 16 ],
      "id_str" : "35015249",
      "id" : 35015249
    }, {
      "name" : "DianeN56",
      "screen_name" : "DianeN56",
      "indices" : [ 40, 49 ],
      "id_str" : "30971909",
      "id" : 30971909
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481533738921127937",
  "text" : "RT @JeffTitelius: \"honey, I'm home!\" RT @DianeN56: Nature photo of the day: Family love... by Wolfgang Von Vietinghoff http:\/\/t.co\/7JJimm9K\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "DianeN56",
        "screen_name" : "DianeN56",
        "indices" : [ 22, 31 ],
        "id_str" : "30971909",
        "id" : 30971909
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 123 ],
        "url" : "http:\/\/t.co\/7JJimm9KNQ",
        "expanded_url" : "https:\/\/twitter.com\/kimczwicker\/status\/481099462329528320\/photo\/1",
        "display_url" : "pic.twitter.com\/7JJimm9KNQ"
      } ]
    },
    "geo" : { },
    "id_str" : "481209821338017792",
    "text" : "\"honey, I'm home!\" RT @DianeN56: Nature photo of the day: Family love... by Wolfgang Von Vietinghoff http:\/\/t.co\/7JJimm9KNQ RT @kimczwicker",
    "id" : 481209821338017792,
    "created_at" : "2014-06-23 22:58:56 +0000",
    "user" : {
      "name" : "Jeff Titelius",
      "screen_name" : "JeffTitelius",
      "protected" : false,
      "id_str" : "35015249",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/743498041252941825\/q2-g5GFX_normal.jpg",
      "id" : 35015249,
      "verified" : false
    }
  },
  "id" : 481533738921127937,
  "created_at" : "2014-06-24 20:26:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jadedjenny",
      "screen_name" : "jadedjenny71",
      "indices" : [ 3, 16 ],
      "id_str" : "143521190",
      "id" : 143521190
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 129 ],
      "url" : "http:\/\/t.co\/AJkdayMzZB",
      "expanded_url" : "http:\/\/bit.ly\/1mcTKkr",
      "display_url" : "bit.ly\/1mcTKkr"
    } ]
  },
  "geo" : { },
  "id_str" : "481528885327040512",
  "text" : "RT @jadedjenny71: Scientists simulated how quantum particles could travel through a wormhole back in time: http:\/\/t.co\/AJkdayMzZB http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jadedjenny71\/status\/481502312062394368\/photo\/1",
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/5p2KdpfO8P",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq6jzKNCQAAM0Jr.jpg",
        "id_str" : "481502309482905600",
        "id" : 481502309482905600,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq6jzKNCQAAM0Jr.jpg",
        "sizes" : [ {
          "h" : 336,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 217,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/5p2KdpfO8P"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 111 ],
        "url" : "http:\/\/t.co\/AJkdayMzZB",
        "expanded_url" : "http:\/\/bit.ly\/1mcTKkr",
        "display_url" : "bit.ly\/1mcTKkr"
      } ]
    },
    "geo" : { },
    "id_str" : "481502312062394368",
    "text" : "Scientists simulated how quantum particles could travel through a wormhole back in time: http:\/\/t.co\/AJkdayMzZB http:\/\/t.co\/5p2KdpfO8P",
    "id" : 481502312062394368,
    "created_at" : "2014-06-24 18:21:11 +0000",
    "user" : {
      "name" : "jadedjenny",
      "screen_name" : "jadedjenny71",
      "protected" : false,
      "id_str" : "143521190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015512308813824\/bMjE63Qf_normal.jpg",
      "id" : 143521190,
      "verified" : false
    }
  },
  "id" : 481528885327040512,
  "created_at" : "2014-06-24 20:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481491080588693505",
  "text" : "the back of my head\/neck is making crunchy noises.. hmmm..",
  "id" : 481491080588693505,
  "created_at" : "2014-06-24 17:36:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Nightmares",
      "screen_name" : "ChristnNitemare",
      "indices" : [ 0, 16 ],
      "id_str" : "116009507",
      "id" : 116009507
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481471376596140032",
  "geo" : { },
  "id_str" : "481478224010960897",
  "in_reply_to_user_id" : 116009507,
  "text" : "@ChristnNitemare \"It's an awesome thing to create a new life, right, Don?\" \"That's right, Frank.\" so Don's validation should persuade us?",
  "id" : 481478224010960897,
  "in_reply_to_status_id" : 481471376596140032,
  "created_at" : "2014-06-24 16:45:28 +0000",
  "in_reply_to_screen_name" : "ChristnNitemare",
  "in_reply_to_user_id_str" : "116009507",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481475113934544896",
  "text" : "Dear Universe.. so much crazy out there. Help me to radiate peace. Thank you.",
  "id" : 481475113934544896,
  "created_at" : "2014-06-24 16:33:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 0, 9 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481472287141412864",
  "geo" : { },
  "id_str" : "481473443884310529",
  "in_reply_to_user_id" : 889536330,
  "text" : "@rm123077 stunning. just what i needed to see in my TL right now. : )",
  "id" : 481473443884310529,
  "in_reply_to_status_id" : 481472287141412864,
  "created_at" : "2014-06-24 16:26:29 +0000",
  "in_reply_to_screen_name" : "rm123077",
  "in_reply_to_user_id_str" : "889536330",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookPage",
      "screen_name" : "bookpage",
      "indices" : [ 3, 12 ],
      "id_str" : "17304367",
      "id" : 17304367
    }, {
      "name" : "Farrar,Straus&Giroux",
      "screen_name" : "fsgbooks",
      "indices" : [ 121, 130 ],
      "id_str" : "19402584",
      "id" : 19402584
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/JTxENIn9E5",
      "expanded_url" : "http:\/\/bkpg.it\/4ma",
      "display_url" : "bkpg.it\/4ma"
    } ]
  },
  "geo" : { },
  "id_str" : "481471943829225472",
  "text" : "RT @bookpage: THE OWL WHO LIKED SITTING ON CAESAR is a lovely reflection on life with a tawny owl http:\/\/t.co\/JTxENIn9E5 @fsgbooks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Farrar,Straus&Giroux",
        "screen_name" : "fsgbooks",
        "indices" : [ 107, 116 ],
        "id_str" : "19402584",
        "id" : 19402584
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 106 ],
        "url" : "http:\/\/t.co\/JTxENIn9E5",
        "expanded_url" : "http:\/\/bkpg.it\/4ma",
        "display_url" : "bkpg.it\/4ma"
      } ]
    },
    "geo" : { },
    "id_str" : "481470674926829568",
    "text" : "THE OWL WHO LIKED SITTING ON CAESAR is a lovely reflection on life with a tawny owl http:\/\/t.co\/JTxENIn9E5 @fsgbooks",
    "id" : 481470674926829568,
    "created_at" : "2014-06-24 16:15:28 +0000",
    "user" : {
      "name" : "BookPage",
      "screen_name" : "bookpage",
      "protected" : false,
      "id_str" : "17304367",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793482805435068416\/rGBg6Wdr_normal.jpg",
      "id" : 17304367,
      "verified" : false
    }
  },
  "id" : 481471943829225472,
  "created_at" : "2014-06-24 16:20:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 8, 23 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 0, 4 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481471064896049154",
  "geo" : { },
  "id_str" : "481471361336881152",
  "in_reply_to_user_id" : 105049016,
  "text" : "#woo RT @richarddoetsch It's easy to look, it's much harder to see...",
  "id" : 481471361336881152,
  "in_reply_to_status_id" : 481471064896049154,
  "created_at" : "2014-06-24 16:18:12 +0000",
  "in_reply_to_screen_name" : "richarddoetsch",
  "in_reply_to_user_id_str" : "105049016",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "woo",
      "indices" : [ 111, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481455474210922496",
  "text" : "i know what I forgot in my list yesterday.. WOO! I believe in the woo, I live by the woo, I'll die in the woo. #woo",
  "id" : 481455474210922496,
  "created_at" : "2014-06-24 15:15:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481452665713340416",
  "text" : "RT @TheGoldenMirror: Say hi to strangers. Make them feel like they matter. If only for a moment.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481448494621016064",
    "text" : "Say hi to strangers. Make them feel like they matter. If only for a moment.",
    "id" : 481448494621016064,
    "created_at" : "2014-06-24 14:47:20 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 481452665713340416,
  "created_at" : "2014-06-24 15:03:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Larry Chason",
      "screen_name" : "wedge58",
      "indices" : [ 3, 11 ],
      "id_str" : "2738992878",
      "id" : 2738992878
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481436052607864833",
  "text" : "RT @Wedge58: WTF Do we live in Iraq?leave your guns at home.These people have serious issues they want to live in a Military State http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Wedge58\/status\/481247734872031233\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/GEFIUnQjTj",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq28QXVCAAAZBLP.jpg",
        "id_str" : "481247724524666880",
        "id" : 481247724524666880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq28QXVCAAAZBLP.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 504
        }, {
          "h" : 338,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 501,
          "resize" : "fit",
          "w" : 504
        } ],
        "display_url" : "pic.twitter.com\/GEFIUnQjTj"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481247734872031233",
    "text" : "WTF Do we live in Iraq?leave your guns at home.These people have serious issues they want to live in a Military State http:\/\/t.co\/GEFIUnQjTj",
    "id" : 481247734872031233,
    "created_at" : "2014-06-24 01:29:35 +0000",
    "user" : {
      "name" : "Wedge",
      "screen_name" : "Wedge85i",
      "protected" : false,
      "id_str" : "16796341",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622580492680826880\/29Y_gLLs_normal.jpg",
      "id" : 16796341,
      "verified" : false
    }
  },
  "id" : 481436052607864833,
  "created_at" : "2014-06-24 13:57:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rio Slade",
      "screen_name" : "RioSlade",
      "indices" : [ 3, 12 ],
      "id_str" : "409503621",
      "id" : 409503621
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481434048531664897",
  "text" : "RT @RioSlade: Louisiana cut a $70,000 check, and\u00A0sent it to the stars of hit reality show \"Duck Dynasty, for every episode it airs\n\nhttp:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/veEPkd1AP6",
        "expanded_url" : "http:\/\/www.truth-out.org\/opinion\/item\/24551-the-gop-is-the-pro-death-party",
        "display_url" : "truth-out.org\/opinion\/item\/2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481421914749952000",
    "text" : "Louisiana cut a $70,000 check, and\u00A0sent it to the stars of hit reality show \"Duck Dynasty, for every episode it airs\n\nhttp:\/\/t.co\/veEPkd1AP6",
    "id" : 481421914749952000,
    "created_at" : "2014-06-24 13:01:43 +0000",
    "user" : {
      "name" : "Rio Slade",
      "screen_name" : "RioSlade",
      "protected" : false,
      "id_str" : "409503621",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763885705965801473\/zUCbxX_3_normal.jpg",
      "id" : 409503621,
      "verified" : false
    }
  },
  "id" : 481434048531664897,
  "created_at" : "2014-06-24 13:49:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 0, 9 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481154822306275329",
  "geo" : { },
  "id_str" : "481164271435272192",
  "in_reply_to_user_id" : 215045056,
  "text" : "@Pandeism in the beginning, there was something. which used itself to make a variety of things.",
  "id" : 481164271435272192,
  "in_reply_to_status_id" : 481154822306275329,
  "created_at" : "2014-06-23 19:57:56 +0000",
  "in_reply_to_screen_name" : "Pandeism",
  "in_reply_to_user_id_str" : "215045056",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481144629715161088",
  "geo" : { },
  "id_str" : "481145442403487744",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater runs and hides under my rock!",
  "id" : 481145442403487744,
  "in_reply_to_status_id" : 481144629715161088,
  "created_at" : "2014-06-23 18:43:07 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 0, 13 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480903227878416384",
  "geo" : { },
  "id_str" : "481128089611542529",
  "in_reply_to_user_id" : 94619438,
  "text" : "@micahjmurray what's the title?",
  "id" : 481128089611542529,
  "in_reply_to_status_id" : 480903227878416384,
  "created_at" : "2014-06-23 17:34:10 +0000",
  "in_reply_to_screen_name" : "micahjmurray",
  "in_reply_to_user_id_str" : "94619438",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    }, {
      "name" : "Richard Rohr, OFM",
      "screen_name" : "RichardRohrOFM",
      "indices" : [ 96, 111 ],
      "id_str" : "399080466",
      "id" : 399080466
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/micahjmurray\/status\/480903227878416384\/photo\/1",
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/qHIzU3ZS68",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqyC76BCAAAZhcS.jpg",
      "id_str" : "480903225919275008",
      "id" : 480903225919275008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqyC76BCAAAZhcS.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/qHIzU3ZS68"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481126284047560704",
  "text" : "RT @micahjmurray: This is unlike the Christianity I always knew, but strangely compelling. (via @RichardRohrOFM) http:\/\/t.co\/qHIzU3ZS68",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Richard Rohr, OFM",
        "screen_name" : "RichardRohrOFM",
        "indices" : [ 78, 93 ],
        "id_str" : "399080466",
        "id" : 399080466
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/micahjmurray\/status\/480903227878416384\/photo\/1",
        "indices" : [ 95, 117 ],
        "url" : "http:\/\/t.co\/qHIzU3ZS68",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqyC76BCAAAZhcS.jpg",
        "id_str" : "480903225919275008",
        "id" : 480903225919275008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqyC76BCAAAZhcS.jpg",
        "sizes" : [ {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/qHIzU3ZS68"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480903227878416384",
    "text" : "This is unlike the Christianity I always knew, but strangely compelling. (via @RichardRohrOFM) http:\/\/t.co\/qHIzU3ZS68",
    "id" : 480903227878416384,
    "created_at" : "2014-06-23 02:40:38 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 481126284047560704,
  "created_at" : "2014-06-23 17:26:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dolphin Project",
      "screen_name" : "Dolphin_Project",
      "indices" : [ 3, 19 ],
      "id_str" : "378746121",
      "id" : 378746121
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/Dolphin_Project\/status\/481099529291186177\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/u9jXxLqNzt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq01eMFCIAAHrJ9.jpg",
      "id_str" : "481099527953195008",
      "id" : 481099527953195008,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq01eMFCIAAHrJ9.jpg",
      "sizes" : [ {
        "h" : 179,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 588
      }, {
        "h" : 310,
        "resize" : "fit",
        "w" : 588
      } ],
      "display_url" : "pic.twitter.com\/u9jXxLqNzt"
    } ],
    "hashtags" : [ {
      "text" : "Tweet4Dolphins",
      "indices" : [ 79, 94 ]
    } ],
    "urls" : [ {
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/1l5uMwntsy",
      "expanded_url" : "http:\/\/goodmenproject.com\/featured-content\/what-kind-of-company-tells-seaworldthanks-for-the-order-but-we-dont-want-your-money-dg\/",
      "display_url" : "goodmenproject.com\/featured-conte\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481123566184714241",
  "text" : "RT @Dolphin_Project: In a quiet revolution, one company stands up to SeaWorld. #Tweet4Dolphins http:\/\/t.co\/1l5uMwntsy http:\/\/t.co\/u9jXxLqNzt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/Dolphin_Project\/status\/481099529291186177\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/u9jXxLqNzt",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq01eMFCIAAHrJ9.jpg",
        "id_str" : "481099527953195008",
        "id" : 481099527953195008,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq01eMFCIAAHrJ9.jpg",
        "sizes" : [ {
          "h" : 179,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 588
        }, {
          "h" : 310,
          "resize" : "fit",
          "w" : 588
        } ],
        "display_url" : "pic.twitter.com\/u9jXxLqNzt"
      } ],
      "hashtags" : [ {
        "text" : "Tweet4Dolphins",
        "indices" : [ 58, 73 ]
      } ],
      "urls" : [ {
        "indices" : [ 74, 96 ],
        "url" : "http:\/\/t.co\/1l5uMwntsy",
        "expanded_url" : "http:\/\/goodmenproject.com\/featured-content\/what-kind-of-company-tells-seaworldthanks-for-the-order-but-we-dont-want-your-money-dg\/",
        "display_url" : "goodmenproject.com\/featured-conte\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481099529291186177",
    "text" : "In a quiet revolution, one company stands up to SeaWorld. #Tweet4Dolphins http:\/\/t.co\/1l5uMwntsy http:\/\/t.co\/u9jXxLqNzt",
    "id" : 481099529291186177,
    "created_at" : "2014-06-23 15:40:40 +0000",
    "user" : {
      "name" : "Dolphin Project",
      "screen_name" : "Dolphin_Project",
      "protected" : false,
      "id_str" : "378746121",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695636571366686720\/2EBEENiC_normal.jpg",
      "id" : 378746121,
      "verified" : true
    }
  },
  "id" : 481123566184714241,
  "created_at" : "2014-06-23 17:16:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "indices" : [ 3, 19 ],
      "id_str" : "14211946",
      "id" : 14211946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481122990189318146",
  "text" : "RT @rachelheldevans: The little birds in our carport are leaving the nest today. Six of them, one at a time. Can't write while all this exc\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481121707647062016",
    "text" : "The little birds in our carport are leaving the nest today. Six of them, one at a time. Can't write while all this excitement is happening!",
    "id" : 481121707647062016,
    "created_at" : "2014-06-23 17:08:48 +0000",
    "user" : {
      "name" : "Rachel Held Evans",
      "screen_name" : "rachelheldevans",
      "protected" : false,
      "id_str" : "14211946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1951244700\/headshot-resized_normal.jpg",
      "id" : 14211946,
      "verified" : true
    }
  },
  "id" : 481122990189318146,
  "created_at" : "2014-06-23 17:13:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481120389183967232",
  "text" : "hmm.. did I miss anything? (I feel so much better now!)",
  "id" : 481120389183967232,
  "created_at" : "2014-06-23 17:03:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481119986333646848",
  "text" : "you don't like about me: pro-choice, pacifist, anarchist, anti-death penalty, conspiracies, theist, fat, lazy, pro-single payer, kindle.",
  "id" : 481119986333646848,
  "created_at" : "2014-06-23 17:01:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 3, 16 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/BrianMerritt\/status\/481118185690005504\/photo\/1",
      "indices" : [ 115, 137 ],
      "url" : "http:\/\/t.co\/YvPYnx7dWv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1GcDkIEAAwgUr.jpg",
      "id_str" : "481118183005622272",
      "id" : 481118183005622272,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1GcDkIEAAwgUr.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/YvPYnx7dWv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481118686099435520",
  "text" : "RT @BrianMerritt: Off to mail the July issue of Holy Heretic. There is still time to get a copy. DM me an address! http:\/\/t.co\/YvPYnx7dWv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/BrianMerritt\/status\/481118185690005504\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/YvPYnx7dWv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq1GcDkIEAAwgUr.jpg",
        "id_str" : "481118183005622272",
        "id" : 481118183005622272,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq1GcDkIEAAwgUr.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/YvPYnx7dWv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481118185690005504",
    "text" : "Off to mail the July issue of Holy Heretic. There is still time to get a copy. DM me an address! http:\/\/t.co\/YvPYnx7dWv",
    "id" : 481118185690005504,
    "created_at" : "2014-06-23 16:54:48 +0000",
    "user" : {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "protected" : false,
      "id_str" : "15364301",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/613679986394968064\/-WlkVARS_normal.jpg",
      "id" : 15364301,
      "verified" : false
    }
  },
  "id" : 481118686099435520,
  "created_at" : "2014-06-23 16:56:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "481107382668247041",
  "geo" : { },
  "id_str" : "481111158640766978",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny big (((hugs)))",
  "id" : 481111158640766978,
  "in_reply_to_status_id" : 481107382668247041,
  "created_at" : "2014-06-23 16:26:53 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481110866377453568",
  "text" : "RT @ChickenJen: When in doubt, eat donuts.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481108285240918016",
    "text" : "When in doubt, eat donuts.",
    "id" : 481108285240918016,
    "created_at" : "2014-06-23 16:15:28 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 481110866377453568,
  "created_at" : "2014-06-23 16:25:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481107052601671680",
  "text" : "DD has a moto x using republic wireless plan. check that out. hybrid wifi\/cell $5 to $45\/mo ($25 suitable for most)",
  "id" : 481107052601671680,
  "created_at" : "2014-06-23 16:10:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481105748131209217",
  "text" : "I really don't see what makes the Fire phone so special...",
  "id" : 481105748131209217,
  "created_at" : "2014-06-23 16:05:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "indices" : [ 3, 15 ],
      "id_str" : "572225652",
      "id" : 572225652
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/481103669459705856\/photo\/1",
      "indices" : [ 63, 85 ],
      "url" : "http:\/\/t.co\/L9HQmjHLKX",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq05PP4IQAA1APt.jpg",
      "id_str" : "481103669321285632",
      "id" : 481103669321285632,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq05PP4IQAA1APt.jpg",
      "sizes" : [ {
        "h" : 736,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 736,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/L9HQmjHLKX"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481105461215649792",
  "text" : "RT @SciencePorn: When your girlfriend says \"I need some space\" http:\/\/t.co\/L9HQmjHLKX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SciencePorn\/status\/481103669459705856\/photo\/1",
        "indices" : [ 46, 68 ],
        "url" : "http:\/\/t.co\/L9HQmjHLKX",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq05PP4IQAA1APt.jpg",
        "id_str" : "481103669321285632",
        "id" : 481103669321285632,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq05PP4IQAA1APt.jpg",
        "sizes" : [ {
          "h" : 736,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 736,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/L9HQmjHLKX"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481103669459705856",
    "text" : "When your girlfriend says \"I need some space\" http:\/\/t.co\/L9HQmjHLKX",
    "id" : 481103669459705856,
    "created_at" : "2014-06-23 15:57:07 +0000",
    "user" : {
      "name" : "SciencePorn \uD83D\uDE80",
      "screen_name" : "SciencePorn",
      "protected" : false,
      "id_str" : "572225652",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779655933991481344\/40fIH7LV_normal.jpg",
      "id" : 572225652,
      "verified" : false
    }
  },
  "id" : 481105461215649792,
  "created_at" : "2014-06-23 16:04:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481104497029029891",
  "text" : "RT @donnalouxxooxx: Good morning, sweet ones. May your day be filled with love &amp; laughter. &lt;3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481098597564289026",
    "text" : "Good morning, sweet ones. May your day be filled with love &amp; laughter. &lt;3",
    "id" : 481098597564289026,
    "created_at" : "2014-06-23 15:36:58 +0000",
    "user" : {
      "name" : "donnalou stevens",
      "screen_name" : "donnaloustevens",
      "protected" : false,
      "id_str" : "222689047",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/468133045581524992\/FXvsdOQf_normal.jpeg",
      "id" : 222689047,
      "verified" : false
    }
  },
  "id" : 481104497029029891,
  "created_at" : "2014-06-23 16:00:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/481102921145516032\/photo\/1",
      "indices" : [ 62, 84 ],
      "url" : "http:\/\/t.co\/zi5tB6WPFn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq04jsMIgAAEJWI.jpg",
      "id_str" : "481102921007136768",
      "id" : 481102921007136768,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq04jsMIgAAEJWI.jpg",
      "sizes" : [ {
        "h" : 336,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 238,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 480
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 336,
        "resize" : "fit",
        "w" : 480
      } ],
      "display_url" : "pic.twitter.com\/zi5tB6WPFn"
    } ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 32, 38 ]
    } ],
    "urls" : [ {
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/4clj1tA6QB",
      "expanded_url" : "http:\/\/ebks.to\/1iADlBn",
      "display_url" : "ebks.to\/1iADlBn"
    } ]
  },
  "geo" : { },
  "id_str" : "481103717739925504",
  "text" : "RT @ebookfriendly: The world of #books http:\/\/t.co\/4clj1tA6QB http:\/\/t.co\/zi5tB6WPFn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ebookfriendly\/status\/481102921145516032\/photo\/1",
        "indices" : [ 43, 65 ],
        "url" : "http:\/\/t.co\/zi5tB6WPFn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq04jsMIgAAEJWI.jpg",
        "id_str" : "481102921007136768",
        "id" : 481102921007136768,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq04jsMIgAAEJWI.jpg",
        "sizes" : [ {
          "h" : 336,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 238,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 480
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 336,
          "resize" : "fit",
          "w" : 480
        } ],
        "display_url" : "pic.twitter.com\/zi5tB6WPFn"
      } ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 13, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/4clj1tA6QB",
        "expanded_url" : "http:\/\/ebks.to\/1iADlBn",
        "display_url" : "ebks.to\/1iADlBn"
      } ]
    },
    "geo" : { },
    "id_str" : "481102921145516032",
    "text" : "The world of #books http:\/\/t.co\/4clj1tA6QB http:\/\/t.co\/zi5tB6WPFn",
    "id" : 481102921145516032,
    "created_at" : "2014-06-23 15:54:09 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 481103717739925504,
  "created_at" : "2014-06-23 15:57:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dorothea",
      "screen_name" : "AveArt2012",
      "indices" : [ 3, 14 ],
      "id_str" : "1043831857",
      "id" : 1043831857
    }, {
      "name" : "Quad",
      "screen_name" : "ChikuwaQ",
      "indices" : [ 105, 114 ],
      "id_str" : "84088684",
      "id" : 84088684
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MarkTur94275194\/status\/441528836530765826\/photo\/1",
      "indices" : [ 82, 104 ],
      "url" : "http:\/\/t.co\/49Rf9TySMv",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BiCgIykCQAA1EQF.jpg",
      "id_str" : "441528836354621440",
      "id" : 441528836354621440,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiCgIykCQAA1EQF.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 598
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 598
      } ],
      "display_url" : "pic.twitter.com\/49Rf9TySMv"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481097431380008963",
  "text" : "RT @AveArt2012: Miauuuu \u2026. have you all a good start into an amazing new week !\n\n\"http:\/\/t.co\/49Rf9TySMv @ChikuwaQ \"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Quad",
        "screen_name" : "ChikuwaQ",
        "indices" : [ 89, 98 ],
        "id_str" : "84088684",
        "id" : 84088684
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MarkTur94275194\/status\/441528836530765826\/photo\/1",
        "indices" : [ 66, 88 ],
        "url" : "http:\/\/t.co\/49Rf9TySMv",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BiCgIykCQAA1EQF.jpg",
        "id_str" : "441528836354621440",
        "id" : 441528836354621440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BiCgIykCQAA1EQF.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 598
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 598
        } ],
        "display_url" : "pic.twitter.com\/49Rf9TySMv"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480918614074462210",
    "text" : "Miauuuu \u2026. have you all a good start into an amazing new week !\n\n\"http:\/\/t.co\/49Rf9TySMv @ChikuwaQ \"",
    "id" : 480918614074462210,
    "created_at" : "2014-06-23 03:41:47 +0000",
    "user" : {
      "name" : "Dorothea",
      "screen_name" : "AveArt2012",
      "protected" : false,
      "id_str" : "1043831857",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781423955303362560\/dx1CtQHc_normal.jpg",
      "id" : 1043831857,
      "verified" : false
    }
  },
  "id" : 481097431380008963,
  "created_at" : "2014-06-23 15:32:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "indices" : [ 3, 16 ],
      "id_str" : "15843059",
      "id" : 15843059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 127 ],
      "url" : "http:\/\/t.co\/bNZT3TNU9v",
      "expanded_url" : "http:\/\/www.naturalnews.com\/045690_memory_implants_induced_loss_medical_ethics.html",
      "display_url" : "naturalnews.com\/045690_memory_\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481092825556078592",
  "text" : "RT @HealthRanger: Science fiction no more: scientists are now able to create or erase memories at will - http:\/\/t.co\/bNZT3TNU9v",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 87, 109 ],
        "url" : "http:\/\/t.co\/bNZT3TNU9v",
        "expanded_url" : "http:\/\/www.naturalnews.com\/045690_memory_implants_induced_loss_medical_ethics.html",
        "display_url" : "naturalnews.com\/045690_memory_\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481089925732106241",
    "text" : "Science fiction no more: scientists are now able to create or erase memories at will - http:\/\/t.co\/bNZT3TNU9v",
    "id" : 481089925732106241,
    "created_at" : "2014-06-23 15:02:31 +0000",
    "user" : {
      "name" : "HealthRanger",
      "screen_name" : "HealthRanger",
      "protected" : false,
      "id_str" : "15843059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/466669627947237377\/qu4FUDr6_normal.jpeg",
      "id" : 15843059,
      "verified" : false
    }
  },
  "id" : 481092825556078592,
  "created_at" : "2014-06-23 15:14:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    }, {
      "name" : "Marco Rubio",
      "screen_name" : "marcorubio",
      "indices" : [ 28, 39 ],
      "id_str" : "15745368",
      "id" : 15745368
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "spectrum",
      "indices" : [ 67, 76 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481091873591656448",
  "text" : "RT @CoryBooker: I\u2019m joining @MarcoRubio in legislation 2 make more #spectrum avail to pwr your wireless dvcs- smartphones tablets etc. #wid\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marco Rubio",
        "screen_name" : "marcorubio",
        "indices" : [ 12, 23 ],
        "id_str" : "15745368",
        "id" : 15745368
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "spectrum",
        "indices" : [ 51, 60 ]
      }, {
        "text" : "widenWiFi",
        "indices" : [ 119, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481091425770426368",
    "text" : "I\u2019m joining @MarcoRubio in legislation 2 make more #spectrum avail to pwr your wireless dvcs- smartphones tablets etc. #widenWiFi",
    "id" : 481091425770426368,
    "created_at" : "2014-06-23 15:08:28 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 481091873591656448,
  "created_at" : "2014-06-23 15:10:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/481081214845976576\/photo\/1",
      "indices" : [ 92, 114 ],
      "url" : "http:\/\/t.co\/uELJekBNtc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0k0EuCAAAFIZv.jpg",
      "id_str" : "481081212237119488",
      "id" : 481081212237119488,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0k0EuCAAAFIZv.jpg",
      "sizes" : [ {
        "h" : 256,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 452,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1067,
        "resize" : "fit",
        "w" : 1417
      }, {
        "h" : 771,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/uELJekBNtc"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/igYnMhbzpC",
      "expanded_url" : "http:\/\/dailygalaxy.com",
      "display_url" : "dailygalaxy.com"
    } ]
  },
  "geo" : { },
  "id_str" : "481088850245058560",
  "text" : "RT @dailygalaxy: Never Before Seen Object Observed on Saturn's Titan http:\/\/t.co\/igYnMhbzpC http:\/\/t.co\/uELJekBNtc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/dailygalaxy\/status\/481081214845976576\/photo\/1",
        "indices" : [ 75, 97 ],
        "url" : "http:\/\/t.co\/uELJekBNtc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0k0EuCAAAFIZv.jpg",
        "id_str" : "481081212237119488",
        "id" : 481081212237119488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0k0EuCAAAFIZv.jpg",
        "sizes" : [ {
          "h" : 256,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 452,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1067,
          "resize" : "fit",
          "w" : 1417
        }, {
          "h" : 771,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/uELJekBNtc"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/igYnMhbzpC",
        "expanded_url" : "http:\/\/dailygalaxy.com",
        "display_url" : "dailygalaxy.com"
      } ]
    },
    "geo" : { },
    "id_str" : "481081214845976576",
    "text" : "Never Before Seen Object Observed on Saturn's Titan http:\/\/t.co\/igYnMhbzpC http:\/\/t.co\/uELJekBNtc",
    "id" : 481081214845976576,
    "created_at" : "2014-06-23 14:27:54 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 481088850245058560,
  "created_at" : "2014-06-23 14:58:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "481088761648779264",
  "text" : "RT @Seeds4Parents: Call me mentally unstable (it\u2019s not like I haven\u2019t heard it before!)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "481081243744759809",
    "text" : "Call me mentally unstable (it\u2019s not like I haven\u2019t heard it before!)",
    "id" : 481081243744759809,
    "created_at" : "2014-06-23 14:28:01 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 481088761648779264,
  "created_at" : "2014-06-23 14:57:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "indices" : [ 3, 13 ],
      "id_str" : "194209267",
      "id" : 194209267
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/EpicReads\/status\/481082064939540480\/photo\/1",
      "indices" : [ 121, 143 ],
      "url" : "http:\/\/t.co\/bPLMIffJA2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0llssIUAEBkHb.jpg",
      "id_str" : "481082064780152833",
      "id" : 481082064780152833,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0llssIUAEBkHb.jpg",
      "sizes" : [ {
        "h" : 339,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 161,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 339,
        "resize" : "fit",
        "w" : 714
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 285,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/bPLMIffJA2"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 120 ],
      "url" : "http:\/\/t.co\/gqkk6YfKk9",
      "expanded_url" : "http:\/\/www.epicreads.com\/blog\/try-it-the-69-test\/",
      "display_url" : "epicreads.com\/blog\/try-it-th\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "481088465455427585",
  "text" : "RT @EpicReads: Want to know if there book you're considering is any good? Flip to page 69! \u2013\u2013&gt; http:\/\/t.co\/gqkk6YfKk9 http:\/\/t.co\/bPLMIffJA2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/EpicReads\/status\/481082064939540480\/photo\/1",
        "indices" : [ 106, 128 ],
        "url" : "http:\/\/t.co\/bPLMIffJA2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bq0llssIUAEBkHb.jpg",
        "id_str" : "481082064780152833",
        "id" : 481082064780152833,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bq0llssIUAEBkHb.jpg",
        "sizes" : [ {
          "h" : 339,
          "resize" : "fit",
          "w" : 714
        }, {
          "h" : 161,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 339,
          "resize" : "fit",
          "w" : 714
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 285,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/bPLMIffJA2"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/gqkk6YfKk9",
        "expanded_url" : "http:\/\/www.epicreads.com\/blog\/try-it-the-69-test\/",
        "display_url" : "epicreads.com\/blog\/try-it-th\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "481082064939540480",
    "text" : "Want to know if there book you're considering is any good? Flip to page 69! \u2013\u2013&gt; http:\/\/t.co\/gqkk6YfKk9 http:\/\/t.co\/bPLMIffJA2",
    "id" : 481082064939540480,
    "created_at" : "2014-06-23 14:31:17 +0000",
    "user" : {
      "name" : "Epic Reads",
      "screen_name" : "EpicReads",
      "protected" : false,
      "id_str" : "194209267",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710877075469701121\/1Vj7UzYf_normal.jpg",
      "id" : 194209267,
      "verified" : true
    }
  },
  "id" : 481088465455427585,
  "created_at" : "2014-06-23 14:56:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480865095057043456",
  "geo" : { },
  "id_str" : "480872032985313280",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre interesting...",
  "id" : 480872032985313280,
  "in_reply_to_status_id" : 480865095057043456,
  "created_at" : "2014-06-23 00:36:41 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    }, {
      "name" : "Beth Foster",
      "screen_name" : "BethneyFoster",
      "indices" : [ 14, 28 ],
      "id_str" : "398558370",
      "id" : 398558370
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480022296867123200",
  "geo" : { },
  "id_str" : "480802458768113664",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt @BethneyFoster I'd love a copy, so please check. : ) Thank you!!",
  "id" : 480802458768113664,
  "in_reply_to_status_id" : 480022296867123200,
  "created_at" : "2014-06-22 20:00:13 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NotSheriffWoody\/status\/476418142349320192\/photo\/1",
      "indices" : [ 34, 56 ],
      "url" : "http:\/\/t.co\/sYMrQC1NJc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpyTxlKCAAAWcgQ.jpg",
      "id_str" : "476418140591489024",
      "id" : 476418140591489024,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpyTxlKCAAAWcgQ.jpg",
      "sizes" : [ {
        "h" : 176,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 306,
        "resize" : "fit",
        "w" : 592
      } ],
      "display_url" : "pic.twitter.com\/sYMrQC1NJc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480792252852097025",
  "text" : "RT @robboma3: retweet this second http:\/\/t.co\/sYMrQC1NJc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NotSheriffWoody\/status\/476418142349320192\/photo\/1",
        "indices" : [ 20, 42 ],
        "url" : "http:\/\/t.co\/sYMrQC1NJc",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpyTxlKCAAAWcgQ.jpg",
        "id_str" : "476418140591489024",
        "id" : 476418140591489024,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpyTxlKCAAAWcgQ.jpg",
        "sizes" : [ {
          "h" : 176,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 306,
          "resize" : "fit",
          "w" : 592
        } ],
        "display_url" : "pic.twitter.com\/sYMrQC1NJc"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476438707407708160",
    "text" : "retweet this second http:\/\/t.co\/sYMrQC1NJc",
    "id" : 476438707407708160,
    "created_at" : "2014-06-10 19:00:14 +0000",
    "user" : {
      "name" : "Mark Robinson",
      "screen_name" : "robboma24",
      "protected" : false,
      "id_str" : "186569856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797875356187459584\/ZMjtsfv6_normal.jpg",
      "id" : 186569856,
      "verified" : false
    }
  },
  "id" : 480792252852097025,
  "created_at" : "2014-06-22 19:19:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/NotSheriffWoody\/status\/476418102985777152\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/ewiwratqeG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpyTvTrIcAAXZYr.jpg",
      "id_str" : "476418101538746368",
      "id" : 476418101538746368,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpyTvTrIcAAXZYr.jpg",
      "sizes" : [ {
        "h" : 322,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 185,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 592
      }, {
        "h" : 322,
        "resize" : "fit",
        "w" : 592
      } ],
      "display_url" : "pic.twitter.com\/ewiwratqeG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480792224171446272",
  "text" : "RT @robboma3: retweet this first http:\/\/t.co\/ewiwratqeG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NotSheriffWoody\/status\/476418102985777152\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/ewiwratqeG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpyTvTrIcAAXZYr.jpg",
        "id_str" : "476418101538746368",
        "id" : 476418101538746368,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpyTvTrIcAAXZYr.jpg",
        "sizes" : [ {
          "h" : 322,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 185,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 592
        }, {
          "h" : 322,
          "resize" : "fit",
          "w" : 592
        } ],
        "display_url" : "pic.twitter.com\/ewiwratqeG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476438683223330817",
    "text" : "retweet this first http:\/\/t.co\/ewiwratqeG",
    "id" : 476438683223330817,
    "created_at" : "2014-06-10 19:00:08 +0000",
    "user" : {
      "name" : "Mark Robinson",
      "screen_name" : "robboma24",
      "protected" : false,
      "id_str" : "186569856",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797875356187459584\/ZMjtsfv6_normal.jpg",
      "id" : 186569856,
      "verified" : false
    }
  },
  "id" : 480792224171446272,
  "created_at" : "2014-06-22 19:19:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480766136112254976",
  "text" : "RT @JohnFugelsang: As soon as Bobby Jindal's done taking abt the need for lawless violence against DC he'd like to tell you abt how Christi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480763804754935808",
    "text" : "As soon as Bobby Jindal's done taking abt the need for lawless violence against DC he'd like to tell you abt how Christian he is.",
    "id" : 480763804754935808,
    "created_at" : "2014-06-22 17:26:37 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 480766136112254976,
  "created_at" : "2014-06-22 17:35:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 2, 15 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480421438915375104",
  "geo" : { },
  "id_str" : "480765385470255104",
  "in_reply_to_user_id" : 592182458,
  "text" : ". @Angelapaints yet when we question govt re: 9\/11, vaccines, wars, lost planes, etc. we are considered lunatics.. sigh..",
  "id" : 480765385470255104,
  "in_reply_to_status_id" : 480421438915375104,
  "created_at" : "2014-06-22 17:32:54 +0000",
  "in_reply_to_screen_name" : "Angelapaints",
  "in_reply_to_user_id_str" : "592182458",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480752404107776000",
  "text" : "RT @richarddoetsch: Sometime we just need someone to listen...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480751560473849857",
    "text" : "Sometime we just need someone to listen...",
    "id" : 480751560473849857,
    "created_at" : "2014-06-22 16:37:58 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 480752404107776000,
  "created_at" : "2014-06-22 16:41:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480740623394172928",
  "text" : "RT @DeepakChopra: Upon death consciousness does not go anywhere. It just stops using a particular body for its manifestation. #CosmicConsci\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "CosmicConsciousness",
        "indices" : [ 108, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480734551921426432",
    "text" : "Upon death consciousness does not go anywhere. It just stops using a particular body for its manifestation. #CosmicConsciousness",
    "id" : 480734551921426432,
    "created_at" : "2014-06-22 15:30:23 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 480740623394172928,
  "created_at" : "2014-06-22 15:54:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The BC Berrie",
      "screen_name" : "BCBerrie",
      "indices" : [ 3, 12 ],
      "id_str" : "3052903286",
      "id" : 3052903286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480732716028026880",
  "text" : "RT @BCBerrie: Neighbours chickens must think they are pets or somethin. Walk up the stairs 2 the back deck &amp; make these god awful noises wa\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480727698377957378",
    "text" : "Neighbours chickens must think they are pets or somethin. Walk up the stairs 2 the back deck &amp; make these god awful noises wantin 2B let in",
    "id" : 480727698377957378,
    "created_at" : "2014-06-22 15:03:09 +0000",
    "user" : {
      "name" : "\uD83C\uDF3A\u026E\u0105w~\u0273\u00E9e\uD83C\uDF3A",
      "screen_name" : "BCBawnee",
      "protected" : false,
      "id_str" : "24500414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707344203278200833\/yTRgqHSe_normal.jpg",
      "id" : 24500414,
      "verified" : false
    }
  },
  "id" : 480732716028026880,
  "created_at" : "2014-06-22 15:23:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480732534695673857",
  "text" : "we heard rustling. it was a deer running along the fence just behind us. cool.",
  "id" : 480732534695673857,
  "created_at" : "2014-06-22 15:22:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480718581265494016",
  "text" : "so, so tired of the anti-theist war.. sigh..",
  "id" : 480718581265494016,
  "created_at" : "2014-06-22 14:26:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "indices" : [ 3, 13 ],
      "id_str" : "23539037",
      "id" : 23539037
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/OhYouGirl\/status\/480715131458830336\/photo\/1",
      "indices" : [ 29, 51 ],
      "url" : "http:\/\/t.co\/WacWQpHlmx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqvX3WiCYAEk4N_.jpg",
      "id_str" : "480715131186208769",
      "id" : 480715131186208769,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqvX3WiCYAEk4N_.jpg",
      "sizes" : [ {
        "h" : 852,
        "resize" : "fit",
        "w" : 639
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 852,
        "resize" : "fit",
        "w" : 639
      } ],
      "display_url" : "pic.twitter.com\/WacWQpHlmx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480715587618750465",
  "text" : "RT @OhYouGirl: Kitty hazard. http:\/\/t.co\/WacWQpHlmx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/OhYouGirl\/status\/480715131458830336\/photo\/1",
        "indices" : [ 14, 36 ],
        "url" : "http:\/\/t.co\/WacWQpHlmx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqvX3WiCYAEk4N_.jpg",
        "id_str" : "480715131186208769",
        "id" : 480715131186208769,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqvX3WiCYAEk4N_.jpg",
        "sizes" : [ {
          "h" : 852,
          "resize" : "fit",
          "w" : 639
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 852,
          "resize" : "fit",
          "w" : 639
        } ],
        "display_url" : "pic.twitter.com\/WacWQpHlmx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480715131458830336",
    "text" : "Kitty hazard. http:\/\/t.co\/WacWQpHlmx",
    "id" : 480715131458830336,
    "created_at" : "2014-06-22 14:13:13 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 480715587618750465,
  "created_at" : "2014-06-22 14:15:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEcfs",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "MCS",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480439671109869568",
  "text" : "RT @Angelapaints: #MEcfs #MCS Cannot find in searches any criminal charges\/investigations resulted even as information became public: http:\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MEcfs",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "MCS",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 116, 138 ],
        "url" : "http:\/\/t.co\/AhhVoOP5LC",
        "expanded_url" : "http:\/\/www.damninteresting.com\/undark-and-the-radium-girls\/",
        "display_url" : "damninteresting.com\/undark-and-the\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "480422697516953601",
    "geo" : { },
    "id_str" : "480434099346485248",
    "in_reply_to_user_id" : 592182458,
    "text" : "#MEcfs #MCS Cannot find in searches any criminal charges\/investigations resulted even as information became public: http:\/\/t.co\/AhhVoOP5LC \u2026",
    "id" : 480434099346485248,
    "in_reply_to_status_id" : 480422697516953601,
    "created_at" : "2014-06-21 19:36:29 +0000",
    "in_reply_to_screen_name" : "Angelapaints",
    "in_reply_to_user_id_str" : "592182458",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 480439671109869568,
  "created_at" : "2014-06-21 19:58:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEcfs",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "MCS",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 128 ],
      "url" : "http:\/\/t.co\/AhhVoOP5LC",
      "expanded_url" : "http:\/\/www.damninteresting.com\/undark-and-the-radium-girls\/",
      "display_url" : "damninteresting.com\/undark-and-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480439642068488192",
  "text" : "RT @Angelapaints: #MEcfs #MCS Can't even imagine how many people were involved for them to pull this off: http:\/\/t.co\/AhhVoOP5LC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MEcfs",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "MCS",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/AhhVoOP5LC",
        "expanded_url" : "http:\/\/www.damninteresting.com\/undark-and-the-radium-girls\/",
        "display_url" : "damninteresting.com\/undark-and-the\u2026"
      } ]
    },
    "in_reply_to_status_id_str" : "480421438915375104",
    "geo" : { },
    "id_str" : "480422697516953601",
    "in_reply_to_user_id" : 592182458,
    "text" : "#MEcfs #MCS Can't even imagine how many people were involved for them to pull this off: http:\/\/t.co\/AhhVoOP5LC",
    "id" : 480422697516953601,
    "in_reply_to_status_id" : 480421438915375104,
    "created_at" : "2014-06-21 18:51:11 +0000",
    "in_reply_to_screen_name" : "Angelapaints",
    "in_reply_to_user_id_str" : "592182458",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 480439642068488192,
  "created_at" : "2014-06-21 19:58:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEcfs",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "MCS",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 130 ],
      "url" : "http:\/\/t.co\/AhhVoOP5LC",
      "expanded_url" : "http:\/\/www.damninteresting.com\/undark-and-the-radium-girls\/",
      "display_url" : "damninteresting.com\/undark-and-the\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480439622263001089",
  "text" : "RT @Angelapaints: #MEcfs #MCS It could be worse (always) NJ radium watch dial girls told they had syphylis: http:\/\/t.co\/AhhVoOP5LC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MEcfs",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "MCS",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 112 ],
        "url" : "http:\/\/t.co\/AhhVoOP5LC",
        "expanded_url" : "http:\/\/www.damninteresting.com\/undark-and-the-radium-girls\/",
        "display_url" : "damninteresting.com\/undark-and-the\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480421438915375104",
    "text" : "#MEcfs #MCS It could be worse (always) NJ radium watch dial girls told they had syphylis: http:\/\/t.co\/AhhVoOP5LC",
    "id" : 480421438915375104,
    "created_at" : "2014-06-21 18:46:11 +0000",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 480439622263001089,
  "created_at" : "2014-06-21 19:58:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mindfulness Training",
      "screen_name" : "TrainingMindful",
      "indices" : [ 3, 19 ],
      "id_str" : "1081982948",
      "id" : 1081982948
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480437798747381760",
  "text" : "RT @TrainingMindful: \"My religion is very simple. My religion is kindness.\" ~ Dalai Lama",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480435416278237184",
    "text" : "\"My religion is very simple. My religion is kindness.\" ~ Dalai Lama",
    "id" : 480435416278237184,
    "created_at" : "2014-06-21 19:41:43 +0000",
    "user" : {
      "name" : "Mindfulness Training",
      "screen_name" : "TrainingMindful",
      "protected" : false,
      "id_str" : "1081982948",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/566526924059459584\/gdMxDA9x_normal.jpeg",
      "id" : 1081982948,
      "verified" : false
    }
  },
  "id" : 480437798747381760,
  "created_at" : "2014-06-21 19:51:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/oDW8uTbES7",
      "expanded_url" : "https:\/\/plus.google.com\/u\/0\/110585962532856059731\/posts\/ibb3rtix9QP",
      "display_url" : "plus.google.com\/u\/0\/1105859625\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480433020885692416",
  "text" : "https:\/\/t.co\/oDW8uTbES7",
  "id" : 480433020885692416,
  "created_at" : "2014-06-21 19:32:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "indices" : [ 3, 16 ],
      "id_str" : "592182458",
      "id" : 592182458
    }, {
      "name" : "Oh boy what a shot",
      "screen_name" : "ohboywhatashot",
      "indices" : [ 38, 53 ],
      "id_str" : "210556794",
      "id" : 210556794
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "MEcfs",
      "indices" : [ 18, 24 ]
    }, {
      "text" : "MCS",
      "indices" : [ 25, 29 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480406549634887680",
  "text" : "RT @Angelapaints: #MEcfs #MCS hmmm RT @ohboywhatashot The complete history of Monsanto, the world\u2019s most evil corporation \u2500\u25BA http:\/\/t.co\/Wi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oh boy what a shot",
        "screen_name" : "ohboywhatashot",
        "indices" : [ 20, 35 ],
        "id_str" : "210556794",
        "id" : 210556794
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "MEcfs",
        "indices" : [ 0, 6 ]
      }, {
        "text" : "MCS",
        "indices" : [ 7, 11 ]
      } ],
      "urls" : [ {
        "indices" : [ 107, 129 ],
        "url" : "http:\/\/t.co\/WiaWAAfh9k",
        "expanded_url" : "http:\/\/bit.ly\/1qqMRfY",
        "display_url" : "bit.ly\/1qqMRfY"
      } ]
    },
    "in_reply_to_status_id_str" : "480402030499209216",
    "geo" : { },
    "id_str" : "480403719452753921",
    "in_reply_to_user_id" : 210556794,
    "text" : "#MEcfs #MCS hmmm RT @ohboywhatashot The complete history of Monsanto, the world\u2019s most evil corporation \u2500\u25BA http:\/\/t.co\/WiaWAAfh9k",
    "id" : 480403719452753921,
    "in_reply_to_status_id" : 480402030499209216,
    "created_at" : "2014-06-21 17:35:46 +0000",
    "in_reply_to_screen_name" : "ohboywhatashot",
    "in_reply_to_user_id_str" : "210556794",
    "user" : {
      "name" : "Angela Paints",
      "screen_name" : "Angelapaints",
      "protected" : false,
      "id_str" : "592182458",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000381626481\/b0fc0b6ce190664d120a99d6e206b1d2_normal.jpeg",
      "id" : 592182458,
      "verified" : false
    }
  },
  "id" : 480406549634887680,
  "created_at" : "2014-06-21 17:47:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Albert Einstein",
      "screen_name" : "AlbertE_Quotes",
      "indices" : [ 0, 15 ],
      "id_str" : "253004295",
      "id" : 253004295
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480387172814835712",
  "geo" : { },
  "id_str" : "480394730522435584",
  "in_reply_to_user_id" : 253004295,
  "text" : "@AlbertE_Quotes @CantrellTweets yet some ppl are sooo rational, reason based.. they are basically anti-fantasy or imagination.",
  "id" : 480394730522435584,
  "in_reply_to_status_id" : 480387172814835712,
  "created_at" : "2014-06-21 17:00:03 +0000",
  "in_reply_to_screen_name" : "AlbertE_Quotes",
  "in_reply_to_user_id_str" : "253004295",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 0, 15 ],
      "id_str" : "32435460",
      "id" : 32435460
    }, {
      "name" : "Mira",
      "screen_name" : "CartierBasha",
      "indices" : [ 16, 29 ],
      "id_str" : "2478211514",
      "id" : 2478211514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480393804520763393",
  "geo" : { },
  "id_str" : "480394142225149952",
  "in_reply_to_user_id" : 32435460,
  "text" : "@SpiritualNurse @CartierBasha now I'm dizzy..lol",
  "id" : 480394142225149952,
  "in_reply_to_status_id" : 480393804520763393,
  "created_at" : "2014-06-21 16:57:43 +0000",
  "in_reply_to_screen_name" : "SpiritualNurse",
  "in_reply_to_user_id_str" : "32435460",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480153964407562241",
  "text" : "RT @Emmanueldagher: Life is always here for you, cheering you on, wanting you to be happy. Always.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480150668909355009",
    "text" : "Life is always here for you, cheering you on, wanting you to be happy. Always.",
    "id" : 480150668909355009,
    "created_at" : "2014-06-21 00:50:14 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 480153964407562241,
  "created_at" : "2014-06-21 01:03:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "indices" : [ 3, 17 ],
      "id_str" : "195173057",
      "id" : 195173057
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lindapoitevin\/status\/480138264355934209\/photo\/1",
      "indices" : [ 54, 76 ],
      "url" : "http:\/\/t.co\/pJFctIHXB4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqnLNFbCQAM1Goa.jpg",
      "id_str" : "480138260945977347",
      "id" : 480138260945977347,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqnLNFbCQAM1Goa.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 841
      }, {
        "h" : 414,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/pJFctIHXB4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480143251404357634",
  "text" : "RT @lindapoitevin: Go ahead. Move him. I dare you. ;) http:\/\/t.co\/pJFctIHXB4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lindapoitevin\/status\/480138264355934209\/photo\/1",
        "indices" : [ 35, 57 ],
        "url" : "http:\/\/t.co\/pJFctIHXB4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqnLNFbCQAM1Goa.jpg",
        "id_str" : "480138260945977347",
        "id" : 480138260945977347,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqnLNFbCQAM1Goa.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 841
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 841
        }, {
          "h" : 414,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/pJFctIHXB4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480138264355934209",
    "text" : "Go ahead. Move him. I dare you. ;) http:\/\/t.co\/pJFctIHXB4",
    "id" : 480138264355934209,
    "created_at" : "2014-06-21 00:00:57 +0000",
    "user" : {
      "name" : "Linda Poitevin",
      "screen_name" : "lindapoitevin",
      "protected" : false,
      "id_str" : "195173057",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/653593067958571008\/PyqlHnTV_normal.jpg",
      "id" : 195173057,
      "verified" : false
    }
  },
  "id" : 480143251404357634,
  "created_at" : "2014-06-21 00:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00A1bote aqu\u00ED! \uD83D\uDEAE",
      "screen_name" : "sariweather",
      "indices" : [ 3, 15 ],
      "id_str" : "2169316567",
      "id" : 2169316567
    }, {
      "name" : "Simion Stefan",
      "screen_name" : "Simi131",
      "indices" : [ 17, 25 ],
      "id_str" : "762725655423356928",
      "id" : 762725655423356928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480126667197661184",
  "text" : "RT @sariweather: @Simi131 That's interesting. Because the entire town of Lawrenceville, VA fears the kids will bring DISEASE. http:\/\/t.co\/g\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Simion Stefan",
        "screen_name" : "Simi131",
        "indices" : [ 0, 8 ],
        "id_str" : "762725655423356928",
        "id" : 762725655423356928
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 131 ],
        "url" : "http:\/\/t.co\/gF1HY1uaFz",
        "expanded_url" : "http:\/\/n.pr\/1jEeNI3",
        "display_url" : "n.pr\/1jEeNI3"
      } ]
    },
    "geo" : { },
    "id_str" : "480123532899536896",
    "text" : "@Simi131 That's interesting. Because the entire town of Lawrenceville, VA fears the kids will bring DISEASE. http:\/\/t.co\/gF1HY1uaFz",
    "id" : 480123532899536896,
    "created_at" : "2014-06-20 23:02:25 +0000",
    "user" : {
      "name" : "\u00A1bote aqu\u00ED! \uD83D\uDEAE",
      "screen_name" : "sariweather",
      "protected" : false,
      "id_str" : "2169316567",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762695164418633728\/QVAe7ftE_normal.jpg",
      "id" : 2169316567,
      "verified" : false
    }
  },
  "id" : 480126667197661184,
  "created_at" : "2014-06-20 23:14:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u00A1bote aqu\u00ED! \uD83D\uDEAE",
      "screen_name" : "sariweather",
      "indices" : [ 2, 14 ],
      "id_str" : "2169316567",
      "id" : 2169316567
    }, {
      "name" : "Simion Stefan",
      "screen_name" : "Simi131",
      "indices" : [ 15, 23 ],
      "id_str" : "762725655423356928",
      "id" : 762725655423356928
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480123532899536896",
  "geo" : { },
  "id_str" : "480126615372849152",
  "in_reply_to_user_id" : 2169316567,
  "text" : ". @sariweather @Simi131 they'll be vaccinated, screened and guarded.. jeezus.. like a dystopian novel. WTF?",
  "id" : 480126615372849152,
  "in_reply_to_status_id" : 480123532899536896,
  "created_at" : "2014-06-20 23:14:40 +0000",
  "in_reply_to_screen_name" : "sariweather",
  "in_reply_to_user_id_str" : "2169316567",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin R Daugherty",
      "screen_name" : "KevinRDaugherty",
      "indices" : [ 74, 90 ],
      "id_str" : "792886005602877440",
      "id" : 792886005602877440
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/nC2zklewGh",
      "expanded_url" : "http:\/\/wp.me\/p2DqfA-xo",
      "display_url" : "wp.me\/p2DqfA-xo"
    } ]
  },
  "geo" : { },
  "id_str" : "480111133697662976",
  "text" : "Gay Marriage Is Not Against Biblical Authority http:\/\/t.co\/nC2zklewGh via @KevinRDaugherty",
  "id" : 480111133697662976,
  "created_at" : "2014-06-20 22:13:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kickstarter",
      "screen_name" : "kickstarter",
      "indices" : [ 69, 81 ],
      "id_str" : "16186995",
      "id" : 16186995
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 42, 64 ],
      "url" : "http:\/\/t.co\/tXFWBH4zh6",
      "expanded_url" : "http:\/\/kck.st\/S72nke",
      "display_url" : "kck.st\/S72nke"
    } ]
  },
  "geo" : { },
  "id_str" : "480110060782104577",
  "text" : "If I Were Enlightened by Donnalou Stevens http:\/\/t.co\/tXFWBH4zh6 via @kickstarter",
  "id" : 480110060782104577,
  "created_at" : "2014-06-20 22:08:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 59, 81 ],
      "url" : "http:\/\/t.co\/bwaYViQvji",
      "expanded_url" : "http:\/\/youtu.be\/O4QzHeUE-CM",
      "display_url" : "youtu.be\/O4QzHeUE-CM"
    } ]
  },
  "geo" : { },
  "id_str" : "480108643988164608",
  "text" : "This is good : ) ---&gt; Older Ladies by Donnalou Stevens: http:\/\/t.co\/bwaYViQvji",
  "id" : 480108643988164608,
  "created_at" : "2014-06-20 22:03:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "j clement wall",
      "screen_name" : "jclementwall",
      "indices" : [ 3, 16 ],
      "id_str" : "19427862",
      "id" : 19427862
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jclementwall\/status\/480079739382558720\/photo\/1",
      "indices" : [ 88, 110 ],
      "url" : "http:\/\/t.co\/hrBgmCa651",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmV-iFCYAA5bNF.jpg",
      "id_str" : "480079736824029184",
      "id" : 480079736824029184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmV-iFCYAA5bNF.jpg",
      "sizes" : [ {
        "h" : 704,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 704,
        "resize" : "fit",
        "w" : 1000
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 422,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 239,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/hrBgmCa651"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 87 ],
      "url" : "https:\/\/t.co\/8wMmldQdn7",
      "expanded_url" : "https:\/\/www.etsy.com\/listing\/193500909\/be-your-own-kind-of-pretty-art-card?ref=shop_home_feat_1",
      "display_url" : "etsy.com\/listing\/193500\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480106800214073344",
  "text" : "RT @jclementwall: Be Your Own Kind Of Pretty - new in the shop. https:\/\/t.co\/8wMmldQdn7 http:\/\/t.co\/hrBgmCa651",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jclementwall\/status\/480079739382558720\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/hrBgmCa651",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmV-iFCYAA5bNF.jpg",
        "id_str" : "480079736824029184",
        "id" : 480079736824029184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmV-iFCYAA5bNF.jpg",
        "sizes" : [ {
          "h" : 704,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 704,
          "resize" : "fit",
          "w" : 1000
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 422,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 239,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/hrBgmCa651"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 69 ],
        "url" : "https:\/\/t.co\/8wMmldQdn7",
        "expanded_url" : "https:\/\/www.etsy.com\/listing\/193500909\/be-your-own-kind-of-pretty-art-card?ref=shop_home_feat_1",
        "display_url" : "etsy.com\/listing\/193500\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480079739382558720",
    "text" : "Be Your Own Kind Of Pretty - new in the shop. https:\/\/t.co\/8wMmldQdn7 http:\/\/t.co\/hrBgmCa651",
    "id" : 480079739382558720,
    "created_at" : "2014-06-20 20:08:23 +0000",
    "user" : {
      "name" : "j clement wall",
      "screen_name" : "jclementwall",
      "protected" : false,
      "id_str" : "19427862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/631664673599807488\/6nd9doa9_normal.jpg",
      "id" : 19427862,
      "verified" : false
    }
  },
  "id" : 480106800214073344,
  "created_at" : "2014-06-20 21:55:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480102299226759169",
  "geo" : { },
  "id_str" : "480104015359791104",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem I'd love to see you on MasterChef : )",
  "id" : 480104015359791104,
  "in_reply_to_status_id" : 480102299226759169,
  "created_at" : "2014-06-20 21:44:51 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 87, 103 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 82 ],
      "url" : "http:\/\/t.co\/fGRy0WsNES",
      "expanded_url" : "http:\/\/ebookne.ws\/1qq8JrM",
      "display_url" : "ebookne.ws\/1qq8JrM"
    } ]
  },
  "geo" : { },
  "id_str" : "480096056739246081",
  "text" : "This Notebook Will Encourage You to Write Outside the Lines http:\/\/t.co\/fGRy0WsNES via @thdigitalreader",
  "id" : 480096056739246081,
  "created_at" : "2014-06-20 21:13:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 98 ],
      "url" : "http:\/\/t.co\/xXSQ20M7AL",
      "expanded_url" : "http:\/\/christianpundit.wordpress.com\/2014\/06\/20\/when-suits-become-a-stumbling-block-a-plea-to-my-brothers-in-christ-by-lp\/",
      "display_url" : "christianpundit.wordpress.com\/2014\/06\/20\/whe\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480095260794552321",
  "text" : "When Suits Become a Stumbling Block: A Plea to My Brothers in Christ* by LP http:\/\/t.co\/xXSQ20M7AL",
  "id" : 480095260794552321,
  "created_at" : "2014-06-20 21:10:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "indices" : [ 3, 13 ],
      "id_str" : "815384234",
      "id" : 815384234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/480079783876116484\/photo\/1",
      "indices" : [ 39, 61 ],
      "url" : "http:\/\/t.co\/rcruCvfQrM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmWBF3CUAAlDo5.jpg",
      "id_str" : "480079780788719616",
      "id" : 480079780788719616,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmWBF3CUAAlDo5.jpg",
      "sizes" : [ {
        "h" : 545,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 581,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 309,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/rcruCvfQrM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480080299070484481",
  "text" : "RT @CamoDave_: Need I say more lol :O) http:\/\/t.co\/rcruCvfQrM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CamoDave_\/status\/480079783876116484\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/rcruCvfQrM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmWBF3CUAAlDo5.jpg",
        "id_str" : "480079780788719616",
        "id" : 480079780788719616,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmWBF3CUAAlDo5.jpg",
        "sizes" : [ {
          "h" : 545,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 581,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 581,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 309,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/rcruCvfQrM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480079783876116484",
    "text" : "Need I say more lol :O) http:\/\/t.co\/rcruCvfQrM",
    "id" : 480079783876116484,
    "created_at" : "2014-06-20 20:08:34 +0000",
    "user" : {
      "name" : "Camo Dave",
      "screen_name" : "CamoDave_",
      "protected" : false,
      "id_str" : "815384234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/749321167102742528\/95l7jVHZ_normal.jpg",
      "id" : 815384234,
      "verified" : false
    }
  },
  "id" : 480080299070484481,
  "created_at" : "2014-06-20 20:10:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "indices" : [ 3, 12 ],
      "id_str" : "800652126",
      "id" : 800652126
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/480070945319563265\/photo\/1",
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/pIe6gc5tW3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmN-vSCIAAsiOB.jpg",
      "id_str" : "480070944275177472",
      "id" : 480070944275177472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmN-vSCIAAsiOB.jpg",
      "sizes" : [ {
        "h" : 269,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 573,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 152,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/pIe6gc5tW3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480073611068207104",
  "text" : "RT @MrRat395: Hey human; fill up the feeder!!! http:\/\/t.co\/pIe6gc5tW3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/MrRat395\/status\/480070945319563265\/photo\/1",
        "indices" : [ 33, 55 ],
        "url" : "http:\/\/t.co\/pIe6gc5tW3",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmN-vSCIAAsiOB.jpg",
        "id_str" : "480070944275177472",
        "id" : 480070944275177472,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmN-vSCIAAsiOB.jpg",
        "sizes" : [ {
          "h" : 269,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 573,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 152,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/pIe6gc5tW3"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480070945319563265",
    "text" : "Hey human; fill up the feeder!!! http:\/\/t.co\/pIe6gc5tW3",
    "id" : 480070945319563265,
    "created_at" : "2014-06-20 19:33:27 +0000",
    "user" : {
      "name" : "Squeak!",
      "screen_name" : "MrRat395",
      "protected" : false,
      "id_str" : "800652126",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/779503692802240512\/iVwM-mwl_normal.jpg",
      "id" : 800652126,
      "verified" : false
    }
  },
  "id" : 480073611068207104,
  "created_at" : "2014-06-20 19:44:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480073023131615233",
  "text" : "saw a big woodchuck in yard. poor thing got tackled by dog but made it into bushes.",
  "id" : 480073023131615233,
  "created_at" : "2014-06-20 19:41:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "indices" : [ 3, 12 ],
      "id_str" : "1316959200",
      "id" : 1316959200
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/480060372821749760\/photo\/1",
      "indices" : [ 14, 36 ],
      "url" : "http:\/\/t.co\/vnKXYupvt2",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmEXMCCEAEtRD5.jpg",
      "id_str" : "480060369193275393",
      "id" : 480060369193275393,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmEXMCCEAEtRD5.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 478,
        "resize" : "fit",
        "w" : 640
      } ],
      "display_url" : "pic.twitter.com\/vnKXYupvt2"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480063591408619520",
  "text" : "RT @zacaplus: http:\/\/t.co\/vnKXYupvt2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/zacaplus\/status\/480060372821749760\/photo\/1",
        "indices" : [ 0, 22 ],
        "url" : "http:\/\/t.co\/vnKXYupvt2",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqmEXMCCEAEtRD5.jpg",
        "id_str" : "480060369193275393",
        "id" : 480060369193275393,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqmEXMCCEAEtRD5.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 478,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/vnKXYupvt2"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480060372821749760",
    "text" : "http:\/\/t.co\/vnKXYupvt2",
    "id" : 480060372821749760,
    "created_at" : "2014-06-20 18:51:26 +0000",
    "user" : {
      "name" : "KaZa\uD83C\uDF1FFoToS",
      "screen_name" : "zacaplus",
      "protected" : false,
      "id_str" : "1316959200",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/711110597593702400\/FL6-Tb30_normal.jpg",
      "id" : 1316959200,
      "verified" : false
    }
  },
  "id" : 480063591408619520,
  "created_at" : "2014-06-20 19:04:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "`Joshua",
      "screen_name" : "JoshuaTongol",
      "indices" : [ 3, 16 ],
      "id_str" : "353049578",
      "id" : 353049578
    }, {
      "name" : "The Truth",
      "screen_name" : "truth",
      "indices" : [ 126, 132 ],
      "id_str" : "3315264553",
      "id" : 3315264553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "questions",
      "indices" : [ 115, 125 ]
    } ],
    "urls" : [ {
      "indices" : [ 91, 114 ],
      "url" : "https:\/\/t.co\/AKNkQTHOPi",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pukHQh1mEHI",
      "display_url" : "youtube.com\/watch?v=pukHQh\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480062126346629120",
  "text" : "RT @JoshuaTongol: Check this out! \"IF YOU'RE RELIGIOUS, THIS MIGHT MAKE YOU UNCOMFORTABLE\" https:\/\/t.co\/AKNkQTHOPi #questions @truth #rethi\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The Truth",
        "screen_name" : "truth",
        "indices" : [ 108, 114 ],
        "id_str" : "3315264553",
        "id" : 3315264553
      }, {
        "name" : "religion",
        "screen_name" : "religion",
        "indices" : [ 124, 133 ],
        "id_str" : "3857411",
        "id" : 3857411
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "questions",
        "indices" : [ 97, 107 ]
      }, {
        "text" : "rethink",
        "indices" : [ 115, 123 ]
      }, {
        "text" : "love",
        "indices" : [ 134, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 73, 96 ],
        "url" : "https:\/\/t.co\/AKNkQTHOPi",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=pukHQh1mEHI",
        "display_url" : "youtube.com\/watch?v=pukHQh\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480061223468146688",
    "text" : "Check this out! \"IF YOU'RE RELIGIOUS, THIS MIGHT MAKE YOU UNCOMFORTABLE\" https:\/\/t.co\/AKNkQTHOPi #questions @truth #rethink @religion #love",
    "id" : 480061223468146688,
    "created_at" : "2014-06-20 18:54:49 +0000",
    "user" : {
      "name" : "`Joshua",
      "screen_name" : "JoshuaTongol",
      "protected" : false,
      "id_str" : "353049578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/443510403192983553\/YGTApjCv_normal.jpeg",
      "id" : 353049578,
      "verified" : false
    }
  },
  "id" : 480062126346629120,
  "created_at" : "2014-06-20 18:58:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 31, 53 ],
      "url" : "http:\/\/t.co\/HDtADrJrbB",
      "expanded_url" : "http:\/\/www.preposterousuniverse.com\/blog\/2014\/06\/20\/quantum-mechanics-in-your-face\/",
      "display_url" : "preposterousuniverse.com\/blog\/2014\/06\/2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480058189472215040",
  "text" : "Quantum Mechanics In Your Face http:\/\/t.co\/HDtADrJrbB",
  "id" : 480058189472215040,
  "created_at" : "2014-06-20 18:42:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "indices" : [ 3, 17 ],
      "id_str" : "27392088",
      "id" : 27392088
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 119, 141 ],
      "url" : "http:\/\/t.co\/kD1ETweAqR",
      "expanded_url" : "http:\/\/www.nbcnews.com\/news\/us-news\/presbyterian-church-leaders-declare-gay-marriage-christian-n136256",
      "display_url" : "nbcnews.com\/news\/us-news\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480055258018619393",
  "text" : "RT @ChristianDems: This is big news today &gt;&gt;&gt; \"Presbyterian Church Leaders Declare Gay Marriage Is Christian\" http:\/\/t.co\/kD1ETweAqR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/kD1ETweAqR",
        "expanded_url" : "http:\/\/www.nbcnews.com\/news\/us-news\/presbyterian-church-leaders-declare-gay-marriage-christian-n136256",
        "display_url" : "nbcnews.com\/news\/us-news\/p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480054405971320832",
    "text" : "This is big news today &gt;&gt;&gt; \"Presbyterian Church Leaders Declare Gay Marriage Is Christian\" http:\/\/t.co\/kD1ETweAqR",
    "id" : 480054405971320832,
    "created_at" : "2014-06-20 18:27:44 +0000",
    "user" : {
      "name" : "Christian Democrats",
      "screen_name" : "ChristianDems",
      "protected" : false,
      "id_str" : "27392088",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/601174572801531904\/R4SVPPIs_normal.png",
      "id" : 27392088,
      "verified" : false
    }
  },
  "id" : 480055258018619393,
  "created_at" : "2014-06-20 18:31:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The QI Elves",
      "screen_name" : "qikipedia",
      "indices" : [ 3, 13 ],
      "id_str" : "22151193",
      "id" : 22151193
    } ],
    "media" : [ {
      "expanded_url" : "http:\/\/twitter.com\/qikipedia\/status\/479675085612408832\/photo\/1",
      "indices" : [ 74, 96 ],
      "url" : "http:\/\/t.co\/1htBFFn5an",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqgl8hcCAAAByp9.jpg",
      "id_str" : "479675082013278208",
      "id" : 479675082013278208,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqgl8hcCAAAByp9.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 900
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 900
      } ],
      "display_url" : "pic.twitter.com\/1htBFFn5an"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480054916270940161",
  "text" : "RT @qikipedia: Crescent Venus and crescent Moon\u2026 (Image: NASA, Iv\u00E1n \u00C9der) http:\/\/t.co\/1htBFFn5an",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "http:\/\/twitter.com\/qikipedia\/status\/479675085612408832\/photo\/1",
        "indices" : [ 59, 81 ],
        "url" : "http:\/\/t.co\/1htBFFn5an",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqgl8hcCAAAByp9.jpg",
        "id_str" : "479675082013278208",
        "id" : 479675082013278208,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqgl8hcCAAAByp9.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 900
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 900
        } ],
        "display_url" : "pic.twitter.com\/1htBFFn5an"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479675085612408832",
    "text" : "Crescent Venus and crescent Moon\u2026 (Image: NASA, Iv\u00E1n \u00C9der) http:\/\/t.co\/1htBFFn5an",
    "id" : 479675085612408832,
    "created_at" : "2014-06-19 17:20:27 +0000",
    "user" : {
      "name" : "The QI Elves",
      "screen_name" : "qikipedia",
      "protected" : false,
      "id_str" : "22151193",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/549435855962513408\/RAEeXuVF_normal.png",
      "id" : 22151193,
      "verified" : true
    }
  },
  "id" : 480054916270940161,
  "created_at" : "2014-06-20 18:29:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480052935884562432",
  "geo" : { },
  "id_str" : "480054761509502976",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni ohhh.. hate when that happens! such a tease!",
  "id" : 480054761509502976,
  "in_reply_to_status_id" : 480052935884562432,
  "created_at" : "2014-06-20 18:29:08 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "indices" : [ 3, 19 ],
      "id_str" : "191110048",
      "id" : 191110048
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 92 ],
      "url" : "http:\/\/t.co\/UtTvqls28x",
      "expanded_url" : "http:\/\/www.sciencethrillers.com\/2014\/vote-on-title-for-my-next-science-thriller-novel\/",
      "display_url" : "sciencethrillers.com\/2014\/vote-on-t\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480054086947983360",
  "text" : "RT @ScienceThriller: Vote on title for my next science thriller novel http:\/\/t.co\/UtTvqls28x",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/UtTvqls28x",
        "expanded_url" : "http:\/\/www.sciencethrillers.com\/2014\/vote-on-title-for-my-next-science-thriller-novel\/",
        "display_url" : "sciencethrillers.com\/2014\/vote-on-t\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480053253061627905",
    "text" : "Vote on title for my next science thriller novel http:\/\/t.co\/UtTvqls28x",
    "id" : 480053253061627905,
    "created_at" : "2014-06-20 18:23:09 +0000",
    "user" : {
      "name" : "Amy Rogers",
      "screen_name" : "ScienceThriller",
      "protected" : false,
      "id_str" : "191110048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509554102632587264\/zmyDrP9j_normal.jpeg",
      "id" : 191110048,
      "verified" : false
    }
  },
  "id" : 480054086947983360,
  "created_at" : "2014-06-20 18:26:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Raven Luni",
      "screen_name" : "Raven_Luni",
      "indices" : [ 0, 11 ],
      "id_str" : "264530860",
      "id" : 264530860
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480053775437008897",
  "in_reply_to_user_id" : 264530860,
  "text" : "@Raven_Luni isnt that an awesome photo? i love swans.",
  "id" : 480053775437008897,
  "created_at" : "2014-06-20 18:25:13 +0000",
  "in_reply_to_screen_name" : "Raven_Luni",
  "in_reply_to_user_id_str" : "264530860",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480053472469872640",
  "text" : "@Tabayel2 looking at systemic theology on amazon. looks interesting.",
  "id" : 480053472469872640,
  "created_at" : "2014-06-20 18:24:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480052614751473664",
  "text" : "oh Twitter.. the feels, the feels. you twist me round and round!",
  "id" : 480052614751473664,
  "created_at" : "2014-06-20 18:20:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480051349778726913",
  "geo" : { },
  "id_str" : "480051917616197633",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre well, then...lol",
  "id" : 480051917616197633,
  "in_reply_to_status_id" : 480051349778726913,
  "created_at" : "2014-06-20 18:17:50 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480048289555836931",
  "geo" : { },
  "id_str" : "480050658070913024",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino @Tabayel2 Thank you Hillary.",
  "id" : 480050658070913024,
  "in_reply_to_status_id" : 480048289555836931,
  "created_at" : "2014-06-20 18:12:50 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "indices" : [ 3, 12 ],
      "id_str" : "215045056",
      "id" : 215045056
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480049788457480193",
  "text" : "RT @Pandeism: Live your life for yourself, but recognize it as a self which impacts the lives of others.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480048051084873728",
    "text" : "Live your life for yourself, but recognize it as a self which impacts the lives of others.",
    "id" : 480048051084873728,
    "created_at" : "2014-06-20 18:02:28 +0000",
    "user" : {
      "name" : "Pandeism = Love All",
      "screen_name" : "Pandeism",
      "protected" : false,
      "id_str" : "215045056",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1541969322\/Wave_normal.gif",
      "id" : 215045056,
      "verified" : false
    }
  },
  "id" : 480049788457480193,
  "created_at" : "2014-06-20 18:09:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "indices" : [ 3, 13 ],
      "id_str" : "75137401",
      "id" : 75137401
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 78, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480049715401064448",
  "text" : "RT @JALpalyul: What you see and hear is simply how your karma is playing out. #quote JAL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 63, 69 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480048462575468545",
    "text" : "What you see and hear is simply how your karma is playing out. #quote JAL",
    "id" : 480048462575468545,
    "created_at" : "2014-06-20 18:04:07 +0000",
    "user" : {
      "name" : "Jetsunma Ahkon Lhamo",
      "screen_name" : "JALpalyul",
      "protected" : false,
      "id_str" : "75137401",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/622951821552799744\/1S95Jwl__normal.jpg",
      "id" : 75137401,
      "verified" : false
    }
  },
  "id" : 480049715401064448,
  "created_at" : "2014-06-20 18:09:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480049590729596929",
  "text" : "@Lluminous_ ho",
  "id" : 480049590729596929,
  "created_at" : "2014-06-20 18:08:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "indices" : [ 3, 15 ],
      "id_str" : "409492415",
      "id" : 409492415
    }, {
      "name" : "Chou Chou Scantlin",
      "screen_name" : "docscantlin",
      "indices" : [ 17, 29 ],
      "id_str" : "559512879",
      "id" : 559512879
    }, {
      "name" : "Susan M",
      "screen_name" : "_Susan_M_",
      "indices" : [ 30, 40 ],
      "id_str" : "320741012",
      "id" : 320741012
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/479236037496299520\/photo\/1",
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/1feSlQVe5F",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqaWoqYCQAEixC1.jpg",
      "id_str" : "479236035675570177",
      "id" : 479236035675570177,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqaWoqYCQAEixC1.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 685,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1370,
        "resize" : "fit",
        "w" : 2048
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/1feSlQVe5F"
    } ],
    "hashtags" : [ {
      "text" : "PondSecrets",
      "indices" : [ 74, 86 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480048022680662017",
  "text" : "RT @Coyotetooth: @docscantlin @_Susan_M_  Learning to make water hearts.  #PondSecrets http:\/\/t.co\/1feSlQVe5F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chou Chou Scantlin",
        "screen_name" : "docscantlin",
        "indices" : [ 0, 12 ],
        "id_str" : "559512879",
        "id" : 559512879
      }, {
        "name" : "Susan M",
        "screen_name" : "_Susan_M_",
        "indices" : [ 13, 23 ],
        "id_str" : "320741012",
        "id" : 320741012
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Coyotetooth\/status\/479236037496299520\/photo\/1",
        "indices" : [ 70, 92 ],
        "url" : "http:\/\/t.co\/1feSlQVe5F",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqaWoqYCQAEixC1.jpg",
        "id_str" : "479236035675570177",
        "id" : 479236035675570177,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqaWoqYCQAEixC1.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 685,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1370,
          "resize" : "fit",
          "w" : 2048
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/1feSlQVe5F"
      } ],
      "hashtags" : [ {
        "text" : "PondSecrets",
        "indices" : [ 57, 69 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "479195456237744128",
    "geo" : { },
    "id_str" : "479236037496299520",
    "in_reply_to_user_id" : 559512879,
    "text" : "@docscantlin @_Susan_M_  Learning to make water hearts.  #PondSecrets http:\/\/t.co\/1feSlQVe5F",
    "id" : 479236037496299520,
    "in_reply_to_status_id" : 479195456237744128,
    "created_at" : "2014-06-18 12:15:49 +0000",
    "in_reply_to_screen_name" : "docscantlin",
    "in_reply_to_user_id_str" : "559512879",
    "user" : {
      "name" : "Stefano  Anders",
      "screen_name" : "Coyotetooth",
      "protected" : false,
      "id_str" : "409492415",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502871900054642688\/RlK3naNt_normal.jpeg",
      "id" : 409492415,
      "verified" : false
    }
  },
  "id" : 480048022680662017,
  "created_at" : "2014-06-20 18:02:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480047148906463232",
  "text" : "I was very blessed as a kid. I could wonder and ask. I was taken to the library and given books. I did the same w my daughter.",
  "id" : 480047148906463232,
  "created_at" : "2014-06-20 17:58:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alicia Brockett",
      "screen_name" : "Whitsonypu",
      "indices" : [ 3, 14 ],
      "id_str" : "391396304",
      "id" : 391396304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480046429713342465",
  "text" : "RT @Whitsonypu: Worrying won't stop the bad stuff from happening it just stops you from enjoying the good.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M2)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480045568341721089",
    "text" : "Worrying won't stop the bad stuff from happening it just stops you from enjoying the good.",
    "id" : 480045568341721089,
    "created_at" : "2014-06-20 17:52:36 +0000",
    "user" : {
      "name" : "Alicia Brockett",
      "screen_name" : "Whitsonypu",
      "protected" : false,
      "id_str" : "391396304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000633082395\/a789b3dd804cd414f9a914b1664a4040_normal.png",
      "id" : 391396304,
      "verified" : false
    }
  },
  "id" : 480046429713342465,
  "created_at" : "2014-06-20 17:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glen E. Ivey",
      "screen_name" : "gleneivey",
      "indices" : [ 3, 13 ],
      "id_str" : "3083114561",
      "id" : 3083114561
    }, {
      "name" : "lisacrispin",
      "screen_name" : "lisacrispin",
      "indices" : [ 15, 27 ],
      "id_str" : "15171615",
      "id" : 15171615
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480045813402324994",
  "text" : "RT @gleneivey: @lisacrispin I've reached the point where I label anyone who gets out of bed every morning as an \"optimist.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "lisacrispin",
        "screen_name" : "lisacrispin",
        "indices" : [ 0, 12 ],
        "id_str" : "15171615",
        "id" : 15171615
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "480028447079530496",
    "geo" : { },
    "id_str" : "480044090671648769",
    "in_reply_to_user_id" : 15171615,
    "text" : "@lisacrispin I've reached the point where I label anyone who gets out of bed every morning as an \"optimist.\"",
    "id" : 480044090671648769,
    "in_reply_to_status_id" : 480028447079530496,
    "created_at" : "2014-06-20 17:46:44 +0000",
    "in_reply_to_screen_name" : "lisacrispin",
    "in_reply_to_user_id_str" : "15171615",
    "user" : {
      "name" : "Glen E. Ivey",
      "screen_name" : "dotglen",
      "protected" : false,
      "id_str" : "995051",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800932804150235136\/YvOXCpR8_normal.jpg",
      "id" : 995051,
      "verified" : false
    }
  },
  "id" : 480045813402324994,
  "created_at" : "2014-06-20 17:53:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480044354791149569",
  "text" : "@Tabayel2 i certainly hope yr feeling better!",
  "id" : 480044354791149569,
  "created_at" : "2014-06-20 17:47:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "WattsWednesday",
      "indices" : [ 103, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480043397512572928",
  "text" : "RT @ResetME_: \"The meaning of life is just to be alive.   It's so plain and so obvious and so simple.\" #WattsWednesday http:\/\/t.co\/Sul3xZYB\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ResetME_\/status\/479257140339560448\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/Sul3xZYBF9",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqap1AVCYAAKX-Y.jpg",
        "id_str" : "479257138447933440",
        "id" : 479257138447933440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqap1AVCYAAKX-Y.jpg",
        "sizes" : [ {
          "h" : 402,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 228,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 493,
          "resize" : "fit",
          "w" : 736
        } ],
        "display_url" : "pic.twitter.com\/Sul3xZYBF9"
      } ],
      "hashtags" : [ {
        "text" : "WattsWednesday",
        "indices" : [ 89, 104 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479257140339560448",
    "text" : "\"The meaning of life is just to be alive.   It's so plain and so obvious and so simple.\" #WattsWednesday http:\/\/t.co\/Sul3xZYBF9",
    "id" : 479257140339560448,
    "created_at" : "2014-06-18 13:39:41 +0000",
    "user" : {
      "name" : "Reset.Me",
      "screen_name" : "resetmenews",
      "protected" : false,
      "id_str" : "2275532738",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/453615229360828417\/EKBb-Ryy_normal.jpeg",
      "id" : 2275532738,
      "verified" : false
    }
  },
  "id" : 480043397512572928,
  "created_at" : "2014-06-20 17:43:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480043146697396224",
  "text" : "@Tabayel2  thank you for yr kindness. dont feel bad. its not you. think i hit buttons unintentionally w her.",
  "id" : 480043146697396224,
  "created_at" : "2014-06-20 17:42:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480042767528108033",
  "text" : "@Tabayel2 amazing how we can connect at such levels online, isnt it? she needs to do whats best for her. i'll bounce back..",
  "id" : 480042767528108033,
  "created_at" : "2014-06-20 17:41:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "imblocked",
      "indices" : [ 81, 91 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480041604833480704",
  "text" : "she reminds me so much of my DD which I suppose is why its so upsetting to me... #imblocked",
  "id" : 480041604833480704,
  "created_at" : "2014-06-20 17:36:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480038251722313730",
  "geo" : { },
  "id_str" : "480039271072415745",
  "in_reply_to_user_id" : 1371275868,
  "text" : "@CantrellTweets i never realized how much religious abuse is out there. just never occured to me. understand now that god = pain to many.",
  "id" : 480039271072415745,
  "in_reply_to_status_id" : 480038251722313730,
  "created_at" : "2014-06-20 17:27:35 +0000",
  "in_reply_to_screen_name" : "AngstHill",
  "in_reply_to_user_id_str" : "1371275868",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480038513799204865",
  "text" : "sometimes its hard to be me... sigh.",
  "id" : 480038513799204865,
  "created_at" : "2014-06-20 17:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480037970833985536",
  "text" : "i have to remember its not about me. i try to be positive in my conversations. to not be righteous or demeaning. try to encourage.",
  "id" : 480037970833985536,
  "created_at" : "2014-06-20 17:22:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480036218168553473",
  "geo" : { },
  "id_str" : "480037532160106496",
  "in_reply_to_user_id" : 93747129,
  "text" : "@cosmicaudino ps. good luck with yr booth!",
  "id" : 480037532160106496,
  "in_reply_to_status_id" : 480036218168553473,
  "created_at" : "2014-06-20 17:20:40 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "indices" : [ 3, 15 ],
      "id_str" : "18761076",
      "id" : 18761076
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 118 ],
      "url" : "http:\/\/t.co\/vfNUkMUNzf",
      "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/PS+Vita\/Pavilion\/video.asp?c=60195",
      "display_url" : "pocketgamer.co.uk\/r\/PS+Vita\/Pavi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480037249392721920",
  "text" : "RT @PocketGamer: Here's an extended look at the magical, twisted world of Pavilion on PS Vita - http:\/\/t.co\/vfNUkMUNzf http:\/\/t.co\/ZdyGyor0\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PocketGamer\/status\/480036941396975616\/photo\/1",
        "indices" : [ 102, 124 ],
        "url" : "http:\/\/t.co\/ZdyGyor0G5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqlvDcvCIAAsOrb.jpg",
        "id_str" : "480036940335423488",
        "id" : 480036940335423488,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqlvDcvCIAAsOrb.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 700,
          "resize" : "fit",
          "w" : 1400
        }, {
          "h" : 512,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 300,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 170,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/ZdyGyor0G5"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 79, 101 ],
        "url" : "http:\/\/t.co\/vfNUkMUNzf",
        "expanded_url" : "http:\/\/www.pocketgamer.co.uk\/r\/PS+Vita\/Pavilion\/video.asp?c=60195",
        "display_url" : "pocketgamer.co.uk\/r\/PS+Vita\/Pavi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "480036941396975616",
    "text" : "Here's an extended look at the magical, twisted world of Pavilion on PS Vita - http:\/\/t.co\/vfNUkMUNzf http:\/\/t.co\/ZdyGyor0G5",
    "id" : 480036941396975616,
    "created_at" : "2014-06-20 17:18:20 +0000",
    "user" : {
      "name" : "Pocket Gamer",
      "screen_name" : "PocketGamer",
      "protected" : false,
      "id_str" : "18761076",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/479184281449660417\/JEbx7R5G_normal.jpeg",
      "id" : 18761076,
      "verified" : false
    }
  },
  "id" : 480037249392721920,
  "created_at" : "2014-06-20 17:19:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480036168898068480",
  "geo" : { },
  "id_str" : "480037126172459011",
  "in_reply_to_user_id" : 1371275868,
  "text" : "@CantrellTweets ((hug)) thank you.",
  "id" : 480037126172459011,
  "in_reply_to_status_id" : 480036168898068480,
  "created_at" : "2014-06-20 17:19:04 +0000",
  "in_reply_to_screen_name" : "AngstHill",
  "in_reply_to_user_id_str" : "1371275868",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480036338826498048",
  "geo" : { },
  "id_str" : "480036720583266304",
  "in_reply_to_user_id" : 1371275868,
  "text" : "@CantrellTweets no, no. dont blame yrself. i just get attached to ppl. i still like Hillary very much. i know she's had it tough.",
  "id" : 480036720583266304,
  "in_reply_to_status_id" : 480036338826498048,
  "created_at" : "2014-06-20 17:17:27 +0000",
  "in_reply_to_screen_name" : "AngstHill",
  "in_reply_to_user_id_str" : "1371275868",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480035632316563457",
  "geo" : { },
  "id_str" : "480036218168553473",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino i dont recall you ever being mean to me? and very wise to associate with uplifting ppl, avoid negative, upsetting.",
  "id" : 480036218168553473,
  "in_reply_to_status_id" : 480035632316563457,
  "created_at" : "2014-06-20 17:15:27 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480035843462004736",
  "text" : "anyone care to give me a hug? im feeling weepy. damn hormones!",
  "id" : 480035843462004736,
  "created_at" : "2014-06-20 17:13:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480035605603053568",
  "text" : "twitter needs an unlike button. i am so sad. : (",
  "id" : 480035605603053568,
  "created_at" : "2014-06-20 17:13:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480034910296481792",
  "geo" : { },
  "id_str" : "480035386492600320",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino makes me sad as I enjoy yr company. take care, hun.",
  "id" : 480035386492600320,
  "in_reply_to_status_id" : 480034910296481792,
  "created_at" : "2014-06-20 17:12:09 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480034293595389952",
  "geo" : { },
  "id_str" : "480035074801295361",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino im sorry if my tweets or comments are upsetting. never my intention. do what you need to. ((hugs))",
  "id" : 480035074801295361,
  "in_reply_to_status_id" : 480034293595389952,
  "created_at" : "2014-06-20 17:10:55 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480034293595389952",
  "geo" : { },
  "id_str" : "480034805887692800",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino well, you could just unfollow me. why block? (now i feel kinda dirty) @Tabayel",
  "id" : 480034805887692800,
  "in_reply_to_status_id" : 480034293595389952,
  "created_at" : "2014-06-20 17:09:51 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480033194209583104",
  "geo" : { },
  "id_str" : "480034428979146753",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino there is more to this world going on than what we can see. @Tabayel",
  "id" : 480034428979146753,
  "in_reply_to_status_id" : 480033194209583104,
  "created_at" : "2014-06-20 17:08:21 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480032267155165184",
  "geo" : { },
  "id_str" : "480033841801740288",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino remember I RT'd that. ; ) now yr getting testy with --&gt; @Tabayel who's wondering WTH?",
  "id" : 480033841801740288,
  "in_reply_to_status_id" : 480032267155165184,
  "created_at" : "2014-06-20 17:06:01 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480031779726700544",
  "geo" : { },
  "id_str" : "480033506228072448",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino how can God be measured when God is the ultimate \"thing\" of which where all other things come from? @Tabayel",
  "id" : 480033506228072448,
  "in_reply_to_status_id" : 480031779726700544,
  "created_at" : "2014-06-20 17:04:41 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480027036971311104",
  "geo" : { },
  "id_str" : "480032815887552512",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino @Tabayel in a debate, yes, a copout (cop out?) but as a point of view, no.",
  "id" : 480032815887552512,
  "in_reply_to_status_id" : 480027036971311104,
  "created_at" : "2014-06-20 17:01:56 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "indices" : [ 3, 19 ],
      "id_str" : "15615511",
      "id" : 15615511
    }, {
      "name" : "Pamela Belding",
      "screen_name" : "pambelding",
      "indices" : [ 31, 42 ],
      "id_str" : "41792500",
      "id" : 41792500
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lisarobbinyoung\/status\/480026498057785345\/photo\/1",
      "indices" : [ 109, 131 ],
      "url" : "http:\/\/t.co\/FtHsVLAeHw",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqlljlECAAAfG6I.jpg",
      "id_str" : "480026497210515456",
      "id" : 480026497210515456,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqlljlECAAAfG6I.jpg",
      "sizes" : [ {
        "h" : 318,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 450
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 318,
        "resize" : "fit",
        "w" : 450
      } ],
      "display_url" : "pic.twitter.com\/FtHsVLAeHw"
    } ],
    "hashtags" : [ {
      "text" : "ownyourdreams",
      "indices" : [ 94, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480026779394916352",
  "text" : "RT @lisarobbinyoung: My friend @pambelding shared this with me today. Attitude is a decision. #ownyourdreams http:\/\/t.co\/FtHsVLAeHw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pamela Belding",
        "screen_name" : "pambelding",
        "indices" : [ 10, 21 ],
        "id_str" : "41792500",
        "id" : 41792500
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lisarobbinyoung\/status\/480026498057785345\/photo\/1",
        "indices" : [ 88, 110 ],
        "url" : "http:\/\/t.co\/FtHsVLAeHw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqlljlECAAAfG6I.jpg",
        "id_str" : "480026497210515456",
        "id" : 480026497210515456,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqlljlECAAAfG6I.jpg",
        "sizes" : [ {
          "h" : 318,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 450
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 318,
          "resize" : "fit",
          "w" : 450
        } ],
        "display_url" : "pic.twitter.com\/FtHsVLAeHw"
      } ],
      "hashtags" : [ {
        "text" : "ownyourdreams",
        "indices" : [ 73, 87 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480026498057785345",
    "text" : "My friend @pambelding shared this with me today. Attitude is a decision. #ownyourdreams http:\/\/t.co\/FtHsVLAeHw",
    "id" : 480026498057785345,
    "created_at" : "2014-06-20 16:36:50 +0000",
    "user" : {
      "name" : "Lisa Robbin Young",
      "screen_name" : "lisarobbinyoung",
      "protected" : false,
      "id_str" : "15615511",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/627643170231226368\/HrmGYgZN_normal.png",
      "id" : 15615511,
      "verified" : false
    }
  },
  "id" : 480026779394916352,
  "created_at" : "2014-06-20 16:37:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480014689250705408",
  "geo" : { },
  "id_str" : "480024872119066624",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre nice to know i'm not alone. happens to me, too. I blame it on the female hormones..lol",
  "id" : 480024872119066624,
  "in_reply_to_status_id" : 480014689250705408,
  "created_at" : "2014-06-20 16:30:22 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480022797683417089",
  "text" : ". @weakSquare but what if the advisors are not wise themselves??",
  "id" : 480022797683417089,
  "created_at" : "2014-06-20 16:22:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Croft",
      "screen_name" : "JennACroft",
      "indices" : [ 3, 14 ],
      "id_str" : "108327235",
      "id" : 108327235
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/JennACroft\/status\/479719579418365952\/photo\/1",
      "indices" : [ 68, 90 ],
      "url" : "http:\/\/t.co\/BGFmRHSjp8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqhOagZCAAA3rNs.jpg",
      "id_str" : "479719577593446400",
      "id" : 479719577593446400,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqhOagZCAAA3rNs.jpg",
      "sizes" : [ {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 428,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 731,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 243,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/BGFmRHSjp8"
    } ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 50, 57 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 58, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480022515067412481",
  "text" : "RT @JennACroft: Helping himself to the bird seed! #nature #wildlife http:\/\/t.co\/BGFmRHSjp8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JennACroft\/status\/479719579418365952\/photo\/1",
        "indices" : [ 52, 74 ],
        "url" : "http:\/\/t.co\/BGFmRHSjp8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqhOagZCAAA3rNs.jpg",
        "id_str" : "479719577593446400",
        "id" : 479719577593446400,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqhOagZCAAA3rNs.jpg",
        "sizes" : [ {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 428,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 731,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 243,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/BGFmRHSjp8"
      } ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 34, 41 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 42, 51 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479719579418365952",
    "text" : "Helping himself to the bird seed! #nature #wildlife http:\/\/t.co\/BGFmRHSjp8",
    "id" : 479719579418365952,
    "created_at" : "2014-06-19 20:17:15 +0000",
    "user" : {
      "name" : "Jennifer Croft",
      "screen_name" : "JennACroft",
      "protected" : false,
      "id_str" : "108327235",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666293974190149632\/DiXNeAPy_normal.jpg",
      "id" : 108327235,
      "verified" : false
    }
  },
  "id" : 480022515067412481,
  "created_at" : "2014-06-20 16:21:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480020754260844544",
  "geo" : { },
  "id_str" : "480021878854021121",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt i sent my address via msg the holy heretic page on FB.",
  "id" : 480021878854021121,
  "in_reply_to_status_id" : 480020754260844544,
  "created_at" : "2014-06-20 16:18:28 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480019741210210304",
  "geo" : { },
  "id_str" : "480021608241717248",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem just wanted to clarify that.",
  "id" : 480021608241717248,
  "in_reply_to_status_id" : 480019741210210304,
  "created_at" : "2014-06-20 16:17:24 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480019741210210304",
  "geo" : { },
  "id_str" : "480021522904383488",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem when i say karma.. im referring to cause\/effect; not good\/bad. our souls evolve (change) according to our thoughts\/actions",
  "id" : 480021522904383488,
  "in_reply_to_status_id" : 480019741210210304,
  "created_at" : "2014-06-20 16:17:04 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 0, 13 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480017310372331520",
  "geo" : { },
  "id_str" : "480020569870446593",
  "in_reply_to_user_id" : 15364301,
  "text" : "@BrianMerritt did you get my msg on facebook about this?",
  "id" : 480020569870446593,
  "in_reply_to_status_id" : 480017310372331520,
  "created_at" : "2014-06-20 16:13:16 +0000",
  "in_reply_to_screen_name" : "BrianMerritt",
  "in_reply_to_user_id_str" : "15364301",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "indices" : [ 3, 18 ],
      "id_str" : "105049016",
      "id" : 105049016
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480019954641543168",
  "text" : "RT @richarddoetsch: Imagine if children didn't have to overcome their childhood... ?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetadder.com\" rel=\"nofollow\"\u003ETweetAdder v4\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480019360648404992",
    "text" : "Imagine if children didn't have to overcome their childhood... ?",
    "id" : 480019360648404992,
    "created_at" : "2014-06-20 16:08:28 +0000",
    "user" : {
      "name" : "richard doetsch",
      "screen_name" : "richarddoetsch",
      "protected" : false,
      "id_str" : "105049016",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/753607357654007809\/m5nPodBc_normal.jpg",
      "id" : 105049016,
      "verified" : false
    }
  },
  "id" : 480019954641543168,
  "created_at" : "2014-06-20 16:10:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480016908851224578",
  "geo" : { },
  "id_str" : "480018623520456706",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem no, it doesn't change that fact. but forgiveness is more about releasing yourself from that pain.",
  "id" : 480018623520456706,
  "in_reply_to_status_id" : 480016908851224578,
  "created_at" : "2014-06-20 16:05:32 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480017175000776704",
  "geo" : { },
  "id_str" : "480018395333550082",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem well, there really is no such thing as legal justice. only karmic justice. (in my view)",
  "id" : 480018395333550082,
  "in_reply_to_status_id" : 480017175000776704,
  "created_at" : "2014-06-20 16:04:38 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479316014648143873",
  "geo" : { },
  "id_str" : "480015870496747522",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem forgiveness is about taking back the power from the trespasser. its like taking meds for infection.",
  "id" : 480015870496747522,
  "in_reply_to_status_id" : 479316014648143873,
  "created_at" : "2014-06-20 15:54:36 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480014605096210432",
  "text" : "RT @mindymayhem: Maybe if you were so pious and full of virtue, you'd fight harder for people to make a wage that supports raising children.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha OLD\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479320523361353728",
    "text" : "Maybe if you were so pious and full of virtue, you'd fight harder for people to make a wage that supports raising children.",
    "id" : 479320523361353728,
    "created_at" : "2014-06-18 17:51:32 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 480014605096210432,
  "created_at" : "2014-06-20 15:49:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480014491438952449",
  "text" : "RT @mindymayhem: America loves poverty. Poverty helps feed some of our biggest industries: Military, pharmaceuticals, prisons. We \u2665 keeping\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sinproject.net\/tweecha\/\" rel=\"nofollow\"\u003Etweecha OLD\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479335947754942464",
    "text" : "America loves poverty. Poverty helps feed some of our biggest industries: Military, pharmaceuticals, prisons. We \u2665 keeping people poor!",
    "id" : 479335947754942464,
    "created_at" : "2014-06-18 18:52:50 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 480014491438952449,
  "created_at" : "2014-06-20 15:49:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Angela Lidder",
      "screen_name" : "CollieColleen",
      "indices" : [ 3, 17 ],
      "id_str" : "396075623",
      "id" : 396075623
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/480008178680475648\/photo\/1",
      "indices" : [ 43, 65 ],
      "url" : "http:\/\/t.co\/fZJBvDstCo",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqlU5R1IYAAhjfv.jpg",
      "id_str" : "480008178307194880",
      "id" : 480008178307194880,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqlU5R1IYAAhjfv.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 496,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 847,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 281,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1270,
        "resize" : "fit",
        "w" : 1536
      } ],
      "display_url" : "pic.twitter.com\/fZJBvDstCo"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480013953385238528",
  "text" : "RT @CollieColleen: Just watching his back. http:\/\/t.co\/fZJBvDstCo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\/\" rel=\"nofollow\"\u003EOS X\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CollieColleen\/status\/480008178680475648\/photo\/1",
        "indices" : [ 24, 46 ],
        "url" : "http:\/\/t.co\/fZJBvDstCo",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqlU5R1IYAAhjfv.jpg",
        "id_str" : "480008178307194880",
        "id" : 480008178307194880,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqlU5R1IYAAhjfv.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 496,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 847,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 281,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1270,
          "resize" : "fit",
          "w" : 1536
        } ],
        "display_url" : "pic.twitter.com\/fZJBvDstCo"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "480008178680475648",
    "text" : "Just watching his back. http:\/\/t.co\/fZJBvDstCo",
    "id" : 480008178680475648,
    "created_at" : "2014-06-20 15:24:02 +0000",
    "user" : {
      "name" : "Angela Lidder",
      "screen_name" : "CollieColleen",
      "protected" : false,
      "id_str" : "396075623",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2249749495\/20120306_79_normal.jpg",
      "id" : 396075623,
      "verified" : false
    }
  },
  "id" : 480013953385238528,
  "created_at" : "2014-06-20 15:46:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480009551249281025",
  "geo" : { },
  "id_str" : "480013483262476288",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem but then I know someone who prays to be a good neighbor and always tries to do the more loving action.",
  "id" : 480013483262476288,
  "in_reply_to_status_id" : 480009551249281025,
  "created_at" : "2014-06-20 15:45:07 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "480009551249281025",
  "geo" : { },
  "id_str" : "480012129626365952",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem yes, there are many like him who feel righteous.",
  "id" : 480012129626365952,
  "in_reply_to_status_id" : 480009551249281025,
  "created_at" : "2014-06-20 15:39:44 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480010669224259585",
  "text" : "it was cool to watch the process.. he installed heavy duty security for me. call mark if you need help. pleasant and knowledgeable.",
  "id" : 480010669224259585,
  "created_at" : "2014-06-20 15:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 7, 29 ],
      "url" : "http:\/\/t.co\/a9xvQYlkrO",
      "expanded_url" : "http:\/\/certifiedonlinecomputerrepair.com\/",
      "display_url" : "certifiedonlinecomputerrepair.com"
    } ]
  },
  "geo" : { },
  "id_str" : "480009958302285824",
  "text" : "I used http:\/\/t.co\/a9xvQYlkrO who logged in, used professional software and got me running in a few hours.",
  "id" : 480009958302285824,
  "created_at" : "2014-06-20 15:31:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480009232096325632",
  "text" : "I am back online people. After using my tablet for a week due to sick laptop. Got fancy protection now, too.",
  "id" : 480009232096325632,
  "created_at" : "2014-06-20 15:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480008836967706625",
  "text" : "woohoo, my pkg made it finally after 10 days of visiting the tri-state area. no pics or souvenirs, tho..lol",
  "id" : 480008836967706625,
  "created_at" : "2014-06-20 15:26:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "480006760288100352",
  "text" : "Dear Universe, I'm sorry if I misread someone's intentions.",
  "id" : 480006760288100352,
  "created_at" : "2014-06-20 15:18:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 87, 109 ],
      "url" : "http:\/\/t.co\/WCReysAfur",
      "expanded_url" : "http:\/\/redemptionpictures.com\/2014\/06\/18\/im-not-going-to-heaven\/",
      "display_url" : "redemptionpictures.com\/2014\/06\/18\/im-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480005897129717761",
  "text" : "\"But it only works as long as I don\u2019t question the authority of this scrap of paper.\"  http:\/\/t.co\/WCReysAfur",
  "id" : 480005897129717761,
  "created_at" : "2014-06-20 15:14:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "indices" : [ 3, 16 ],
      "id_str" : "94619438",
      "id" : 94619438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/XlF6U8ueaI",
      "expanded_url" : "http:\/\/redemptionpictures.com\/2014\/06\/18\/im-not-going-to-heaven\/",
      "display_url" : "redemptionpictures.com\/2014\/06\/18\/im-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "480005577913794561",
  "text" : "RT @micahjmurray: 4 Reasons I'm Not Going to Heaven http:\/\/t.co\/XlF6U8ueaI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 56 ],
        "url" : "http:\/\/t.co\/XlF6U8ueaI",
        "expanded_url" : "http:\/\/redemptionpictures.com\/2014\/06\/18\/im-not-going-to-heaven\/",
        "display_url" : "redemptionpictures.com\/2014\/06\/18\/im-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "479604783360135169",
    "text" : "4 Reasons I'm Not Going to Heaven http:\/\/t.co\/XlF6U8ueaI",
    "id" : 479604783360135169,
    "created_at" : "2014-06-19 12:41:05 +0000",
    "user" : {
      "name" : "Micah J. Murray",
      "screen_name" : "micahjmurray",
      "protected" : false,
      "id_str" : "94619438",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745012205314150400\/5E99t-ly_normal.jpg",
      "id" : 94619438,
      "verified" : false
    }
  },
  "id" : 480005577913794561,
  "created_at" : "2014-06-20 15:13:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/hH0DgwP1Oe",
      "expanded_url" : "http:\/\/on.doi.gov\/SGImkS",
      "display_url" : "on.doi.gov\/SGImkS"
    } ]
  },
  "geo" : { },
  "id_str" : "479988670460485632",
  "text" : "RT @Interior: When you have a problem with noxious weeds &amp; brush overgrowth who do you call? 409 goats of course! http:\/\/t.co\/hH0DgwP1Oe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/bitly.com\/\" rel=\"nofollow\"\u003EBitly\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 126 ],
        "url" : "http:\/\/t.co\/hH0DgwP1Oe",
        "expanded_url" : "http:\/\/on.doi.gov\/SGImkS",
        "display_url" : "on.doi.gov\/SGImkS"
      } ]
    },
    "geo" : { },
    "id_str" : "477526202459357185",
    "text" : "When you have a problem with noxious weeds &amp; brush overgrowth who do you call? 409 goats of course! http:\/\/t.co\/hH0DgwP1Oe",
    "id" : 477526202459357185,
    "created_at" : "2014-06-13 19:01:33 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 479988670460485632,
  "created_at" : "2014-06-20 14:06:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Fish and Wildlife",
      "screen_name" : "USFWSMtnPrairie",
      "indices" : [ 3, 19 ],
      "id_str" : "161705350",
      "id" : 161705350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bison",
      "indices" : [ 31, 37 ]
    }, {
      "text" : "USFWS",
      "indices" : [ 111, 117 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 118, 127 ]
    }, {
      "text" : "ND",
      "indices" : [ 128, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479988241370578945",
  "text" : "RT @USFWSMtnPrairie: Beautiful #bison browse the botany at Sullys Hill National Game Preserve in North Dakota. #USFWS #wildlife #ND http:\/\/\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/sproutsocial.com\" rel=\"nofollow\"\u003ESprout Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/USFWSMtnPrairie\/status\/479248420138274816\/photo\/1",
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/9GjI4dEf2M",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bqah5hJCAAAOiFl.jpg",
        "id_str" : "479248419882401792",
        "id" : 479248419882401792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bqah5hJCAAAOiFl.jpg",
        "sizes" : [ {
          "h" : 585,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 342,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 194,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1169,
          "resize" : "fit",
          "w" : 2048
        } ],
        "display_url" : "pic.twitter.com\/9GjI4dEf2M"
      } ],
      "hashtags" : [ {
        "text" : "bison",
        "indices" : [ 10, 16 ]
      }, {
        "text" : "USFWS",
        "indices" : [ 90, 96 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 97, 106 ]
      }, {
        "text" : "ND",
        "indices" : [ 107, 110 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479248420138274816",
    "text" : "Beautiful #bison browse the botany at Sullys Hill National Game Preserve in North Dakota. #USFWS #wildlife #ND http:\/\/t.co\/9GjI4dEf2M",
    "id" : 479248420138274816,
    "created_at" : "2014-06-18 13:05:02 +0000",
    "user" : {
      "name" : "US Fish and Wildlife",
      "screen_name" : "USFWSMtnPrairie",
      "protected" : false,
      "id_str" : "161705350",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/475007847780999168\/f5kR3g4t_normal.jpeg",
      "id" : 161705350,
      "verified" : true
    }
  },
  "id" : 479988241370578945,
  "created_at" : "2014-06-20 14:04:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mairead Sayre",
      "screen_name" : "Mairead_Sayre",
      "indices" : [ 0, 14 ],
      "id_str" : "99910224",
      "id" : 99910224
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479959336576225281",
  "geo" : { },
  "id_str" : "479987705942523904",
  "in_reply_to_user_id" : 99910224,
  "text" : "@Mairead_Sayre yes, they do.. awesome! thanks for sharing. following them now. : )",
  "id" : 479987705942523904,
  "in_reply_to_status_id" : 479959336576225281,
  "created_at" : "2014-06-20 14:02:41 +0000",
  "in_reply_to_screen_name" : "Mairead_Sayre",
  "in_reply_to_user_id_str" : "99910224",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479786958630031360",
  "text" : "i cannot tolerate anyone telling me what to do. and knowing ladies who allow hubby to do so.. makes me sad, angry.",
  "id" : 479786958630031360,
  "created_at" : "2014-06-20 00:44:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479785775974739968",
  "text" : "\"won't let her\" won't let her visit? who the hell does he think he is?",
  "id" : 479785775974739968,
  "created_at" : "2014-06-20 00:40:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 0, 11 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479778791913689089",
  "geo" : { },
  "id_str" : "479779596988977152",
  "in_reply_to_user_id" : 38417795,
  "text" : "@ChickenJen they are so beautiful.",
  "id" : 479779596988977152,
  "in_reply_to_status_id" : 479778791913689089,
  "created_at" : "2014-06-20 00:15:44 +0000",
  "in_reply_to_screen_name" : "ChickenJen",
  "in_reply_to_user_id_str" : "38417795",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 3, 14 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ScottishHighlandcows",
      "indices" : [ 39, 60 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 121 ],
      "url" : "http:\/\/t.co\/WG84b04Xj9",
      "expanded_url" : "http:\/\/twitpic.com\/e6iuuk",
      "display_url" : "twitpic.com\/e6iuuk"
    } ]
  },
  "geo" : { },
  "id_str" : "479779438050021376",
  "text" : "RT @ChickenJen: I love this pic of our #ScottishHighlandcows coming up to greet me in the pasture. http:\/\/t.co\/WG84b04Xj9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ScottishHighlandcows",
        "indices" : [ 23, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 105 ],
        "url" : "http:\/\/t.co\/WG84b04Xj9",
        "expanded_url" : "http:\/\/twitpic.com\/e6iuuk",
        "display_url" : "twitpic.com\/e6iuuk"
      } ]
    },
    "geo" : { },
    "id_str" : "479778791913689089",
    "text" : "I love this pic of our #ScottishHighlandcows coming up to greet me in the pasture. http:\/\/t.co\/WG84b04Xj9",
    "id" : 479778791913689089,
    "created_at" : "2014-06-20 00:12:32 +0000",
    "user" : {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "protected" : false,
      "id_str" : "38417795",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/726746028305608704\/bN-QES0c_normal.jpg",
      "id" : 38417795,
      "verified" : false
    }
  },
  "id" : 479779438050021376,
  "created_at" : "2014-06-20 00:15:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "indices" : [ 3, 12 ],
      "id_str" : "76348185",
      "id" : 76348185
    }, {
      "name" : "BLM Alaska",
      "screen_name" : "BLMAlaska",
      "indices" : [ 100, 110 ],
      "id_str" : "322189705",
      "id" : 322189705
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/479390541084233730\/photo\/1",
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/kKX4ircA6T",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqcjKA_CIAAHrcQ.jpg",
      "id_str" : "479390540308291584",
      "id" : 479390540308291584,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqcjKA_CIAAHrcQ.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 792,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 727
      }, {
        "h" : 449,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 960,
        "resize" : "fit",
        "w" : 727
      } ],
      "display_url" : "pic.twitter.com\/kKX4ircA6T"
    } ],
    "hashtags" : [ {
      "text" : "Alaska",
      "indices" : [ 91, 98 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479771328254201856",
  "text" : "RT @Interior: Here's your evening dose of cute. Two moose calves near the Fortymile River, #Alaska. @BLMAlaska http:\/\/t.co\/kKX4ircA6T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BLM Alaska",
        "screen_name" : "BLMAlaska",
        "indices" : [ 86, 96 ],
        "id_str" : "322189705",
        "id" : 322189705
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Interior\/status\/479390541084233730\/photo\/1",
        "indices" : [ 97, 119 ],
        "url" : "http:\/\/t.co\/kKX4ircA6T",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqcjKA_CIAAHrcQ.jpg",
        "id_str" : "479390540308291584",
        "id" : 479390540308291584,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqcjKA_CIAAHrcQ.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 792,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 727
        }, {
          "h" : 449,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 960,
          "resize" : "fit",
          "w" : 727
        } ],
        "display_url" : "pic.twitter.com\/kKX4ircA6T"
      } ],
      "hashtags" : [ {
        "text" : "Alaska",
        "indices" : [ 77, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479390541084233730",
    "text" : "Here's your evening dose of cute. Two moose calves near the Fortymile River, #Alaska. @BLMAlaska http:\/\/t.co\/kKX4ircA6T",
    "id" : 479390541084233730,
    "created_at" : "2014-06-18 22:29:46 +0000",
    "user" : {
      "name" : "US Dept of Interior",
      "screen_name" : "Interior",
      "protected" : false,
      "id_str" : "76348185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/432081479\/DOI_LOGO_normal.jpg",
      "id" : 76348185,
      "verified" : true
    }
  },
  "id" : 479771328254201856,
  "created_at" : "2014-06-19 23:42:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479685039404228608",
  "geo" : { },
  "id_str" : "479685373031755776",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino what a cutie!",
  "id" : 479685373031755776,
  "in_reply_to_status_id" : 479685039404228608,
  "created_at" : "2014-06-19 18:01:19 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/wildobs\/status\/479678789304479744\/photo\/1",
      "indices" : [ 81, 103 ],
      "url" : "http:\/\/t.co\/48KRNRtvms",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BqgpUTiIEAEwqDP.jpg",
      "id_str" : "479678789132488705",
      "id" : 479678789132488705,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqgpUTiIEAEwqDP.jpg",
      "sizes" : [ {
        "h" : 424,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 799,
        "resize" : "fit",
        "w" : 640
      }, {
        "h" : 749,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/48KRNRtvms"
    } ],
    "hashtags" : [ {
      "text" : "DailyBirdApp",
      "indices" : [ 13, 26 ]
    }, {
      "text" : "NESP",
      "indices" : [ 27, 32 ]
    } ],
    "urls" : [ {
      "indices" : [ 58, 80 ],
      "url" : "http:\/\/t.co\/CuJY33ggX0",
      "expanded_url" : "http:\/\/dailybirdapp.com",
      "display_url" : "dailybirdapp.com"
    } ]
  },
  "geo" : { },
  "id_str" : "479679631478378496",
  "text" : "RT @wildobs: #DailyBirdApp #NESP\n\nPhoto \u00A9 Sean Fitzgerald http:\/\/t.co\/CuJY33ggX0 http:\/\/t.co\/48KRNRtvms",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/wildobs\/status\/479678789304479744\/photo\/1",
        "indices" : [ 68, 90 ],
        "url" : "http:\/\/t.co\/48KRNRtvms",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BqgpUTiIEAEwqDP.jpg",
        "id_str" : "479678789132488705",
        "id" : 479678789132488705,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BqgpUTiIEAEwqDP.jpg",
        "sizes" : [ {
          "h" : 424,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 799,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 749,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/48KRNRtvms"
      } ],
      "hashtags" : [ {
        "text" : "DailyBirdApp",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "NESP",
        "indices" : [ 14, 19 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 67 ],
        "url" : "http:\/\/t.co\/CuJY33ggX0",
        "expanded_url" : "http:\/\/dailybirdapp.com",
        "display_url" : "dailybirdapp.com"
      } ]
    },
    "geo" : { },
    "id_str" : "479678789304479744",
    "text" : "#DailyBirdApp #NESP\n\nPhoto \u00A9 Sean Fitzgerald http:\/\/t.co\/CuJY33ggX0 http:\/\/t.co\/48KRNRtvms",
    "id" : 479678789304479744,
    "created_at" : "2014-06-19 17:35:10 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 479679631478378496,
  "created_at" : "2014-06-19 17:38:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Affirmation",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479651474767491073",
  "text" : "RT @Emmanueldagher: #Affirmation: Dear Universe, remind me always that by loving &amp; accepting myself, I am showing you the greatest honor. A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Affirmation",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479649992009740288",
    "text" : "#Affirmation: Dear Universe, remind me always that by loving &amp; accepting myself, I am showing you the greatest honor. And so it is.",
    "id" : 479649992009740288,
    "created_at" : "2014-06-19 15:40:44 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 479651474767491073,
  "created_at" : "2014-06-19 15:46:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479451387693383680",
  "text" : "Soo.. Basically I just threw out money in the garbage. My PC is still messed up. Will have to take to local shop.",
  "id" : 479451387693383680,
  "created_at" : "2014-06-19 02:31:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479450929242988544",
  "text" : "I'm just going to assume this is a karmic lesson about misusing trust.. Sigh.",
  "id" : 479450929242988544,
  "created_at" : "2014-06-19 02:29:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479443217675735040",
  "text" : "I don't know what to think.. Or what to do. Is this person fooling me? Or just doesn't know what he's doing?",
  "id" : 479443217675735040,
  "created_at" : "2014-06-19 01:59:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nervous Jarred",
      "screen_name" : "12jrutherford",
      "indices" : [ 77, 91 ],
      "id_str" : "354617828",
      "id" : 354617828
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479406577149956096",
  "geo" : { },
  "id_str" : "479433160200306688",
  "in_reply_to_user_id" : 14364749,
  "text" : "@cosmicaudino you cant change ppl but you can be a beacon of light for them. @12jrutherford",
  "id" : 479433160200306688,
  "in_reply_to_status_id" : 479406577149956096,
  "created_at" : "2014-06-19 01:19:07 +0000",
  "in_reply_to_screen_name" : "trustsuperjail",
  "in_reply_to_user_id_str" : "14364749",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jennifer Wixson",
      "screen_name" : "ChickenJen",
      "indices" : [ 11, 22 ],
      "id_str" : "38417795",
      "id" : 38417795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 69 ],
      "url" : "http:\/\/t.co\/KwAMsY0AFg",
      "expanded_url" : "http:\/\/twitpic.com\/e6ggr4",
      "display_url" : "twitpic.com\/e6ggr4"
    } ]
  },
  "geo" : { },
  "id_str" : "479431082094624768",
  "text" : "Beautiful \"@ChickenJen: Maine evening pastoral http:\/\/t.co\/KwAMsY0AFg\"",
  "id" : 479431082094624768,
  "created_at" : "2014-06-19 01:10:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479337981141340160",
  "geo" : { },
  "id_str" : "479342382362546176",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields ahh. I'm just nervous as I'm using a service now to get rid of malware.",
  "id" : 479342382362546176,
  "in_reply_to_status_id" : 479337981141340160,
  "created_at" : "2014-06-18 19:18:24 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479331595162099712",
  "geo" : { },
  "id_str" : "479336221626626049",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields was it you using it for yourself? Or a service accessing your computer?",
  "id" : 479336221626626049,
  "in_reply_to_status_id" : 479331595162099712,
  "created_at" : "2014-06-18 18:53:55 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479327983376019456",
  "text" : "Anyone use remote computer services before?",
  "id" : 479327983376019456,
  "created_at" : "2014-06-18 18:21:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James W. Bravos,J.D.",
      "screen_name" : "Bhava_Jim",
      "indices" : [ 3, 13 ],
      "id_str" : "104553468",
      "id" : 104553468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479048423702663169",
  "text" : "RT @Bhava_Jim: The brain is only an interface like a computer, but instead of interfacing with the World Wide Web it interfaces with Consci\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479047161767034880",
    "text" : "The brain is only an interface like a computer, but instead of interfacing with the World Wide Web it interfaces with Consciousness the EMF.",
    "id" : 479047161767034880,
    "created_at" : "2014-06-17 23:45:18 +0000",
    "user" : {
      "name" : "James W. Bravos,J.D.",
      "screen_name" : "Bhava_Jim",
      "protected" : false,
      "id_str" : "104553468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2005731750\/Cover9_normal.jpg",
      "id" : 104553468,
      "verified" : false
    }
  },
  "id" : 479048423702663169,
  "created_at" : "2014-06-17 23:50:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "James W. Bravos,J.D.",
      "screen_name" : "Bhava_Jim",
      "indices" : [ 3, 13 ],
      "id_str" : "104553468",
      "id" : 104553468
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479048205465051136",
  "text" : "RT @Bhava_Jim: Consciousness is the Electro-Magnetic-Field (\"EMF\") or the Unified Field of Einstein's Unified Field Theory. The brain inter\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479047704929402880",
    "text" : "Consciousness is the Electro-Magnetic-Field (\"EMF\") or the Unified Field of Einstein's Unified Field Theory. The brain interfaces with it.",
    "id" : 479047704929402880,
    "created_at" : "2014-06-17 23:47:27 +0000",
    "user" : {
      "name" : "James W. Bravos,J.D.",
      "screen_name" : "Bhava_Jim",
      "protected" : false,
      "id_str" : "104553468",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2005731750\/Cover9_normal.jpg",
      "id" : 104553468,
      "verified" : false
    }
  },
  "id" : 479048205465051136,
  "created_at" : "2014-06-17 23:49:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "indices" : [ 3, 19 ],
      "id_str" : "395797972",
      "id" : 395797972
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479048074657275904",
  "text" : "RT @TheGoldenMirror: You can't make others see the truth. You can only seek it yourself and be a beacon to others, but it's up to them to n\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "479047758058643456",
    "text" : "You can't make others see the truth. You can only seek it yourself and be a beacon to others, but it's up to them to notice it or not.",
    "id" : 479047758058643456,
    "created_at" : "2014-06-17 23:47:40 +0000",
    "user" : {
      "name" : "The Golden Mirror",
      "screen_name" : "TheGoldenMirror",
      "protected" : false,
      "id_str" : "395797972",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797179561867935744\/BwCjVghv_normal.jpg",
      "id" : 395797972,
      "verified" : false
    }
  },
  "id" : 479048074657275904,
  "created_at" : "2014-06-17 23:48:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "479045156377608192",
  "geo" : { },
  "id_str" : "479045905602347008",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves Happy birthday! Love the hot-n-sweaty comment..heehee",
  "id" : 479045905602347008,
  "in_reply_to_status_id" : 479045156377608192,
  "created_at" : "2014-06-17 23:40:18 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "479001276890361856",
  "text" : "My brother in law is very kind. May the Universe bless him.",
  "id" : 479001276890361856,
  "created_at" : "2014-06-17 20:42:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478995429858615296",
  "text" : "RT @_NealeDWalsch: If U think that love is what U want, U will go searching 4 it all over. If U think love is what U R, U will go sharing i\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bufferapp.com\" rel=\"nofollow\"\u003EBuffer\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "478990744737546241",
    "text" : "If U think that love is what U want, U will go searching 4 it all over. If U think love is what U R, U will go sharing it all over the place",
    "id" : 478990744737546241,
    "created_at" : "2014-06-17 20:01:07 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 478995429858615296,
  "created_at" : "2014-06-17 20:19:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478941883058491392",
  "text" : "Yesterday was a bad day. I'm thinking today might be worse.",
  "id" : 478941883058491392,
  "created_at" : "2014-06-17 16:46:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478737845629517824",
  "text" : "I was wrong but I can't say I'm sorry...",
  "id" : 478737845629517824,
  "created_at" : "2014-06-17 03:16:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 135 ],
      "url" : "http:\/\/t.co\/pzic9JIvZg",
      "expanded_url" : "http:\/\/www.addictinginfo.org\/2014\/05\/31\/marriage-only-for-christians\/",
      "display_url" : "addictinginfo.org\/2014\/05\/31\/mar\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "478586729264185344",
  "text" : "Virginia Court Official Tells Atheist Couple They Have No Right To Get Married Because They Don\u2019t Believe In God\nhttp:\/\/t.co\/pzic9JIvZg",
  "id" : 478586729264185344,
  "created_at" : "2014-06-16 17:15:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web (M5)\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478567623987585024",
  "text" : "Got a thank you note from young nephew today. I kissed it.",
  "id" : 478567623987585024,
  "created_at" : "2014-06-16 15:59:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John",
      "screen_name" : "johnnie_cakes",
      "indices" : [ 0, 14 ],
      "id_str" : "16901470",
      "id" : 16901470
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "478303995652345856",
  "in_reply_to_user_id" : 16901470,
  "text" : "@johnnie_cakes big (((hugs)))",
  "id" : 478303995652345856,
  "created_at" : "2014-06-15 22:32:13 +0000",
  "in_reply_to_screen_name" : "johnnie_cakes",
  "in_reply_to_user_id_str" : "16901470",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 2, 10 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "478303222759948288",
  "geo" : { },
  "id_str" : "478303777405947904",
  "in_reply_to_user_id" : 59574144,
  "text" : ". @MWM4444 didnt make sense to me.. so i chose 1st concept and disregarded 2nd. continued my journey from there. : )",
  "id" : 478303777405947904,
  "in_reply_to_status_id" : 478303222759948288,
  "created_at" : "2014-06-15 22:31:21 +0000",
  "in_reply_to_screen_name" : "MWM4444",
  "in_reply_to_user_id_str" : "59574144",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477825892056432640",
  "text" : "Never trust me w anything important. I should have been institutionalized long ago.",
  "id" : 477825892056432640,
  "created_at" : "2014-06-14 14:52:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477824717798137856",
  "text" : "I'm such a dunce. I put the incorrect zip on order. WTF is wrong w me??? My brain is becoming more useless...",
  "id" : 477824717798137856,
  "created_at" : "2014-06-14 14:47:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477597921601269760",
  "text" : "Pkg I ordered Mon, due to arrive Wed. Went from Kingston NY to Red Hook. Now its in Springfield MA! WTH?",
  "id" : 477597921601269760,
  "created_at" : "2014-06-13 23:46:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9ED2\u732Bbot",
      "screen_name" : "Black_cat_cat__",
      "indices" : [ 3, 19 ],
      "id_str" : "1630745089",
      "id" : 1630745089
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/Black_cat_cat__\/status\/408107954072600576\/photo\/1",
      "indices" : [ 49, 72 ],
      "url" : "https:\/\/t.co\/P8Ew3SVhjA",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BankBaECQAA-Uuc.jpg",
      "id_str" : "408107954080989184",
      "id" : 408107954080989184,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BankBaECQAA-Uuc.jpg",
      "sizes" : [ {
        "h" : 398,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 225,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 477,
        "resize" : "fit",
        "w" : 720
      } ],
      "display_url" : "pic.twitter.com\/P8Ew3SVhjA"
    } ],
    "hashtags" : [ {
      "text" : "\u9ED2\u732B",
      "indices" : [ 34, 37 ]
    }, {
      "text" : "Blackcat",
      "indices" : [ 38, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477522421050650624",
  "text" : "RT @Black_cat_cat__: \u3053\u306E\u9ED2\u732B\u304C\u597D\u304D\u306A\u4EBA\u306FRT #\u9ED2\u732B #Blackcat \nhttps:\/\/t.co\/P8Ew3SVhjA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twittbot.net\/\" rel=\"nofollow\"\u003Etwittbot.net\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Black_cat_cat__\/status\/408107954072600576\/photo\/1",
        "indices" : [ 28, 51 ],
        "url" : "https:\/\/t.co\/P8Ew3SVhjA",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BankBaECQAA-Uuc.jpg",
        "id_str" : "408107954080989184",
        "id" : 408107954080989184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BankBaECQAA-Uuc.jpg",
        "sizes" : [ {
          "h" : 398,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 720
        }, {
          "h" : 225,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 477,
          "resize" : "fit",
          "w" : 720
        } ],
        "display_url" : "pic.twitter.com\/P8Ew3SVhjA"
      } ],
      "hashtags" : [ {
        "text" : "\u9ED2\u732B",
        "indices" : [ 13, 16 ]
      }, {
        "text" : "Blackcat",
        "indices" : [ 17, 26 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477475816033374208",
    "text" : "\u3053\u306E\u9ED2\u732B\u304C\u597D\u304D\u306A\u4EBA\u306FRT #\u9ED2\u732B #Blackcat \nhttps:\/\/t.co\/P8Ew3SVhjA",
    "id" : 477475816033374208,
    "created_at" : "2014-06-13 15:41:20 +0000",
    "user" : {
      "name" : "\u9ED2\u732Bbot",
      "screen_name" : "Black_cat_cat__",
      "protected" : false,
      "id_str" : "1630745089",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000209266798\/7e386bcdf3aa236cc4dfb86df48caa97_normal.jpeg",
      "id" : 1630745089,
      "verified" : false
    }
  },
  "id" : 477522421050650624,
  "created_at" : "2014-06-13 18:46:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allen Stairs",
      "screen_name" : "AllenStairs",
      "indices" : [ 3, 15 ],
      "id_str" : "17176889",
      "id" : 17176889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477522060508295168",
  "text" : "RT @AllenStairs: If there\u2019s a God, She can deal with Her enemies by Herself. If not, \u201Cenmity against God is a non-issue.\nhttps:\/\/t.co\/GBrIv\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 127 ],
        "url" : "https:\/\/t.co\/GBrIv8Vsyp",
        "expanded_url" : "https:\/\/www.hrw.org\/news\/2014\/06\/12\/iran-halt-execution-33-sunnis",
        "display_url" : "hrw.org\/news\/2014\/06\/1\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "477509023026397184",
    "text" : "If there\u2019s a God, She can deal with Her enemies by Herself. If not, \u201Cenmity against God is a non-issue.\nhttps:\/\/t.co\/GBrIv8Vsyp",
    "id" : 477509023026397184,
    "created_at" : "2014-06-13 17:53:17 +0000",
    "user" : {
      "name" : "Allen Stairs",
      "screen_name" : "AllenStairs",
      "protected" : false,
      "id_str" : "17176889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000647219310\/1ac165df0f63a85977462159517777a8_normal.jpeg",
      "id" : 17176889,
      "verified" : false
    }
  },
  "id" : 477522060508295168,
  "created_at" : "2014-06-13 18:45:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477222635005161473",
  "text" : "i gotta stop reading right wing watch. it really messes with my aura. gets me all discombobulated!",
  "id" : 477222635005161473,
  "created_at" : "2014-06-12 22:55:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/477203170478002177\/photo\/1",
      "indices" : [ 38, 60 ],
      "url" : "http:\/\/t.co\/kGoiFiCWKG",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp9dwPWCUAA3atm.jpg",
      "id_str" : "477203168858624000",
      "id" : 477203168858624000,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp9dwPWCUAA3atm.jpg",
      "sizes" : [ {
        "h" : 227,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 736
      }, {
        "h" : 401,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 492,
        "resize" : "fit",
        "w" : 736
      } ],
      "display_url" : "pic.twitter.com\/kGoiFiCWKG"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "477203665204150272",
  "text" : "RT @CUMALi_YILDIZ: Old Forest. Poland http:\/\/t.co\/kGoiFiCWKG",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/477203170478002177\/photo\/1",
        "indices" : [ 19, 41 ],
        "url" : "http:\/\/t.co\/kGoiFiCWKG",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bp9dwPWCUAA3atm.jpg",
        "id_str" : "477203168858624000",
        "id" : 477203168858624000,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bp9dwPWCUAA3atm.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 492,
          "resize" : "fit",
          "w" : 736
        }, {
          "h" : 401,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 492,
          "resize" : "fit",
          "w" : 736
        } ],
        "display_url" : "pic.twitter.com\/kGoiFiCWKG"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "477203170478002177",
    "text" : "Old Forest. Poland http:\/\/t.co\/kGoiFiCWKG",
    "id" : 477203170478002177,
    "created_at" : "2014-06-12 21:37:56 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 477203665204150272,
  "created_at" : "2014-06-12 21:39:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "horses",
      "indices" : [ 49, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/2xYZNyndSD",
      "expanded_url" : "http:\/\/wp.me\/p21fo3-1D",
      "display_url" : "wp.me\/p21fo3-1D"
    } ]
  },
  "geo" : { },
  "id_str" : "477200967905984512",
  "text" : "The Truth About the Amish http:\/\/t.co\/2xYZNyndSD #horses",
  "id" : 477200967905984512,
  "created_at" : "2014-06-12 21:29:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 133 ],
      "url" : "http:\/\/t.co\/2iOvpmLEbv",
      "expanded_url" : "http:\/\/tmblr.co\/Zp3-jx1IVbQ01",
      "display_url" : "tmblr.co\/Zp3-jx1IVbQ01"
    } ]
  },
  "geo" : { },
  "id_str" : "477111549237424128",
  "text" : "Photoset: unexplained-events: In Seattle, Washington, an aged and allegedly \u201Chaunted\u201D coke machine has been... http:\/\/t.co\/2iOvpmLEbv",
  "id" : 477111549237424128,
  "created_at" : "2014-06-12 15:33:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "writing pis",
      "screen_name" : "writingpis",
      "indices" : [ 3, 14 ],
      "id_str" : "31615386",
      "id" : 31615386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476763804169027584",
  "text" : "RT @writingpis: \"Forensic Science Isn\u2019t Science - Why juries hear &amp; trust so much biased, unreliable, inaccurate evidence\" http:\/\/t.co\/3piN\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Slate",
        "screen_name" : "Slate",
        "indices" : [ 135, 141 ],
        "id_str" : "15164565",
        "id" : 15164565
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 133 ],
        "url" : "http:\/\/t.co\/3piNDuRHIy",
        "expanded_url" : "http:\/\/tinyurl.com\/pz64t9n",
        "display_url" : "tinyurl.com\/pz64t9n"
      } ]
    },
    "geo" : { },
    "id_str" : "476751934490443776",
    "text" : "\"Forensic Science Isn\u2019t Science - Why juries hear &amp; trust so much biased, unreliable, inaccurate evidence\" http:\/\/t.co\/3piNDuRHIy  @Slate",
    "id" : 476751934490443776,
    "created_at" : "2014-06-11 15:44:53 +0000",
    "user" : {
      "name" : "writing pis",
      "screen_name" : "writingpis",
      "protected" : false,
      "id_str" : "31615386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1889224683\/Cocos_Ink_1_normal.jpg",
      "id" : 31615386,
      "verified" : false
    }
  },
  "id" : 476763804169027584,
  "created_at" : "2014-06-11 16:32:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "indices" : [ 3, 17 ],
      "id_str" : "780850862",
      "id" : 780850862
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476763217151016960",
  "text" : "RT @UnfundieXians: Luke 18: 9-14 (NIV)\n\nTo some who were confident of their own righteousness and looked down on everyone else,... http:\/\/t\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/iBUfxje14Z",
        "expanded_url" : "http:\/\/fb.me\/2I65TnyW3",
        "display_url" : "fb.me\/2I65TnyW3"
      } ]
    },
    "geo" : { },
    "id_str" : "476755747062038530",
    "text" : "Luke 18: 9-14 (NIV)\n\nTo some who were confident of their own righteousness and looked down on everyone else,... http:\/\/t.co\/iBUfxje14Z",
    "id" : 476755747062038530,
    "created_at" : "2014-06-11 16:00:02 +0000",
    "user" : {
      "name" : "Unfundie Christians",
      "screen_name" : "UnfundieXians",
      "protected" : false,
      "id_str" : "780850862",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000612253854\/d369ca7c4cc3d27a5fe05ca11521b685_normal.jpeg",
      "id" : 780850862,
      "verified" : false
    }
  },
  "id" : 476763217151016960,
  "created_at" : "2014-06-11 16:29:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 77 ],
      "url" : "http:\/\/t.co\/75Tnub2hwd",
      "expanded_url" : "http:\/\/po.st\/4ExgSQ",
      "display_url" : "po.st\/4ExgSQ"
    } ]
  },
  "geo" : { },
  "id_str" : "476759851645693952",
  "text" : "The Best Kitty Hug Ever! | The Animal Rescue Site Blog http:\/\/t.co\/75Tnub2hwd",
  "id" : 476759851645693952,
  "created_at" : "2014-06-11 16:16:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "indices" : [ 3, 16 ],
      "id_str" : "17355721",
      "id" : 17355721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TNZSummerNights",
      "indices" : [ 113, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476742370705149952",
  "text" : "RT @RichardMabry: How well do you know your authors? Test your skills in this new matching game from TNZ Fiction.#TNZSummerNights http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "TNZSummerNights",
        "indices" : [ 95, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 134 ],
        "url" : "http:\/\/t.co\/Cmdaw0las2",
        "expanded_url" : "http:\/\/bit.ly\/1n4ZpZb",
        "display_url" : "bit.ly\/1n4ZpZb"
      } ]
    },
    "geo" : { },
    "id_str" : "476385934041423872",
    "text" : "How well do you know your authors? Test your skills in this new matching game from TNZ Fiction.#TNZSummerNights http:\/\/t.co\/Cmdaw0las2",
    "id" : 476385934041423872,
    "created_at" : "2014-06-10 15:30:32 +0000",
    "user" : {
      "name" : "Richard Mabry",
      "screen_name" : "RichardMabry",
      "protected" : false,
      "id_str" : "17355721",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2962879796\/49c64d61962d4587ca5154d35d04ebc4_normal.jpeg",
      "id" : 17355721,
      "verified" : false
    }
  },
  "id" : 476742370705149952,
  "created_at" : "2014-06-11 15:06:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476359505211445248",
  "text" : "RT @TheGodLight: There are no mistakes in God's world, we are all learning as one, through the passage of time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476349393491464192",
    "text" : "There are no mistakes in God's world, we are all learning as one, through the passage of time.",
    "id" : 476349393491464192,
    "created_at" : "2014-06-10 13:05:20 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 476359505211445248,
  "created_at" : "2014-06-10 13:45:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0935\u093F\u0936\u094D\u0935\u0927\u0930\u094D\u092E \u0930\u0915\u094D\u0937\u0915",
      "screen_name" : "dewet5",
      "indices" : [ 3, 10 ],
      "id_str" : "3396900112",
      "id" : 3396900112
    }, {
      "name" : "Anna \u264F",
      "screen_name" : "xscorpioncinax",
      "indices" : [ 13, 28 ],
      "id_str" : "1004085655",
      "id" : 1004085655
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/xscorpioncinax\/status\/474918926288453633\/photo\/1",
      "indices" : [ 30, 52 ],
      "url" : "http:\/\/t.co\/dHAwBorPZ5",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpdAPv2IMAAGaif.jpg",
      "id_str" : "474918924996587520",
      "id" : 474918924996587520,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpdAPv2IMAAGaif.jpg",
      "sizes" : [ {
        "h" : 540,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 540,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 230,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 405,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/dHAwBorPZ5"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476359352106770432",
  "text" : "RT @DeWet5: \"@xscorpioncinax: http:\/\/t.co\/dHAwBorPZ5\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Anna \u264F",
        "screen_name" : "xscorpioncinax",
        "indices" : [ 1, 16 ],
        "id_str" : "1004085655",
        "id" : 1004085655
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/xscorpioncinax\/status\/474918926288453633\/photo\/1",
        "indices" : [ 18, 40 ],
        "url" : "http:\/\/t.co\/dHAwBorPZ5",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpdAPv2IMAAGaif.jpg",
        "id_str" : "474918924996587520",
        "id" : 474918924996587520,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpdAPv2IMAAGaif.jpg",
        "sizes" : [ {
          "h" : 540,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 540,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 230,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 405,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/dHAwBorPZ5"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476349280190746624",
    "text" : "\"@xscorpioncinax: http:\/\/t.co\/dHAwBorPZ5\"",
    "id" : 476349280190746624,
    "created_at" : "2014-06-10 13:04:53 +0000",
    "user" : {
      "name" : "Dubs&tits",
      "screen_name" : "PoesKoets",
      "protected" : false,
      "id_str" : "312116139",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/791660176466116608\/omSVRClT_normal.jpg",
      "id" : 312116139,
      "verified" : false
    }
  },
  "id" : 476359352106770432,
  "created_at" : "2014-06-10 13:44:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Just Andy",
      "screen_name" : "andymarsden1984",
      "indices" : [ 2, 18 ],
      "id_str" : "77185433",
      "id" : 77185433
    }, {
      "name" : "wavesofmissingu",
      "screen_name" : "clarkherlin",
      "indices" : [ 19, 31 ],
      "id_str" : "2664066128",
      "id" : 2664066128
    }, {
      "name" : "(((Darwinian))) FCD",
      "screen_name" : "Gr8Darwinians",
      "indices" : [ 32, 46 ],
      "id_str" : "2344141208",
      "id" : 2344141208
    }, {
      "name" : "Ashamed of America",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 47, 59 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "476347821978030080",
  "geo" : { },
  "id_str" : "476358507382321152",
  "in_reply_to_user_id" : 77185433,
  "text" : ". @andymarsden1984 @clarkherlin @Gr8Darwinians @VirgoJohnny ahh, yes.. my view of God becomes more broad as time goes on.",
  "id" : 476358507382321152,
  "in_reply_to_status_id" : 476347821978030080,
  "created_at" : "2014-06-10 13:41:33 +0000",
  "in_reply_to_screen_name" : "andymarsden1984",
  "in_reply_to_user_id_str" : "77185433",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476353495302287362",
  "text" : "RT @JeremyCShipp: When the world collapses, I for one am going to shout, \"Jenga!\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "476352848108593152",
    "text" : "When the world collapses, I for one am going to shout, \"Jenga!\"",
    "id" : 476352848108593152,
    "created_at" : "2014-06-10 13:19:03 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 476353495302287362,
  "created_at" : "2014-06-10 13:21:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy Teevens",
      "screen_name" : "CindyTeevens",
      "indices" : [ 3, 16 ],
      "id_str" : "49857989",
      "id" : 49857989
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "serotonin",
      "indices" : [ 74, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 112, 134 ],
      "url" : "http:\/\/t.co\/9p1dxPPwTO",
      "expanded_url" : "http:\/\/goo.gl\/fb\/W0u8N",
      "display_url" : "goo.gl\/fb\/W0u8N"
    } ]
  },
  "geo" : { },
  "id_str" : "476174153326673921",
  "text" : "RT @CindyTeevens: Research shows SSRIs reduce brain\u2019s capacity to produce #serotonin Chris Wodskou of CBC news\u2026 http:\/\/t.co\/9p1dxPPwTO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "serotonin",
        "indices" : [ 56, 66 ]
      } ],
      "urls" : [ {
        "indices" : [ 94, 116 ],
        "url" : "http:\/\/t.co\/9p1dxPPwTO",
        "expanded_url" : "http:\/\/goo.gl\/fb\/W0u8N",
        "display_url" : "goo.gl\/fb\/W0u8N"
      } ]
    },
    "geo" : { },
    "id_str" : "475986777543426048",
    "text" : "Research shows SSRIs reduce brain\u2019s capacity to produce #serotonin Chris Wodskou of CBC news\u2026 http:\/\/t.co\/9p1dxPPwTO",
    "id" : 475986777543426048,
    "created_at" : "2014-06-09 13:04:25 +0000",
    "user" : {
      "name" : "Cindy Teevens",
      "screen_name" : "CindyTeevens",
      "protected" : false,
      "id_str" : "49857989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/277670878\/MeNew_normal.jpg",
      "id" : 49857989,
      "verified" : false
    }
  },
  "id" : 476174153326673921,
  "created_at" : "2014-06-10 01:28:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 22 ],
      "url" : "http:\/\/t.co\/E29Yq6q5zQ",
      "expanded_url" : "http:\/\/alchemylovejoy.com\/antidepressant-drugs-may-make-mental-illness-worse\/",
      "display_url" : "alchemylovejoy.com\/antidepressant\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "476173653696987136",
  "text" : "http:\/\/t.co\/E29Yq6q5zQ",
  "id" : 476173653696987136,
  "created_at" : "2014-06-10 01:27:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Total Film",
      "screen_name" : "totalfilm",
      "indices" : [ 3, 13 ],
      "id_str" : "17483878",
      "id" : 17483878
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/totalfilm\/status\/476016504044257281\/photo\/1",
      "indices" : [ 95, 117 ],
      "url" : "http:\/\/t.co\/VGpylxg8W7",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpsmfNjIIAEjhbi.jpg",
      "id_str" : "476016503272513537",
      "id" : 476016503272513537,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpsmfNjIIAEjhbi.jpg",
      "sizes" : [ {
        "h" : 486,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 260,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 486,
        "resize" : "fit",
        "w" : 636
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 458,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/VGpylxg8W7"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 94 ],
      "url" : "http:\/\/t.co\/rs7lZop0Ta",
      "expanded_url" : "http:\/\/bbc.in\/TzSs8f",
      "display_url" : "bbc.in\/TzSs8f"
    } ]
  },
  "geo" : { },
  "id_str" : "476018510083010560",
  "text" : "RT @totalfilm: Very shocked to hear the great Rik Mayall has died. RIP. http:\/\/t.co\/rs7lZop0Ta http:\/\/t.co\/VGpylxg8W7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/totalfilm\/status\/476016504044257281\/photo\/1",
        "indices" : [ 80, 102 ],
        "url" : "http:\/\/t.co\/VGpylxg8W7",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpsmfNjIIAEjhbi.jpg",
        "id_str" : "476016503272513537",
        "id" : 476016503272513537,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpsmfNjIIAEjhbi.jpg",
        "sizes" : [ {
          "h" : 486,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 260,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 486,
          "resize" : "fit",
          "w" : 636
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 458,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/VGpylxg8W7"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 79 ],
        "url" : "http:\/\/t.co\/rs7lZop0Ta",
        "expanded_url" : "http:\/\/bbc.in\/TzSs8f",
        "display_url" : "bbc.in\/TzSs8f"
      } ]
    },
    "geo" : { },
    "id_str" : "476016504044257281",
    "text" : "Very shocked to hear the great Rik Mayall has died. RIP. http:\/\/t.co\/rs7lZop0Ta http:\/\/t.co\/VGpylxg8W7",
    "id" : 476016504044257281,
    "created_at" : "2014-06-09 15:02:33 +0000",
    "user" : {
      "name" : "Total Film",
      "screen_name" : "totalfilm",
      "protected" : false,
      "id_str" : "17483878",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/738652880387878912\/kEeI_JQZ_normal.jpg",
      "id" : 17483878,
      "verified" : true
    }
  },
  "id" : 476018510083010560,
  "created_at" : "2014-06-09 15:10:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "indices" : [ 3, 13 ],
      "id_str" : "63043",
      "id" : 63043
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/8qxFwgpwuC",
      "expanded_url" : "http:\/\/muo.fm\/1l0rlbW",
      "display_url" : "muo.fm\/1l0rlbW"
    } ]
  },
  "geo" : { },
  "id_str" : "476015496249090050",
  "text" : "RT @MakeUseOf: Save Your Web Favorites As Notes With OneNote Clipper For Chrome http:\/\/t.co\/8qxFwgpwuC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/dlvr.it\" rel=\"nofollow\"\u003Edlvr.it\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 65, 87 ],
        "url" : "http:\/\/t.co\/8qxFwgpwuC",
        "expanded_url" : "http:\/\/muo.fm\/1l0rlbW",
        "display_url" : "muo.fm\/1l0rlbW"
      } ]
    },
    "geo" : { },
    "id_str" : "476014056420040704",
    "text" : "Save Your Web Favorites As Notes With OneNote Clipper For Chrome http:\/\/t.co\/8qxFwgpwuC",
    "id" : 476014056420040704,
    "created_at" : "2014-06-09 14:52:49 +0000",
    "user" : {
      "name" : "MakeUseOf",
      "screen_name" : "MakeUseOf",
      "protected" : false,
      "id_str" : "63043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771290297255006208\/qJzhURwu_normal.jpg",
      "id" : 63043,
      "verified" : true
    }
  },
  "id" : 476015496249090050,
  "created_at" : "2014-06-09 14:58:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "476009055811428352",
  "text" : "soo.. i was wrong. my pkg WAS delivered on Saturday. just wasnt updated right away. sorry, amazon and fedex.",
  "id" : 476009055811428352,
  "created_at" : "2014-06-09 14:32:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475777916505047041",
  "text" : "RT @SpiritualNurse: What some call health, if purchased by perpetual anxiety about diet, isn't much better than tedious disease. ~George D.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475776712287199233",
    "text" : "What some call health, if purchased by perpetual anxiety about diet, isn't much better than tedious disease. ~George D. Prentice, 1860",
    "id" : 475776712287199233,
    "created_at" : "2014-06-08 23:09:42 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 475777916505047041,
  "created_at" : "2014-06-08 23:14:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475777563982188545",
  "text" : "RT @AnAmericanMonk: We are only dominated by an internal threat which is the power and belief we entrust upon the illusionary ego.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475777147442061314",
    "text" : "We are only dominated by an internal threat which is the power and belief we entrust upon the illusionary ego.",
    "id" : 475777147442061314,
    "created_at" : "2014-06-08 23:11:26 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 475777563982188545,
  "created_at" : "2014-06-08 23:13:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475774014284382208",
  "text" : "dh started watching Deadwood while i was away last wkend. we've been watching each night since.",
  "id" : 475774014284382208,
  "created_at" : "2014-06-08 22:58:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "indices" : [ 3, 14 ],
      "id_str" : "15808765",
      "id" : 15808765
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475718895643271168",
  "text" : "RT @CoryBooker: Its OK not to like someone but it is NEVER OK to try and degrade, humiliate or dehumanize them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475716474963644416",
    "text" : "Its OK not to like someone but it is NEVER OK to try and degrade, humiliate or dehumanize them.",
    "id" : 475716474963644416,
    "created_at" : "2014-06-08 19:10:20 +0000",
    "user" : {
      "name" : "Cory Booker",
      "screen_name" : "CoryBooker",
      "protected" : false,
      "id_str" : "15808765",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/694587770812104704\/2fOI9t5R_normal.jpg",
      "id" : 15808765,
      "verified" : true
    }
  },
  "id" : 475718895643271168,
  "created_at" : "2014-06-08 19:19:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "freedom",
      "indices" : [ 83, 91 ]
    }, {
      "text" : "choice",
      "indices" : [ 92, 99 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475714815311093760",
  "text" : "when in VT in car, saw road worker smoking cig while holding sign.. made me happy. #freedom #choice",
  "id" : 475714815311093760,
  "created_at" : "2014-06-08 19:03:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil Randall",
      "screen_name" : "NARandall1",
      "indices" : [ 3, 14 ],
      "id_str" : "589203492",
      "id" : 589203492
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 90, 95 ]
    } ],
    "urls" : [ {
      "indices" : [ 106, 129 ],
      "url" : "https:\/\/t.co\/7nC9UCqjwc",
      "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/440959",
      "display_url" : "smashwords.com\/books\/view\/440\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "475713997551853569",
  "text" : "RT @NARandall1: To mark the release of THE HOLY DRINKER, TALES OF ORDINARY SADNESS is now #free to d\/load https:\/\/t.co\/7nC9UCqjwc http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/NARandall1\/status\/475711938773921792\/photo\/1",
        "indices" : [ 114, 136 ],
        "url" : "http:\/\/t.co\/qRqhtJC6WO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpoRfIkCYAA3Nnr.jpg",
        "id_str" : "475711937213259776",
        "id" : 475711937213259776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpoRfIkCYAA3Nnr.jpg",
        "sizes" : [ {
          "h" : 558,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 360
        }, {
          "h" : 527,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 558,
          "resize" : "fit",
          "w" : 360
        } ],
        "display_url" : "pic.twitter.com\/qRqhtJC6WO"
      } ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 74, 79 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 113 ],
        "url" : "https:\/\/t.co\/7nC9UCqjwc",
        "expanded_url" : "https:\/\/www.smashwords.com\/books\/view\/440959",
        "display_url" : "smashwords.com\/books\/view\/440\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "475711938773921792",
    "text" : "To mark the release of THE HOLY DRINKER, TALES OF ORDINARY SADNESS is now #free to d\/load https:\/\/t.co\/7nC9UCqjwc http:\/\/t.co\/qRqhtJC6WO",
    "id" : 475711938773921792,
    "created_at" : "2014-06-08 18:52:19 +0000",
    "user" : {
      "name" : "Neil Randall",
      "screen_name" : "NARandall1",
      "protected" : false,
      "id_str" : "589203492",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535085234169995264\/JpWPxiQx_normal.jpeg",
      "id" : 589203492,
      "verified" : false
    }
  },
  "id" : 475713997551853569,
  "created_at" : "2014-06-08 19:00:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael Willis",
      "screen_name" : "MichaelinMERICA",
      "indices" : [ 2, 18 ],
      "id_str" : "18462514",
      "id" : 18462514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475143750831063040",
  "geo" : { },
  "id_str" : "475713491253223424",
  "in_reply_to_user_id" : 18462514,
  "text" : ". @MichaelinMERICA @Justinsweh WTH? o-O",
  "id" : 475713491253223424,
  "in_reply_to_status_id" : 475143750831063040,
  "created_at" : "2014-06-08 18:58:29 +0000",
  "in_reply_to_screen_name" : "MichaelinMERICA",
  "in_reply_to_user_id_str" : "18462514",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "indices" : [ 3, 17 ],
      "id_str" : "1963095853",
      "id" : 1963095853
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/475660412881743872\/photo\/1",
      "indices" : [ 61, 83 ],
      "url" : "http:\/\/t.co\/S2DTdKRkYU",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpnin4VIUAEG3S2.jpg",
      "id_str" : "475660410428084225",
      "id" : 475660410428084225,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpnin4VIUAEG3S2.jpg",
      "sizes" : [ {
        "h" : 253,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 526
      }, {
        "h" : 392,
        "resize" : "fit",
        "w" : 526
      } ],
      "display_url" : "pic.twitter.com\/S2DTdKRkYU"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475663164827115521",
  "text" : "RT @jacqueduncalf: Please help my friend Marie to find Lola! http:\/\/t.co\/S2DTdKRkYU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/jacqueduncalf\/status\/475660412881743872\/photo\/1",
        "indices" : [ 42, 64 ],
        "url" : "http:\/\/t.co\/S2DTdKRkYU",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpnin4VIUAEG3S2.jpg",
        "id_str" : "475660410428084225",
        "id" : 475660410428084225,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpnin4VIUAEG3S2.jpg",
        "sizes" : [ {
          "h" : 253,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 526
        }, {
          "h" : 392,
          "resize" : "fit",
          "w" : 526
        } ],
        "display_url" : "pic.twitter.com\/S2DTdKRkYU"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475660412881743872",
    "text" : "Please help my friend Marie to find Lola! http:\/\/t.co\/S2DTdKRkYU",
    "id" : 475660412881743872,
    "created_at" : "2014-06-08 15:27:34 +0000",
    "user" : {
      "name" : "jacqueline duncalf",
      "screen_name" : "jacqueduncalf",
      "protected" : false,
      "id_str" : "1963095853",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/619214923382583296\/q09G0g_S_normal.png",
      "id" : 1963095853,
      "verified" : false
    }
  },
  "id" : 475663164827115521,
  "created_at" : "2014-06-08 15:38:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475662191031353347",
  "text" : "we have amazon prime so at least we didnt pay extra for the shipping. but still disappointed...",
  "id" : 475662191031353347,
  "created_at" : "2014-06-08 15:34:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475661841792643073",
  "text" : "bleh.. (bday) pkg I sent from amazon w 2 day shipping (fedex) didnt get delivered yesterday. : (",
  "id" : 475661841792643073,
  "created_at" : "2014-06-08 15:33:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "475659270810505216",
  "geo" : { },
  "id_str" : "475660776674312193",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater i want to smooch those precious heads!",
  "id" : 475660776674312193,
  "in_reply_to_status_id" : 475659270810505216,
  "created_at" : "2014-06-08 15:29:01 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bryan Henry",
      "screen_name" : "lightgood",
      "indices" : [ 3, 13 ],
      "id_str" : "20303017",
      "id" : 20303017
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lightgood\/status\/475324675577626624\/photo\/1",
      "indices" : [ 56, 78 ],
      "url" : "http:\/\/t.co\/H3x34cSqBk",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpixRiIIIAAiShY.jpg",
      "id_str" : "475324675464372224",
      "id" : 475324675464372224,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpixRiIIIAAiShY.jpg",
      "sizes" : [ {
        "h" : 331,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 468
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 240,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 331,
        "resize" : "fit",
        "w" : 468
      } ],
      "display_url" : "pic.twitter.com\/H3x34cSqBk"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475325849634217984",
  "text" : "RT @lightgood: Imagine if Obama did this... Oh Lordy... http:\/\/t.co\/H3x34cSqBk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EiOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lightgood\/status\/475324675577626624\/photo\/1",
        "indices" : [ 41, 63 ],
        "url" : "http:\/\/t.co\/H3x34cSqBk",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpixRiIIIAAiShY.jpg",
        "id_str" : "475324675464372224",
        "id" : 475324675464372224,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpixRiIIIAAiShY.jpg",
        "sizes" : [ {
          "h" : 331,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 468
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 240,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 331,
          "resize" : "fit",
          "w" : 468
        } ],
        "display_url" : "pic.twitter.com\/H3x34cSqBk"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "475324675577626624",
    "text" : "Imagine if Obama did this... Oh Lordy... http:\/\/t.co\/H3x34cSqBk",
    "id" : 475324675577626624,
    "created_at" : "2014-06-07 17:13:28 +0000",
    "user" : {
      "name" : "Bryan Henry",
      "screen_name" : "lightgood",
      "protected" : false,
      "id_str" : "20303017",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/678935516729970692\/dfsUaO61_normal.jpg",
      "id" : 20303017,
      "verified" : false
    }
  },
  "id" : 475325849634217984,
  "created_at" : "2014-06-07 17:18:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CIA",
      "screen_name" : "CIA",
      "indices" : [ 3, 7 ],
      "id_str" : "2359926157",
      "id" : 2359926157
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "475289082642169856",
  "text" : "RT @CIA: We can neither confirm nor deny that this is our first tweet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474971393852182528",
    "text" : "We can neither confirm nor deny that this is our first tweet.",
    "id" : 474971393852182528,
    "created_at" : "2014-06-06 17:49:39 +0000",
    "user" : {
      "name" : "CIA",
      "screen_name" : "CIA",
      "protected" : false,
      "id_str" : "2359926157",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/474250448757481472\/QcQ_P01E_normal.jpeg",
      "id" : 2359926157,
      "verified" : true
    }
  },
  "id" : 475289082642169856,
  "created_at" : "2014-06-07 14:52:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Read",
      "screen_name" : "traread",
      "indices" : [ 3, 11 ],
      "id_str" : "37361536",
      "id" : 37361536
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/traread\/status\/474772173354041344\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/jrOJNiUmjH",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpa6xlUCQAAok6Q.jpg",
      "id_str" : "474772171726667776",
      "id" : 474772171726667776,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpa6xlUCQAAok6Q.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 488,
        "resize" : "fit",
        "w" : 650
      } ],
      "display_url" : "pic.twitter.com\/jrOJNiUmjH"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474932902631710721",
  "text" : "RT @traread: I never realized that the Chicago Bulls logo flipped upside-down looks like a robot reading the bible... http:\/\/t.co\/jrOJNiUmjH",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/traread\/status\/474772173354041344\/photo\/1",
        "indices" : [ 105, 127 ],
        "url" : "http:\/\/t.co\/jrOJNiUmjH",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Bpa6xlUCQAAok6Q.jpg",
        "id_str" : "474772171726667776",
        "id" : 474772171726667776,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Bpa6xlUCQAAok6Q.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 488,
          "resize" : "fit",
          "w" : 650
        } ],
        "display_url" : "pic.twitter.com\/jrOJNiUmjH"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474772173354041344",
    "text" : "I never realized that the Chicago Bulls logo flipped upside-down looks like a robot reading the bible... http:\/\/t.co\/jrOJNiUmjH",
    "id" : 474772173354041344,
    "created_at" : "2014-06-06 04:38:01 +0000",
    "user" : {
      "name" : "Tom Read",
      "screen_name" : "traread",
      "protected" : false,
      "id_str" : "37361536",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631688862\/8f234e19112825a502e926207615e433_normal.jpeg",
      "id" : 37361536,
      "verified" : false
    }
  },
  "id" : 474932902631710721,
  "created_at" : "2014-06-06 15:16:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AIG",
      "indices" : [ 103, 107 ]
    }, {
      "text" : "KenHam",
      "indices" : [ 108, 115 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 102 ],
      "url" : "http:\/\/t.co\/IdB67C5xbX",
      "expanded_url" : "http:\/\/shar.es\/P3K6s",
      "display_url" : "shar.es\/P3K6s"
    } ]
  },
  "geo" : { },
  "id_str" : "474660331411619840",
  "text" : "Sinking Ship?: Creationist Ministry Continues To Over-Promise On Ky. \u2018Ark Park\u2019 http:\/\/t.co\/IdB67C5xbX #AIG #KenHam",
  "id" : 474660331411619840,
  "created_at" : "2014-06-05 21:13:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/474655858241327105\/photo\/1",
      "indices" : [ 69, 91 ],
      "url" : "http:\/\/t.co\/2xaZDaLkrn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZQ_JUIQAAdhch.jpg",
      "id_str" : "474655856496492544",
      "id" : 474655856496492544,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZQ_JUIQAAdhch.jpg",
      "sizes" : [ {
        "h" : 226,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 399,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 639,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/2xaZDaLkrn"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474656248902590464",
  "text" : "RT @CUMALi_YILDIZ: A very GOOD MORNING to you from Samsun, Blacksea! http:\/\/t.co\/2xaZDaLkrn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/474655858241327105\/photo\/1",
        "indices" : [ 50, 72 ],
        "url" : "http:\/\/t.co\/2xaZDaLkrn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpZQ_JUIQAAdhch.jpg",
        "id_str" : "474655856496492544",
        "id" : 474655856496492544,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpZQ_JUIQAAdhch.jpg",
        "sizes" : [ {
          "h" : 226,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 399,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 639,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/2xaZDaLkrn"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474655858241327105",
    "text" : "A very GOOD MORNING to you from Samsun, Blacksea! http:\/\/t.co\/2xaZDaLkrn",
    "id" : 474655858241327105,
    "created_at" : "2014-06-05 20:55:49 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 474656248902590464,
  "created_at" : "2014-06-05 20:57:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Antitheist",
      "screen_name" : "Thee_Antitheist",
      "indices" : [ 3, 19 ],
      "id_str" : "2344499587",
      "id" : 2344499587
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 139 ],
      "url" : "https:\/\/t.co\/h8Td8Nad5C",
      "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SN72nJhyr3A",
      "display_url" : "youtube.com\/watch?v=SN72nJ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "474632701694078976",
  "text" : "RT @Thee_Antitheist: World's creepiest pastor...but in religion its not that creepy at all,he's the run of the mill.https:\/\/t.co\/h8Td8Nad5C",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 118 ],
        "url" : "https:\/\/t.co\/h8Td8Nad5C",
        "expanded_url" : "https:\/\/www.youtube.com\/watch?v=SN72nJhyr3A",
        "display_url" : "youtube.com\/watch?v=SN72nJ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "474629773373607936",
    "text" : "World's creepiest pastor...but in religion its not that creepy at all,he's the run of the mill.https:\/\/t.co\/h8Td8Nad5C",
    "id" : 474629773373607936,
    "created_at" : "2014-06-05 19:12:10 +0000",
    "user" : {
      "name" : "Antitheist",
      "screen_name" : "Thee_Antitheist",
      "protected" : false,
      "id_str" : "2344499587",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740742481180909570\/lFh5qWde_normal.jpg",
      "id" : 2344499587,
      "verified" : false
    }
  },
  "id" : 474632701694078976,
  "created_at" : "2014-06-05 19:23:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "indices" : [ 3, 12 ],
      "id_str" : "889536330",
      "id" : 889536330
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/474611635420942336\/photo\/1",
      "indices" : [ 52, 74 ],
      "url" : "http:\/\/t.co\/Pcjr9BOsQn",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYoxBKIQAIDDfe.jpg",
      "id_str" : "474611633323786242",
      "id" : 474611633323786242,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYoxBKIQAIDDfe.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/Pcjr9BOsQn"
    } ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 46, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474613105167564801",
  "text" : "RT @rm123077: If only everyone just would.... #love http:\/\/t.co\/Pcjr9BOsQn",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/rm123077\/status\/474611635420942336\/photo\/1",
        "indices" : [ 38, 60 ],
        "url" : "http:\/\/t.co\/Pcjr9BOsQn",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYoxBKIQAIDDfe.jpg",
        "id_str" : "474611633323786242",
        "id" : 474611633323786242,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYoxBKIQAIDDfe.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/Pcjr9BOsQn"
      } ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 32, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474611635420942336",
    "text" : "If only everyone just would.... #love http:\/\/t.co\/Pcjr9BOsQn",
    "id" : 474611635420942336,
    "created_at" : "2014-06-05 18:00:06 +0000",
    "user" : {
      "name" : "thefarmerswife",
      "screen_name" : "rm123077",
      "protected" : false,
      "id_str" : "889536330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/703067591871324160\/8qFj3gUf_normal.jpg",
      "id" : 889536330,
      "verified" : false
    }
  },
  "id" : 474613105167564801,
  "created_at" : "2014-06-05 18:05:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474580332943904768",
  "text" : "last night in a dream i was singing \"end of the world\" by REM. i was trying to stop ppl from shooting a laser thing which wld end the world.",
  "id" : 474580332943904768,
  "created_at" : "2014-06-05 15:55:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Affirmation",
      "indices" : [ 20, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474575607884304385",
  "text" : "RT @Emmanueldagher: #Affirmation: Dear Universe, expand my capacity to share great compassion with all humanity including myself. http:\/\/t.\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/Emmanueldagher\/status\/474574403850600448\/photo\/1",
        "indices" : [ 110, 132 ],
        "url" : "http:\/\/t.co\/JnGhze0DOw",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpYG57CIUAA9mlW.jpg",
        "id_str" : "474574402903101440",
        "id" : 474574402903101440,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpYG57CIUAA9mlW.jpg",
        "sizes" : [ {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/JnGhze0DOw"
      } ],
      "hashtags" : [ {
        "text" : "Affirmation",
        "indices" : [ 0, 12 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474574403850600448",
    "text" : "#Affirmation: Dear Universe, expand my capacity to share great compassion with all humanity including myself. http:\/\/t.co\/JnGhze0DOw",
    "id" : 474574403850600448,
    "created_at" : "2014-06-05 15:32:09 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 474575607884304385,
  "created_at" : "2014-06-05 15:36:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474573693017149440",
  "geo" : { },
  "id_str" : "474574593689006080",
  "in_reply_to_user_id" : 246103,
  "text" : "@JeffreyGuterman absolutely! everyone needs to find their own way.. whatever path works for them.",
  "id" : 474574593689006080,
  "in_reply_to_status_id" : 474573693017149440,
  "created_at" : "2014-06-05 15:32:54 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "zen",
      "indices" : [ 37, 41 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474565718961582080",
  "geo" : { },
  "id_str" : "474573492357451777",
  "in_reply_to_user_id" : 246103,
  "text" : "@JeffreyGuterman true.. that's where #zen and living in the now comes in. another concept that i was slow to grasp..lol",
  "id" : 474573492357451777,
  "in_reply_to_status_id" : 474565718961582080,
  "created_at" : "2014-06-05 15:28:32 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 2, 18 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eink",
      "indices" : [ 54, 59 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474561782565339136",
  "geo" : { },
  "id_str" : "474565026347360256",
  "in_reply_to_user_id" : 111579405,
  "text" : ". @thDigitalReader but it's still a tablet, right? no #eink on it? gah. just another tablet then..",
  "id" : 474565026347360256,
  "in_reply_to_status_id" : 474561782565339136,
  "created_at" : "2014-06-05 14:54:53 +0000",
  "in_reply_to_screen_name" : "thDigitalReader",
  "in_reply_to_user_id_str" : "111579405",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474564308626444288",
  "in_reply_to_user_id" : 246103,
  "text" : "@JeffreyGuterman I took awhile to realize I needed to accept and love myself. : )",
  "id" : 474564308626444288,
  "created_at" : "2014-06-05 14:52:02 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474563859194200064",
  "in_reply_to_user_id" : 246103,
  "text" : "@JeffreyGuterman when i was an unhappy teen, i used to think someone would \"save me\" and make it better...",
  "id" : 474563859194200064,
  "created_at" : "2014-06-05 14:50:15 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474563655124545536",
  "in_reply_to_user_id" : 246103,
  "text" : "@JeffreyGuterman looking outside ourselves for answers (for love?) is not the answer.",
  "id" : 474563655124545536,
  "created_at" : "2014-06-05 14:49:27 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Heather Pyle",
      "screen_name" : "hapdoc",
      "indices" : [ 3, 10 ],
      "id_str" : "63853156",
      "id" : 63853156
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/hapdoc\/status\/474555666422849536\/photo\/1",
      "indices" : [ 33, 55 ],
      "url" : "http:\/\/t.co\/I15Y37tFkx",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpX13TzIcAEHo6r.jpg",
      "id_str" : "474555666313801729",
      "id" : 474555666313801729,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpX13TzIcAEHo6r.jpg",
      "sizes" : [ {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      } ],
      "display_url" : "pic.twitter.com\/I15Y37tFkx"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474559075208798208",
  "text" : "RT @hapdoc: Still rings true.... http:\/\/t.co\/I15Y37tFkx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for i\u039FS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/hapdoc\/status\/474555666422849536\/photo\/1",
        "indices" : [ 21, 43 ],
        "url" : "http:\/\/t.co\/I15Y37tFkx",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpX13TzIcAEHo6r.jpg",
        "id_str" : "474555666313801729",
        "id" : 474555666313801729,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpX13TzIcAEHo6r.jpg",
        "sizes" : [ {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        } ],
        "display_url" : "pic.twitter.com\/I15Y37tFkx"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474555666422849536",
    "text" : "Still rings true.... http:\/\/t.co\/I15Y37tFkx",
    "id" : 474555666422849536,
    "created_at" : "2014-06-05 14:17:42 +0000",
    "user" : {
      "name" : "Dr. Heather Pyle",
      "screen_name" : "hapdoc",
      "protected" : false,
      "id_str" : "63853156",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3285245920\/95373746323d0e8176d06204ee105d24_normal.jpeg",
      "id" : 63853156,
      "verified" : false
    }
  },
  "id" : 474559075208798208,
  "created_at" : "2014-06-05 14:31:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "indices" : [ 3, 18 ],
      "id_str" : "377540405",
      "id" : 377540405
    }, {
      "name" : "Alexandria",
      "screen_name" : "tomalpat",
      "indices" : [ 23, 32 ],
      "id_str" : "804471787",
      "id" : 804471787
    }, {
      "name" : "Iridescent Heart",
      "screen_name" : "IridescentMind2",
      "indices" : [ 34, 50 ],
      "id_str" : "2326547647",
      "id" : 2326547647
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/IridescentMind2\/status\/473883427284869122\/photo\/1",
      "indices" : [ 51, 73 ],
      "url" : "http:\/\/t.co\/NCtynZMeze",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpOSdz6CYAA9tgz.jpg",
      "id_str" : "473883426651529216",
      "id" : 473883426651529216,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpOSdz6CYAA9tgz.jpg",
      "sizes" : [ {
        "h" : 658,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 658,
        "resize" : "fit",
        "w" : 700
      }, {
        "h" : 564,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 320,
        "resize" : "fit",
        "w" : 340
      } ],
      "display_url" : "pic.twitter.com\/NCtynZMeze"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474558763559432194",
  "text" : "RT @JamiaStarheart: RT @tomalpat: @IridescentMind2 http:\/\/t.co\/NCtynZMeze",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alexandria",
        "screen_name" : "tomalpat",
        "indices" : [ 3, 12 ],
        "id_str" : "804471787",
        "id" : 804471787
      }, {
        "name" : "Iridescent Heart",
        "screen_name" : "IridescentMind2",
        "indices" : [ 14, 30 ],
        "id_str" : "2326547647",
        "id" : 2326547647
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/IridescentMind2\/status\/473883427284869122\/photo\/1",
        "indices" : [ 31, 53 ],
        "url" : "http:\/\/t.co\/NCtynZMeze",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpOSdz6CYAA9tgz.jpg",
        "id_str" : "473883426651529216",
        "id" : 473883426651529216,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpOSdz6CYAA9tgz.jpg",
        "sizes" : [ {
          "h" : 658,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 658,
          "resize" : "fit",
          "w" : 700
        }, {
          "h" : 564,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 320,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/NCtynZMeze"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474556221417324544",
    "text" : "RT @tomalpat: @IridescentMind2 http:\/\/t.co\/NCtynZMeze",
    "id" : 474556221417324544,
    "created_at" : "2014-06-05 14:19:54 +0000",
    "user" : {
      "name" : "FriendofTrees",
      "screen_name" : "JamiaStarheart",
      "protected" : false,
      "id_str" : "377540405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/750758200580804608\/VqITZfgW_normal.png",
      "id" : 377540405,
      "verified" : false
    }
  },
  "id" : 474558763559432194,
  "created_at" : "2014-06-05 14:30:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474555063390580736",
  "text" : "@weakSquare yes?? lol",
  "id" : 474555063390580736,
  "created_at" : "2014-06-05 14:15:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474554662729707520",
  "text" : "so much misunderstanding out there. everything is perception!!",
  "id" : 474554662729707520,
  "created_at" : "2014-06-05 14:13:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cyndella",
      "screen_name" : "red_ink_ranch",
      "indices" : [ 3, 17 ],
      "id_str" : "1488268520",
      "id" : 1488268520
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474553032441466881",
  "text" : "RT @red_ink_ranch: My little friend is now flying still following the mother demanding to fed, reminds of some teenagers I use to have:D ht\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/red_ink_ranch\/status\/473480248970215424\/photo\/1",
        "indices" : [ 118, 140 ],
        "url" : "http:\/\/t.co\/avRPcvI4D4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpIjxugCcAAWaOf.jpg",
        "id_str" : "473480248030294016",
        "id" : 473480248030294016,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpIjxugCcAAWaOf.jpg",
        "sizes" : [ {
          "h" : 227,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 400,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 427,
          "resize" : "fit",
          "w" : 640
        } ],
        "display_url" : "pic.twitter.com\/avRPcvI4D4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "473480248970215424",
    "text" : "My little friend is now flying still following the mother demanding to fed, reminds of some teenagers I use to have:D http:\/\/t.co\/avRPcvI4D4",
    "id" : 473480248970215424,
    "created_at" : "2014-06-02 15:04:22 +0000",
    "user" : {
      "name" : "Cyndella",
      "screen_name" : "red_ink_ranch",
      "protected" : false,
      "id_str" : "1488268520",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/781256576132849664\/5tgcmOvG_normal.jpg",
      "id" : 1488268520,
      "verified" : false
    }
  },
  "id" : 474553032441466881,
  "created_at" : "2014-06-05 14:07:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474551350886289408",
  "text" : "i read something about \"petticoating\" boys yesterday. do ppl really do that?",
  "id" : 474551350886289408,
  "created_at" : "2014-06-05 14:00:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474547492525060098",
  "geo" : { },
  "id_str" : "474549852232097792",
  "in_reply_to_user_id" : 93747129,
  "text" : "@JeffreyGuterman I feel like I'm watching the Telephone Game gone horribly wrong... : \/",
  "id" : 474549852232097792,
  "in_reply_to_status_id" : 474547492525060098,
  "created_at" : "2014-06-05 13:54:36 +0000",
  "in_reply_to_screen_name" : "moosebegab",
  "in_reply_to_user_id_str" : "93747129",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 0, 16 ],
      "id_str" : "246103",
      "id" : 246103
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474547492525060098",
  "in_reply_to_user_id" : 246103,
  "text" : "@JeffreyGuterman interesting convo going on in your timeline..lol",
  "id" : 474547492525060098,
  "created_at" : "2014-06-05 13:45:13 +0000",
  "in_reply_to_screen_name" : "JeffreyGuterman",
  "in_reply_to_user_id_str" : "246103",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather McCance",
      "screen_name" : "rev_heather",
      "indices" : [ 0, 12 ],
      "id_str" : "27905866",
      "id" : 27905866
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474534969398657024",
  "geo" : { },
  "id_str" : "474544355412168705",
  "in_reply_to_user_id" : 27905866,
  "text" : "@rev_heather (((hugs)))",
  "id" : 474544355412168705,
  "in_reply_to_status_id" : 474534969398657024,
  "created_at" : "2014-06-05 13:32:45 +0000",
  "in_reply_to_screen_name" : "rev_heather",
  "in_reply_to_user_id_str" : "27905866",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "rightspeech",
      "indices" : [ 113, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474543896039407616",
  "text" : "RT @dhammagirl: Use your words to uplift and comfort today..\n\nThat includes your own internal conversations. :)\n\n#rightspeech",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "rightspeech",
        "indices" : [ 97, 109 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474533935469572096",
    "text" : "Use your words to uplift and comfort today..\n\nThat includes your own internal conversations. :)\n\n#rightspeech",
    "id" : 474533935469572096,
    "created_at" : "2014-06-05 12:51:21 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 474543896039407616,
  "created_at" : "2014-06-05 13:30:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "indices" : [ 3, 19 ],
      "id_str" : "246103",
      "id" : 246103
    }, {
      "name" : "JustVisiting",
      "screen_name" : "woznyjs",
      "indices" : [ 23, 31 ],
      "id_str" : "2215219752",
      "id" : 2215219752
    }, {
      "name" : "Richard Dawkins",
      "screen_name" : "RichardDawkins",
      "indices" : [ 32, 47 ],
      "id_str" : "15143478",
      "id" : 15143478
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474542431505899521",
  "text" : "RT @JeffreyGuterman: . @woznyjs @RichardDawkins There are no objective standards of what is moral: right or wrong, good or bad; it depends \u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JustVisiting",
        "screen_name" : "woznyjs",
        "indices" : [ 2, 10 ],
        "id_str" : "2215219752",
        "id" : 2215219752
      }, {
        "name" : "Richard Dawkins",
        "screen_name" : "RichardDawkins",
        "indices" : [ 11, 26 ],
        "id_str" : "15143478",
        "id" : 15143478
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "474536707631906816",
    "geo" : { },
    "id_str" : "474538502751670272",
    "in_reply_to_user_id" : 2215219752,
    "text" : ". @woznyjs @RichardDawkins There are no objective standards of what is moral: right or wrong, good or bad; it depends on who is defining.",
    "id" : 474538502751670272,
    "in_reply_to_status_id" : 474536707631906816,
    "created_at" : "2014-06-05 13:09:30 +0000",
    "in_reply_to_screen_name" : "woznyjs",
    "in_reply_to_user_id_str" : "2215219752",
    "user" : {
      "name" : "Jeffrey Guterman",
      "screen_name" : "JeffreyGuterman",
      "protected" : false,
      "id_str" : "246103",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733422221889179648\/rrTOT7vZ_normal.jpg",
      "id" : 246103,
      "verified" : true
    }
  },
  "id" : 474542431505899521,
  "created_at" : "2014-06-05 13:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474237805749469184",
  "text" : "now im writing it in calendar along with time. 300mg of effexor is no fun. weakness, nausea. i wasnt as sick as last time, tho. so not sure.",
  "id" : 474237805749469184,
  "created_at" : "2014-06-04 17:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474237232300052480",
  "text" : "i usually have my pills in a 1 week container. i also have reminders on all my devices (to take pill.) but didnt take that container.",
  "id" : 474237232300052480,
  "created_at" : "2014-06-04 17:12:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474236751028830211",
  "text" : "i think i accidentally doubled my effexor on sunday. took ill that afternoon. feeling better but still not normal yet. gah. stupid.",
  "id" : 474236751028830211,
  "created_at" : "2014-06-04 17:10:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "indices" : [ 3, 17 ],
      "id_str" : "109003770",
      "id" : 109003770
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/474235845076320256\/photo\/1",
      "indices" : [ 75, 97 ],
      "url" : "http:\/\/t.co\/P9E4HGzMd1",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpTS_KfCIAANYcb.jpg",
      "id_str" : "474235843368853504",
      "id" : 474235843368853504,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpTS_KfCIAANYcb.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 386,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 440
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 440
      } ],
      "display_url" : "pic.twitter.com\/P9E4HGzMd1"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474236239223091202",
  "text" : "RT @CUMALi_YILDIZ: Sun Halo Moilanen arc  Oslo, Norway  Photo by: Zen Roxy http:\/\/t.co\/P9E4HGzMd1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/CUMALi_YILDIZ\/status\/474235845076320256\/photo\/1",
        "indices" : [ 56, 78 ],
        "url" : "http:\/\/t.co\/P9E4HGzMd1",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpTS_KfCIAANYcb.jpg",
        "id_str" : "474235843368853504",
        "id" : 474235843368853504,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpTS_KfCIAANYcb.jpg",
        "sizes" : [ {
          "h" : 500,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 386,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 440
        }, {
          "h" : 500,
          "resize" : "fit",
          "w" : 440
        } ],
        "display_url" : "pic.twitter.com\/P9E4HGzMd1"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "474235845076320256",
    "text" : "Sun Halo Moilanen arc  Oslo, Norway  Photo by: Zen Roxy http:\/\/t.co\/P9E4HGzMd1",
    "id" : 474235845076320256,
    "created_at" : "2014-06-04 17:06:51 +0000",
    "user" : {
      "name" : "Cumali",
      "screen_name" : "CUMALi_YILDIZ",
      "protected" : false,
      "id_str" : "109003770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/714881535984476160\/6Z65_cyA_normal.jpg",
      "id" : 109003770,
      "verified" : false
    }
  },
  "id" : 474236239223091202,
  "created_at" : "2014-06-04 17:08:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BrianMerritt",
      "screen_name" : "BrianMerritt",
      "indices" : [ 2, 15 ],
      "id_str" : "15364301",
      "id" : 15364301
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "prescriptions",
      "indices" : [ 107, 121 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 48 ],
      "url" : "http:\/\/t.co\/IK6hKI0bAm",
      "expanded_url" : "http:\/\/healthwarehouse.com",
      "display_url" : "healthwarehouse.com"
    } ]
  },
  "geo" : { },
  "id_str" : "474208487786815488",
  "text" : ". @BrianMerritt look into http:\/\/t.co\/IK6hKI0bAm .. i was getting my effexor from them very inexpensively. #prescriptions",
  "id" : 474208487786815488,
  "created_at" : "2014-06-04 15:18:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474205577535451136",
  "text" : "i need to read up on this John Shelby Spong. He sounds like someone right up my alley. : )",
  "id" : 474205577535451136,
  "created_at" : "2014-06-04 15:06:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "johnshelbyspong",
      "indices" : [ 127, 143 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 126 ],
      "url" : "http:\/\/t.co\/K86rrsKcPi",
      "expanded_url" : "http:\/\/youtu.be\/LkaH3hEmV3M",
      "display_url" : "youtu.be\/LkaH3hEmV3M"
    } ]
  },
  "geo" : { },
  "id_str" : "474203289752305664",
  "text" : "love what he says! &gt;&gt; Priest says Hell is an invention of the church to control people with fear: http:\/\/t.co\/K86rrsKcPi #johnshelbyspong",
  "id" : 474203289752305664,
  "created_at" : "2014-06-04 14:57:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474200246650544129",
  "text" : "dear Universe, fill me with compassion, so much so that there is no room for anything else. thank you!",
  "id" : 474200246650544129,
  "created_at" : "2014-06-04 14:45:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 2, 14 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "474198489186840576",
  "geo" : { },
  "id_str" : "474199602623553536",
  "in_reply_to_user_id" : 71118021,
  "text" : ". @CaroleODell some ppl are stuck and I notice those are the ones not so happy. i think we need to change for emotional\/spiritual health.",
  "id" : 474199602623553536,
  "in_reply_to_status_id" : 474198489186840576,
  "created_at" : "2014-06-04 14:42:50 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474198809497440256",
  "text" : "shedding our skins as we outgrow them... if you're not shedding, you're stagnating.",
  "id" : 474198809497440256,
  "created_at" : "2014-06-04 14:39:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474198427782246400",
  "text" : "all of life is a journey, discovery. its about trying different things and keeping or discarding as we see fit.",
  "id" : 474198427782246400,
  "created_at" : "2014-06-04 14:38:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "474197361686618112",
  "text" : "i was challenged this past weekend to see who i really am. to see how ive changed and what needs work.",
  "id" : 474197361686618112,
  "created_at" : "2014-06-04 14:33:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Big Draw",
      "screen_name" : "The_Big_Draw",
      "indices" : [ 3, 16 ],
      "id_str" : "145593132",
      "id" : 145593132
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/The_Big_Draw\/status\/473401661655089152\/photo\/1",
      "indices" : [ 118, 140 ],
      "url" : "http:\/\/t.co\/l3pbTxhJyR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/BpHcTPJCIAAlHZy.png",
      "id_str" : "473401658890657792",
      "id" : 473401658890657792,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpHcTPJCIAAlHZy.png",
      "sizes" : [ {
        "h" : 180,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 153,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 180,
        "resize" : "fit",
        "w" : 400
      } ],
      "display_url" : "pic.twitter.com\/l3pbTxhJyR"
    } ],
    "hashtags" : [ {
      "text" : "drawing",
      "indices" : [ 90, 98 ]
    }, {
      "text" : "illustration",
      "indices" : [ 99, 112 ]
    }, {
      "text" : "art",
      "indices" : [ 113, 117 ]
    } ],
    "urls" : [ {
      "indices" : [ 67, 89 ],
      "url" : "http:\/\/t.co\/QC54bImqOg",
      "expanded_url" : "http:\/\/www.thebigdraw.org",
      "display_url" : "thebigdraw.org"
    } ]
  },
  "geo" : { },
  "id_str" : "473858836504535040",
  "text" : "RT @The_Big_Draw: Please RT. Introducing the new Big Draw website! http:\/\/t.co\/QC54bImqOg #drawing #illustration #art http:\/\/t.co\/l3pbTxhJyR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/The_Big_Draw\/status\/473401661655089152\/photo\/1",
        "indices" : [ 100, 122 ],
        "url" : "http:\/\/t.co\/l3pbTxhJyR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/BpHcTPJCIAAlHZy.png",
        "id_str" : "473401658890657792",
        "id" : 473401658890657792,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/BpHcTPJCIAAlHZy.png",
        "sizes" : [ {
          "h" : 180,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 153,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 400
        }, {
          "h" : 180,
          "resize" : "fit",
          "w" : 400
        } ],
        "display_url" : "pic.twitter.com\/l3pbTxhJyR"
      } ],
      "hashtags" : [ {
        "text" : "drawing",
        "indices" : [ 72, 80 ]
      }, {
        "text" : "illustration",
        "indices" : [ 81, 94 ]
      }, {
        "text" : "art",
        "indices" : [ 95, 99 ]
      } ],
      "urls" : [ {
        "indices" : [ 49, 71 ],
        "url" : "http:\/\/t.co\/QC54bImqOg",
        "expanded_url" : "http:\/\/www.thebigdraw.org",
        "display_url" : "thebigdraw.org"
      } ]
    },
    "geo" : { },
    "id_str" : "473401661655089152",
    "text" : "Please RT. Introducing the new Big Draw website! http:\/\/t.co\/QC54bImqOg #drawing #illustration #art http:\/\/t.co\/l3pbTxhJyR",
    "id" : 473401661655089152,
    "created_at" : "2014-06-02 09:52:06 +0000",
    "user" : {
      "name" : "The Big Draw",
      "screen_name" : "The_Big_Draw",
      "protected" : false,
      "id_str" : "145593132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/665540916539691008\/SQiCGOcK_normal.jpg",
      "id" : 145593132,
      "verified" : false
    }
  },
  "id" : 473858836504535040,
  "created_at" : "2014-06-03 16:08:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "backhome",
      "indices" : [ 104, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "473840112053145601",
  "text" : "im not used to being away from DH.. and i decided i definitely dont like it. he truly is my other half. #backhome",
  "id" : 473840112053145601,
  "created_at" : "2014-06-03 14:54:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]