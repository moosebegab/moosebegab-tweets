Grailbird.data.tweets_2012_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Etsy",
      "indices" : [ 62, 67 ]
    }, {
      "text" : "Giveaway",
      "indices" : [ 68, 77 ]
    }, {
      "text" : "win",
      "indices" : [ 100, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/beRmq6Ut",
      "expanded_url" : "http:\/\/ow.ly\/1FfPgD",
      "display_url" : "ow.ly\/1FfPgD"
    } ]
  },
  "geo" : { },
  "id_str" : "164453837984382977",
  "text" : "RT @JAScribbles: Awesome Book Crafts - I'm Drooling - Plus an #Etsy #Giveaway http:\/\/t.co\/beRmq6Ut  #win",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Etsy",
        "indices" : [ 45, 50 ]
      }, {
        "text" : "Giveaway",
        "indices" : [ 51, 60 ]
      }, {
        "text" : "win",
        "indices" : [ 83, 87 ]
      } ],
      "urls" : [ {
        "indices" : [ 61, 81 ],
        "url" : "http:\/\/t.co\/beRmq6Ut",
        "expanded_url" : "http:\/\/ow.ly\/1FfPgD",
        "display_url" : "ow.ly\/1FfPgD"
      } ]
    },
    "geo" : { },
    "id_str" : "164451933187358721",
    "text" : "Awesome Book Crafts - I'm Drooling - Plus an #Etsy #Giveaway http:\/\/t.co\/beRmq6Ut  #win",
    "id" : 164451933187358721,
    "created_at" : "2012-01-31 20:56:10 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 164453837984382977,
  "created_at" : "2012-01-31 21:03:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    }, {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 63, 76 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ShortyAward",
      "indices" : [ 83, 95 ]
    }, {
      "text" : "AUTHOR",
      "indices" : [ 99, 106 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164440745233756161",
  "text" : "RT @UnseeingEyes: Did you VOTE for =V=? Just Tweet: I nominate @UnSeeingEyes for a #ShortyAward in #AUTHOR because...(& write your reaso ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vincenzo Scipioni",
        "screen_name" : "UnseeingEyes",
        "indices" : [ 45, 58 ],
        "id_str" : "36008885",
        "id" : 36008885
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ShortyAward",
        "indices" : [ 65, 77 ]
      }, {
        "text" : "AUTHOR",
        "indices" : [ 81, 88 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164439040693780481",
    "text" : "Did you VOTE for =V=? Just Tweet: I nominate @UnSeeingEyes for a #ShortyAward in #AUTHOR because...(& write your reason here!)",
    "id" : 164439040693780481,
    "created_at" : "2012-01-31 20:04:57 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 164440745233756161,
  "created_at" : "2012-01-31 20:11:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "USA TODAY",
      "screen_name" : "USATODAY",
      "indices" : [ 70, 79 ],
      "id_str" : "15754281",
      "id" : 15754281
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/LIZbPmlY",
      "expanded_url" : "http:\/\/usat.ly\/zuZXm3",
      "display_url" : "usat.ly\/zuZXm3"
    } ]
  },
  "geo" : { },
  "id_str" : "164439070724988928",
  "text" : "Traumatized turtle gets new fiberglass shell http:\/\/t.co\/LIZbPmlY via @USATODAY",
  "id" : 164439070724988928,
  "created_at" : "2012-01-31 20:05:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0428\u0443\u0431\u043E\u0434\u0435\u0440\u043E\u0432 \u0412\u0441\u0435\u0441\u043B\u0430\u0432",
      "screen_name" : "bunnymcintosh",
      "indices" : [ 3, 17 ],
      "id_str" : "2822955722",
      "id" : 2822955722
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/Ttha9mPk",
      "expanded_url" : "http:\/\/ow.ly\/8N0sQ",
      "display_url" : "ow.ly\/8N0sQ"
    } ]
  },
  "geo" : { },
  "id_str" : "164426017065271296",
  "text" : "RT @bunnymcintosh: H&M deserves all the bad press it gets for this... http:\/\/t.co\/Ttha9mPk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/Ttha9mPk",
        "expanded_url" : "http:\/\/ow.ly\/8N0sQ",
        "display_url" : "ow.ly\/8N0sQ"
      } ]
    },
    "geo" : { },
    "id_str" : "164424232745451521",
    "text" : "H&M deserves all the bad press it gets for this... http:\/\/t.co\/Ttha9mPk",
    "id" : 164424232745451521,
    "created_at" : "2012-01-31 19:06:06 +0000",
    "user" : {
      "name" : "Allison",
      "screen_name" : "allison_pons",
      "protected" : false,
      "id_str" : "21675573",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713537075212075008\/lZGQwV8b_normal.jpg",
      "id" : 21675573,
      "verified" : false
    }
  },
  "id" : 164426017065271296,
  "created_at" : "2012-01-31 19:13:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "indices" : [ 3, 14 ],
      "id_str" : "283660852",
      "id" : 283660852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/qNs0wHwE",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=t5jw3T3Jy70",
      "display_url" : "youtube.com\/watch?v=t5jw3T\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164424286579339264",
  "text" : "RT @slothville: How would YOU react to a sloth at your party? http:\/\/t.co\/qNs0wHwE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/qNs0wHwE",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=t5jw3T3Jy70",
        "display_url" : "youtube.com\/watch?v=t5jw3T\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164422807466422272",
    "text" : "How would YOU react to a sloth at your party? http:\/\/t.co\/qNs0wHwE",
    "id" : 164422807466422272,
    "created_at" : "2012-01-31 19:00:26 +0000",
    "user" : {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "protected" : false,
      "id_str" : "283660852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529221111280463872\/E06rTIEQ_normal.jpeg",
      "id" : 283660852,
      "verified" : false
    }
  },
  "id" : 164424286579339264,
  "created_at" : "2012-01-31 19:06:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164419067183251456",
  "geo" : { },
  "id_str" : "164419535804440576",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous we need to find you a magic wand that gets rid of these things! ((hugs))",
  "id" : 164419535804440576,
  "in_reply_to_status_id" : 164419067183251456,
  "created_at" : "2012-01-31 18:47:26 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 59, 67 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/RYloCF6w",
      "expanded_url" : "http:\/\/youtu.be\/qrSa6vjjRHo",
      "display_url" : "youtu.be\/qrSa6vjjRHo"
    } ]
  },
  "geo" : { },
  "id_str" : "164403656001720320",
  "text" : "RT @EarthLifeShop: new born deer: http:\/\/t.co\/RYloCF6w via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 40, 48 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/RYloCF6w",
        "expanded_url" : "http:\/\/youtu.be\/qrSa6vjjRHo",
        "display_url" : "youtu.be\/qrSa6vjjRHo"
      } ]
    },
    "geo" : { },
    "id_str" : "164402051919523841",
    "text" : "new born deer: http:\/\/t.co\/RYloCF6w via @youtube",
    "id" : 164402051919523841,
    "created_at" : "2012-01-31 17:37:58 +0000",
    "user" : {
      "name" : "Dagmar Magdalena",
      "screen_name" : "BatyaHavDesign",
      "protected" : false,
      "id_str" : "25688058",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/602426519487647744\/kogV47_M_normal.jpg",
      "id" : 25688058,
      "verified" : false
    }
  },
  "id" : 164403656001720320,
  "created_at" : "2012-01-31 17:44:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wisdom",
      "screen_name" : "ImmortalMasters",
      "indices" : [ 3, 19 ],
      "id_str" : "109191530",
      "id" : 109191530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164349348753313792",
  "text" : "RT @ImmortalMasters: inhale through the 3rd eye, and exhale from the Heart",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164343835068088320",
    "text" : "inhale through the 3rd eye, and exhale from the Heart",
    "id" : 164343835068088320,
    "created_at" : "2012-01-31 13:46:38 +0000",
    "user" : {
      "name" : "Wisdom",
      "screen_name" : "ImmortalMasters",
      "protected" : false,
      "id_str" : "109191530",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3470523743\/198f7ecd49d219ae473ae6035eab4e6f_normal.jpeg",
      "id" : 109191530,
      "verified" : false
    }
  },
  "id" : 164349348753313792,
  "created_at" : "2012-01-31 14:08:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "purplepoetry77",
      "screen_name" : "purplepoetry77",
      "indices" : [ 3, 18 ],
      "id_str" : "2511633660",
      "id" : 2511633660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164347242864582656",
  "text" : "RT @purplepoetry77: I never knew my true value till the doors were all closed and I found myself sitting alone in darkness. That's when  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164345868558925825",
    "text" : "I never knew my true value till the doors were all closed and I found myself sitting alone in darkness. That's when the unveiling began.",
    "id" : 164345868558925825,
    "created_at" : "2012-01-31 13:54:43 +0000",
    "user" : {
      "name" : "poemscape",
      "screen_name" : "poemscape",
      "protected" : true,
      "id_str" : "310624642",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552530565875105796\/G7vcRm1e_normal.jpeg",
      "id" : 310624642,
      "verified" : false
    }
  },
  "id" : 164347242864582656,
  "created_at" : "2012-01-31 14:00:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164345519009828865",
  "text" : "today is bible study day. one never knows what will happen! lol",
  "id" : 164345519009828865,
  "created_at" : "2012-01-31 13:53:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164344691616256000",
  "text" : "RT @LSFProgram: Seek what inspires you",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "164344536930336770",
    "text" : "Seek what inspires you",
    "id" : 164344536930336770,
    "created_at" : "2012-01-31 13:49:25 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 164344691616256000,
  "created_at" : "2012-01-31 13:50:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 127, 135 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 57, 63 ]
    } ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/yDgmOKgB",
      "expanded_url" : "http:\/\/youtu.be\/qP6JDLQF23g",
      "display_url" : "youtu.be\/qP6JDLQF23g"
    } ]
  },
  "geo" : { },
  "id_str" : "164158734690562048",
  "text" : "RT @CharlesBivona: \"I'll mend myself before it gets me.\" #quote Word =&gt; Seether - Rise Above This: http:\/\/t.co\/yDgmOKgB via @youtube",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 108, 116 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 38, 44 ]
      } ],
      "urls" : [ {
        "indices" : [ 83, 103 ],
        "url" : "http:\/\/t.co\/yDgmOKgB",
        "expanded_url" : "http:\/\/youtu.be\/qP6JDLQF23g",
        "display_url" : "youtu.be\/qP6JDLQF23g"
      } ]
    },
    "geo" : { },
    "id_str" : "164157611263012864",
    "text" : "\"I'll mend myself before it gets me.\" #quote Word =&gt; Seether - Rise Above This: http:\/\/t.co\/yDgmOKgB via @youtube",
    "id" : 164157611263012864,
    "created_at" : "2012-01-31 01:26:39 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 164158734690562048,
  "created_at" : "2012-01-31 01:31:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/nM6IAYn7",
      "expanded_url" : "http:\/\/pulse.me\/s\/5vbwQ",
      "display_url" : "pulse.me\/s\/5vbwQ"
    } ]
  },
  "geo" : { },
  "id_str" : "164152701482049536",
  "text" : "RT @Matth3ous: I want one! \uD83D\uDC49Junk-market door as a desk\/table\/streetdoor http:\/\/t.co\/nM6IAYn7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/nM6IAYn7",
        "expanded_url" : "http:\/\/pulse.me\/s\/5vbwQ",
        "display_url" : "pulse.me\/s\/5vbwQ"
      } ]
    },
    "geo" : { },
    "id_str" : "164151771936202752",
    "text" : "I want one! \uD83D\uDC49Junk-market door as a desk\/table\/streetdoor http:\/\/t.co\/nM6IAYn7",
    "id" : 164151771936202752,
    "created_at" : "2012-01-31 01:03:26 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 164152701482049536,
  "created_at" : "2012-01-31 01:07:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164136866206068737",
  "text" : "i am cranky today. dunno why.. everything DH & DD say irritates me!",
  "id" : 164136866206068737,
  "created_at" : "2012-01-31 00:04:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "The White House",
      "screen_name" : "WhiteHouse",
      "indices" : [ 17, 28 ],
      "id_str" : "30313925",
      "id" : 30313925
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164115430284345345",
  "text" : "RT @gemswinc: RT @whitehouse: Starting now: President Obama answers your questions live in  Google+ Hangout from  West Wing. Watch: http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The White House",
        "screen_name" : "WhiteHouse",
        "indices" : [ 3, 14 ],
        "id_str" : "30313925",
        "id" : 30313925
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 118, 138 ],
        "url" : "http:\/\/t.co\/1200ur2U",
        "expanded_url" : "http:\/\/YouTube.com\/Whitehouse",
        "display_url" : "YouTube.com\/Whitehouse"
      } ]
    },
    "geo" : { },
    "id_str" : "164114324443512832",
    "text" : "RT @whitehouse: Starting now: President Obama answers your questions live in  Google+ Hangout from  West Wing. Watch: http:\/\/t.co\/1200ur2U",
    "id" : 164114324443512832,
    "created_at" : "2012-01-30 22:34:38 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 164115430284345345,
  "created_at" : "2012-01-30 22:39:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Maggie Lawrence",
      "screen_name" : "BackyardWisdom",
      "indices" : [ 33, 48 ],
      "id_str" : "77215232",
      "id" : 77215232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Bird",
      "indices" : [ 50, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/s3ojUGjm",
      "expanded_url" : "http:\/\/yfrog.com\/h7dx4cpj",
      "display_url" : "yfrog.com\/h7dx4cpj"
    } ]
  },
  "geo" : { },
  "id_str" : "164083621139988480",
  "text" : "RT @KerriFar: ID Help needed! RT @BackyardWisdom: #Bird folks    my ID is an immature red tail hawk.  Am I right?  http:\/\/t.co\/s3ojUGjm  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Maggie Lawrence",
        "screen_name" : "BackyardWisdom",
        "indices" : [ 19, 34 ],
        "id_str" : "77215232",
        "id" : 77215232
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Bird",
        "indices" : [ 36, 41 ]
      }, {
        "text" : "nature",
        "indices" : [ 122, 129 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/s3ojUGjm",
        "expanded_url" : "http:\/\/yfrog.com\/h7dx4cpj",
        "display_url" : "yfrog.com\/h7dx4cpj"
      } ]
    },
    "geo" : { },
    "id_str" : "164083443817385984",
    "text" : "ID Help needed! RT @BackyardWisdom: #Bird folks    my ID is an immature red tail hawk.  Am I right?  http:\/\/t.co\/s3ojUGjm #nature #wildlife\u201D",
    "id" : 164083443817385984,
    "created_at" : "2012-01-30 20:31:56 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 164083621139988480,
  "created_at" : "2012-01-30 20:32:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/gG5V1JSG",
      "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
      "display_url" : "shortyawards.com\/UnseeingEyes"
    } ]
  },
  "geo" : { },
  "id_str" : "164081240125865985",
  "text" : "RT @UnseeingEyes: Jan 30, 2012...Please VOTE for Twitter's Best Author http:\/\/t.co\/gG5V1JSG ...=V= is 73 votes out of 6th place. http:\/\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/gG5V1JSG",
        "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
        "display_url" : "shortyawards.com\/UnseeingEyes"
      }, {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/SU3Ohgir",
        "expanded_url" : "http:\/\/twitpic.com\/8cggl0",
        "display_url" : "twitpic.com\/8cggl0"
      } ]
    },
    "geo" : { },
    "id_str" : "164064916637089794",
    "text" : "Jan 30, 2012...Please VOTE for Twitter's Best Author http:\/\/t.co\/gG5V1JSG ...=V= is 73 votes out of 6th place. http:\/\/t.co\/SU3Ohgir",
    "id" : 164064916637089794,
    "created_at" : "2012-01-30 19:18:18 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 164081240125865985,
  "created_at" : "2012-01-30 20:23:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NEWS",
      "indices" : [ 99, 104 ]
    } ],
    "urls" : [ {
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/szEqyhV4",
      "expanded_url" : "http:\/\/www.buzzfeed.com\/zekejmiller\/gingrichs-space-colony-may-run-afoul-of-internati",
      "display_url" : "buzzfeed.com\/zekejmiller\/gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "164081043555627009",
  "text" : "RT @UnseeingEyes: Gingrich's Space Colony May Run Afoul Of International Law  http:\/\/t.co\/szEqyhV4 #NEWS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NEWS",
        "indices" : [ 81, 86 ]
      } ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/szEqyhV4",
        "expanded_url" : "http:\/\/www.buzzfeed.com\/zekejmiller\/gingrichs-space-colony-may-run-afoul-of-internati",
        "display_url" : "buzzfeed.com\/zekejmiller\/gi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "164079526622674944",
    "text" : "Gingrich's Space Colony May Run Afoul Of International Law  http:\/\/t.co\/szEqyhV4 #NEWS",
    "id" : 164079526622674944,
    "created_at" : "2012-01-30 20:16:22 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 164081043555627009,
  "created_at" : "2012-01-30 20:22:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/vpbvFtwZ",
      "expanded_url" : "http:\/\/zachsmind.wordpress.com",
      "display_url" : "zachsmind.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "164046969793286144",
  "text" : "RT @ZachsMind: Self publicity tweet: if you haven't checked http:\/\/t.co\/vpbvFtwZ give it a go. I'm working on an ongoing project about c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/vpbvFtwZ",
        "expanded_url" : "http:\/\/zachsmind.wordpress.com",
        "display_url" : "zachsmind.wordpress.com"
      } ]
    },
    "geo" : { },
    "id_str" : "164042835304255489",
    "text" : "Self publicity tweet: if you haven't checked http:\/\/t.co\/vpbvFtwZ give it a go. I'm working on an ongoing project about comedy.",
    "id" : 164042835304255489,
    "created_at" : "2012-01-30 17:50:34 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 164046969793286144,
  "created_at" : "2012-01-30 18:07:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "164043770520801280",
  "geo" : { },
  "id_str" : "164046650812268545",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope Happy Birthday! ((confettifalling)) you're still younger than me! lol",
  "id" : 164046650812268545,
  "in_reply_to_status_id" : 164043770520801280,
  "created_at" : "2012-01-30 18:05:44 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "164025417106329600",
  "text" : "so far, so good.. have successfully transferred over to generic effexor.",
  "id" : 164025417106329600,
  "created_at" : "2012-01-30 16:41:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163780535104180225",
  "geo" : { },
  "id_str" : "163781087187836930",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin ((hugs)) hope yr daughter is feeling better",
  "id" : 163781087187836930,
  "in_reply_to_status_id" : 163780535104180225,
  "created_at" : "2012-01-30 00:30:28 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163777997873229824",
  "geo" : { },
  "id_str" : "163780501180649473",
  "in_reply_to_user_id" : 21884322,
  "text" : "@CelticCamera LOL (im not a sports fan, so.. yeah.)",
  "id" : 163780501180649473,
  "in_reply_to_status_id" : 163777997873229824,
  "created_at" : "2012-01-30 00:28:09 +0000",
  "in_reply_to_screen_name" : "GarethGlynnAsh",
  "in_reply_to_user_id_str" : "21884322",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FREE",
      "indices" : [ 14, 19 ]
    }, {
      "text" : "birds",
      "indices" : [ 94, 100 ]
    }, {
      "text" : "nature",
      "indices" : [ 101, 108 ]
    } ],
    "urls" : [ {
      "indices" : [ 71, 91 ],
      "url" : "http:\/\/t.co\/d2ZCz6QE",
      "expanded_url" : "http:\/\/bit.ly\/yx6Wvn",
      "display_url" : "bit.ly\/yx6Wvn"
    } ]
  },
  "geo" : { },
  "id_str" : "163779879060516864",
  "text" : "RT @KerriFar: #FREE - February Calendar Download featuring Mr Red :) ~ http:\/\/t.co\/d2ZCz6QE ~ #birds #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FREE",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "birds",
        "indices" : [ 80, 86 ]
      }, {
        "text" : "nature",
        "indices" : [ 87, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/d2ZCz6QE",
        "expanded_url" : "http:\/\/bit.ly\/yx6Wvn",
        "display_url" : "bit.ly\/yx6Wvn"
      } ]
    },
    "geo" : { },
    "id_str" : "163777702023802880",
    "text" : "#FREE - February Calendar Download featuring Mr Red :) ~ http:\/\/t.co\/d2ZCz6QE ~ #birds #nature",
    "id" : 163777702023802880,
    "created_at" : "2012-01-30 00:17:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 163779879060516864,
  "created_at" : "2012-01-30 00:25:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163760746273062913",
  "text" : "wow.. the 1 stray was staring down the other and growling. had to put out another serving!",
  "id" : 163760746273062913,
  "created_at" : "2012-01-29 23:09:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "indices" : [ 3, 17 ],
      "id_str" : "22517956",
      "id" : 22517956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/1R6F9sLy",
      "expanded_url" : "http:\/\/bit.ly\/A8e00S",
      "display_url" : "bit.ly\/A8e00S"
    } ]
  },
  "geo" : { },
  "id_str" : "163696356370821120",
  "text" : "RT @holycutenesss: Bunny goes sheepherding http:\/\/t.co\/1R6F9sLy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/1R6F9sLy",
        "expanded_url" : "http:\/\/bit.ly\/A8e00S",
        "display_url" : "bit.ly\/A8e00S"
      } ]
    },
    "geo" : { },
    "id_str" : "163694447165571072",
    "text" : "Bunny goes sheepherding http:\/\/t.co\/1R6F9sLy",
    "id" : 163694447165571072,
    "created_at" : "2012-01-29 18:46:12 +0000",
    "user" : {
      "name" : "Holy Cuteness",
      "screen_name" : "holycutenesss",
      "protected" : false,
      "id_str" : "22517956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1828767982\/photo_normal.jpg",
      "id" : 22517956,
      "verified" : false
    }
  },
  "id" : 163696356370821120,
  "created_at" : "2012-01-29 18:53:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Book Snoop",
      "screen_name" : "TheBookSnoop",
      "indices" : [ 3, 16 ],
      "id_str" : "430718927",
      "id" : 430718927
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Etsy",
      "indices" : [ 30, 35 ]
    }, {
      "text" : "handmade",
      "indices" : [ 46, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/wjoGlNgO",
      "expanded_url" : "http:\/\/thebooksnoop.blogspot.com\/search\/label\/Book%20Crafts",
      "display_url" : "thebooksnoop.blogspot.com\/search\/label\/B\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163675968328839168",
  "text" : "RT @TheBookSnoop: Do you like #Etsy and other #handmade items? Check out my blog category, Books Crafts http:\/\/t.co\/wjoGlNgO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Etsy",
        "indices" : [ 12, 17 ]
      }, {
        "text" : "handmade",
        "indices" : [ 28, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 86, 106 ],
        "url" : "http:\/\/t.co\/wjoGlNgO",
        "expanded_url" : "http:\/\/thebooksnoop.blogspot.com\/search\/label\/Book%20Crafts",
        "display_url" : "thebooksnoop.blogspot.com\/search\/label\/B\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "163674056934178816",
    "text" : "Do you like #Etsy and other #handmade items? Check out my blog category, Books Crafts http:\/\/t.co\/wjoGlNgO",
    "id" : 163674056934178816,
    "created_at" : "2012-01-29 17:25:10 +0000",
    "user" : {
      "name" : "The Book Snoop",
      "screen_name" : "TheBookSnoop",
      "protected" : false,
      "id_str" : "430718927",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1679783899\/book-snoop_crop_normal.jpg",
      "id" : 430718927,
      "verified" : false
    }
  },
  "id" : 163675968328839168,
  "created_at" : "2012-01-29 17:32:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BetsyTrue",
      "screen_name" : "betsytrue",
      "indices" : [ 3, 13 ],
      "id_str" : "26624654",
      "id" : 26624654
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleBoards",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163675919477780480",
  "text" : "RT @betsytrue: #KindleBoards, We're still working the issue with KB down, think it is a problem at the service provider side...  please  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KindleBoards",
        "indices" : [ 0, 13 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163654308347392000",
    "text" : "#KindleBoards, We're still working the issue with KB down, think it is a problem at the service provider side...  please pass the word!",
    "id" : 163654308347392000,
    "created_at" : "2012-01-29 16:06:42 +0000",
    "user" : {
      "name" : "BetsyTrue",
      "screen_name" : "betsytrue",
      "protected" : false,
      "id_str" : "26624654",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797480690723983360\/nRS3t2pM_normal.jpg",
      "id" : 26624654,
      "verified" : false
    }
  },
  "id" : 163675919477780480,
  "created_at" : "2012-01-29 17:32:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 81, 101 ],
      "url" : "http:\/\/t.co\/Gw7cNFED",
      "expanded_url" : "http:\/\/tinyurl.com\/cdxgukl",
      "display_url" : "tinyurl.com\/cdxgukl"
    } ]
  },
  "geo" : { },
  "id_str" : "163652824197103616",
  "text" : "RT @Seeds4Parents: Question EVERYTHING, including what you read in this article, http:\/\/t.co\/Gw7cNFED.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/Gw7cNFED",
        "expanded_url" : "http:\/\/tinyurl.com\/cdxgukl",
        "display_url" : "tinyurl.com\/cdxgukl"
      } ]
    },
    "geo" : { },
    "id_str" : "163652014943911936",
    "text" : "Question EVERYTHING, including what you read in this article, http:\/\/t.co\/Gw7cNFED.",
    "id" : 163652014943911936,
    "created_at" : "2012-01-29 15:57:35 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 163652824197103616,
  "created_at" : "2012-01-29 16:00:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 14, 34 ],
      "url" : "http:\/\/t.co\/zeVFKamN",
      "expanded_url" : "http:\/\/bit.ly\/yun674",
      "display_url" : "bit.ly\/yun674"
    } ]
  },
  "geo" : { },
  "id_str" : "163649536739381250",
  "text" : "Gab's chatter http:\/\/t.co\/zeVFKamN I\u2019m using this blog for my random philosophical chatter.",
  "id" : 163649536739381250,
  "created_at" : "2012-01-29 15:47:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163649014091358208",
  "text" : "RT @By_Bashar: Everything has a reason for being part an event~down to the Tiniest, most infinitesimal detail. Nothing is an accident No ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163646117416927234",
    "text" : "Everything has a reason for being part an event~down to the Tiniest, most infinitesimal detail. Nothing is an accident No exceptions ~bashar",
    "id" : 163646117416927234,
    "created_at" : "2012-01-29 15:34:09 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 163649014091358208,
  "created_at" : "2012-01-29 15:45:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "indices" : [ 3, 15 ],
      "id_str" : "18256901",
      "id" : 18256901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "grateful",
      "indices" : [ 22, 31 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163648386707374080",
  "text" : "RT @deonnakelli: I am #grateful for life lessons, although I am often very slow to learn them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "grateful",
        "indices" : [ 5, 14 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163647720479920129",
    "text" : "I am #grateful for life lessons, although I am often very slow to learn them.",
    "id" : 163647720479920129,
    "created_at" : "2012-01-29 15:40:31 +0000",
    "user" : {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "protected" : false,
      "id_str" : "18256901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796046774813200384\/-eoNtOic_normal.jpg",
      "id" : 18256901,
      "verified" : false
    }
  },
  "id" : 163648386707374080,
  "created_at" : "2012-01-29 15:43:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/D7H9vmnF",
      "expanded_url" : "http:\/\/www.whatisdiaspora.com",
      "display_url" : "whatisdiaspora.com"
    } ]
  },
  "geo" : { },
  "id_str" : "163643289956913152",
  "text" : "Check out diaspora social web.  Privacy-aware and open source http:\/\/t.co\/D7H9vmnF",
  "id" : 163643289956913152,
  "created_at" : "2012-01-29 15:22:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/rdX3fZDg",
      "expanded_url" : "http:\/\/yfrog.com\/espx6jxj",
      "display_url" : "yfrog.com\/espx6jxj"
    } ]
  },
  "geo" : { },
  "id_str" : "163435456724340736",
  "text" : "RT @GaribaldiRous: Fluffy, my friend squirrel, come into the house for a treat today. http:\/\/t.co\/rdX3fZDg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/rdX3fZDg",
        "expanded_url" : "http:\/\/yfrog.com\/espx6jxj",
        "display_url" : "yfrog.com\/espx6jxj"
      } ]
    },
    "geo" : { },
    "id_str" : "163434837573775360",
    "text" : "Fluffy, my friend squirrel, come into the house for a treat today. http:\/\/t.co\/rdX3fZDg",
    "id" : 163434837573775360,
    "created_at" : "2012-01-29 01:34:36 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 163435456724340736,
  "created_at" : "2012-01-29 01:37:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163435063059558400",
  "text" : "so nice to know the black & white stray kitty is ok.. hadnt seen in long time!",
  "id" : 163435063059558400,
  "created_at" : "2012-01-29 01:35:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 0, 14 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163433353767428097",
  "geo" : { },
  "id_str" : "163434448099094529",
  "in_reply_to_user_id" : 244989679,
  "text" : "@GaribaldiRous they'd be welcome to come in.. but they run when they see us peeking out..lol.. nice pic, btw : )",
  "id" : 163434448099094529,
  "in_reply_to_status_id" : 163433353767428097,
  "created_at" : "2012-01-29 01:33:03 +0000",
  "in_reply_to_screen_name" : "GaribaldiRous",
  "in_reply_to_user_id_str" : "244989679",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163432903047520258",
  "text" : "I get the warm fuzzies when I see critters eating the scraps on my porch...",
  "id" : 163432903047520258,
  "created_at" : "2012-01-29 01:26:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 8, 18 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163353854547730432",
  "geo" : { },
  "id_str" : "163409304035131392",
  "in_reply_to_user_id" : 77106578,
  "text" : "awww... @Matth3ous you're cute! and nice hat! : )",
  "id" : 163409304035131392,
  "in_reply_to_status_id" : 163353854547730432,
  "created_at" : "2012-01-28 23:53:08 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163298781490716673",
  "text" : "RT @JohnCali: Struggling against old patterns only reinforces them. ~ Chopra Center",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163297265446957057",
    "text" : "Struggling against old patterns only reinforces them. ~ Chopra Center",
    "id" : 163297265446957057,
    "created_at" : "2012-01-28 16:27:56 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 163298781490716673,
  "created_at" : "2012-01-28 16:33:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163298736183840768",
  "text" : "RT @JohnCali: Question: How do I take it to the next level? Answer: By making peace with this level. ~ Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163297373911650305",
    "text" : "Question: How do I take it to the next level? Answer: By making peace with this level. ~ Abraham",
    "id" : 163297373911650305,
    "created_at" : "2012-01-28 16:28:22 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 163298736183840768,
  "created_at" : "2012-01-28 16:33:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JohnCali",
      "indices" : [ 115, 124 ]
    }, {
      "text" : "Spirit",
      "indices" : [ 125, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163298643338723330",
  "text" : "RT @JohnCali: Have fun. Laugh. Play. Life is too important to take it so seriously. It\u2019s not serious. All is well. #JohnCali #Spirit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JohnCali",
        "indices" : [ 101, 110 ]
      }, {
        "text" : "Spirit",
        "indices" : [ 111, 118 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163297937219268608",
    "text" : "Have fun. Laugh. Play. Life is too important to take it so seriously. It\u2019s not serious. All is well. #JohnCali #Spirit",
    "id" : 163297937219268608,
    "created_at" : "2012-01-28 16:30:36 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 163298643338723330,
  "created_at" : "2012-01-28 16:33:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 4, 14 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163078872118722560",
  "geo" : { },
  "id_str" : "163285300167192576",
  "in_reply_to_user_id" : 77106578,
  "text" : "hey @Matth3ous ... PICTURE!!!",
  "id" : 163285300167192576,
  "in_reply_to_status_id" : 163078872118722560,
  "created_at" : "2012-01-28 15:40:23 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163283154206064641",
  "text" : "have to make a cake this am.. hubby needs to get me 3 eggs first! lol",
  "id" : 163283154206064641,
  "created_at" : "2012-01-28 15:31:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/wqElxihi",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com\/2012\/01\/28\/love-blots\/",
      "display_url" : "abfabgab.wordpress.com\/2012\/01\/28\/lov\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "163282915093000192",
  "text" : "http:\/\/t.co\/wqElxihi",
  "id" : 163282915093000192,
  "created_at" : "2012-01-28 15:30:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A Man Called RKP",
      "screen_name" : "rk_p",
      "indices" : [ 14, 19 ],
      "id_str" : "10820222",
      "id" : 10820222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163070346717696000",
  "text" : "@tragic_pizza @rk_p ROFL.. omg'ness, John.. you ARE a hoot! ((hugs))",
  "id" : 163070346717696000,
  "created_at" : "2012-01-28 01:26:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 97, 100 ]
    }, {
      "text" : "tcot",
      "indices" : [ 101, 106 ]
    }, {
      "text" : "teaperty",
      "indices" : [ 107, 116 ]
    }, {
      "text" : "topprog",
      "indices" : [ 117, 125 ]
    }, {
      "text" : "news",
      "indices" : [ 126, 131 ]
    }, {
      "text" : "gop",
      "indices" : [ 132, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/rUpbPNwf",
      "expanded_url" : "http:\/\/bit.ly\/wxeG6V",
      "display_url" : "bit.ly\/wxeG6V"
    } ]
  },
  "geo" : { },
  "id_str" : "163065449221853184",
  "text" : "RT @CharlesBivona: Mitt Romney Baptised & Converted a Dead Man to Mormanism http:\/\/t.co\/rUpbPNwf #p2 #tcot #teaperty #topprog #news #gop ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "EzKool Media",
        "screen_name" : "EzKool",
        "indices" : [ 133, 140 ],
        "id_str" : "21964694",
        "id" : 21964694
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 78, 81 ]
      }, {
        "text" : "tcot",
        "indices" : [ 82, 87 ]
      }, {
        "text" : "teaperty",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "topprog",
        "indices" : [ 98, 106 ]
      }, {
        "text" : "news",
        "indices" : [ 107, 112 ]
      }, {
        "text" : "gop",
        "indices" : [ 113, 117 ]
      }, {
        "text" : "sgp",
        "indices" : [ 118, 122 ]
      }, {
        "text" : "flgop",
        "indices" : [ 123, 129 ]
      } ],
      "urls" : [ {
        "indices" : [ 57, 77 ],
        "url" : "http:\/\/t.co\/rUpbPNwf",
        "expanded_url" : "http:\/\/bit.ly\/wxeG6V",
        "display_url" : "bit.ly\/wxeG6V"
      } ]
    },
    "geo" : { },
    "id_str" : "163063620907958272",
    "text" : "Mitt Romney Baptised & Converted a Dead Man to Mormanism http:\/\/t.co\/rUpbPNwf #p2 #tcot #teaperty #topprog #news #gop #sgp #flgop RT @ezkool",
    "id" : 163063620907958272,
    "created_at" : "2012-01-28 00:59:31 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 163065449221853184,
  "created_at" : "2012-01-28 01:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rain Gatdula",
      "screen_name" : "RainGatdula",
      "indices" : [ 35, 47 ],
      "id_str" : "3188065214",
      "id" : 3188065214
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163057890813411328",
  "text" : "maturity is overrated anyway... RT @raingatdula: If a person hasn't matured by the age of 40,they never will.",
  "id" : 163057890813411328,
  "created_at" : "2012-01-28 00:36:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "food",
      "indices" : [ 92, 97 ]
    }, {
      "text" : "ows",
      "indices" : [ 98, 102 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163056073958375425",
  "text" : "RT @CharlesBivona: Something that is needed for basic survival should never be a commodity. #food #ows",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "food",
        "indices" : [ 73, 78 ]
      }, {
        "text" : "ows",
        "indices" : [ 79, 83 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163055770836008961",
    "text" : "Something that is needed for basic survival should never be a commodity. #food #ows",
    "id" : 163055770836008961,
    "created_at" : "2012-01-28 00:28:19 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 163056073958375425,
  "created_at" : "2012-01-28 00:29:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deena.",
      "screen_name" : "feelingstold",
      "indices" : [ 3, 16 ],
      "id_str" : "447122141",
      "id" : 447122141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163055231884726272",
  "text" : "RT @FeelingsTold: What if life is a dream, and when we die we wake up?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162413708759412736",
    "text" : "What if life is a dream, and when we die we wake up?",
    "id" : 162413708759412736,
    "created_at" : "2012-01-26 05:57:00 +0000",
    "user" : {
      "name" : "Wildaris Hernandez",
      "screen_name" : "LoyalStatement",
      "protected" : false,
      "id_str" : "59344414",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/674768418994790403\/xca45RRT_normal.jpg",
      "id" : 59344414,
      "verified" : false
    }
  },
  "id" : 163055231884726272,
  "created_at" : "2012-01-28 00:26:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Undercover Nun",
      "screen_name" : "undercovernun",
      "indices" : [ 16, 30 ],
      "id_str" : "154979698",
      "id" : 154979698
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163055201899655168",
  "text" : "RT @SangyeH: RT @undercovernun: Gah! A person cannot be (has never been, is not now, and never will be) illegal. STOP CALLING PEOPLE \"IL ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Undercover Nun",
        "screen_name" : "undercovernun",
        "indices" : [ 3, 17 ],
        "id_str" : "154979698",
        "id" : 154979698
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162708266491723776",
    "text" : "RT @undercovernun: Gah! A person cannot be (has never been, is not now, and never will be) illegal. STOP CALLING PEOPLE \"ILLEGALS.\"",
    "id" : 162708266491723776,
    "created_at" : "2012-01-27 01:27:28 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 163055201899655168,
  "created_at" : "2012-01-28 00:26:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "163050170374828032",
  "geo" : { },
  "id_str" : "163051288685318144",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl oh my dear one ((hugs))",
  "id" : 163051288685318144,
  "in_reply_to_status_id" : 163050170374828032,
  "created_at" : "2012-01-28 00:10:31 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "163039770627424256",
  "text" : "RT @ChrisGroove1: Life is too short. Live life like you want to.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "163033053504077824",
    "text" : "Life is too short. Live life like you want to.",
    "id" : 163033053504077824,
    "created_at" : "2012-01-27 22:58:03 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 163039770627424256,
  "created_at" : "2012-01-27 23:24:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "indices" : [ 3, 11 ],
      "id_str" : "14653298",
      "id" : 14653298
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/SKdVgWDQ",
      "expanded_url" : "http:\/\/ow.ly\/8JcUH",
      "display_url" : "ow.ly\/8JcUH"
    } ]
  },
  "geo" : { },
  "id_str" : "163039016986476544",
  "text" : "RT @CandyTX: Finally set up a Facebook page for OffAssist, stop by and \"like\" me. You DO like me, right? RIGHT? http:\/\/t.co\/SKdVgWDQ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/SKdVgWDQ",
        "expanded_url" : "http:\/\/ow.ly\/8JcUH",
        "display_url" : "ow.ly\/8JcUH"
      } ]
    },
    "geo" : { },
    "id_str" : "163037937028706306",
    "text" : "Finally set up a Facebook page for OffAssist, stop by and \"like\" me. You DO like me, right? RIGHT? http:\/\/t.co\/SKdVgWDQ",
    "id" : 163037937028706306,
    "created_at" : "2012-01-27 23:17:27 +0000",
    "user" : {
      "name" : "Candy Beauchamp",
      "screen_name" : "CandyTX",
      "protected" : false,
      "id_str" : "14653298",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/419625197843382272\/Kw203SKq_normal.jpeg",
      "id" : 14653298,
      "verified" : false
    }
  },
  "id" : 163039016986476544,
  "created_at" : "2012-01-27 23:21:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 88, 94 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 109, 129 ],
      "url" : "http:\/\/t.co\/MpgKhOt3",
      "expanded_url" : "http:\/\/bit.ly\/A0lYqM",
      "display_url" : "bit.ly\/A0lYqM"
    } ]
  },
  "geo" : { },
  "id_str" : "162983082482335744",
  "text" : "RT @neiltyson: My thoughts from yesterday on Newt Gingrich's space plan, just posted by @MSNBC [6min 45sec]: http:\/\/t.co\/MpgKhOt3",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 73, 79 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 94, 114 ],
        "url" : "http:\/\/t.co\/MpgKhOt3",
        "expanded_url" : "http:\/\/bit.ly\/A0lYqM",
        "display_url" : "bit.ly\/A0lYqM"
      } ]
    },
    "geo" : { },
    "id_str" : "162982444495142912",
    "text" : "My thoughts from yesterday on Newt Gingrich's space plan, just posted by @MSNBC [6min 45sec]: http:\/\/t.co\/MpgKhOt3",
    "id" : 162982444495142912,
    "created_at" : "2012-01-27 19:36:57 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 162983082482335744,
  "created_at" : "2012-01-27 19:39:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Xy",
      "screen_name" : "Chonnymo",
      "indices" : [ 19, 28 ],
      "id_str" : "20875393",
      "id" : 20875393
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162977901740961793",
  "text" : "RT @TrishScott: RT @chonnymo: We are salmon, bear, crow, moose, eagle, wolf. \/\/\/ and even newt.. sigh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Xy",
        "screen_name" : "Chonnymo",
        "indices" : [ 3, 12 ],
        "id_str" : "20875393",
        "id" : 20875393
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162977209383002112",
    "text" : "RT @chonnymo: We are salmon, bear, crow, moose, eagle, wolf. \/\/\/ and even newt.. sigh",
    "id" : 162977209383002112,
    "created_at" : "2012-01-27 19:16:09 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 162977901740961793,
  "created_at" : "2012-01-27 19:18:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "indices" : [ 3, 17 ],
      "id_str" : "16975697",
      "id" : 16975697
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162977781075030017",
  "text" : "RT @JosephRanseth: Everything is as it should be. We experience stress to the degree that we don't accept it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162977331303038976",
    "text" : "Everything is as it should be. We experience stress to the degree that we don't accept it.",
    "id" : 162977331303038976,
    "created_at" : "2012-01-27 19:16:38 +0000",
    "user" : {
      "name" : "Joseph Ranseth",
      "screen_name" : "JosephRanseth",
      "protected" : false,
      "id_str" : "16975697",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771129380454019072\/DndKC8KA_normal.jpg",
      "id" : 16975697,
      "verified" : true
    }
  },
  "id" : 162977781075030017,
  "created_at" : "2012-01-27 19:18:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162974892873105408",
  "text" : "RT @By_Bashar: Just because you can't see a tree growing, Doesn't mean it's not",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162974304911372288",
    "text" : "Just because you can't see a tree growing, Doesn't mean it's not",
    "id" : 162974304911372288,
    "created_at" : "2012-01-27 19:04:36 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 162974892873105408,
  "created_at" : "2012-01-27 19:06:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/CkNfjymT",
      "expanded_url" : "http:\/\/tl.gd\/fj1ljf",
      "display_url" : "tl.gd\/fj1ljf"
    } ]
  },
  "geo" : { },
  "id_str" : "162967898606940160",
  "text" : "RT @UnseeingEyes: I can't reach everyone...so please inspire YOUR friends & readers to VOTE for me at the Shorty (cont) http:\/\/t.co\/CkNfjymT",
  "id" : 162967898606940160,
  "created_at" : "2012-01-27 18:39:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "hiroyuki kubo",
      "screen_name" : "BYU1368",
      "indices" : [ 3, 11 ],
      "id_str" : "83024099",
      "id" : 83024099
    }, {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 24, 37 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "author",
      "indices" : [ 60, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162967763843948545",
  "text" : "RT @BYU1368: I nominate @UnseeingEyes for a Shorty Award in #author because of his insight and interesting and unique views. http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/shortyawards.com\" rel=\"nofollow\"\u003EShorty Awards\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vincenzo Scipioni",
        "screen_name" : "UnseeingEyes",
        "indices" : [ 11, 24 ],
        "id_str" : "36008885",
        "id" : 36008885
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "author",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 132 ],
        "url" : "http:\/\/t.co\/OBVJCR7T",
        "expanded_url" : "http:\/\/shortyawards.com?category=author&screen_name=unseeingeyes",
        "display_url" : "shortyawards.com\/?category=auth\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162912740145504256",
    "text" : "I nominate @UnseeingEyes for a Shorty Award in #author because of his insight and interesting and unique views. http:\/\/t.co\/OBVJCR7T",
    "id" : 162912740145504256,
    "created_at" : "2012-01-27 14:59:58 +0000",
    "user" : {
      "name" : "hiroyuki kubo",
      "screen_name" : "BYU1368",
      "protected" : false,
      "id_str" : "83024099",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1359783539\/201001021000000_normal.jpg",
      "id" : 83024099,
      "verified" : false
    }
  },
  "id" : 162967763843948545,
  "created_at" : "2012-01-27 18:38:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 9, 22 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/g8RJFENV",
      "expanded_url" : "http:\/\/tl.gd\/fj1jen",
      "display_url" : "tl.gd\/fj1jen"
    } ]
  },
  "geo" : { },
  "id_str" : "162966499131265024",
  "text" : "THIS! RT @UnseeingEyes: I'm going to go to court & see if I can help my friend. His family...his father & mother (cont) http:\/\/t.co\/g8RJFENV",
  "id" : 162966499131265024,
  "created_at" : "2012-01-27 18:33:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162962478735687680",
  "text" : "yeah, mark driscoll would not like me at all...",
  "id" : 162962478735687680,
  "created_at" : "2012-01-27 18:17:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 3, 11 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 75, 80 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162958594285899776",
  "text" : "RT @arphaus: Great idea - professors around the world creating classes for #free. Man do we live in interesting times... http:\/\/t.co\/o9V ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 62, 67 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/o9VL6ehK",
        "expanded_url" : "http:\/\/facultyproject.com\/",
        "display_url" : "facultyproject.com"
      } ]
    },
    "geo" : { },
    "id_str" : "162956952765333504",
    "text" : "Great idea - professors around the world creating classes for #free. Man do we live in interesting times... http:\/\/t.co\/o9VL6ehK",
    "id" : 162956952765333504,
    "created_at" : "2012-01-27 17:55:39 +0000",
    "user" : {
      "name" : "Arp Laszlo",
      "screen_name" : "thisisarp",
      "protected" : false,
      "id_str" : "7339162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773529857464688640\/ZPr3v43v_normal.jpg",
      "id" : 7339162,
      "verified" : false
    }
  },
  "id" : 162958594285899776,
  "created_at" : "2012-01-27 18:02:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/KpKF4zWb",
      "expanded_url" : "http:\/\/bit.ly\/yrfycQ",
      "display_url" : "bit.ly\/yrfycQ"
    } ]
  },
  "geo" : { },
  "id_str" : "162948763185451009",
  "text" : "RT @screek: Police Officer's Final Act of Kindness Caught on Tape Before Dying http:\/\/t.co\/KpKF4zWb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/KpKF4zWb",
        "expanded_url" : "http:\/\/bit.ly\/yrfycQ",
        "display_url" : "bit.ly\/yrfycQ"
      } ]
    },
    "geo" : { },
    "id_str" : "162946022895661056",
    "text" : "Police Officer's Final Act of Kindness Caught on Tape Before Dying http:\/\/t.co\/KpKF4zWb",
    "id" : 162946022895661056,
    "created_at" : "2012-01-27 17:12:13 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 162948763185451009,
  "created_at" : "2012-01-27 17:23:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "indices" : [ 3, 15 ],
      "id_str" : "18256901",
      "id" : 18256901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162947763309527040",
  "text" : "RT @deonnakelli: Newt Gingrich hurts my aura. Well, no  politician does much for it,  to be honest.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162945024420622337",
    "text" : "Newt Gingrich hurts my aura. Well, no  politician does much for it,  to be honest.",
    "id" : 162945024420622337,
    "created_at" : "2012-01-27 17:08:15 +0000",
    "user" : {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "protected" : false,
      "id_str" : "18256901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796046774813200384\/-eoNtOic_normal.jpg",
      "id" : 18256901,
      "verified" : false
    }
  },
  "id" : 162947763309527040,
  "created_at" : "2012-01-27 17:19:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 83, 89 ]
    }, {
      "text" : "nature",
      "indices" : [ 90, 97 ]
    }, {
      "text" : "outdoors",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/PvHOTu6l",
      "expanded_url" : "http:\/\/su.pr\/18fuTZ",
      "display_url" : "su.pr\/18fuTZ"
    } ]
  },
  "geo" : { },
  "id_str" : "162947611018530817",
  "text" : "RT @KerriFar: Sitting pretty in the Pines ~ A House finch ~ http:\/\/t.co\/PvHOTu6l ~ #birds #nature #outdoors",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 69, 75 ]
      }, {
        "text" : "nature",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "outdoors",
        "indices" : [ 84, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 46, 66 ],
        "url" : "http:\/\/t.co\/PvHOTu6l",
        "expanded_url" : "http:\/\/su.pr\/18fuTZ",
        "display_url" : "su.pr\/18fuTZ"
      } ]
    },
    "geo" : { },
    "id_str" : "162945971213438976",
    "text" : "Sitting pretty in the Pines ~ A House finch ~ http:\/\/t.co\/PvHOTu6l ~ #birds #nature #outdoors",
    "id" : 162945971213438976,
    "created_at" : "2012-01-27 17:12:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 162947611018530817,
  "created_at" : "2012-01-27 17:18:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Barbara Matthiessen",
      "screen_name" : "Blackdogworld",
      "indices" : [ 3, 17 ],
      "id_str" : "20105071",
      "id" : 20105071
    }, {
      "name" : "Heifer International",
      "screen_name" : "Heifer",
      "indices" : [ 22, 29 ],
      "id_str" : "18225966",
      "id" : 18225966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162947503321387008",
  "text" : "RT @Blackdogworld: RT @Heifer: If you're interested in finding out how to set up your own chicken coop, there's an app for that. iPoultr ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Heifer International",
        "screen_name" : "Heifer",
        "indices" : [ 3, 10 ],
        "id_str" : "18225966",
        "id" : 18225966
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/oO611tfE",
        "expanded_url" : "http:\/\/bit.ly\/x8dCxo",
        "display_url" : "bit.ly\/x8dCxo"
      } ]
    },
    "geo" : { },
    "id_str" : "162945940183990273",
    "text" : "RT @Heifer: If you're interested in finding out how to set up your own chicken coop, there's an app for that. iPoultry. http:\/\/t.co\/oO611tfE",
    "id" : 162945940183990273,
    "created_at" : "2012-01-27 17:11:54 +0000",
    "user" : {
      "name" : "Barbara Matthiessen",
      "screen_name" : "Blackdogworld",
      "protected" : false,
      "id_str" : "20105071",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1792242998\/c881deed-db55-4132-8683-f60f3ce2bb0d_normal.png",
      "id" : 20105071,
      "verified" : false
    }
  },
  "id" : 162947503321387008,
  "created_at" : "2012-01-27 17:18:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KindleFireDept",
      "screen_name" : "KindleFireDept",
      "indices" : [ 3, 18 ],
      "id_str" : "867417752",
      "id" : 867417752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleFire",
      "indices" : [ 41, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162945050907639809",
  "text" : "RT @KindleFireDept: What do you use your #KindleFire for the most? We look at some poll data and offer some polls of our own! http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KindleFire",
        "indices" : [ 21, 32 ]
      } ],
      "urls" : [ {
        "indices" : [ 106, 126 ],
        "url" : "http:\/\/t.co\/RL9M21JB",
        "expanded_url" : "http:\/\/fireapps.blogspot.com\/2012\/01\/polls-what-do-you-use-fire-for.html",
        "display_url" : "fireapps.blogspot.com\/2012\/01\/polls-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162942467249946625",
    "text" : "What do you use your #KindleFire for the most? We look at some poll data and offer some polls of our own! http:\/\/t.co\/RL9M21JB",
    "id" : 162942467249946625,
    "created_at" : "2012-01-27 16:58:06 +0000",
    "user" : {
      "name" : "BookSends",
      "screen_name" : "BookSends",
      "protected" : false,
      "id_str" : "398225352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520255313811755008\/WYb6d_5Y_normal.png",
      "id" : 398225352,
      "verified" : false
    }
  },
  "id" : 162945050907639809,
  "created_at" : "2012-01-27 17:08:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 3, 9 ],
      "id_str" : "11006552",
      "id" : 11006552
    }, {
      "name" : "Believe It or Not!",
      "screen_name" : "ripleyworld",
      "indices" : [ 14, 26 ],
      "id_str" : "1671609746",
      "id" : 1671609746
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162944514347110400",
  "text" : "RT @DrRus: RT @ripleyworld: A 250lb bear was enlisted in Polish Army in WWII. He caught a spy, helped transport ammo and had his own ran ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Believe It or Not!",
        "screen_name" : "ripleyworld",
        "indices" : [ 3, 15 ],
        "id_str" : "1671609746",
        "id" : 1671609746
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162943017651671040",
    "text" : "RT @ripleyworld: A 250lb bear was enlisted in Polish Army in WWII. He caught a spy, helped transport ammo and had his own rank and number.",
    "id" : 162943017651671040,
    "created_at" : "2012-01-27 17:00:17 +0000",
    "user" : {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "protected" : false,
      "id_str" : "11006552",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2998045873\/401a4460295cb0375428b8b577bd2249_normal.jpeg",
      "id" : 11006552,
      "verified" : false
    }
  },
  "id" : 162944514347110400,
  "created_at" : "2012-01-27 17:06:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162942515207618560",
  "text" : "RT @Buddhaworld: lets learn how to love each other, or at least stay out of each others way. Buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162942298764750848",
    "text" : "lets learn how to love each other, or at least stay out of each others way. Buddha volko.",
    "id" : 162942298764750848,
    "created_at" : "2012-01-27 16:57:26 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 162942515207618560,
  "created_at" : "2012-01-27 16:58:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "random",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162941797243428867",
  "text" : "hubby and I discuss fashion on The Weather Channel..lol #random",
  "id" : 162941797243428867,
  "created_at" : "2012-01-27 16:55:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 120, 127 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 119 ],
      "url" : "http:\/\/t.co\/rFhXLtlJ",
      "expanded_url" : "http:\/\/bit.ly\/zWuZKd",
      "display_url" : "bit.ly\/zWuZKd"
    } ]
  },
  "geo" : { },
  "id_str" : "162932379902685184",
  "text" : "RT @DawnFine: Beautiful shots!!!!  Via Natural Moments Mule Deer Baby Enjoying Fresh Winthrop Snow http:\/\/t.co\/rFhXLtlJ #nature",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 106, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 85, 105 ],
        "url" : "http:\/\/t.co\/rFhXLtlJ",
        "expanded_url" : "http:\/\/bit.ly\/zWuZKd",
        "display_url" : "bit.ly\/zWuZKd"
      } ]
    },
    "geo" : { },
    "id_str" : "162931762941542400",
    "text" : "Beautiful shots!!!!  Via Natural Moments Mule Deer Baby Enjoying Fresh Winthrop Snow http:\/\/t.co\/rFhXLtlJ #nature",
    "id" : 162931762941542400,
    "created_at" : "2012-01-27 16:15:34 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 162932379902685184,
  "created_at" : "2012-01-27 16:18:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Honey Badger",
      "screen_name" : "BronxZooHBadger",
      "indices" : [ 3, 19 ],
      "id_str" : "273624512",
      "id" : 273624512
    }, {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 76, 86 ],
      "id_str" : "19725644",
      "id" : 19725644
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 21, 24 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162931884899315713",
  "text" : "RT @BronxZooHBadger: #FF the honey badger of Reason and President of Space: @NeilTyson.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Neil deGrasse Tyson",
        "screen_name" : "neiltyson",
        "indices" : [ 55, 65 ],
        "id_str" : "19725644",
        "id" : 19725644
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162929518603018240",
    "text" : "#FF the honey badger of Reason and President of Space: @NeilTyson.",
    "id" : 162929518603018240,
    "created_at" : "2012-01-27 16:06:38 +0000",
    "user" : {
      "name" : "The Honey Badger",
      "screen_name" : "BronxZooHBadger",
      "protected" : false,
      "id_str" : "273624512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1598524575\/honey_badger_normal.jpg",
      "id" : 273624512,
      "verified" : false
    }
  },
  "id" : 162931884899315713,
  "created_at" : "2012-01-27 16:16:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "indices" : [ 3, 12 ],
      "id_str" : "19636553",
      "id" : 19636553
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 14, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162931493830787072",
  "text" : "RT @LunaJune: #FF I follow you for what you say, what you share, & how you care",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FF",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162930728458399745",
    "text" : "#FF I follow you for what you say, what you share, & how you care",
    "id" : 162930728458399745,
    "created_at" : "2012-01-27 16:11:27 +0000",
    "user" : {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "protected" : false,
      "id_str" : "19636553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521342919387533313\/KI-XkoTw_normal.jpeg",
      "id" : 19636553,
      "verified" : false
    }
  },
  "id" : 162931493830787072,
  "created_at" : "2012-01-27 16:14:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162729606233866240",
  "geo" : { },
  "id_str" : "162730052696551425",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts oh, never! you're a keeper! *muah* : )",
  "id" : 162730052696551425,
  "in_reply_to_status_id" : 162729606233866240,
  "created_at" : "2012-01-27 02:54:02 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162728598434881536",
  "geo" : { },
  "id_str" : "162729530883178497",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH yeah, I dont get that either...",
  "id" : 162729530883178497,
  "in_reply_to_status_id" : 162728598434881536,
  "created_at" : "2012-01-27 02:51:58 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162727084324700160",
  "geo" : { },
  "id_str" : "162727313333690368",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts LOL",
  "id" : 162727313333690368,
  "in_reply_to_status_id" : 162727084324700160,
  "created_at" : "2012-01-27 02:43:09 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 0, 8 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162724176447283201",
  "geo" : { },
  "id_str" : "162725284888580097",
  "in_reply_to_user_id" : 54744689,
  "text" : "@SangyeH yeah.. I thought thats what I heard...",
  "id" : 162725284888580097,
  "in_reply_to_status_id" : 162724176447283201,
  "created_at" : "2012-01-27 02:35:05 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnndebate",
      "indices" : [ 46, 56 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162719899087667200",
  "text" : "omg.. all this talk about \"free riders\".. oy! #cnndebate",
  "id" : 162719899087667200,
  "created_at" : "2012-01-27 02:13:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Larsen",
      "screen_name" : "Marleybonez",
      "indices" : [ 3, 15 ],
      "id_str" : "231796277",
      "id" : 231796277
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/8CH4gTVX",
      "expanded_url" : "http:\/\/bit.ly\/ypv1UR",
      "display_url" : "bit.ly\/ypv1UR"
    } ]
  },
  "geo" : { },
  "id_str" : "162663744986550272",
  "text" : "RT @Marleybonez: The Power of Introverts: A Manifesto for Quiet Brilliance http:\/\/t.co\/8CH4gTVX",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialflow.com\" rel=\"nofollow\"\u003ESocialFlow\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/8CH4gTVX",
        "expanded_url" : "http:\/\/bit.ly\/ypv1UR",
        "display_url" : "bit.ly\/ypv1UR"
      } ]
    },
    "geo" : { },
    "id_str" : "162642592889184256",
    "text" : "The Power of Introverts: A Manifesto for Quiet Brilliance http:\/\/t.co\/8CH4gTVX",
    "id" : 162642592889184256,
    "created_at" : "2012-01-26 21:06:30 +0000",
    "user" : {
      "name" : "Mike Larsen",
      "screen_name" : "Marleybonez",
      "protected" : false,
      "id_str" : "231796277",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234829772\/marleybonez_normal.png",
      "id" : 231796277,
      "verified" : false
    }
  },
  "id" : 162663744986550272,
  "created_at" : "2012-01-26 22:30:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/ieWo3HiL",
      "expanded_url" : "http:\/\/magickalgraphics.com\/Graphics\/Miscellaneous\/Funny\/funny158.jpg",
      "display_url" : "magickalgraphics.com\/Graphics\/Misce\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "162661514501820416",
  "geo" : { },
  "id_str" : "162663108484136960",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous my reply: http:\/\/t.co\/ieWo3HiL",
  "id" : 162663108484136960,
  "in_reply_to_status_id" : 162661514501820416,
  "created_at" : "2012-01-26 22:28:01 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162658276402671619",
  "geo" : { },
  "id_str" : "162660138501668864",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous will we get a picture?",
  "id" : 162660138501668864,
  "in_reply_to_status_id" : 162658276402671619,
  "created_at" : "2012-01-26 22:16:13 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 3, 12 ],
      "id_str" : "46760072",
      "id" : 46760072
    }, {
      "name" : "Newt Gingrich",
      "screen_name" : "newtgingrich",
      "indices" : [ 32, 45 ],
      "id_str" : "20713061",
      "id" : 20713061
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162644314508378113",
  "text" : "RT @WahminSC: Seriously? Gah RT @newtgingrich: If you are for paychecks you are with us, & if you are for food stamps you are with Barac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Newt Gingrich",
        "screen_name" : "newtgingrich",
        "indices" : [ 18, 31 ],
        "id_str" : "20713061",
        "id" : 20713061
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "withnewt",
        "indices" : [ 130, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162643263721975808",
    "text" : "Seriously? Gah RT @newtgingrich: If you are for paychecks you are with us, & if you are for food stamps you are with Barack Obama.#withnewt",
    "id" : 162643263721975808,
    "created_at" : "2012-01-26 21:09:10 +0000",
    "user" : {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "protected" : false,
      "id_str" : "46760072",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2619665382\/fa008c9a-f9b0-4abf-be01-e2dc1ec3cbe4_normal.png",
      "id" : 46760072,
      "verified" : false
    }
  },
  "id" : 162644314508378113,
  "created_at" : "2012-01-26 21:13:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162617765792989186",
  "text" : "RT @Matth3ous: The weather outside looks like it's been written by Stephen King.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162617382379069440",
    "text" : "The weather outside looks like it's been written by Stephen King.",
    "id" : 162617382379069440,
    "created_at" : "2012-01-26 19:26:19 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 162617765792989186,
  "created_at" : "2012-01-26 19:27:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 3, 19 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162617656086773760",
  "text" : "RT @aliceinthewater: Good god... there's another debate tonight?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162616570240180224",
    "text" : "Good god... there's another debate tonight?",
    "id" : 162616570240180224,
    "created_at" : "2012-01-26 19:23:06 +0000",
    "user" : {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "protected" : false,
      "id_str" : "17489079",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1489891728\/floofyball_normal.jpg",
      "id" : 17489079,
      "verified" : false
    }
  },
  "id" : 162617656086773760,
  "created_at" : "2012-01-26 19:27:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Queer Voices",
      "screen_name" : "huffpostgay",
      "indices" : [ 3, 15 ],
      "id_str" : "4343856743",
      "id" : 4343856743
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "LGBTFacts",
      "indices" : [ 57, 67 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162613423090311169",
  "text" : "RT @huffpostgay: Originally used as an anti-gay hashtag, #LGBTFacts gets hijacked by pro-gay Tweeters with hilarious results http:\/\/t.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.huffingtonpost.com\" rel=\"nofollow\"\u003EThe Huffington Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LGBTFacts",
        "indices" : [ 40, 50 ]
      } ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/ZhmfVknA",
        "expanded_url" : "http:\/\/huff.to\/ywriAY",
        "display_url" : "huff.to\/ywriAY"
      } ]
    },
    "geo" : { },
    "id_str" : "162609775920685056",
    "text" : "Originally used as an anti-gay hashtag, #LGBTFacts gets hijacked by pro-gay Tweeters with hilarious results http:\/\/t.co\/ZhmfVknA",
    "id" : 162609775920685056,
    "created_at" : "2012-01-26 18:56:06 +0000",
    "user" : {
      "name" : "huffpostqueer",
      "screen_name" : "huffpostqueer",
      "protected" : false,
      "id_str" : "366606110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/614479428668796928\/XaFrYuE1_normal.png",
      "id" : 366606110,
      "verified" : true
    }
  },
  "id" : 162613423090311169,
  "created_at" : "2012-01-26 19:10:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "indices" : [ 3, 13 ],
      "id_str" : "19725644",
      "id" : 19725644
    }, {
      "name" : "MSNBC",
      "screen_name" : "MSNBC",
      "indices" : [ 42, 48 ],
      "id_str" : "2836421",
      "id" : 2836421
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162611742986346496",
  "text" : "RT @neiltyson: Just an FYI:  Appearing on @MSNBC with Martin Bashir at 3:15pm ET.  To offer my views on Newt Gingrich's space plan.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "MSNBC",
        "screen_name" : "MSNBC",
        "indices" : [ 27, 33 ],
        "id_str" : "2836421",
        "id" : 2836421
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162608791546896384",
    "text" : "Just an FYI:  Appearing on @MSNBC with Martin Bashir at 3:15pm ET.  To offer my views on Newt Gingrich's space plan.",
    "id" : 162608791546896384,
    "created_at" : "2012-01-26 18:52:11 +0000",
    "user" : {
      "name" : "Neil deGrasse Tyson",
      "screen_name" : "neiltyson",
      "protected" : false,
      "id_str" : "19725644",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/74188698\/NeilTysonOriginsA-Crop_normal.jpg",
      "id" : 19725644,
      "verified" : true
    }
  },
  "id" : 162611742986346496,
  "created_at" : "2012-01-26 19:03:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162601849210404865",
  "text" : "RT @ThisBlueWorld: What??? The bank holds your check for 10 days? TEN DAYS??? Meanwhile all these checks bounce, they don't care that th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162596234517938177",
    "text" : "What??? The bank holds your check for 10 days? TEN DAYS??? Meanwhile all these checks bounce, they don't care that the money is there...",
    "id" : 162596234517938177,
    "created_at" : "2012-01-26 18:02:17 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 162601849210404865,
  "created_at" : "2012-01-26 18:24:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162601774761517057",
  "text" : "RT @DeepakChopra: We create our reality through choice.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162596602010271745",
    "text" : "We create our reality through choice.",
    "id" : 162596602010271745,
    "created_at" : "2012-01-26 18:03:45 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 162601774761517057,
  "created_at" : "2012-01-26 18:24:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    }, {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 46, 59 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Author",
      "indices" : [ 82, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162601738149445632",
  "text" : "RT @UnseeingEyes: RT this to VOTE: I nominate @UnSeeingEyes for a Shorty Award in #Author because his stream is a STORY & I experience i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vincenzo Scipioni",
        "screen_name" : "UnseeingEyes",
        "indices" : [ 28, 41 ],
        "id_str" : "36008885",
        "id" : 36008885
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Author",
        "indices" : [ 64, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162596662479564801",
    "text" : "RT this to VOTE: I nominate @UnSeeingEyes for a Shorty Award in #Author because his stream is a STORY & I experience it daily.",
    "id" : 162596662479564801,
    "created_at" : "2012-01-26 18:03:59 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 162601738149445632,
  "created_at" : "2012-01-26 18:24:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162601398696030208",
  "text" : "RT @ThisBlueWorld: Seems morally wrong, for the same people who are holding your money, charge you money because they don't let you have ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162598755252707328",
    "text" : "Seems morally wrong, for the same people who are holding your money, charge you money because they don't let you have it yet.",
    "id" : 162598755252707328,
    "created_at" : "2012-01-26 18:12:18 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 162601398696030208,
  "created_at" : "2012-01-26 18:22:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/rhYi9gkC",
      "expanded_url" : "http:\/\/www.psychologytoday.com\/blog\/turning-straw-gold\/201110\/5-techniques-help-physical-pain",
      "display_url" : "psychologytoday.com\/blog\/turning-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "162584685636104192",
  "text" : "RT @howtobesick: If you're in pain, this may help: 5 Techniques to Help with Physical Pain | Psychology Today http:\/\/t.co\/rhYi9gkC #spoo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "spoonie",
        "indices" : [ 114, 122 ]
      }, {
        "text" : "chronicpain",
        "indices" : [ 123, 135 ]
      }, {
        "text" : "cfs",
        "indices" : [ 136, 140 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/rhYi9gkC",
        "expanded_url" : "http:\/\/www.psychologytoday.com\/blog\/turning-straw-gold\/201110\/5-techniques-help-physical-pain",
        "display_url" : "psychologytoday.com\/blog\/turning-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162583555602518016",
    "text" : "If you're in pain, this may help: 5 Techniques to Help with Physical Pain | Psychology Today http:\/\/t.co\/rhYi9gkC #spoonie #chronicpain #cfs",
    "id" : 162583555602518016,
    "created_at" : "2012-01-26 17:11:54 +0000",
    "user" : {
      "name" : "Toni Bernhard",
      "screen_name" : "toni_bernhard",
      "protected" : false,
      "id_str" : "169982819",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/759869867449196544\/dEV7yImo_normal.jpg",
      "id" : 169982819,
      "verified" : false
    }
  },
  "id" : 162584685636104192,
  "created_at" : "2012-01-26 17:16:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162583043834523649",
  "text" : "RT @SpiritualNurse: One's destination is never a place, but a new way of seeing things. ~Henry Miller",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162581866468212736",
    "text" : "One's destination is never a place, but a new way of seeing things. ~Henry Miller",
    "id" : 162581866468212736,
    "created_at" : "2012-01-26 17:05:12 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 162583043834523649,
  "created_at" : "2012-01-26 17:09:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162581719956983809",
  "text" : "RT @UnseeingEyes: If I get back into the TOP 6; I WIN!!! It's really that easy; because not a SINGLE person in the TOP 6 is an Active Tw ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162579144197156865",
    "text" : "If I get back into the TOP 6; I WIN!!! It's really that easy; because not a SINGLE person in the TOP 6 is an Active Tweeter and\/or Author.",
    "id" : 162579144197156865,
    "created_at" : "2012-01-26 16:54:23 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 162581719956983809,
  "created_at" : "2012-01-26 17:04:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AUTHOR",
      "indices" : [ 122, 129 ]
    } ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/77nxLjAn",
      "expanded_url" : "http:\/\/youtu.be\/eDuRoPIOBjE",
      "display_url" : "youtu.be\/eDuRoPIOBjE"
    } ]
  },
  "geo" : { },
  "id_str" : "162581514020855808",
  "text" : "RT @UnseeingEyes: Last name \"Eva\"...70 More VOTES is all =V= NEEDS!!! -Forever- http:\/\/t.co\/77nxLjAn If you haven't; VOTE #AUTHOR NOW... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "AUTHOR",
        "indices" : [ 104, 111 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/77nxLjAn",
        "expanded_url" : "http:\/\/youtu.be\/eDuRoPIOBjE",
        "display_url" : "youtu.be\/eDuRoPIOBjE"
      }, {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/gG5V1JSG",
        "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
        "display_url" : "shortyawards.com\/UnseeingEyes"
      } ]
    },
    "geo" : { },
    "id_str" : "162579822403534848",
    "text" : "Last name \"Eva\"...70 More VOTES is all =V= NEEDS!!! -Forever- http:\/\/t.co\/77nxLjAn If you haven't; VOTE #AUTHOR NOW... http:\/\/t.co\/gG5V1JSG",
    "id" : 162579822403534848,
    "created_at" : "2012-01-26 16:57:04 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 162581514020855808,
  "created_at" : "2012-01-26 17:03:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162574366775836672",
  "geo" : { },
  "id_str" : "162576835287334912",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous is it a pokemon hat?",
  "id" : 162576835287334912,
  "in_reply_to_status_id" : 162574366775836672,
  "created_at" : "2012-01-26 16:45:12 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Author",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162573310255824896",
  "text" : "RT @UnseeingEyes: Jan 26, 2012...=V= has 646 Votes under #Author & is currently in 7th Place. ONLY THE TOP 6 are considered (cont) http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Author",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/3qingFFo",
        "expanded_url" : "http:\/\/tl.gd\/ficik7",
        "display_url" : "tl.gd\/ficik7"
      } ]
    },
    "geo" : { },
    "id_str" : "162572676949475329",
    "text" : "Jan 26, 2012...=V= has 646 Votes under #Author & is currently in 7th Place. ONLY THE TOP 6 are considered (cont) http:\/\/t.co\/3qingFFo",
    "id" : 162572676949475329,
    "created_at" : "2012-01-26 16:28:41 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 162573310255824896,
  "created_at" : "2012-01-26 16:31:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 13, 26 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162573077010587648",
  "text" : "@scutterbugg @dwaynereaves definitely! : )",
  "id" : 162573077010587648,
  "created_at" : "2012-01-26 16:30:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 0, 14 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162567242909880322",
  "geo" : { },
  "id_str" : "162568477910118400",
  "in_reply_to_user_id" : 19251068,
  "text" : "@JacksonPearce options under chat; limit availability; make me unavailable to; check all boxes",
  "id" : 162568477910118400,
  "in_reply_to_status_id" : 162567242909880322,
  "created_at" : "2012-01-26 16:12:00 +0000",
  "in_reply_to_screen_name" : "JacksonPearce",
  "in_reply_to_user_id_str" : "19251068",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Shields",
      "screen_name" : "adamrshields",
      "indices" : [ 0, 13 ],
      "id_str" : "14835882",
      "id" : 14835882
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162566313896714240",
  "geo" : { },
  "id_str" : "162567548305555456",
  "in_reply_to_user_id" : 14835882,
  "text" : "@adamrshields ahh.. truth! : )",
  "id" : 162567548305555456,
  "in_reply_to_status_id" : 162566313896714240,
  "created_at" : "2012-01-26 16:08:18 +0000",
  "in_reply_to_screen_name" : "adamrshields",
  "in_reply_to_user_id_str" : "14835882",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 31, 44 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "author",
      "indices" : [ 67, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162567144087879680",
  "text" : "RT @hannahsforcina: I nominate @UnseeingEyes for a Shorty Award in #author because of the raw passion with which he tweets his life. htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/shortyawards.com\" rel=\"nofollow\"\u003EShorty Awards\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Vincenzo Scipioni",
        "screen_name" : "UnseeingEyes",
        "indices" : [ 11, 24 ],
        "id_str" : "36008885",
        "id" : 36008885
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "author",
        "indices" : [ 47, 54 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/lX4jSOXo",
        "expanded_url" : "http:\/\/shortyawards.com?category=author&screen_name=unseeingeyes",
        "display_url" : "shortyawards.com\/?category=auth\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162468337329246208",
    "text" : "I nominate @UnseeingEyes for a Shorty Award in #author because of the raw passion with which he tweets his life. http:\/\/t.co\/lX4jSOXo",
    "id" : 162468337329246208,
    "created_at" : "2012-01-26 09:34:04 +0000",
    "user" : {
      "name" : "Hannah van Didden",
      "screen_name" : "hannahvandidden",
      "protected" : false,
      "id_str" : "23178171",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796171860740182016\/2f17rJ7w_normal.jpg",
      "id" : 23178171,
      "verified" : false
    }
  },
  "id" : 162567144087879680,
  "created_at" : "2012-01-26 16:06:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 0, 14 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162565912552157184",
  "geo" : { },
  "id_str" : "162567049351147522",
  "in_reply_to_user_id" : 19251068,
  "text" : "@JacksonPearce see the \"limit availability\" option when you right click on chat...",
  "id" : 162567049351147522,
  "in_reply_to_status_id" : 162565912552157184,
  "created_at" : "2012-01-26 16:06:19 +0000",
  "in_reply_to_screen_name" : "JacksonPearce",
  "in_reply_to_user_id_str" : "19251068",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162564310265106433",
  "text" : "im all 4 space exploration but we need to care 4 ppl on earth 1st!",
  "id" : 162564310265106433,
  "created_at" : "2012-01-26 15:55:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "JohnCali",
      "indices" : [ 102, 111 ]
    }, {
      "text" : "Spirit",
      "indices" : [ 112, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162562666064384000",
  "text" : "RT @JohnCali: God is all that is, everything that exists. That includes money. So money is spiritual. #JohnCali #Spirit",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "JohnCali",
        "indices" : [ 88, 97 ]
      }, {
        "text" : "Spirit",
        "indices" : [ 98, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162562476578312194",
    "text" : "God is all that is, everything that exists. That includes money. So money is spiritual. #JohnCali #Spirit",
    "id" : 162562476578312194,
    "created_at" : "2012-01-26 15:48:09 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 162562666064384000,
  "created_at" : "2012-01-26 15:48:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162562500020281345",
  "text" : "RT @TheChristianLft: God is liberal with love; God is liberal with forgiveness; God is liberal with mercy; God is liberal with... http:\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/kkK1oj2g",
        "expanded_url" : "http:\/\/fb.me\/WRFag86l",
        "display_url" : "fb.me\/WRFag86l"
      } ]
    },
    "geo" : { },
    "id_str" : "162562129340280832",
    "text" : "God is liberal with love; God is liberal with forgiveness; God is liberal with mercy; God is liberal with... http:\/\/t.co\/kkK1oj2g",
    "id" : 162562129340280832,
    "created_at" : "2012-01-26 15:46:46 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 162562500020281345,
  "created_at" : "2012-01-26 15:48:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162561329184522240",
  "geo" : { },
  "id_str" : "162562371582312449",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC you just put a smile on my face.. thx 4 lightening up my day : )",
  "id" : 162562371582312449,
  "in_reply_to_status_id" : 162561329184522240,
  "created_at" : "2012-01-26 15:47:44 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162562158394224641",
  "text" : "RT @JohnCali: Often, having what you want is a function of letting go of what you have. If you know what I mean. ~ The Universe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162561532293685248",
    "text" : "Often, having what you want is a function of letting go of what you have. If you know what I mean. ~ The Universe",
    "id" : 162561532293685248,
    "created_at" : "2012-01-26 15:44:24 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 162562158394224641,
  "created_at" : "2012-01-26 15:46:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162562032279887874",
  "text" : "I love my twitter anipals and I get very sad when they leave for Rainbow Bridge...",
  "id" : 162562032279887874,
  "created_at" : "2012-01-26 15:46:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162561230962311168",
  "text" : "prayers for @SamsaricWarrior .. chills\/fever.. just had heart surgery",
  "id" : 162561230962311168,
  "created_at" : "2012-01-26 15:43:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 0, 15 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Henry Cat",
      "screen_name" : "HenryCat3",
      "indices" : [ 16, 26 ],
      "id_str" : "609396605",
      "id" : 609396605
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162555063015976960",
  "geo" : { },
  "id_str" : "162559939745816576",
  "in_reply_to_user_id" : 25846336,
  "text" : "@mssuzcatsilver @HenryCat3 big kitty smooches.. i \u2665 u sweet cat! big ((hugs)) to your mama",
  "id" : 162559939745816576,
  "in_reply_to_status_id" : 162555063015976960,
  "created_at" : "2012-01-26 15:38:04 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 3, 14 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 34, 54 ],
      "url" : "http:\/\/t.co\/OiFXwIOd",
      "expanded_url" : "http:\/\/trextrying.tumblr.com\/",
      "display_url" : "trextrying.tumblr.com"
    } ]
  },
  "geo" : { },
  "id_str" : "162559157696868352",
  "text" : "RT @adampknave: Please to notice: http:\/\/t.co\/OiFXwIOd is the funniest Tumblr of the week.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 38 ],
        "url" : "http:\/\/t.co\/OiFXwIOd",
        "expanded_url" : "http:\/\/trextrying.tumblr.com\/",
        "display_url" : "trextrying.tumblr.com"
      } ]
    },
    "geo" : { },
    "id_str" : "162556448394588160",
    "text" : "Please to notice: http:\/\/t.co\/OiFXwIOd is the funniest Tumblr of the week.",
    "id" : 162556448394588160,
    "created_at" : "2012-01-26 15:24:12 +0000",
    "user" : {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "protected" : false,
      "id_str" : "2772041",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/719570232503709696\/uoZJEGPR_normal.jpg",
      "id" : 2772041,
      "verified" : false
    }
  },
  "id" : 162559157696868352,
  "created_at" : "2012-01-26 15:34:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162558240436133888",
  "text" : "having a bad day.. chipped a bowl and (unintentionally) killed a mouse : (",
  "id" : 162558240436133888,
  "created_at" : "2012-01-26 15:31:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 82, 95 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 96, 116 ],
      "url" : "http:\/\/t.co\/J2i1hJsI",
      "expanded_url" : "http:\/\/eyesonnorthcarolina.com\/",
      "display_url" : "eyesonnorthcarolina.com"
    } ]
  },
  "geo" : { },
  "id_str" : "162553767571628032",
  "text" : "\"a place to show people how I see things in life through the lens of a camera\" by @DwayneReaves http:\/\/t.co\/J2i1hJsI",
  "id" : 162553767571628032,
  "created_at" : "2012-01-26 15:13:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162528855591104513",
  "geo" : { },
  "id_str" : "162553067596816384",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves @scutterbugg aww.. you're such a sweetheart! : )",
  "id" : 162553067596816384,
  "in_reply_to_status_id" : 162528855591104513,
  "created_at" : "2012-01-26 15:10:46 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 21, 34 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/ctX5UktL",
      "expanded_url" : "http:\/\/bit.ly\/xDEco2",
      "display_url" : "bit.ly\/xDEco2"
    } ]
  },
  "geo" : { },
  "id_str" : "162552742882181121",
  "text" : "RT @DwayneReaves: RT @dwaynereaves Eyes On North Carolina http:\/\/t.co\/ctX5UktL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dwayne Reaves",
        "screen_name" : "dwaynereaves",
        "indices" : [ 3, 16 ],
        "id_str" : "73908822",
        "id" : 73908822
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 60 ],
        "url" : "http:\/\/t.co\/ctX5UktL",
        "expanded_url" : "http:\/\/bit.ly\/xDEco2",
        "display_url" : "bit.ly\/xDEco2"
      } ]
    },
    "geo" : { },
    "id_str" : "162289242758840320",
    "text" : "RT @dwaynereaves Eyes On North Carolina http:\/\/t.co\/ctX5UktL",
    "id" : 162289242758840320,
    "created_at" : "2012-01-25 21:42:25 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 162552742882181121,
  "created_at" : "2012-01-26 15:09:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 124, 144 ],
      "url" : "http:\/\/t.co\/YsvWnkJr",
      "expanded_url" : "http:\/\/tl.gd\/fiab8r",
      "display_url" : "tl.gd\/fiab8r"
    } ]
  },
  "geo" : { },
  "id_str" : "162544526894972928",
  "text" : "ROFL &gt;&gt; \"Then the engine turned off and the whole power on the plane turned off, and they said they were doing (cont) http:\/\/t.co\/YsvWnkJr",
  "id" : 162544526894972928,
  "created_at" : "2012-01-26 14:36:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162347666204934148",
  "geo" : { },
  "id_str" : "162348905986658304",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts hehe..",
  "id" : 162348905986658304,
  "in_reply_to_status_id" : 162347666204934148,
  "created_at" : "2012-01-26 01:39:30 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162347792117932032",
  "text" : "RT @By_Bashar: By definition, if you exist, you must fit in this world Otherwise you would not exist at all ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162347579693219841",
    "text" : "By definition, if you exist, you must fit in this world Otherwise you would not exist at all ~ bashar",
    "id" : 162347579693219841,
    "created_at" : "2012-01-26 01:34:13 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 162347792117932032,
  "created_at" : "2012-01-26 01:35:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shelby Knox",
      "screen_name" : "ShelbyKnox",
      "indices" : [ 3, 14 ],
      "id_str" : "16170115",
      "id" : 16170115
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162347508071284737",
  "text" : "RT @ShelbyKnox: Calista Gingrich DID NOT have a woman arrested for breastfeeding. The story was a FAKE that was picked up by a real femi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162331815380652032",
    "text" : "Calista Gingrich DID NOT have a woman arrested for breastfeeding. The story was a FAKE that was picked up by a real feminist site.",
    "id" : 162331815380652032,
    "created_at" : "2012-01-26 00:31:35 +0000",
    "user" : {
      "name" : "Shelby Knox",
      "screen_name" : "ShelbyKnox",
      "protected" : false,
      "id_str" : "16170115",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710993072457388032\/ZVcpPqMz_normal.jpg",
      "id" : 16170115,
      "verified" : false
    }
  },
  "id" : 162347508071284737,
  "created_at" : "2012-01-26 01:33:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joel Strauss",
      "screen_name" : "justjoel59",
      "indices" : [ 0, 11 ],
      "id_str" : "314087476",
      "id" : 314087476
    }, {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 12, 23 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162338033302114304",
  "geo" : { },
  "id_str" : "162340808199114752",
  "in_reply_to_user_id" : 314087476,
  "text" : "@justjoel59 @mimismutts is that story real? im seeing some ppl say its fake...",
  "id" : 162340808199114752,
  "in_reply_to_status_id" : 162338033302114304,
  "created_at" : "2012-01-26 01:07:19 +0000",
  "in_reply_to_screen_name" : "justjoel59",
  "in_reply_to_user_id_str" : "314087476",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Joel Strauss",
      "screen_name" : "justjoel59",
      "indices" : [ 30, 41 ],
      "id_str" : "314087476",
      "id" : 314087476
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162330280059871232",
  "text" : "RT @mimismutts: READ THIS! RT @justjoel59: Callista Gingrich has woman arrested for breast feeding one month old in public https:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Joel Strauss",
        "screen_name" : "justjoel59",
        "indices" : [ 14, 25 ],
        "id_str" : "314087476",
        "id" : 314087476
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 128 ],
        "url" : "https:\/\/t.co\/JpAJeFfP",
        "expanded_url" : "https:\/\/twitter.com\/cheeriogrrrl\/status\/162317861879156736",
        "display_url" : "twitter.com\/cheeriogrrrl\/s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "162328826943242241",
    "text" : "READ THIS! RT @justjoel59: Callista Gingrich has woman arrested for breast feeding one month old in public https:\/\/t.co\/JpAJeFfP",
    "id" : 162328826943242241,
    "created_at" : "2012-01-26 00:19:42 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 162330280059871232,
  "created_at" : "2012-01-26 00:25:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "162295761038614529",
  "geo" : { },
  "id_str" : "162299142264205313",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous its all those 2012 vibrations stirring things up...",
  "id" : 162299142264205313,
  "in_reply_to_status_id" : 162295761038614529,
  "created_at" : "2012-01-25 22:21:45 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dr. Robert R Cargill",
      "screen_name" : "xkv8r",
      "indices" : [ 104, 110 ],
      "id_str" : "18840795",
      "id" : 18840795
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/qWSpfJUP",
      "expanded_url" : "http:\/\/wp.me\/pm5VN-2bK",
      "display_url" : "wp.me\/pm5VN-2bK"
    } ]
  },
  "geo" : { },
  "id_str" : "162211188388802562",
  "text" : "how much more evidence do you need? mark driscoll's mars hill church is a cult http:\/\/t.co\/qWSpfJUP via @xkv8r",
  "id" : 162211188388802562,
  "created_at" : "2012-01-25 16:32:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162183544939085824",
  "text" : "RT @dhammagirl: Awoke with a feeling of abundance and gratitude.\nSharing with you (((((()))))))))=====&gt;",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "162178861713457153",
    "text" : "Awoke with a feeling of abundance and gratitude.\nSharing with you (((((()))))))))=====&gt;",
    "id" : 162178861713457153,
    "created_at" : "2012-01-25 14:23:48 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 162183544939085824,
  "created_at" : "2012-01-25 14:42:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Christie",
      "screen_name" : "jchristie",
      "indices" : [ 3, 13 ],
      "id_str" : "15186189",
      "id" : 15186189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "162182927793401856",
  "text" : "RT @jchristie: Can't we just come together in these troubled times and agree that reading books - ebooks or print - is pretty great?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tapbots.com\/tweetbot\" rel=\"nofollow\"\u003ETweetbot for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161996307903422464",
    "text" : "Can't we just come together in these troubled times and agree that reading books - ebooks or print - is pretty great?",
    "id" : 161996307903422464,
    "created_at" : "2012-01-25 02:18:24 +0000",
    "user" : {
      "name" : "Josh Christie",
      "screen_name" : "jchristie",
      "protected" : false,
      "id_str" : "15186189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793774888163180544\/r6CQmJeM_normal.jpg",
      "id" : 15186189,
      "verified" : false
    }
  },
  "id" : 162182927793401856,
  "created_at" : "2012-01-25 14:39:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161966941643350016",
  "text" : "RT @By_Bashar: All appears to change when we change.\u00A0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161962556892790784",
    "text" : "All appears to change when we change.\u00A0",
    "id" : 161962556892790784,
    "created_at" : "2012-01-25 00:04:17 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 161966941643350016,
  "created_at" : "2012-01-25 00:21:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161950813126787073",
  "geo" : { },
  "id_str" : "161952727314862082",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell I dont ask for jewelry or bling.. I ask for kindle credit and webhosting..lol",
  "id" : 161952727314862082,
  "in_reply_to_status_id" : 161950813126787073,
  "created_at" : "2012-01-24 23:25:13 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 3, 18 ],
      "id_str" : "19512493",
      "id" : 19512493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 32, 52 ],
      "url" : "http:\/\/t.co\/bVxcdjxQ",
      "expanded_url" : "http:\/\/www.drawastickman.com\/",
      "display_url" : "drawastickman.com"
    } ]
  },
  "geo" : { },
  "id_str" : "161951838323740672",
  "text" : "RT @RichardWiseman: This is ace http:\/\/t.co\/bVxcdjxQ (and whatever you do, don't draw something rude)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 12, 32 ],
        "url" : "http:\/\/t.co\/bVxcdjxQ",
        "expanded_url" : "http:\/\/www.drawastickman.com\/",
        "display_url" : "drawastickman.com"
      } ]
    },
    "geo" : { },
    "id_str" : "161950580070293504",
    "text" : "This is ace http:\/\/t.co\/bVxcdjxQ (and whatever you do, don't draw something rude)",
    "id" : 161950580070293504,
    "created_at" : "2012-01-24 23:16:41 +0000",
    "user" : {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "protected" : false,
      "id_str" : "19512493",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3225534671\/ef59c3b397d28dacb74034b47d8cd9e2_normal.jpeg",
      "id" : 19512493,
      "verified" : true
    }
  },
  "id" : 161951838323740672,
  "created_at" : "2012-01-24 23:21:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 18, 30 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "geek",
      "indices" : [ 9, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161950578484838400",
  "text" : "hehe : ) #geek RT @CaroleODell: Hubby bought me a new domain name today. He's a keeper :-)",
  "id" : 161950578484838400,
  "created_at" : "2012-01-24 23:16:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161950150850387968",
  "text" : "RT @By_Bashar: If your schedule isn't smooth & effortless that's a sure sign it's not your schedule - must be someone else's",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161947457637457920",
    "text" : "If your schedule isn't smooth & effortless that's a sure sign it's not your schedule - must be someone else's",
    "id" : 161947457637457920,
    "created_at" : "2012-01-24 23:04:17 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 161950150850387968,
  "created_at" : "2012-01-24 23:14:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161946281902739456",
  "text" : "wow.. just heard the Tardis on Ghost Hunters!",
  "id" : 161946281902739456,
  "created_at" : "2012-01-24 22:59:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 0, 13 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Authors",
      "indices" : [ 57, 65 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/A3FH2nrE",
      "expanded_url" : "http:\/\/tl.gd\/ffbt89",
      "display_url" : "tl.gd\/ffbt89"
    } ]
  },
  "geo" : { },
  "id_str" : "161944168569122816",
  "in_reply_to_user_id" : 36008885,
  "text" : "@UnseeingEyes needs your VOTES to stay in the TOP 6 Best #Authors at Shorty Awards http:\/\/t.co\/A3FH2nrE Plz RT! Thx!",
  "id" : 161944168569122816,
  "created_at" : "2012-01-24 22:51:13 +0000",
  "in_reply_to_screen_name" : "UnseeingEyes",
  "in_reply_to_user_id_str" : "36008885",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Author",
      "indices" : [ 104, 111 ]
    } ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/aXdz4yvz",
      "expanded_url" : "http:\/\/youtu.be\/rYEDA3JcQqw",
      "display_url" : "youtu.be\/rYEDA3JcQqw"
    } ]
  },
  "geo" : { },
  "id_str" : "161926640270712834",
  "text" : "RT @UnseeingEyes: Leaving you w\/ Adele's -Rolling In The Deep- http:\/\/t.co\/aXdz4yvz & Please VOTE under #Author if you haven't already h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Author",
        "indices" : [ 86, 93 ]
      } ],
      "urls" : [ {
        "indices" : [ 45, 65 ],
        "url" : "http:\/\/t.co\/aXdz4yvz",
        "expanded_url" : "http:\/\/youtu.be\/rYEDA3JcQqw",
        "display_url" : "youtu.be\/rYEDA3JcQqw"
      }, {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/gG5V1JSG",
        "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
        "display_url" : "shortyawards.com\/UnseeingEyes"
      } ]
    },
    "geo" : { },
    "id_str" : "161924906869719040",
    "text" : "Leaving you w\/ Adele's -Rolling In The Deep- http:\/\/t.co\/aXdz4yvz & Please VOTE under #Author if you haven't already http:\/\/t.co\/gG5V1JSG",
    "id" : 161924906869719040,
    "created_at" : "2012-01-24 21:34:40 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 161926640270712834,
  "created_at" : "2012-01-24 21:41:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherrie Thompson",
      "screen_name" : "WahminSC",
      "indices" : [ 0, 9 ],
      "id_str" : "46760072",
      "id" : 46760072
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161920262802116608",
  "geo" : { },
  "id_str" : "161925691330400257",
  "in_reply_to_user_id" : 46760072,
  "text" : "@WahminSC happy birthday to your DD! whoohoo! : )",
  "id" : 161925691330400257,
  "in_reply_to_status_id" : 161920262802116608,
  "created_at" : "2012-01-24 21:37:47 +0000",
  "in_reply_to_screen_name" : "WahminSC",
  "in_reply_to_user_id_str" : "46760072",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161924416203272193",
  "text" : "RT @UnseeingEyes: Believe it or not...I don't feel like Tweeting today. I'm very discouraged over the Shorty Awards & what's happening i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161924210342633474",
    "text" : "Believe it or not...I don't feel like Tweeting today. I'm very discouraged over the Shorty Awards & what's happening in the Author category.",
    "id" : 161924210342633474,
    "created_at" : "2012-01-24 21:31:54 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 161924416203272193,
  "created_at" : "2012-01-24 21:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsey Turrentine",
      "screen_name" : "lturrentine",
      "indices" : [ 3, 15 ],
      "id_str" : "14343185",
      "id" : 14343185
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/lturrentine\/status\/161154849881337856\/photo\/1",
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/nUGM5ff8",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjyJe22CMAAerm3.jpg",
      "id_str" : "161154849889726464",
      "id" : 161154849889726464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjyJe22CMAAerm3.jpg",
      "sizes" : [ {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      }, {
        "h" : 453,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1024,
        "resize" : "fit",
        "w" : 768
      } ],
      "display_url" : "pic.twitter.com\/nUGM5ff8"
    } ],
    "hashtags" : [ {
      "text" : "mindblown",
      "indices" : [ 93, 103 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161908076201521152",
  "text" : "RT @lturrentine: 4K of IBM memory found in my grandpa's pole barn, captured in a 692K photo. #mindblown http:\/\/t.co\/nUGM5ff8",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/lturrentine\/status\/161154849881337856\/photo\/1",
        "indices" : [ 87, 107 ],
        "url" : "http:\/\/t.co\/nUGM5ff8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjyJe22CMAAerm3.jpg",
        "id_str" : "161154849889726464",
        "id" : 161154849889726464,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjyJe22CMAAerm3.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/nUGM5ff8"
      } ],
      "hashtags" : [ {
        "text" : "mindblown",
        "indices" : [ 76, 86 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161154849881337856",
    "text" : "4K of IBM memory found in my grandpa's pole barn, captured in a 692K photo. #mindblown http:\/\/t.co\/nUGM5ff8",
    "id" : 161154849881337856,
    "created_at" : "2012-01-22 18:34:46 +0000",
    "user" : {
      "name" : "Lindsey Turrentine",
      "screen_name" : "lturrentine",
      "protected" : false,
      "id_str" : "14343185",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775402884296880129\/4jcXGirt_normal.jpg",
      "id" : 14343185,
      "verified" : true
    }
  },
  "id" : 161908076201521152,
  "created_at" : "2012-01-24 20:27:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161872044592594944",
  "text" : "RT @By_Bashar: We can only get overwhelmed - when we think the illusions are real",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161871976389029888",
    "text" : "We can only get overwhelmed - when we think the illusions are real",
    "id" : 161871976389029888,
    "created_at" : "2012-01-24 18:04:21 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 161872044592594944,
  "created_at" : "2012-01-24 18:04:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161871680627675136",
  "text" : "at night before falling asleep, I get glimpses of how everything connects. I cry in awe. its weird and wonderful. : )",
  "id" : 161871680627675136,
  "created_at" : "2012-01-24 18:03:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "cnn",
      "indices" : [ 65, 69 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/tEF12AV6",
      "expanded_url" : "http:\/\/www.cnn.com\/2012\/01\/24\/tech\/social-media\/google-plus-nicknames\/index.html",
      "display_url" : "cnn.com\/2012\/01\/24\/tec\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "161870432142761984",
  "text" : "Google swerves, allows nicknames on Google+ http:\/\/t.co\/tEF12AV6 #cnn",
  "id" : 161870432142761984,
  "created_at" : "2012-01-24 17:58:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161816709014106112",
  "text" : "off to bible study w MIL this am : )",
  "id" : 161816709014106112,
  "created_at" : "2012-01-24 14:24:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161816558266621952",
  "text" : "@SamsaricWarrior nice to see you recovering so well ((hugs)) enjoy the sun!",
  "id" : 161816558266621952,
  "created_at" : "2012-01-24 14:24:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "indices" : [ 3, 17 ],
      "id_str" : "19251068",
      "id" : 19251068
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161816012784807938",
  "text" : "RT @JacksonPearce: A friend in the UAE just saw a truck full of baby camels. Her day is already going so much better than mine. http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/JacksonPearce\/status\/161808171353112577\/photo\/1",
        "indices" : [ 109, 129 ],
        "url" : "http:\/\/t.co\/maTylOB8",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Aj7brK_CAAAj9yD.png",
        "id_str" : "161808171361501184",
        "id" : 161808171361501184,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aj7brK_CAAAj9yD.png",
        "sizes" : [ {
          "h" : 647,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 426,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 647,
          "resize" : "fit",
          "w" : 911
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 241,
          "resize" : "fit",
          "w" : 340
        } ],
        "display_url" : "pic.twitter.com\/maTylOB8"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161808171353112577",
    "text" : "A friend in the UAE just saw a truck full of baby camels. Her day is already going so much better than mine. http:\/\/t.co\/maTylOB8",
    "id" : 161808171353112577,
    "created_at" : "2012-01-24 13:50:50 +0000",
    "user" : {
      "name" : "Jackson Pearce",
      "screen_name" : "JacksonPearce",
      "protected" : false,
      "id_str" : "19251068",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/634960367836377088\/sEp05yD1_normal.jpg",
      "id" : 19251068,
      "verified" : true
    }
  },
  "id" : 161816012784807938,
  "created_at" : "2012-01-24 14:21:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Jim Braswell",
      "screen_name" : "ShowMeNature",
      "indices" : [ 80, 93 ],
      "id_str" : "68475519",
      "id" : 68475519
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "Prairie_State_Park_MO",
      "indices" : [ 110, 132 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/sdQsIE2N",
      "expanded_url" : "http:\/\/wildobs.com\/wo\/13763",
      "display_url" : "wildobs.com\/wo\/13763"
    } ]
  },
  "geo" : { },
  "id_str" : "161814484732755968",
  "text" : "RT @wildobs: Today's wildlife encounter: American Bison http:\/\/t.co\/sdQsIE2N by @ShowMeNature #EOTD #wildlife #Prairie_State_Park_MO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jim Braswell",
        "screen_name" : "ShowMeNature",
        "indices" : [ 67, 80 ],
        "id_str" : "68475519",
        "id" : 68475519
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 81, 86 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 87, 96 ]
      }, {
        "text" : "Prairie_State_Park_MO",
        "indices" : [ 97, 119 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/sdQsIE2N",
        "expanded_url" : "http:\/\/wildobs.com\/wo\/13763",
        "display_url" : "wildobs.com\/wo\/13763"
      } ]
    },
    "geo" : { },
    "id_str" : "161811980208971777",
    "text" : "Today's wildlife encounter: American Bison http:\/\/t.co\/sdQsIE2N by @ShowMeNature #EOTD #wildlife #Prairie_State_Park_MO",
    "id" : 161811980208971777,
    "created_at" : "2012-01-24 14:05:57 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 161814484732755968,
  "created_at" : "2012-01-24 14:15:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NDW",
      "screen_name" : "_NealeDWalsch",
      "indices" : [ 3, 17 ],
      "id_str" : "798611160945672192",
      "id" : 798611160945672192
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161645411977789440",
  "text" : "RT @_NealeDWalsch: You alone, get to choose what matters. The meaning of everything is the meaning you give it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.nealedonaldwalsch.com\" rel=\"nofollow\"\u003ENeale Donald Walsch\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161644765203546113",
    "text" : "You alone, get to choose what matters. The meaning of everything is the meaning you give it.",
    "id" : 161644765203546113,
    "created_at" : "2012-01-24 03:01:29 +0000",
    "user" : {
      "name" : "Neale Donald Walsch",
      "screen_name" : "realNDWalsch",
      "protected" : false,
      "id_str" : "40295615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747226194123206656\/8BrM0nGr_normal.jpg",
      "id" : 40295615,
      "verified" : false
    }
  },
  "id" : 161645411977789440,
  "created_at" : "2012-01-24 03:04:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jimgeraghty",
      "screen_name" : "jimgeraghty",
      "indices" : [ 3, 15 ],
      "id_str" : "15335534",
      "id" : 15335534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161645364842205185",
  "text" : "RT @jimgeraghty: If we're going to have nearly 20 debates, at least one of them should be a musical.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161643444819869696",
    "text" : "If we're going to have nearly 20 debates, at least one of them should be a musical.",
    "id" : 161643444819869696,
    "created_at" : "2012-01-24 02:56:15 +0000",
    "user" : {
      "name" : "jimgeraghty",
      "screen_name" : "jimgeraghty",
      "protected" : false,
      "id_str" : "15335534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793503590581231616\/MVREOcVR_normal.jpg",
      "id" : 15335534,
      "verified" : true
    }
  },
  "id" : 161645364842205185,
  "created_at" : "2012-01-24 03:03:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "indices" : [ 3, 11 ],
      "id_str" : "50815971",
      "id" : 50815971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161642857629880320",
  "text" : "RT @Palidan: \"Extend to each person, no matter how trivia the contact, all the care, kindness, and understanding you can muster.\" Og Mandino",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161642465126924288",
    "text" : "\"Extend to each person, no matter how trivia the contact, all the care, kindness, and understanding you can muster.\" Og Mandino",
    "id" : 161642465126924288,
    "created_at" : "2012-01-24 02:52:21 +0000",
    "user" : {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "protected" : false,
      "id_str" : "50815971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747718513\/twitter_background_normal.jpg",
      "id" : 50815971,
      "verified" : false
    }
  },
  "id" : 161642857629880320,
  "created_at" : "2012-01-24 02:53:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Hammons",
      "screen_name" : "TheBeanStraw",
      "indices" : [ 3, 16 ],
      "id_str" : "236673427",
      "id" : 236673427
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161642818752888833",
  "text" : "RT @TheBeanStraw: I had my cat de-clawed. When I woke up the next morning, the cat was staring at me and all my fingernails had been rem ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "funny",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161642501919350784",
    "text" : "I had my cat de-clawed. When I woke up the next morning, the cat was staring at me and all my fingernails had been removed. #funny",
    "id" : 161642501919350784,
    "created_at" : "2012-01-24 02:52:30 +0000",
    "user" : {
      "name" : "David Hammons",
      "screen_name" : "TheBeanStraw",
      "protected" : false,
      "id_str" : "236673427",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1216125480\/My_Pic_normal.jpg",
      "id" : 236673427,
      "verified" : false
    }
  },
  "id" : 161642818752888833,
  "created_at" : "2012-01-24 02:53:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161639418170589185",
  "geo" : { },
  "id_str" : "161642655086940160",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time rofl..",
  "id" : 161642655086940160,
  "in_reply_to_status_id" : 161639418170589185,
  "created_at" : "2012-01-24 02:53:06 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jumbline 2",
      "screen_name" : "Jumbline2",
      "indices" : [ 3, 13 ],
      "id_str" : "449329167",
      "id" : 449329167
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/4bfAPMid",
      "expanded_url" : "http:\/\/ow.ly\/8DojD",
      "display_url" : "ow.ly\/8DojD"
    } ]
  },
  "geo" : { },
  "id_str" : "161538602893971456",
  "text" : "RT @Jumbline2: Want a free iPod Touch? All you have to do is win the Jumble Royal! Details on our blog: http:\/\/t.co\/4bfAPMid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/4bfAPMid",
        "expanded_url" : "http:\/\/ow.ly\/8DojD",
        "display_url" : "ow.ly\/8DojD"
      } ]
    },
    "geo" : { },
    "id_str" : "161536080347267072",
    "text" : "Want a free iPod Touch? All you have to do is win the Jumble Royal! Details on our blog: http:\/\/t.co\/4bfAPMid",
    "id" : 161536080347267072,
    "created_at" : "2012-01-23 19:49:37 +0000",
    "user" : {
      "name" : "Jumbline 2",
      "screen_name" : "Jumbline2",
      "protected" : false,
      "id_str" : "449329167",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1880060748\/iTunesArtwork_normal.png",
      "id" : 449329167,
      "verified" : false
    }
  },
  "id" : 161538602893971456,
  "created_at" : "2012-01-23 19:59:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161512784478216192",
  "geo" : { },
  "id_str" : "161513586718547968",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl good to see you in my timeline! ((hugs))",
  "id" : 161513586718547968,
  "in_reply_to_status_id" : 161512784478216192,
  "created_at" : "2012-01-23 18:20:14 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stuart GuruStu Rosen",
      "screen_name" : "GuruStu",
      "indices" : [ 3, 11 ],
      "id_str" : "19620052",
      "id" : 19620052
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161511367810088961",
  "text" : "RT @GuruStu: Always go for the greatest good, not the lesser evil.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161158741532753920",
    "text" : "Always go for the greatest good, not the lesser evil.",
    "id" : 161158741532753920,
    "created_at" : "2012-01-22 18:50:12 +0000",
    "user" : {
      "name" : "Stuart GuruStu Rosen",
      "screen_name" : "GuruStu",
      "protected" : false,
      "id_str" : "19620052",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/77833735\/Copy_of_stuart-rosen-thumb_normal.jpg",
      "id" : 19620052,
      "verified" : false
    }
  },
  "id" : 161511367810088961,
  "created_at" : "2012-01-23 18:11:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daily Word Magazine",
      "screen_name" : "DailyWordMag",
      "indices" : [ 3, 16 ],
      "id_str" : "38060989",
      "id" : 38060989
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161501948296704001",
  "text" : "RT @DailyWordMag: When praying 4 others, try letting go of specific outcomes. Expand ur vision;see them as a whole, radiating center of  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161501090892881920",
    "text" : "When praying 4 others, try letting go of specific outcomes. Expand ur vision;see them as a whole, radiating center of life and love.",
    "id" : 161501090892881920,
    "created_at" : "2012-01-23 17:30:35 +0000",
    "user" : {
      "name" : "Daily Word Magazine",
      "screen_name" : "DailyWordMag",
      "protected" : false,
      "id_str" : "38060989",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520305558453108736\/7I3IDB72_normal.jpeg",
      "id" : 38060989,
      "verified" : false
    }
  },
  "id" : 161501948296704001,
  "created_at" : "2012-01-23 17:33:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161485498253193217",
  "geo" : { },
  "id_str" : "161487563905970176",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous heehee.. that'l teach you to ask such invasive questions! ; )",
  "id" : 161487563905970176,
  "in_reply_to_status_id" : 161485498253193217,
  "created_at" : "2012-01-23 16:36:50 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161473376974671872",
  "geo" : { },
  "id_str" : "161482275500982276",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous LOL",
  "id" : 161482275500982276,
  "in_reply_to_status_id" : 161473376974671872,
  "created_at" : "2012-01-23 16:15:49 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161180108441391104",
  "text" : "RT @oshum: 12\/21\/2012 will find our Solar System in the \"GAP\" of its Galaxy ... ALL that is \"known\" will be suspended\/transcended...and  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161179703955308544",
    "text" : "12\/21\/2012 will find our Solar System in the \"GAP\" of its Galaxy ... ALL that is \"known\" will be suspended\/transcended...and ALL will BE NEW",
    "id" : 161179703955308544,
    "created_at" : "2012-01-22 20:13:30 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 161180108441391104,
  "created_at" : "2012-01-22 20:15:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161179848616853506",
  "text" : "RT @Emmanueldagher: There's a great sense of momentum building in the air! Can you feel it?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161174539290689537",
    "text" : "There's a great sense of momentum building in the air! Can you feel it?",
    "id" : 161174539290689537,
    "created_at" : "2012-01-22 19:52:59 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 161179848616853506,
  "created_at" : "2012-01-22 20:14:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161161089705459712",
  "geo" : { },
  "id_str" : "161163149133877248",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time hehe.. I was referring to newt and teacher (which I then googled) .. im not great at the games but i enjoy playing..lol",
  "id" : 161163149133877248,
  "in_reply_to_status_id" : 161161089705459712,
  "created_at" : "2012-01-22 19:07:43 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161158989957169152",
  "geo" : { },
  "id_str" : "161159657015099392",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous well that part is not good! sickness, I declare you unwanted and uninvited.. leave now! ((hugs))",
  "id" : 161159657015099392,
  "in_reply_to_status_id" : 161158989957169152,
  "created_at" : "2012-01-22 18:53:51 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "z eant",
      "screen_name" : "andronemai",
      "indices" : [ 3, 14 ],
      "id_str" : "2366426713",
      "id" : 2366426713
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161155126638280706",
  "text" : "RT @andronemai: broke people should keep a picture of a corgi in their wallet so when they open it the cuteness of the corgi negates the ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161143623667290112",
    "text" : "broke people should keep a picture of a corgi in their wallet so when they open it the cuteness of the corgi negates their crippling poverty",
    "id" : 161143623667290112,
    "created_at" : "2012-01-22 17:50:08 +0000",
    "user" : {
      "name" : "indiescent. zant",
      "screen_name" : "maniadrone",
      "protected" : false,
      "id_str" : "14851125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/790829899237822464\/g2sT1O3u_normal.jpg",
      "id" : 14851125,
      "verified" : false
    }
  },
  "id" : 161155126638280706,
  "created_at" : "2012-01-22 18:35:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161152608294285312",
  "geo" : { },
  "id_str" : "161153168808493057",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time wait.. what??",
  "id" : 161153168808493057,
  "in_reply_to_status_id" : 161152608294285312,
  "created_at" : "2012-01-22 18:28:04 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Author",
      "indices" : [ 66, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161151438590976001",
  "text" : "RT @UnseeingEyes: Jan 22, 2012...Vincenzo Scipioni, the only TRUE #Author in the Shorty Awards...has moved to #7 due to unscrupulous Ind ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Author",
        "indices" : [ 48, 55 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161151111061966848",
    "text" : "Jan 22, 2012...Vincenzo Scipioni, the only TRUE #Author in the Shorty Awards...has moved to #7 due to unscrupulous Indonesian accounts.",
    "id" : 161151111061966848,
    "created_at" : "2012-01-22 18:19:53 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 161151438590976001,
  "created_at" : "2012-01-22 18:21:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 43, 54 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161151314619924481",
  "text" : "I like playing megawords & wordsmith on my #kindlefire. wanna play? \"abfabgab\"",
  "id" : 161151314619924481,
  "created_at" : "2012-01-22 18:20:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161147035389673473",
  "text" : "I have been good.. I have not yelled at hubby during his cleaning spree.",
  "id" : 161147035389673473,
  "created_at" : "2012-01-22 18:03:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "indices" : [ 3, 15 ],
      "id_str" : "28461779",
      "id" : 28461779
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 89, 95 ]
    }, {
      "text" : "photog",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "marketing",
      "indices" : [ 104, 114 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/rcEMA2oh",
      "expanded_url" : "http:\/\/pulse.me\/s\/5eHDV",
      "display_url" : "pulse.me\/s\/5eHDV"
    } ]
  },
  "geo" : { },
  "id_str" : "161139949108854784",
  "text" : "RT @MartinBelan: 11 Ways to get Free Marketing for Your Photography http:\/\/t.co\/rcEMA2oh #photo #photog #marketing",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 72, 78 ]
      }, {
        "text" : "photog",
        "indices" : [ 79, 86 ]
      }, {
        "text" : "marketing",
        "indices" : [ 87, 97 ]
      } ],
      "urls" : [ {
        "indices" : [ 51, 71 ],
        "url" : "http:\/\/t.co\/rcEMA2oh",
        "expanded_url" : "http:\/\/pulse.me\/s\/5eHDV",
        "display_url" : "pulse.me\/s\/5eHDV"
      } ]
    },
    "geo" : { },
    "id_str" : "161139723342069761",
    "text" : "11 Ways to get Free Marketing for Your Photography http:\/\/t.co\/rcEMA2oh #photo #photog #marketing",
    "id" : 161139723342069761,
    "created_at" : "2012-01-22 17:34:38 +0000",
    "user" : {
      "name" : "Martin Belan",
      "screen_name" : "MartinBelan",
      "protected" : false,
      "id_str" : "28461779",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/544093532021997568\/PgZXIJNw_normal.jpeg",
      "id" : 28461779,
      "verified" : false
    }
  },
  "id" : 161139949108854784,
  "created_at" : "2012-01-22 17:35:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161135034965823489",
  "text" : "RT @By_Bashar: When we accept tough challenges and move though them with joy and enthusiasm, miracles will happen.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161132107400359936",
    "text" : "When we accept tough challenges and move though them with joy and enthusiasm, miracles will happen.",
    "id" : 161132107400359936,
    "created_at" : "2012-01-22 17:04:22 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 161135034965823489,
  "created_at" : "2012-01-22 17:16:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161131594801876992",
  "text" : "cleaning house sends me into a tizzy.. i cant \"just do it\" .. i dont work that way..",
  "id" : 161131594801876992,
  "created_at" : "2012-01-22 17:02:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161131070086070273",
  "text" : "i am very, very anal and methodical. which means i have very specific ways of doing things (and thinking)",
  "id" : 161131070086070273,
  "created_at" : "2012-01-22 17:00:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PowerfulLivingDesign",
      "screen_name" : "DesignIntuition",
      "indices" : [ 3, 19 ],
      "id_str" : "109693092",
      "id" : 109693092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161130016946667520",
  "text" : "RT @DesignIntuition: Your mind is only as great as your truth.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "161126084220428288",
    "text" : "Your mind is only as great as your truth.",
    "id" : 161126084220428288,
    "created_at" : "2012-01-22 16:40:26 +0000",
    "user" : {
      "name" : "PowerfulLivingDesign",
      "screen_name" : "DesignIntuition",
      "protected" : false,
      "id_str" : "109693092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580467733948686337\/JY6BVlmm_normal.jpg",
      "id" : 109693092,
      "verified" : false
    }
  },
  "id" : 161130016946667520,
  "created_at" : "2012-01-22 16:56:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161127652827209728",
  "geo" : { },
  "id_str" : "161129910214197249",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 but cant do that.. (long story)",
  "id" : 161129910214197249,
  "in_reply_to_status_id" : 161127652827209728,
  "created_at" : "2012-01-22 16:55:38 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "161127652827209728",
  "geo" : { },
  "id_str" : "161129663677210624",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 I cant.. well, I do get rid of bits here and there but I need to be able to just have a big toss out",
  "id" : 161129663677210624,
  "in_reply_to_status_id" : 161127652827209728,
  "created_at" : "2012-01-22 16:54:40 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161125429137252353",
  "text" : "ok, Universe.. either have someone buy the %4#* property or stop looking! I'm tired of losing my stuff!",
  "id" : 161125429137252353,
  "created_at" : "2012-01-22 16:37:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161125047443009537",
  "text" : "if we could just throw stuff out, we wouldn't be in this mess!",
  "id" : 161125047443009537,
  "created_at" : "2012-01-22 16:36:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "161123191719346177",
  "text" : "twitch.. twitch..",
  "id" : 161123191719346177,
  "created_at" : "2012-01-22 16:28:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041D\u0435\u043F\u043E\u043C\u043D\u044F\u0449\u0438\u0445 \u0412\u0438\u043A\u0442\u043E\u0440",
      "screen_name" : "glassdimlyfaith",
      "indices" : [ 3, 19 ],
      "id_str" : "2826504890",
      "id" : 2826504890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160905916982636544",
  "text" : "RT @glassdimlyfaith: Making a door for a shelving unit in our house. Turns out carpentry is hard and involves lots of measuring.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160905542137692160",
    "text" : "Making a door for a shelving unit in our house. Turns out carpentry is hard and involves lots of measuring.",
    "id" : 160905542137692160,
    "created_at" : "2012-01-22 02:04:05 +0000",
    "user" : {
      "name" : "Jeremy John",
      "screen_name" : "glassdimly",
      "protected" : false,
      "id_str" : "247971836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/411886255576592384\/HounElWp_normal.jpeg",
      "id" : 247971836,
      "verified" : false
    }
  },
  "id" : 160905916982636544,
  "created_at" : "2012-01-22 02:05:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/oxcIanMO",
      "expanded_url" : "http:\/\/krissthesexyatheist.blogspot.com\/2012\/01\/it-came-from-something-or-not.html?spref=tw",
      "display_url" : "krissthesexyatheist.blogspot.com\/2012\/01\/it-cam\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "160834773416296449",
  "text" : "RT @thesexyatheist: krissthesexyatheist: \"It Came From \"Something\", Or Not http:\/\/t.co\/oxcIanMO ...aaannnnddd, I'm talking about the uni ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/oxcIanMO",
        "expanded_url" : "http:\/\/krissthesexyatheist.blogspot.com\/2012\/01\/it-came-from-something-or-not.html?spref=tw",
        "display_url" : "krissthesexyatheist.blogspot.com\/2012\/01\/it-cam\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "160831684202344449",
    "text" : "krissthesexyatheist: \"It Came From \"Something\", Or Not http:\/\/t.co\/oxcIanMO ...aaannnnddd, I'm talking about the universe-n-shit.Checkitout.",
    "id" : 160831684202344449,
    "created_at" : "2012-01-21 21:10:36 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 160834773416296449,
  "created_at" : "2012-01-21 21:22:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 20, 40 ],
      "url" : "http:\/\/t.co\/RxCBwTQH",
      "expanded_url" : "http:\/\/twitpic.com\/8a1ku8",
      "display_url" : "twitpic.com\/8a1ku8"
    } ]
  },
  "geo" : { },
  "id_str" : "160833592044437504",
  "text" : "RT @mssuzcatsilver: http:\/\/t.co\/RxCBwTQH Henry cat ... Purrzzz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/RxCBwTQH",
        "expanded_url" : "http:\/\/twitpic.com\/8a1ku8",
        "display_url" : "twitpic.com\/8a1ku8"
      } ]
    },
    "geo" : { },
    "id_str" : "160831764753956865",
    "text" : "http:\/\/t.co\/RxCBwTQH Henry cat ... Purrzzz",
    "id" : 160831764753956865,
    "created_at" : "2012-01-21 21:10:55 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 160833592044437504,
  "created_at" : "2012-01-21 21:18:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Authors",
      "indices" : [ 101, 109 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160833253593452544",
  "text" : "RT @UnseeingEyes: Jan 21, 2012...Vincenzo Scipioni needs your help & VOTES to stay in the TOP 6 Best #Authors at the Shorty (cont) http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Authors",
        "indices" : [ 83, 91 ]
      } ],
      "urls" : [ {
        "indices" : [ 113, 133 ],
        "url" : "http:\/\/t.co\/ZZQ3aYub",
        "expanded_url" : "http:\/\/tl.gd\/ffbt89",
        "display_url" : "tl.gd\/ffbt89"
      } ]
    },
    "geo" : { },
    "id_str" : "160832235048665088",
    "text" : "Jan 21, 2012...Vincenzo Scipioni needs your help & VOTES to stay in the TOP 6 Best #Authors at the Shorty (cont) http:\/\/t.co\/ZZQ3aYub",
    "id" : 160832235048665088,
    "created_at" : "2012-01-21 21:12:47 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 160833253593452544,
  "created_at" : "2012-01-21 21:16:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160828630732255232",
  "text" : "RT @oshum: \"Mama... you are the Oyster and I am the Pearl\"  6 year old Mikkel to his Mom.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160828324178952192",
    "text" : "\"Mama... you are the Oyster and I am the Pearl\"  6 year old Mikkel to his Mom.",
    "id" : 160828324178952192,
    "created_at" : "2012-01-21 20:57:15 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 160828630732255232,
  "created_at" : "2012-01-21 20:58:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindlefire",
      "indices" : [ 21, 32 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160816650503991296",
  "text" : "playing Megawords on #kindlefire .. dont know how to rematch .. hmm..",
  "id" : 160816650503991296,
  "created_at" : "2012-01-21 20:10:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160779552883355648",
  "geo" : { },
  "id_str" : "160780880011476992",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous sounds perfectly wonderful to me! I love huddling under clean sheets w a good story on my Kindle! : )",
  "id" : 160780880011476992,
  "in_reply_to_status_id" : 160779552883355648,
  "created_at" : "2012-01-21 17:48:43 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Etsy",
      "screen_name" : "Etsy",
      "indices" : [ 95, 100 ],
      "id_str" : "11522502",
      "id" : 11522502
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/PQo8BArT",
      "expanded_url" : "http:\/\/etsy.me\/zNJJFp",
      "display_url" : "etsy.me\/zNJJFp"
    } ]
  },
  "geo" : { },
  "id_str" : "160780300736135168",
  "text" : "Nice! &gt;&gt; Kindle Fire Handcrafted Wood & Leather Case by jjkraai http:\/\/t.co\/PQo8BArT via @Etsy",
  "id" : 160780300736135168,
  "created_at" : "2012-01-21 17:46:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160756078504714241",
  "text" : "RT @MyNatureApps: If you deal with Nature, we're looking for reciprocal links",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160754572598583297",
    "text" : "If you deal with Nature, we're looking for reciprocal links",
    "id" : 160754572598583297,
    "created_at" : "2012-01-21 16:04:11 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 160756078504714241,
  "created_at" : "2012-01-21 16:10:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/160520836732817408\/photo\/1",
      "indices" : [ 87, 107 ],
      "url" : "http:\/\/t.co\/3WK07PnO",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjpI2bzCEAAOw1V.jpg",
      "id_str" : "160520836737011712",
      "id" : 160520836737011712,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjpI2bzCEAAOw1V.jpg",
      "sizes" : [ {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      }, {
        "h" : 340,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 600,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 800,
        "resize" : "fit",
        "w" : 800
      } ],
      "display_url" : "pic.twitter.com\/3WK07PnO"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160521450992836608",
  "text" : "RT @SpiritualNurse: New infrared view of Helix Nebula looks like golden eye in the sky http:\/\/t.co\/3WK07PnO",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SpiritualNurse\/status\/160520836732817408\/photo\/1",
        "indices" : [ 67, 87 ],
        "url" : "http:\/\/t.co\/3WK07PnO",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjpI2bzCEAAOw1V.jpg",
        "id_str" : "160520836737011712",
        "id" : 160520836737011712,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjpI2bzCEAAOw1V.jpg",
        "sizes" : [ {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        }, {
          "h" : 340,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 600,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 800
        } ],
        "display_url" : "pic.twitter.com\/3WK07PnO"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160520836732817408",
    "text" : "New infrared view of Helix Nebula looks like golden eye in the sky http:\/\/t.co\/3WK07PnO",
    "id" : 160520836732817408,
    "created_at" : "2012-01-21 00:35:26 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 160521450992836608,
  "created_at" : "2012-01-21 00:37:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "indices" : [ 3, 16 ],
      "id_str" : "93072985",
      "id" : 93072985
    }, {
      "name" : "National Wildlife",
      "screen_name" : "NWF",
      "indices" : [ 21, 25 ],
      "id_str" : "3554721",
      "id" : 3554721
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squirrelday",
      "indices" : [ 95, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/yfITcwFU",
      "expanded_url" : "http:\/\/bit.ly\/yf6bPz",
      "display_url" : "bit.ly\/yf6bPz"
    } ]
  },
  "geo" : { },
  "id_str" : "160518914600730624",
  "text" : "RT @MyNatureApps: RT @NWF: Tomorrow is Squirrel Appreciation Day! How will you be celebrating? #squirrelday\rhttp:\/\/t.co\/yfITcwFU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "National Wildlife",
        "screen_name" : "NWF",
        "indices" : [ 3, 7 ],
        "id_str" : "3554721",
        "id" : 3554721
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squirrelday",
        "indices" : [ 77, 89 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/yfITcwFU",
        "expanded_url" : "http:\/\/bit.ly\/yf6bPz",
        "display_url" : "bit.ly\/yf6bPz"
      } ]
    },
    "geo" : { },
    "id_str" : "160517972501331968",
    "text" : "RT @NWF: Tomorrow is Squirrel Appreciation Day! How will you be celebrating? #squirrelday\rhttp:\/\/t.co\/yfITcwFU",
    "id" : 160517972501331968,
    "created_at" : "2012-01-21 00:24:01 +0000",
    "user" : {
      "name" : "Jeff",
      "screen_name" : "MyNatureApps",
      "protected" : false,
      "id_str" : "93072985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308406509\/mynaturesquare_normal.jpg",
      "id" : 93072985,
      "verified" : false
    }
  },
  "id" : 160518914600730624,
  "created_at" : "2012-01-21 00:27:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160485791154446336",
  "geo" : { },
  "id_str" : "160486612785045505",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin oh no.. hope she feels better!",
  "id" : 160486612785045505,
  "in_reply_to_status_id" : 160485791154446336,
  "created_at" : "2012-01-20 22:19:24 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 3, 18 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "George \u270C\uFE0F",
      "screen_name" : "GeorgeGliddon",
      "indices" : [ 23, 37 ],
      "id_str" : "14993153",
      "id" : 14993153
    }, {
      "name" : "Jason Verly",
      "screen_name" : "mygeekdaddy",
      "indices" : [ 121, 133 ],
      "id_str" : "7981252",
      "id" : 7981252
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/GeorgeGliddon\/status\/160317131781718017\/photo\/1",
      "indices" : [ 91, 111 ],
      "url" : "http:\/\/t.co\/NBgosMMF",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjmPlPuCQAAlOXY.png",
      "id_str" : "160317131785912320",
      "id" : 160317131785912320,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjmPlPuCQAAlOXY.png",
      "sizes" : [ {
        "h" : 359,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 491
      }, {
        "h" : 518,
        "resize" : "fit",
        "w" : 491
      } ],
      "display_url" : "pic.twitter.com\/NBgosMMF"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160432571761704960",
  "text" : "RT @MartijnLinssen: RT @georgegliddon: Just casually taking your 27\" iMac into starbucks.. http:\/\/t.co\/NBgosMMF &lt; via @mygeekdaddy. C ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "George \u270C\uFE0F",
        "screen_name" : "GeorgeGliddon",
        "indices" : [ 3, 17 ],
        "id_str" : "14993153",
        "id" : 14993153
      }, {
        "name" : "Jason Verly",
        "screen_name" : "mygeekdaddy",
        "indices" : [ 101, 113 ],
        "id_str" : "7981252",
        "id" : 7981252
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/GeorgeGliddon\/status\/160317131781718017\/photo\/1",
        "indices" : [ 71, 91 ],
        "url" : "http:\/\/t.co\/NBgosMMF",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjmPlPuCQAAlOXY.png",
        "id_str" : "160317131785912320",
        "id" : 160317131785912320,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjmPlPuCQAAlOXY.png",
        "sizes" : [ {
          "h" : 359,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 491
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 491
        }, {
          "h" : 518,
          "resize" : "fit",
          "w" : 491
        } ],
        "display_url" : "pic.twitter.com\/NBgosMMF"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160431091994468352",
    "text" : "RT @georgegliddon: Just casually taking your 27\" iMac into starbucks.. http:\/\/t.co\/NBgosMMF &lt; via @mygeekdaddy. Candid Camera?",
    "id" : 160431091994468352,
    "created_at" : "2012-01-20 18:38:47 +0000",
    "user" : {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "protected" : false,
      "id_str" : "23757784",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3689401539\/3927999ce37786da88e5a26353e026b6_normal.jpeg",
      "id" : 23757784,
      "verified" : false
    }
  },
  "id" : 160432571761704960,
  "created_at" : "2012-01-20 18:44:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "160430667585437697",
  "text" : "RT @mimismutts: How in the world did we live without twitter all those yrs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "160427143787057152",
    "text" : "How in the world did we live without twitter all those yrs",
    "id" : 160427143787057152,
    "created_at" : "2012-01-20 18:23:06 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 160430667585437697,
  "created_at" : "2012-01-20 18:37:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    }, {
      "name" : "TIMESwampland",
      "screen_name" : "TIMESwampland",
      "indices" : [ 106, 120 ],
      "id_str" : "15896703",
      "id" : 15896703
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 79, 99 ],
      "url" : "http:\/\/t.co\/yQQs64kj",
      "expanded_url" : "http:\/\/ti.me\/xedmKZ",
      "display_url" : "ti.me\/xedmKZ"
    } ]
  },
  "geo" : { },
  "id_str" : "160387259705720834",
  "text" : "RT @TIME: Didn't catch the South Carolina GOP debate? Here's what you missed | http:\/\/t.co\/yQQs64kj  (via @TIMESwampland)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TIMESwampland",
        "screen_name" : "TIMESwampland",
        "indices" : [ 96, 110 ],
        "id_str" : "15896703",
        "id" : 15896703
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/yQQs64kj",
        "expanded_url" : "http:\/\/ti.me\/xedmKZ",
        "display_url" : "ti.me\/xedmKZ"
      } ]
    },
    "geo" : { },
    "id_str" : "160368507253555200",
    "text" : "Didn't catch the South Carolina GOP debate? Here's what you missed | http:\/\/t.co\/yQQs64kj  (via @TIMESwampland)",
    "id" : 160368507253555200,
    "created_at" : "2012-01-20 14:30:06 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 160387259705720834,
  "created_at" : "2012-01-20 15:44:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Richard Wiseman",
      "screen_name" : "RichardWiseman",
      "indices" : [ 9, 24 ],
      "id_str" : "19512493",
      "id" : 19512493
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 97, 117 ],
      "url" : "http:\/\/t.co\/rWyCvbtA",
      "expanded_url" : "http:\/\/bit.ly\/Anf9fI",
      "display_url" : "bit.ly\/Anf9fI"
    } ]
  },
  "geo" : { },
  "id_str" : "160371878056308736",
  "text" : "YES!! RT @RichardWiseman: What do you think to the idea of schools with no classrooms or desks?  http:\/\/t.co\/rWyCvbtA",
  "id" : 160371878056308736,
  "created_at" : "2012-01-20 14:43:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 0, 9 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "160362345300893696",
  "geo" : { },
  "id_str" : "160369177494962176",
  "in_reply_to_user_id" : 14986977,
  "text" : "@Teawench LOL",
  "id" : 160369177494962176,
  "in_reply_to_status_id" : 160362345300893696,
  "created_at" : "2012-01-20 14:32:46 +0000",
  "in_reply_to_screen_name" : "Teawench",
  "in_reply_to_user_id_str" : "14986977",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments",
      "indices" : [ 3, 15 ],
      "id_str" : "17486629",
      "id" : 17486629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159759966771744768",
  "text" : "RT @Zen_Moments: When in doubt, ask: 'What would love do here?' Then do it! ~ Gini Gentry",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/astore.amazon.com\/zenmom-20\" rel=\"nofollow\"\u003EZen Moments Bookstore\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159744293819518976",
    "text" : "When in doubt, ask: 'What would love do here?' Then do it! ~ Gini Gentry",
    "id" : 159744293819518976,
    "created_at" : "2012-01-18 21:09:42 +0000",
    "user" : {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments",
      "protected" : false,
      "id_str" : "17486629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117626620\/circle-1_normal.PNG",
      "id" : 17486629,
      "verified" : false
    }
  },
  "id" : 159759966771744768,
  "created_at" : "2012-01-18 22:11:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 58, 71 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/PZmrG793",
      "expanded_url" : "http:\/\/tl.gd\/fdiv9d",
      "display_url" : "tl.gd\/fdiv9d"
    } ]
  },
  "geo" : { },
  "id_str" : "159758358151299072",
  "text" : "Over 600 votes! Keep going! &gt;&gt; peeps, plz check out @UnseeingEyes tweets and if so inclined, vote: (cont) http:\/\/t.co\/PZmrG793",
  "id" : 159758358151299072,
  "created_at" : "2012-01-18 22:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Amazon Appstore",
      "screen_name" : "amazonappstore",
      "indices" : [ 37, 52 ],
      "id_str" : "247483633",
      "id" : 247483633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleFire",
      "indices" : [ 60, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159739413449027584",
  "text" : "found a few more promising apps from @amazonappstore for my #KindleFire .. Jumbline, Wordsmith, TuneIn : )",
  "id" : 159739413449027584,
  "created_at" : "2012-01-18 20:50:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ginger Brickhouse",
      "screen_name" : "JoyOfSects",
      "indices" : [ 3, 14 ],
      "id_str" : "157178221",
      "id" : 157178221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159738679181582337",
  "text" : "RT @JoyOfSects: Me: 'Give me your SSN so I can add U as a beneficiary on my insurance.' Sister: 'Like I need another reason to want you  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159726509878292480",
    "text" : "Me: 'Give me your SSN so I can add U as a beneficiary on my insurance.' Sister: 'Like I need another reason to want you dead.' &lt;3 her!",
    "id" : 159726509878292480,
    "created_at" : "2012-01-18 19:59:02 +0000",
    "user" : {
      "name" : "Ginger Brickhouse",
      "screen_name" : "JoyOfSects",
      "protected" : false,
      "id_str" : "157178221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3461408267\/9ae4101cf09fe436affbdd5106ce4f20_normal.jpeg",
      "id" : 157178221,
      "verified" : false
    }
  },
  "id" : 159738679181582337,
  "created_at" : "2012-01-18 20:47:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KindleFireDept",
      "screen_name" : "KindleFireDept",
      "indices" : [ 3, 18 ],
      "id_str" : "867417752",
      "id" : 867417752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleFire",
      "indices" : [ 39, 50 ]
    }, {
      "text" : "Amazon",
      "indices" : [ 77, 84 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ALSKzthD",
      "expanded_url" : "http:\/\/fireapps.blogspot.com\/2012\/01\/fire-software-update-622-kindle-lending.html",
      "display_url" : "fireapps.blogspot.com\/2012\/01\/fire-s\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "159673928246247424",
  "text" : "RT @KindleFireDept: Find out about the #KindleFire software update 6.2.2 and #Amazon's new Send to Kindle program! http:\/\/t.co\/ALSKzthD",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "KindleFire",
        "indices" : [ 19, 30 ]
      }, {
        "text" : "Amazon",
        "indices" : [ 57, 64 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/ALSKzthD",
        "expanded_url" : "http:\/\/fireapps.blogspot.com\/2012\/01\/fire-software-update-622-kindle-lending.html",
        "display_url" : "fireapps.blogspot.com\/2012\/01\/fire-s\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "159666132045930496",
    "text" : "Find out about the #KindleFire software update 6.2.2 and #Amazon's new Send to Kindle program! http:\/\/t.co\/ALSKzthD",
    "id" : 159666132045930496,
    "created_at" : "2012-01-18 15:59:06 +0000",
    "user" : {
      "name" : "BookSends",
      "screen_name" : "BookSends",
      "protected" : false,
      "id_str" : "398225352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520255313811755008\/WYb6d_5Y_normal.png",
      "id" : 398225352,
      "verified" : false
    }
  },
  "id" : 159673928246247424,
  "created_at" : "2012-01-18 16:30:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleFire",
      "indices" : [ 63, 74 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159672672454836225",
  "text" : "wonder if there's a way to keep books from downloading onto my #KindleFire carousel? (don't read on my Fire.)",
  "id" : 159672672454836225,
  "created_at" : "2012-01-18 16:25:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Forever Lazy",
      "screen_name" : "ForeverLazy",
      "indices" : [ 3, 15 ],
      "id_str" : "60726920",
      "id" : 60726920
    }, {
      "name" : "TIME NewsFeed",
      "screen_name" : "TIMENewsFeed",
      "indices" : [ 102, 115 ],
      "id_str" : "188443744",
      "id" : 188443744
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/dmMHhGUg",
      "expanded_url" : "http:\/\/ti.me\/yqFxob",
      "display_url" : "ti.me\/yqFxob"
    } ]
  },
  "geo" : { },
  "id_str" : "159483649555828740",
  "text" : "RT @ForeverLazy: Louisiana lawmaker wants to ban wearing pajamas in public | http:\/\/t.co\/dmMHhGUg via @TIMENewsFeed - How dare you sir.. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "TIME NewsFeed",
        "screen_name" : "TIMENewsFeed",
        "indices" : [ 85, 98 ],
        "id_str" : "188443744",
        "id" : 188443744
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 60, 80 ],
        "url" : "http:\/\/t.co\/dmMHhGUg",
        "expanded_url" : "http:\/\/ti.me\/yqFxob",
        "display_url" : "ti.me\/yqFxob"
      } ]
    },
    "geo" : { },
    "id_str" : "159482069335031810",
    "text" : "Louisiana lawmaker wants to ban wearing pajamas in public | http:\/\/t.co\/dmMHhGUg via @TIMENewsFeed - How dare you sir... how dare you.",
    "id" : 159482069335031810,
    "created_at" : "2012-01-18 03:47:43 +0000",
    "user" : {
      "name" : "Forever Lazy",
      "screen_name" : "ForeverLazy",
      "protected" : false,
      "id_str" : "60726920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1476573982\/FL_twitter_icon_normal.jpg",
      "id" : 60726920,
      "verified" : false
    }
  },
  "id" : 159483649555828740,
  "created_at" : "2012-01-18 03:53:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159478793046728704",
  "text" : "RT @SpiritualNurse: \"You wouldn't desire something if you didn't have the talent to carry it out.\" by Napoleon Hill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159467413757370368",
    "text" : "\"You wouldn't desire something if you didn't have the talent to carry it out.\" by Napoleon Hill",
    "id" : 159467413757370368,
    "created_at" : "2012-01-18 02:49:28 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 159478793046728704,
  "created_at" : "2012-01-18 03:34:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 11, 31 ],
      "url" : "http:\/\/t.co\/jnToeHj0",
      "expanded_url" : "http:\/\/about.me",
      "display_url" : "about.me"
    } ]
  },
  "in_reply_to_status_id_str" : "159472422528098304",
  "geo" : { },
  "id_str" : "159478249427173376",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind http:\/\/t.co\/jnToeHj0",
  "id" : 159478249427173376,
  "in_reply_to_status_id" : 159472422528098304,
  "created_at" : "2012-01-18 03:32:32 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 0, 13 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "159453142172442624",
  "geo" : { },
  "id_str" : "159455796999094272",
  "in_reply_to_user_id" : 73908822,
  "text" : "@DwayneReaves same old, same old..lol",
  "id" : 159455796999094272,
  "in_reply_to_status_id" : 159453142172442624,
  "created_at" : "2012-01-18 02:03:19 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Bichon",
      "screen_name" : "KatieBichon",
      "indices" : [ 3, 15 ],
      "id_str" : "27279694",
      "id" : 27279694
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159452065809170432",
  "text" : "RT @KatieBichon: There is no therapy in the world better than a puppy licking your face!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tweetspinner.com\/\" rel=\"nofollow\"\u003ETweet Spinner\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159447536195735553",
    "text" : "There is no therapy in the world better than a puppy licking your face!",
    "id" : 159447536195735553,
    "created_at" : "2012-01-18 01:30:29 +0000",
    "user" : {
      "name" : "Katie Bichon",
      "screen_name" : "KatieBichon",
      "protected" : false,
      "id_str" : "27279694",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2036362719\/profile_image_normal.jpg",
      "id" : 27279694,
      "verified" : false
    }
  },
  "id" : 159452065809170432,
  "created_at" : "2012-01-18 01:48:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Angie",
      "screen_name" : "SavvyBabii",
      "indices" : [ 21, 32 ],
      "id_str" : "54439786",
      "id" : 54439786
    }, {
      "name" : "Faith In God",
      "screen_name" : "PrayInFaith",
      "indices" : [ 82, 94 ],
      "id_str" : "189671070",
      "id" : 189671070
    }, {
      "name" : "Carmen Pray",
      "screen_name" : "sistagirl2u",
      "indices" : [ 95, 107 ],
      "id_str" : "58394460",
      "id" : 58394460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159451660014469120",
  "text" : "RT @DwayneReaves: RT @SavvyBabii: Weave in faith & God will find the thread. | RT @PrayInFaith @sistagirl2u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Angie",
        "screen_name" : "SavvyBabii",
        "indices" : [ 3, 14 ],
        "id_str" : "54439786",
        "id" : 54439786
      }, {
        "name" : "Faith In God",
        "screen_name" : "PrayInFaith",
        "indices" : [ 64, 76 ],
        "id_str" : "189671070",
        "id" : 189671070
      }, {
        "name" : "Carmen Pray",
        "screen_name" : "sistagirl2u",
        "indices" : [ 77, 89 ],
        "id_str" : "58394460",
        "id" : 58394460
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159450798835761153",
    "text" : "RT @SavvyBabii: Weave in faith & God will find the thread. | RT @PrayInFaith @sistagirl2u",
    "id" : 159450798835761153,
    "created_at" : "2012-01-18 01:43:27 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 159451660014469120,
  "created_at" : "2012-01-18 01:46:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158892395390439424",
  "geo" : { },
  "id_str" : "159439878646538241",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl good to hear you are back home! ((hugs))",
  "id" : 159439878646538241,
  "in_reply_to_status_id" : 158892395390439424,
  "created_at" : "2012-01-18 01:00:03 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenyg",
      "screen_name" : "JenyG",
      "indices" : [ 28, 34 ],
      "id_str" : "61921510",
      "id" : 61921510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159439279473442816",
  "text" : "@SamsaricWarrior your wifey @jenyg did an awesome job w updates.. so glad yr home now!",
  "id" : 159439279473442816,
  "created_at" : "2012-01-18 00:57:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    }, {
      "name" : "Tropical Traditions",
      "screen_name" : "Troptraditions",
      "indices" : [ 103, 118 ],
      "id_str" : "21357741",
      "id" : 21357741
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaways",
      "indices" : [ 119, 129 ]
    }, {
      "text" : "natural",
      "indices" : [ 130, 138 ]
    } ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/eQZsbN5S",
      "expanded_url" : "http:\/\/bit.ly\/AdUHvo",
      "display_url" : "bit.ly\/AdUHvo"
    } ]
  },
  "geo" : { },
  "id_str" : "159421601148960768",
  "text" : "RT @taraburner: Tropical Traditions Powered Laundry Detergent Review & Giveaway | http:\/\/t.co\/eQZsbN5S @troptraditions #giveaways #natural",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetmeme.com\" rel=\"nofollow\"\u003ETweetMeme\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tropical Traditions",
        "screen_name" : "Troptraditions",
        "indices" : [ 87, 102 ],
        "id_str" : "21357741",
        "id" : 21357741
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaways",
        "indices" : [ 103, 113 ]
      }, {
        "text" : "natural",
        "indices" : [ 114, 122 ]
      } ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/eQZsbN5S",
        "expanded_url" : "http:\/\/bit.ly\/AdUHvo",
        "display_url" : "bit.ly\/AdUHvo"
      } ]
    },
    "geo" : { },
    "id_str" : "159410592594137088",
    "text" : "Tropical Traditions Powered Laundry Detergent Review & Giveaway | http:\/\/t.co\/eQZsbN5S @troptraditions #giveaways #natural",
    "id" : 159410592594137088,
    "created_at" : "2012-01-17 23:03:41 +0000",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 159421601148960768,
  "created_at" : "2012-01-17 23:47:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159321535566462976",
  "text" : "RT @By_Bashar: Every adversity, every failure, every heartache carries with it the seed of an equal or greater benefit ~ Napoleon Hill",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159320393050636288",
    "text" : "Every adversity, every failure, every heartache carries with it the seed of an equal or greater benefit ~ Napoleon Hill",
    "id" : 159320393050636288,
    "created_at" : "2012-01-17 17:05:16 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 159321535566462976,
  "created_at" : "2012-01-17 17:09:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "petition",
      "indices" : [ 125, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/5zzold7U",
      "expanded_url" : "http:\/\/wh.gov\/WDY",
      "display_url" : "wh.gov\/WDY"
    } ]
  },
  "geo" : { },
  "id_str" : "159316141494378497",
  "text" : "Create Presidential Six Sigma Super Committee to identify gov waste, increase efficiencies, create jobs http:\/\/t.co\/5zzold7U #petition",
  "id" : 159316141494378497,
  "created_at" : "2012-01-17 16:48:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PowerfulLivingDesign",
      "screen_name" : "DesignIntuition",
      "indices" : [ 3, 19 ],
      "id_str" : "109693092",
      "id" : 109693092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 60, 80 ],
      "url" : "http:\/\/t.co\/lPomrUxT",
      "expanded_url" : "http:\/\/tinyurl.com\/4y35a53",
      "display_url" : "tinyurl.com\/4y35a53"
    } ]
  },
  "geo" : { },
  "id_str" : "159087225152356352",
  "text" : "RT @DesignIntuition: Universal matter found in our genomes. http:\/\/t.co\/lPomrUxT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/lPomrUxT",
        "expanded_url" : "http:\/\/tinyurl.com\/4y35a53",
        "display_url" : "tinyurl.com\/4y35a53"
      } ]
    },
    "geo" : { },
    "id_str" : "152411928516505601",
    "text" : "Universal matter found in our genomes. http:\/\/t.co\/lPomrUxT",
    "id" : 152411928516505601,
    "created_at" : "2011-12-29 15:33:30 +0000",
    "user" : {
      "name" : "PowerfulLivingDesign",
      "screen_name" : "DesignIntuition",
      "protected" : false,
      "id_str" : "109693092",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/580467733948686337\/JY6BVlmm_normal.jpg",
      "id" : 109693092,
      "verified" : false
    }
  },
  "id" : 159087225152356352,
  "created_at" : "2012-01-17 01:38:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PowerfulLivingDesign",
      "screen_name" : "DesignIntuition",
      "indices" : [ 98, 114 ],
      "id_str" : "109693092",
      "id" : 109693092
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159086626985877505",
  "text" : "RT @By_Bashar: Conditions exist for you to see that you are innately larger than all of them.~ rt @DesignIntuition",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "PowerfulLivingDesign",
        "screen_name" : "DesignIntuition",
        "indices" : [ 83, 99 ],
        "id_str" : "109693092",
        "id" : 109693092
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "159086338690387968",
    "text" : "Conditions exist for you to see that you are innately larger than all of them.~ rt @DesignIntuition",
    "id" : 159086338690387968,
    "created_at" : "2012-01-17 01:35:13 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 159086626985877505,
  "created_at" : "2012-01-17 01:36:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "159082324552724480",
  "text" : "I am now a red\/black belt. This scares me...",
  "id" : 159082324552724480,
  "created_at" : "2012-01-17 01:19:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "BtheCalvinist",
      "screen_name" : "BtheCalvinist",
      "indices" : [ 19, 33 ],
      "id_str" : "344230025",
      "id" : 344230025
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158952509883428864",
  "text" : "RT @ZachsMind: BTW @BtheCalvinist displaying a dead man on a stick is an offense to mankind. He allegedly came down off that cross. Why  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "BtheCalvinist",
        "screen_name" : "BtheCalvinist",
        "indices" : [ 4, 18 ],
        "id_str" : "344230025",
        "id" : 344230025
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158952025512624129",
    "text" : "BTW @BtheCalvinist displaying a dead man on a stick is an offense to mankind. He allegedly came down off that cross. Why keep him up there?",
    "id" : 158952025512624129,
    "created_at" : "2012-01-16 16:41:30 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 158952509883428864,
  "created_at" : "2012-01-16 16:43:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "WordsAloneApp",
      "screen_name" : "WordsAloneApp",
      "indices" : [ 0, 14 ],
      "id_str" : "440979078",
      "id" : 440979078
    }, {
      "name" : "donna cooter",
      "screen_name" : "st0rmy1",
      "indices" : [ 15, 23 ],
      "id_str" : "454359473",
      "id" : 454359473
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154646058352394240",
  "geo" : { },
  "id_str" : "158952140180688896",
  "in_reply_to_user_id" : 440979078,
  "text" : "@WordsAloneApp @st0rmy1 I second that motion..lol.",
  "id" : 158952140180688896,
  "in_reply_to_status_id" : 154646058352394240,
  "created_at" : "2012-01-16 16:41:58 +0000",
  "in_reply_to_screen_name" : "WordsAloneApp",
  "in_reply_to_user_id_str" : "440979078",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordswithfriends",
      "indices" : [ 7, 24 ]
    }, {
      "text" : "KindleFire",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158944816397430785",
  "text" : "I play #wordswithfriends on my #KindleFire .. noticed timing is weird. I check for turns ..then turn shows up played hours ago",
  "id" : 158944816397430785,
  "created_at" : "2012-01-16 16:12:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158938965817307136",
  "text" : "RT @Jambodhi: \"Even if everyone had an IQ of 200, you'd have exactly the same range of personalities as you have now\"  ~ Haier",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158936950693314561",
    "text" : "\"Even if everyone had an IQ of 200, you'd have exactly the same range of personalities as you have now\"  ~ Haier",
    "id" : 158936950693314561,
    "created_at" : "2012-01-16 15:41:36 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 158938965817307136,
  "created_at" : "2012-01-16 15:49:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158938938843742208",
  "text" : "RT @Jambodhi: \"Intelligence is independent of personality and emotion, you can have very intelligent people who are just kind of crazy p ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158936766349451264",
    "text" : "\"Intelligence is independent of personality and emotion, you can have very intelligent people who are just kind of crazy people\"  ~Haier",
    "id" : 158936766349451264,
    "created_at" : "2012-01-16 15:40:52 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 158938938843742208,
  "created_at" : "2012-01-16 15:49:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "JaqStone",
      "screen_name" : "JaqStone",
      "indices" : [ 26, 35 ],
      "id_str" : "2511454956",
      "id" : 2511454956
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photo",
      "indices" : [ 87, 93 ]
    }, {
      "text" : "cute",
      "indices" : [ 94, 99 ]
    }, {
      "text" : "dog",
      "indices" : [ 100, 104 ]
    }, {
      "text" : "animal",
      "indices" : [ 105, 112 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/qT0C8hN6",
      "expanded_url" : "http:\/\/dld.bz\/ayaF5",
      "display_url" : "dld.bz\/ayaF5"
    } ]
  },
  "geo" : { },
  "id_str" : "158602377501478912",
  "text" : "RT @KerriFar: Cuuuute! RT @JaqStone: Adorable puppy is a bow thief with a guilty face. #photo #cute #dog #animal http:\/\/t.co\/qT0C8hN6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "JaqStone",
        "screen_name" : "JaqStone",
        "indices" : [ 12, 21 ],
        "id_str" : "2511454956",
        "id" : 2511454956
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photo",
        "indices" : [ 73, 79 ]
      }, {
        "text" : "cute",
        "indices" : [ 80, 85 ]
      }, {
        "text" : "dog",
        "indices" : [ 86, 90 ]
      }, {
        "text" : "animal",
        "indices" : [ 91, 98 ]
      } ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/qT0C8hN6",
        "expanded_url" : "http:\/\/dld.bz\/ayaF5",
        "display_url" : "dld.bz\/ayaF5"
      } ]
    },
    "geo" : { },
    "id_str" : "158602100979404800",
    "text" : "Cuuuute! RT @JaqStone: Adorable puppy is a bow thief with a guilty face. #photo #cute #dog #animal http:\/\/t.co\/qT0C8hN6",
    "id" : 158602100979404800,
    "created_at" : "2012-01-15 17:31:02 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 158602377501478912,
  "created_at" : "2012-01-15 17:32:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Ingram",
      "screen_name" : "TheBabayaga",
      "indices" : [ 0, 12 ],
      "id_str" : "17021755",
      "id" : 17021755
    }, {
      "name" : "CHERyL Ingram",
      "screen_name" : "Gesuschic",
      "indices" : [ 27, 37 ],
      "id_str" : "29681555",
      "id" : 29681555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158569285491494912",
  "geo" : { },
  "id_str" : "158595970966364161",
  "in_reply_to_user_id" : 17021755,
  "text" : "@TheBabayaga @tragic_pizza @Gesuschic used 2 wonder why I didnt feel God in church (as child.. when I went w friends a few times)",
  "id" : 158595970966364161,
  "in_reply_to_status_id" : 158569285491494912,
  "created_at" : "2012-01-15 17:06:40 +0000",
  "in_reply_to_screen_name" : "TheBabayaga",
  "in_reply_to_user_id_str" : "17021755",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lisa Ingram",
      "screen_name" : "TheBabayaga",
      "indices" : [ 0, 12 ],
      "id_str" : "17021755",
      "id" : 17021755
    }, {
      "name" : "CHERyL Ingram",
      "screen_name" : "Gesuschic",
      "indices" : [ 27, 37 ],
      "id_str" : "29681555",
      "id" : 29681555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158569549531332609",
  "geo" : { },
  "id_str" : "158595595483881472",
  "in_reply_to_user_id" : 17021755,
  "text" : "@TheBabayaga @tragic_pizza @Gesuschic God speaks 2me thru other ppl, nature and books..",
  "id" : 158595595483881472,
  "in_reply_to_status_id" : 158569549531332609,
  "created_at" : "2012-01-15 17:05:11 +0000",
  "in_reply_to_screen_name" : "TheBabayaga",
  "in_reply_to_user_id_str" : "17021755",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Maarten Verkoren",
      "screen_name" : "verkoren",
      "indices" : [ 3, 12 ],
      "id_str" : "14314467",
      "id" : 14314467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 41, 61 ],
      "url" : "http:\/\/t.co\/i9EnAvRP",
      "expanded_url" : "http:\/\/bit.ly\/zy2rO9",
      "display_url" : "bit.ly\/zy2rO9"
    } ]
  },
  "geo" : { },
  "id_str" : "158593884635664384",
  "text" : "RT @verkoren: 10 Myths About Introverts\n http:\/\/t.co\/i9EnAvRP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 27, 47 ],
        "url" : "http:\/\/t.co\/i9EnAvRP",
        "expanded_url" : "http:\/\/bit.ly\/zy2rO9",
        "display_url" : "bit.ly\/zy2rO9"
      } ]
    },
    "geo" : { },
    "id_str" : "158590735623536640",
    "text" : "10 Myths About Introverts\n http:\/\/t.co\/i9EnAvRP",
    "id" : 158590735623536640,
    "created_at" : "2012-01-15 16:45:52 +0000",
    "user" : {
      "name" : "Maarten Verkoren",
      "screen_name" : "verkoren",
      "protected" : false,
      "id_str" : "14314467",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/716920524186775552\/zop8BAp6_normal.jpg",
      "id" : 14314467,
      "verified" : false
    }
  },
  "id" : 158593884635664384,
  "created_at" : "2012-01-15 16:58:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 58, 71 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 132 ],
      "url" : "http:\/\/t.co\/SPerRXQT",
      "expanded_url" : "http:\/\/tl.gd\/fblebl",
      "display_url" : "tl.gd\/fblebl"
    } ]
  },
  "geo" : { },
  "id_str" : "158586569295532033",
  "text" : "Over 400 votes! Keep going! &gt;&gt; peeps, plz check out @UnseeingEyes tweets and if so inclined, vote: (cont) http:\/\/t.co\/SPerRXQT",
  "id" : 158586569295532033,
  "created_at" : "2012-01-15 16:29:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "NEWS",
      "indices" : [ 131, 136 ]
    } ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/ZkS6chkp",
      "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2086494\/Piste-cake-Death-defying-snowboarders-make-history-conquer-VERTICAL-Alaskan-slope.html",
      "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158585260525879297",
  "text" : "RT @UnseeingEyes: Death-defying snowboarders make history by becoming FIRST to conquer VERTICAL Alaskan slope http:\/\/t.co\/ZkS6chkp #NEWS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "NEWS",
        "indices" : [ 113, 118 ]
      } ],
      "urls" : [ {
        "indices" : [ 92, 112 ],
        "url" : "http:\/\/t.co\/ZkS6chkp",
        "expanded_url" : "http:\/\/www.dailymail.co.uk\/news\/article-2086494\/Piste-cake-Death-defying-snowboarders-make-history-conquer-VERTICAL-Alaskan-slope.html",
        "display_url" : "dailymail.co.uk\/news\/article-2\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "158578502575202304",
    "text" : "Death-defying snowboarders make history by becoming FIRST to conquer VERTICAL Alaskan slope http:\/\/t.co\/ZkS6chkp #NEWS",
    "id" : 158578502575202304,
    "created_at" : "2012-01-15 15:57:15 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 158585260525879297,
  "created_at" : "2012-01-15 16:24:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lee and Steven Hager",
      "screen_name" : "LSHager",
      "indices" : [ 3, 11 ],
      "id_str" : "234627471",
      "id" : 234627471
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158371602566873088",
  "text" : "RT @LSHager: I have learned so much from God that I can no longer call myself a Christian, a Hindu, a Muslim, a Buddhist, a Jew\u2014Hafiz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158346141652615168",
    "text" : "I have learned so much from God that I can no longer call myself a Christian, a Hindu, a Muslim, a Buddhist, a Jew\u2014Hafiz",
    "id" : 158346141652615168,
    "created_at" : "2012-01-15 00:33:56 +0000",
    "user" : {
      "name" : "Lee and Steven Hager",
      "screen_name" : "LSHager",
      "protected" : false,
      "id_str" : "234627471",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1208095950\/Social_Media_headshot_edited_normal.jpg",
      "id" : 234627471,
      "verified" : false
    }
  },
  "id" : 158371602566873088,
  "created_at" : "2012-01-15 02:15:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "chris",
      "screen_name" : "alieumby",
      "indices" : [ 3, 12 ],
      "id_str" : "37279132",
      "id" : 37279132
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158366772943261696",
  "text" : "RT @Alieumby: It doesn't concern me what god, if any, you believe in. As long as your belief is true and you understand that it's just y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158227617688989697",
    "text" : "It doesn't concern me what god, if any, you believe in. As long as your belief is true and you understand that it's just your own.",
    "id" : 158227617688989697,
    "created_at" : "2012-01-14 16:42:58 +0000",
    "user" : {
      "name" : "chris",
      "screen_name" : "alieumby",
      "protected" : false,
      "id_str" : "37279132",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1677564396\/rainbowimage_normal.jpg",
      "id" : 37279132,
      "verified" : false
    }
  },
  "id" : 158366772943261696,
  "created_at" : "2012-01-15 01:55:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158361866018623488",
  "text" : "visit from brown stray cat then possum.. its a good night..lol",
  "id" : 158361866018623488,
  "created_at" : "2012-01-15 01:36:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158359957484486656",
  "text" : "RT @ChrisGroove1: Hope everyone is having a nice and cuddly evening.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158358106143858689",
    "text" : "Hope everyone is having a nice and cuddly evening.",
    "id" : 158358106143858689,
    "created_at" : "2012-01-15 01:21:29 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 158359957484486656,
  "created_at" : "2012-01-15 01:28:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158359847937646592",
  "text" : "RT @UnseeingEyes: I don't see it as numbers. I see each VOTE as a person. & I'm FOUR people away from 400. So Friends, PLEASE act now: h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 117, 137 ],
        "url" : "http:\/\/t.co\/gG5V1JSG",
        "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
        "display_url" : "shortyawards.com\/UnseeingEyes"
      } ]
    },
    "geo" : { },
    "id_str" : "158358680662835201",
    "text" : "I don't see it as numbers. I see each VOTE as a person. & I'm FOUR people away from 400. So Friends, PLEASE act now: http:\/\/t.co\/gG5V1JSG",
    "id" : 158358680662835201,
    "created_at" : "2012-01-15 01:23:46 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 158359847937646592,
  "created_at" : "2012-01-15 01:28:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/b8BZKIMU",
      "expanded_url" : "http:\/\/karma1stprinciple.blogspot.com\/2011\/12\/law-of-creation.html?spref=tw",
      "display_url" : "karma1stprinciple.blogspot.com\/2011\/12\/law-of\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158342743419129856",
  "text" : "RT @AnAmericanMonk: My latest blog on Karma 'The Law of the Mirrors' What you see in another must be in you first? http:\/\/t.co\/b8BZKIMU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/b8BZKIMU",
        "expanded_url" : "http:\/\/karma1stprinciple.blogspot.com\/2011\/12\/law-of-creation.html?spref=tw",
        "display_url" : "karma1stprinciple.blogspot.com\/2011\/12\/law-of\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "158342331504926720",
    "text" : "My latest blog on Karma 'The Law of the Mirrors' What you see in another must be in you first? http:\/\/t.co\/b8BZKIMU",
    "id" : 158342331504926720,
    "created_at" : "2012-01-15 00:18:48 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 158342743419129856,
  "created_at" : "2012-01-15 00:20:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 68, 74 ]
    }, {
      "text" : "nature",
      "indices" : [ 75, 82 ]
    }, {
      "text" : "outdoors",
      "indices" : [ 83, 92 ]
    } ],
    "urls" : [ {
      "indices" : [ 45, 65 ],
      "url" : "http:\/\/t.co\/ADKnwW8g",
      "expanded_url" : "http:\/\/su.pr\/2ZxApY",
      "display_url" : "su.pr\/2ZxApY"
    } ]
  },
  "geo" : { },
  "id_str" : "158341877337300992",
  "text" : "RT @KerriFar: Taking a Nap ~ Mourning Dove ~ http:\/\/t.co\/ADKnwW8g ~ #birds #nature #outdoors",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 54, 60 ]
      }, {
        "text" : "nature",
        "indices" : [ 61, 68 ]
      }, {
        "text" : "outdoors",
        "indices" : [ 69, 78 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/ADKnwW8g",
        "expanded_url" : "http:\/\/su.pr\/2ZxApY",
        "display_url" : "su.pr\/2ZxApY"
      } ]
    },
    "geo" : { },
    "id_str" : "158341379666350080",
    "text" : "Taking a Nap ~ Mourning Dove ~ http:\/\/t.co\/ADKnwW8g ~ #birds #nature #outdoors",
    "id" : 158341379666350080,
    "created_at" : "2012-01-15 00:15:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 158341877337300992,
  "created_at" : "2012-01-15 00:17:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158294133377736704",
  "geo" : { },
  "id_str" : "158339458268270592",
  "in_reply_to_user_id" : 233971651,
  "text" : "@Selaniest ((hugs))",
  "id" : 158339458268270592,
  "in_reply_to_status_id" : 158294133377736704,
  "created_at" : "2012-01-15 00:07:23 +0000",
  "in_reply_to_screen_name" : "UnwashedThe",
  "in_reply_to_user_id_str" : "233971651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "indices" : [ 3, 15 ],
      "id_str" : "76817286",
      "id" : 76817286
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158333838592970752",
  "text" : "RT @ShipsofSong: Do not look to finance to return your good deeds, look to the universe.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158331051121455104",
    "text" : "Do not look to finance to return your good deeds, look to the universe.",
    "id" : 158331051121455104,
    "created_at" : "2012-01-14 23:33:58 +0000",
    "user" : {
      "name" : "Ships of Song",
      "screen_name" : "ShipsofSong",
      "protected" : false,
      "id_str" : "76817286",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/499211752299442176\/VPhVmhHj_normal.jpeg",
      "id" : 76817286,
      "verified" : false
    }
  },
  "id" : 158333838592970752,
  "created_at" : "2012-01-14 23:45:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 21, 34 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 88 ],
      "url" : "http:\/\/t.co\/6HKs7aEp",
      "expanded_url" : "http:\/\/shortyawards.com\/UnseeingEyes",
      "display_url" : "shortyawards.com\/UnseeingEyes"
    } ]
  },
  "geo" : { },
  "id_str" : "158332664737312768",
  "text" : "peeps, plz check out @UnseeingEyes tweets and if so inclined, vote: http:\/\/t.co\/6HKs7aEp - for author. thx!",
  "id" : 158332664737312768,
  "created_at" : "2012-01-14 23:40:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158326918041698307",
  "text" : "RT @fearfuldogs: ugh. another radio show vet saying that speaking soothingly 2 fearful dog will tell them they r right 2 b afraid. LOOKO ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158325046430007296",
    "text" : "ugh. another radio show vet saying that speaking soothingly 2 fearful dog will tell them they r right 2 b afraid. LOOKOUT! is how I'd do it",
    "id" : 158325046430007296,
    "created_at" : "2012-01-14 23:10:07 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 158326918041698307,
  "created_at" : "2012-01-14 23:17:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deb Drake",
      "screen_name" : "debirlfan",
      "indices" : [ 3, 13 ],
      "id_str" : "18296413",
      "id" : 18296413
    }, {
      "name" : "Kyle Peterson",
      "screen_name" : "doghauler",
      "indices" : [ 15, 25 ],
      "id_str" : "19422439",
      "id" : 19422439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 70, 90 ],
      "url" : "http:\/\/t.co\/zuYwUsUS",
      "expanded_url" : "http:\/\/tinyurl.com\/7w6btkr",
      "display_url" : "tinyurl.com\/7w6btkr"
    } ]
  },
  "geo" : { },
  "id_str" : "158308235433091072",
  "text" : "RT @debirlfan: @doghauler  Escaped rescue in PA, could you please RT? http:\/\/t.co\/zuYwUsUS",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kyle Peterson",
        "screen_name" : "doghauler",
        "indices" : [ 0, 10 ],
        "id_str" : "19422439",
        "id" : 19422439
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/zuYwUsUS",
        "expanded_url" : "http:\/\/tinyurl.com\/7w6btkr",
        "display_url" : "tinyurl.com\/7w6btkr"
      } ]
    },
    "geo" : { },
    "id_str" : "158304531116077056",
    "in_reply_to_user_id" : 19422439,
    "text" : "@doghauler  Escaped rescue in PA, could you please RT? http:\/\/t.co\/zuYwUsUS",
    "id" : 158304531116077056,
    "created_at" : "2012-01-14 21:48:36 +0000",
    "in_reply_to_screen_name" : "doghauler",
    "in_reply_to_user_id_str" : "19422439",
    "user" : {
      "name" : "Deb Drake",
      "screen_name" : "debirlfan",
      "protected" : false,
      "id_str" : "18296413",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3652627701\/808c8c450976f582c6ef0ffd17fa4dd8_normal.jpeg",
      "id" : 18296413,
      "verified" : false
    }
  },
  "id" : 158308235433091072,
  "created_at" : "2012-01-14 22:03:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158307103667265537",
  "text" : "RT @Matth3ous: Woohoo! SETI is back online! Earth calling Gallifrey...Come in, Gallifrey...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158303386553417728",
    "text" : "Woohoo! SETI is back online! Earth calling Gallifrey...Come in, Gallifrey...",
    "id" : 158303386553417728,
    "created_at" : "2012-01-14 21:44:03 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 158307103667265537,
  "created_at" : "2012-01-14 21:58:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158286626185953280",
  "geo" : { },
  "id_str" : "158287898448363520",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone once was told I was a \"new\" soul.. reason for my shyness, trouble fitting in. always wondered..",
  "id" : 158287898448363520,
  "in_reply_to_status_id" : 158286626185953280,
  "created_at" : "2012-01-14 20:42:30 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158283366737788928",
  "geo" : { },
  "id_str" : "158285453601161216",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone watching \"science of the soul\" about a boy who was fighter pilot in past life.. really cool!",
  "id" : 158285453601161216,
  "in_reply_to_status_id" : 158283366737788928,
  "created_at" : "2012-01-14 20:32:47 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KindleWeatherStation",
      "screen_name" : "kindlews",
      "indices" : [ 3, 12 ],
      "id_str" : "419437422",
      "id" : 419437422
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158245836516626432",
  "text" : "RT @kindlews: We have upgraded our service recently. Features added: wind speed and direction, atmospheric pressure, quick launcher for  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158245096398143488",
    "text" : "We have upgraded our service recently. Features added: wind speed and direction, atmospheric pressure, quick launcher for Kindle. Enjoy.",
    "id" : 158245096398143488,
    "created_at" : "2012-01-14 17:52:25 +0000",
    "user" : {
      "name" : "KindleWeatherStation",
      "screen_name" : "kindlews",
      "protected" : false,
      "id_str" : "419437422",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1653546723\/twitter_logo_normal.jpg",
      "id" : 419437422,
      "verified" : false
    }
  },
  "id" : 158245836516626432,
  "created_at" : "2012-01-14 17:55:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 31, 39 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/01PFwAo7",
      "expanded_url" : "http:\/\/youtu.be\/lpQkP7LVCFY?a",
      "display_url" : "youtu.be\/lpQkP7LVCFY?a"
    } ]
  },
  "geo" : { },
  "id_str" : "158238926795055104",
  "text" : "RT @neardeathdoc: I uploaded a @YouTube video http:\/\/t.co\/01PFwAo7 Nonlocality: A New Understanding of Consciousness Spiritual",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 13, 21 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 28, 48 ],
        "url" : "http:\/\/t.co\/01PFwAo7",
        "expanded_url" : "http:\/\/youtu.be\/lpQkP7LVCFY?a",
        "display_url" : "youtu.be\/lpQkP7LVCFY?a"
      } ]
    },
    "geo" : { },
    "id_str" : "158225436411838464",
    "text" : "I uploaded a @YouTube video http:\/\/t.co\/01PFwAo7 Nonlocality: A New Understanding of Consciousness Spiritual",
    "id" : 158225436411838464,
    "created_at" : "2012-01-14 16:34:18 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 158238926795055104,
  "created_at" : "2012-01-14 17:27:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "158233648146030592",
  "geo" : { },
  "id_str" : "158237816172707840",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad what a handsome lil dude.. and such wisdom in those eyes!",
  "id" : 158237816172707840,
  "in_reply_to_status_id" : 158233648146030592,
  "created_at" : "2012-01-14 17:23:29 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "indices" : [ 3, 14 ],
      "id_str" : "15439395",
      "id" : 15439395
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/stephenfry\/status\/158152069994389504\/photo\/1",
      "indices" : [ 88, 108 ],
      "url" : "http:\/\/t.co\/eMdw5vgC",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AjHeeEDCIAAXUl9.jpg",
      "id_str" : "158152069998583808",
      "id" : 158152069998583808,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjHeeEDCIAAXUl9.jpg",
      "sizes" : [ {
        "h" : 457,
        "resize" : "fit",
        "w" : 658
      }, {
        "h" : 236,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 417,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 457,
        "resize" : "fit",
        "w" : 658
      } ],
      "display_url" : "pic.twitter.com\/eMdw5vgC"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158237272049860608",
  "text" : "RT @stephenfry: I'm sorry but there is a time and a place for breast feeding in public\u2026 http:\/\/t.co\/eMdw5vgC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/stephenfry\/status\/158152069994389504\/photo\/1",
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/eMdw5vgC",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AjHeeEDCIAAXUl9.jpg",
        "id_str" : "158152069998583808",
        "id" : 158152069998583808,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AjHeeEDCIAAXUl9.jpg",
        "sizes" : [ {
          "h" : 457,
          "resize" : "fit",
          "w" : 658
        }, {
          "h" : 236,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 417,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 457,
          "resize" : "fit",
          "w" : 658
        } ],
        "display_url" : "pic.twitter.com\/eMdw5vgC"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "158152069994389504",
    "text" : "I'm sorry but there is a time and a place for breast feeding in public\u2026 http:\/\/t.co\/eMdw5vgC",
    "id" : 158152069994389504,
    "created_at" : "2012-01-14 11:42:47 +0000",
    "user" : {
      "name" : "Stephen Fry",
      "screen_name" : "stephenfry",
      "protected" : false,
      "id_str" : "15439395",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/504060630450438144\/3tEN_Y7C_normal.png",
      "id" : 15439395,
      "verified" : true
    }
  },
  "id" : 158237272049860608,
  "created_at" : "2012-01-14 17:21:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158224535437574145",
  "text" : "my mom didnt want the house. she sensed bad news but dad loved it.",
  "id" : 158224535437574145,
  "created_at" : "2012-01-14 16:30:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Glastonbury",
      "indices" : [ 35, 47 ]
    }, {
      "text" : "CT",
      "indices" : [ 48, 51 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158224255740424192",
  "text" : "wonder if my house is still there? #Glastonbury #CT tudor, bad well, haunted.",
  "id" : 158224255740424192,
  "created_at" : "2012-01-14 16:29:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 13, 24 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "goodvibrations",
      "indices" : [ 47, 62 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158223141146066944",
  "text" : "hope my dear @dhammagirl is recovering nicely! #goodvibrations",
  "id" : 158223141146066944,
  "created_at" : "2012-01-14 16:25:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kyle Peterson",
      "screen_name" : "doghauler",
      "indices" : [ 36, 46 ],
      "id_str" : "19422439",
      "id" : 19422439
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "158222737754685440",
  "text" : "lived there 35 yrs ago! ack! lol RT @doghauler Families lining up to pick up their dogs in Glastonbury CT pic.twitter.com\/RYpxq2Qq",
  "id" : 158222737754685440,
  "created_at" : "2012-01-14 16:23:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 20 ],
      "url" : "http:\/\/t.co\/lY0xnIUw",
      "expanded_url" : "http:\/\/www.cracked.com\/blog\/5-things-nobody-tells-you-about-being-poor\/",
      "display_url" : "cracked.com\/blog\/5-things-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "158220856223477760",
  "text" : "http:\/\/t.co\/lY0xnIUw",
  "id" : 158220856223477760,
  "created_at" : "2012-01-14 16:16:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "SusanREllis",
      "screen_name" : "SusanREllis",
      "indices" : [ 17, 29 ],
      "id_str" : "441966904",
      "id" : 441966904
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/SusanREllis\/status\/157465100935114753\/photo\/1",
      "indices" : [ 57, 77 ],
      "url" : "http:\/\/t.co\/eFLQmYvM",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai9trM4CMAAKk56.jpg",
      "id_str" : "157465100939309056",
      "id" : 157465100939309056,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai9trM4CMAAKk56.jpg",
      "sizes" : [ {
        "h" : 607,
        "resize" : "fit",
        "w" : 960
      }, {
        "h" : 379,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 215,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 607,
        "resize" : "fit",
        "w" : 960
      } ],
      "display_url" : "pic.twitter.com\/eFLQmYvM"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157991716157263873",
  "text" : "RT @KerriFar: RT @SusanREllis: Time for some chow, deer. http:\/\/t.co\/eFLQmYvM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SusanREllis",
        "screen_name" : "SusanREllis",
        "indices" : [ 3, 15 ],
        "id_str" : "441966904",
        "id" : 441966904
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/SusanREllis\/status\/157465100935114753\/photo\/1",
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/eFLQmYvM",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Ai9trM4CMAAKk56.jpg",
        "id_str" : "157465100939309056",
        "id" : 157465100939309056,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Ai9trM4CMAAKk56.jpg",
        "sizes" : [ {
          "h" : 607,
          "resize" : "fit",
          "w" : 960
        }, {
          "h" : 379,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 215,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 607,
          "resize" : "fit",
          "w" : 960
        } ],
        "display_url" : "pic.twitter.com\/eFLQmYvM"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157990569065447424",
    "text" : "RT @SusanREllis: Time for some chow, deer. http:\/\/t.co\/eFLQmYvM",
    "id" : 157990569065447424,
    "created_at" : "2012-01-14 01:01:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 157991716157263873,
  "created_at" : "2012-01-14 01:05:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "being stray",
      "screen_name" : "beingstray",
      "indices" : [ 3, 14 ],
      "id_str" : "26078307",
      "id" : 26078307
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 98, 118 ],
      "url" : "http:\/\/t.co\/cGN14uDM",
      "expanded_url" : "http:\/\/ow.ly\/8t4gV",
      "display_url" : "ow.ly\/8t4gV"
    } ]
  },
  "geo" : { },
  "id_str" : "157987768339931136",
  "text" : "RT @beingstray: Russian crow snowboarding on a rooftop... I will never look at crows the same. ~~ http:\/\/t.co\/cGN14uDM",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 82, 102 ],
        "url" : "http:\/\/t.co\/cGN14uDM",
        "expanded_url" : "http:\/\/ow.ly\/8t4gV",
        "display_url" : "ow.ly\/8t4gV"
      } ]
    },
    "geo" : { },
    "id_str" : "157978348604231680",
    "text" : "Russian crow snowboarding on a rooftop... I will never look at crows the same. ~~ http:\/\/t.co\/cGN14uDM",
    "id" : 157978348604231680,
    "created_at" : "2012-01-14 00:12:28 +0000",
    "user" : {
      "name" : "being stray",
      "screen_name" : "beingstray",
      "protected" : false,
      "id_str" : "26078307",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/107626840\/goose_normal.JPG",
      "id" : 26078307,
      "verified" : false
    }
  },
  "id" : 157987768339931136,
  "created_at" : "2012-01-14 00:49:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenyg",
      "screen_name" : "JenyG",
      "indices" : [ 4, 10 ],
      "id_str" : "61921510",
      "id" : 61921510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157985120593260544",
  "text" : "hey @JenyG thanks so much for updates on @SamsaricWarrior ((hugs))",
  "id" : 157985120593260544,
  "created_at" : "2012-01-14 00:39:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 73, 80 ]
    }, {
      "text" : "outdoors",
      "indices" : [ 81, 90 ]
    } ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/RjCxngR7",
      "expanded_url" : "http:\/\/su.pr\/2BMqHg",
      "display_url" : "su.pr\/2BMqHg"
    } ]
  },
  "geo" : { },
  "id_str" : "157963272379834369",
  "text" : "RT @KerriFar: Canada Goose ~ Defending His Family http:\/\/t.co\/RjCxngR7 ~ #nature #outdoors",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 59, 66 ]
      }, {
        "text" : "outdoors",
        "indices" : [ 67, 76 ]
      } ],
      "urls" : [ {
        "indices" : [ 36, 56 ],
        "url" : "http:\/\/t.co\/RjCxngR7",
        "expanded_url" : "http:\/\/su.pr\/2BMqHg",
        "display_url" : "su.pr\/2BMqHg"
      } ]
    },
    "geo" : { },
    "id_str" : "157962631322402818",
    "text" : "Canada Goose ~ Defending His Family http:\/\/t.co\/RjCxngR7 ~ #nature #outdoors",
    "id" : 157962631322402818,
    "created_at" : "2012-01-13 23:10:00 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 157963272379834369,
  "created_at" : "2012-01-13 23:12:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 3, 15 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 64, 84 ],
      "url" : "http:\/\/t.co\/ElGsiDb8",
      "expanded_url" : "http:\/\/pulse.me\/s\/4Ican",
      "display_url" : "pulse.me\/s\/4Ican"
    } ]
  },
  "geo" : { },
  "id_str" : "157958046063149056",
  "text" : "RT @Silvercrone \nFive Unusual Ways To Raise Successful Children http:\/\/t.co\/ElGsiDb8",
  "id" : 157958046063149056,
  "created_at" : "2012-01-13 22:51:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 111, 131 ],
      "url" : "http:\/\/t.co\/9CM2eyDb",
      "expanded_url" : "http:\/\/goo.gl\/japDY",
      "display_url" : "goo.gl\/japDY"
    } ]
  },
  "geo" : { },
  "id_str" : "157954749537320960",
  "text" : "RT @TracyLatz: Heroic Dog Saves Owner from Abusive Spouse, Incites Change in Shelter Policy | Life With Dogs - http:\/\/t.co\/9CM2eyDb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.shareaholic.com\" rel=\"nofollow\"\u003Eshareaholic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 96, 116 ],
        "url" : "http:\/\/t.co\/9CM2eyDb",
        "expanded_url" : "http:\/\/goo.gl\/japDY",
        "display_url" : "goo.gl\/japDY"
      } ]
    },
    "geo" : { },
    "id_str" : "157950834309742592",
    "text" : "Heroic Dog Saves Owner from Abusive Spouse, Incites Change in Shelter Policy | Life With Dogs - http:\/\/t.co\/9CM2eyDb",
    "id" : 157950834309742592,
    "created_at" : "2012-01-13 22:23:08 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 157954749537320960,
  "created_at" : "2012-01-13 22:38:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hendrick's Gin",
      "screen_name" : "HendricksGin",
      "indices" : [ 3, 16 ],
      "id_str" : "90655590",
      "id" : 90655590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157941392637825024",
  "text" : "RT @HendricksGin: I wonder, my friends, why do Americans choose from just two people to run for president and 50 for Miss America? Very  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157939909741658113",
    "text" : "I wonder, my friends, why do Americans choose from just two people to run for president and 50 for Miss America? Very unusual.",
    "id" : 157939909741658113,
    "created_at" : "2012-01-13 21:39:43 +0000",
    "user" : {
      "name" : "Hendrick's Gin",
      "screen_name" : "HendricksGin",
      "protected" : false,
      "id_str" : "90655590",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/752574678691176448\/kkiQV6xd_normal.jpg",
      "id" : 90655590,
      "verified" : false
    }
  },
  "id" : 157941392637825024,
  "created_at" : "2012-01-13 21:45:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 62, 69 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 37, 57 ],
      "url" : "http:\/\/t.co\/4BidhENL",
      "expanded_url" : "http:\/\/stevecreek.com\/squirrels-love-to-pose\/",
      "display_url" : "stevecreek.com\/squirrels-love\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157941225167654913",
  "text" : "RT @gemswinc: Squirrels Love To Pose http:\/\/t.co\/4BidhENL via @screek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steve Creek",
        "screen_name" : "screek",
        "indices" : [ 48, 55 ],
        "id_str" : "12023102",
        "id" : 12023102
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 23, 43 ],
        "url" : "http:\/\/t.co\/4BidhENL",
        "expanded_url" : "http:\/\/stevecreek.com\/squirrels-love-to-pose\/",
        "display_url" : "stevecreek.com\/squirrels-love\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "157940998557806592",
    "text" : "Squirrels Love To Pose http:\/\/t.co\/4BidhENL via @screek",
    "id" : 157940998557806592,
    "created_at" : "2012-01-13 21:44:03 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 157941225167654913,
  "created_at" : "2012-01-13 21:44:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bad Hombre Juanito",
      "screen_name" : "VirgoJohnny",
      "indices" : [ 0, 12 ],
      "id_str" : "51880276",
      "id" : 51880276
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157933798477135872",
  "geo" : { },
  "id_str" : "157940445719175169",
  "in_reply_to_user_id" : 51880276,
  "text" : "@VirgoJohnny you know.. I actually thought to myself.. \"havent seen VG tweet for awhile\"",
  "id" : 157940445719175169,
  "in_reply_to_status_id" : 157933798477135872,
  "created_at" : "2012-01-13 21:41:51 +0000",
  "in_reply_to_screen_name" : "VirgoJohnny",
  "in_reply_to_user_id_str" : "51880276",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157939806675009536",
  "text" : "RT @UnseeingEyes: It's just important to me. Whether or not is should or shouldn't be important to me is another question. But it is. &  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157935910552477697",
    "text" : "It's just important to me. Whether or not is should or shouldn't be important to me is another question. But it is. & my feelings are hurt.",
    "id" : 157935910552477697,
    "created_at" : "2012-01-13 21:23:50 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 157939806675009536,
  "created_at" : "2012-01-13 21:39:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Words With Friends",
      "screen_name" : "WordsWFriends",
      "indices" : [ 13, 27 ],
      "id_str" : "224423919",
      "id" : 224423919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157887856860332033",
  "geo" : { },
  "id_str" : "157889816887951360",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone @wordswfriends or the username is zyngawf_123 (example) and I forget who it is (no name attached)",
  "id" : 157889816887951360,
  "in_reply_to_status_id" : 157887856860332033,
  "created_at" : "2012-01-13 18:20:40 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Words With Friends",
      "screen_name" : "WordsWFriends",
      "indices" : [ 13, 27 ],
      "id_str" : "224423919",
      "id" : 224423919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157887856860332033",
  "geo" : { },
  "id_str" : "157888702285234176",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone @wordswfriends sometimes I find username but dont want to play right away but want to remember name...",
  "id" : 157888702285234176,
  "in_reply_to_status_id" : 157887856860332033,
  "created_at" : "2012-01-13 18:16:14 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 0, 12 ],
      "id_str" : "20929609",
      "id" : 20929609
    }, {
      "name" : "Words With Friends",
      "screen_name" : "WordsWFriends",
      "indices" : [ 13, 27 ],
      "id_str" : "224423919",
      "id" : 224423919
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "KindleFire",
      "indices" : [ 45, 56 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157887856860332033",
  "geo" : { },
  "id_str" : "157888455634989057",
  "in_reply_to_user_id" : 20929609,
  "text" : "@Silvercrone @wordswfriends I play WWF on my #KindleFire .. dont play games on FB.",
  "id" : 157888455634989057,
  "in_reply_to_status_id" : 157887856860332033,
  "created_at" : "2012-01-13 18:15:15 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 2, 15 ],
      "id_str" : "14124789",
      "id" : 14124789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157886120686923777",
  "geo" : { },
  "id_str" : "157887947172102144",
  "in_reply_to_user_id" : 14124789,
  "text" : ". @bigfishgames TYVM! I have played BFG on my ipod touch 2G in past & would love to play the new games! : )",
  "id" : 157887947172102144,
  "in_reply_to_status_id" : 157886120686923777,
  "created_at" : "2012-01-13 18:13:14 +0000",
  "in_reply_to_screen_name" : "bigfishgames",
  "in_reply_to_user_id_str" : "14124789",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Words With Friends",
      "screen_name" : "WordsWFriends",
      "indices" : [ 7, 21 ],
      "id_str" : "224423919",
      "id" : 224423919
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157886382361161728",
  "text" : "I wish @WordsWFriends had a way of adding usernames of ppl I want to play with (like friending or having profiles)",
  "id" : 157886382361161728,
  "created_at" : "2012-01-13 18:07:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 21, 34 ],
      "id_str" : "14124789",
      "id" : 14124789
    }, {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 41, 54 ],
      "id_str" : "84249568",
      "id" : 84249568
    }, {
      "name" : "Amazon Appstore",
      "screen_name" : "amazonappstore",
      "indices" : [ 61, 76 ],
      "id_str" : "247483633",
      "id" : 247483633
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 77, 87 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157885442493124608",
  "text" : "I would love to play @bigfishgames on my @AmazonKindle Fire! @amazonappstore #justsayin",
  "id" : 157885442493124608,
  "created_at" : "2012-01-13 18:03:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "indices" : [ 3, 16 ],
      "id_str" : "14124789",
      "id" : 14124789
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157883514468052992",
  "text" : "RT @bigfishgames: We have hit 100k fans! We are celebrating by giving away \"Nightfall Mysteries: Asylum Conspiracy\" for FREE: http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/R4VHXoMT",
        "expanded_url" : "http:\/\/bigfi.sh\/i1NcYZ",
        "display_url" : "bigfi.sh\/i1NcYZ"
      } ]
    },
    "geo" : { },
    "id_str" : "157881931046981633",
    "text" : "We have hit 100k fans! We are celebrating by giving away \"Nightfall Mysteries: Asylum Conspiracy\" for FREE: http:\/\/t.co\/R4VHXoMT",
    "id" : 157881931046981633,
    "created_at" : "2012-01-13 17:49:20 +0000",
    "user" : {
      "name" : "Big Fish Games",
      "screen_name" : "bigfishgames",
      "protected" : false,
      "id_str" : "14124789",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676860668365029376\/hAOsWfK1_normal.jpg",
      "id" : 14124789,
      "verified" : false
    }
  },
  "id" : 157883514468052992,
  "created_at" : "2012-01-13 17:55:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Edgar Allan Poe",
      "screen_name" : "Edgar_Allan_Poe",
      "indices" : [ 3, 19 ],
      "id_str" : "19656577",
      "id" : 19656577
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157873282727690240",
  "text" : "RT @Edgar_Allan_Poe: There are several competitive advantages to being a stark, raving lunatic.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157870667788849152",
    "text" : "There are several competitive advantages to being a stark, raving lunatic.",
    "id" : 157870667788849152,
    "created_at" : "2012-01-13 17:04:34 +0000",
    "user" : {
      "name" : "Edgar Allan Poe",
      "screen_name" : "Edgar_Allan_Poe",
      "protected" : false,
      "id_str" : "19656577",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000667006655\/bf59895895baf1c08f29900c34eb0fe8_normal.jpeg",
      "id" : 19656577,
      "verified" : false
    }
  },
  "id" : 157873282727690240,
  "created_at" : "2012-01-13 17:14:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "Kirk Norbury",
      "screen_name" : "KirkNorbury",
      "indices" : [ 16, 28 ],
      "id_str" : "23232545",
      "id" : 23232545
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 102, 122 ],
      "url" : "http:\/\/t.co\/fThyv79k",
      "expanded_url" : "http:\/\/500px.com\/photo\/4306440",
      "display_url" : "500px.com\/photo\/4306440"
    } ]
  },
  "geo" : { },
  "id_str" : "157860975033335808",
  "text" : "RT @wildobs: RT @KirkNorbury: Incase you missed it :) New Photo: \"Whooper Swan\" taken by Kirk Norbury http:\/\/t.co\/fThyv79k \/\/ Wonderful  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirk Norbury",
        "screen_name" : "KirkNorbury",
        "indices" : [ 3, 15 ],
        "id_str" : "23232545",
        "id" : 23232545
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/fThyv79k",
        "expanded_url" : "http:\/\/500px.com\/photo\/4306440",
        "display_url" : "500px.com\/photo\/4306440"
      } ]
    },
    "geo" : { },
    "id_str" : "157860193563197440",
    "text" : "RT @KirkNorbury: Incase you missed it :) New Photo: \"Whooper Swan\" taken by Kirk Norbury http:\/\/t.co\/fThyv79k \/\/ Wonderful scene",
    "id" : 157860193563197440,
    "created_at" : "2012-01-13 16:22:57 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 157860975033335808,
  "created_at" : "2012-01-13 16:26:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157860830413717504",
  "text" : "RT @DwayneReaves: Forever is composed of nows. ~ Emily Dickinson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157860385783955457",
    "text" : "Forever is composed of nows. ~ Emily Dickinson",
    "id" : 157860385783955457,
    "created_at" : "2012-01-13 16:23:43 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 157860830413717504,
  "created_at" : "2012-01-13 16:25:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157860748050182145",
  "text" : "call from school \"everything's fine but I want to talk to you\" ummmm...",
  "id" : 157860748050182145,
  "created_at" : "2012-01-13 16:25:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 3, 14 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 50, 70 ],
      "url" : "http:\/\/t.co\/dnYgIBrd",
      "expanded_url" : "http:\/\/lockerz.com\/s\/174140990",
      "display_url" : "lockerz.com\/s\/174140990"
    } ]
  },
  "geo" : { },
  "id_str" : "157855266849828865",
  "text" : "RT @mimismutts: That's the moon between the palms http:\/\/t.co\/dnYgIBrd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 34, 54 ],
        "url" : "http:\/\/t.co\/dnYgIBrd",
        "expanded_url" : "http:\/\/lockerz.com\/s\/174140990",
        "display_url" : "lockerz.com\/s\/174140990"
      } ]
    },
    "geo" : { },
    "id_str" : "157853418847875075",
    "text" : "That's the moon between the palms http:\/\/t.co\/dnYgIBrd",
    "id" : 157853418847875075,
    "created_at" : "2012-01-13 15:56:02 +0000",
    "user" : {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "protected" : false,
      "id_str" : "176864114",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2071566033\/profile_normal.jpg",
      "id" : 176864114,
      "verified" : false
    }
  },
  "id" : 157855266849828865,
  "created_at" : "2012-01-13 16:03:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jenyg",
      "screen_name" : "JenyG",
      "indices" : [ 3, 9 ],
      "id_str" : "61921510",
      "id" : 61921510
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157855079532212225",
  "text" : "RT @JenyG: @SamsaricWarrior is doing well, they updated us they were able to go with option A and repair it  should be out of surgery so ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003ETwidroyd for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157853040756523010",
    "text" : "@SamsaricWarrior is doing well, they updated us they were able to go with option A and repair it  should be out of surgery soon :)",
    "id" : 157853040756523010,
    "created_at" : "2012-01-13 15:54:32 +0000",
    "user" : {
      "name" : "Jenyg",
      "screen_name" : "JenyG",
      "protected" : false,
      "id_str" : "61921510",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3298723421\/8c44fd7ed47b8d305b0d0e5694ba3dea_normal.png",
      "id" : 61921510,
      "verified" : false
    }
  },
  "id" : 157855079532212225,
  "created_at" : "2012-01-13 16:02:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Rich",
      "screen_name" : "richcovephoto",
      "indices" : [ 26, 40 ],
      "id_str" : "19910685",
      "id" : 19910685
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "duckling",
      "indices" : [ 80, 89 ]
    }, {
      "text" : "bird",
      "indices" : [ 90, 95 ]
    }, {
      "text" : "baby",
      "indices" : [ 96, 101 ]
    }, {
      "text" : "flickr",
      "indices" : [ 102, 109 ]
    }, {
      "text" : "photography",
      "indices" : [ 110, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157659276154900480",
  "text" : "RT @KerriFar: Sweeeet! RT @richcovephoto: Little fluffy Duckling just beautiful #duckling #bird #baby #flickr #photography  http:\/\/t.co\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rich",
        "screen_name" : "richcovephoto",
        "indices" : [ 12, 26 ],
        "id_str" : "19910685",
        "id" : 19910685
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "duckling",
        "indices" : [ 66, 75 ]
      }, {
        "text" : "bird",
        "indices" : [ 76, 81 ]
      }, {
        "text" : "baby",
        "indices" : [ 82, 87 ]
      }, {
        "text" : "flickr",
        "indices" : [ 88, 95 ]
      }, {
        "text" : "photography",
        "indices" : [ 96, 108 ]
      } ],
      "urls" : [ {
        "indices" : [ 110, 130 ],
        "url" : "http:\/\/t.co\/Gyz9P6pa",
        "expanded_url" : "http:\/\/flic.kr\/p\/9LYMUm",
        "display_url" : "flic.kr\/p\/9LYMUm"
      } ]
    },
    "geo" : { },
    "id_str" : "157658882817277953",
    "text" : "Sweeeet! RT @richcovephoto: Little fluffy Duckling just beautiful #duckling #bird #baby #flickr #photography  http:\/\/t.co\/Gyz9P6pa",
    "id" : 157658882817277953,
    "created_at" : "2012-01-13 03:03:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 157659276154900480,
  "created_at" : "2012-01-13 03:04:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157603826428416000",
  "text" : "my bad eye is sore. thinking it's sinus pain.",
  "id" : 157603826428416000,
  "created_at" : "2012-01-12 23:24:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Sabados",
      "screen_name" : "AdamSab",
      "indices" : [ 3, 11 ],
      "id_str" : "25081390",
      "id" : 25081390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157586883008921601",
  "text" : "RT @AdamSab: I wish people would put less cookies in my browser and more cookies in my stomach.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157585815948636161",
    "text" : "I wish people would put less cookies in my browser and more cookies in my stomach.",
    "id" : 157585815948636161,
    "created_at" : "2012-01-12 22:12:40 +0000",
    "user" : {
      "name" : "Adam Sabados",
      "screen_name" : "AdamSab",
      "protected" : false,
      "id_str" : "25081390",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/763461028764090368\/oWXGyR1B_normal.jpg",
      "id" : 25081390,
      "verified" : false
    }
  },
  "id" : 157586883008921601,
  "created_at" : "2012-01-12 22:16:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157585496216829952",
  "text" : "RT @Selaniest: @tragic_pizza @pastormark Maybe he'll quit his church and go on a #lovereallydidntwin tour. #whosaidthat #isaidthat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pastor Mark Driscoll",
        "screen_name" : "PastorMark",
        "indices" : [ 14, 25 ],
        "id_str" : "4276531",
        "id" : 4276531
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "lovereallydidntwin",
        "indices" : [ 66, 85 ]
      }, {
        "text" : "whosaidthat",
        "indices" : [ 92, 104 ]
      }, {
        "text" : "isaidthat",
        "indices" : [ 105, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157583946983542784",
    "text" : "@tragic_pizza @pastormark Maybe he'll quit his church and go on a #lovereallydidntwin tour. #whosaidthat #isaidthat",
    "id" : 157583946983542784,
    "created_at" : "2012-01-12 22:05:15 +0000",
    "user" : {
      "name" : "The Great Unwashed",
      "screen_name" : "UnwashedThe",
      "protected" : false,
      "id_str" : "233971651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672923186632216576\/tRMQmyrX_normal.jpg",
      "id" : 233971651,
      "verified" : false
    }
  },
  "id" : 157585496216829952,
  "created_at" : "2012-01-12 22:11:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157571727826759680",
  "geo" : { },
  "id_str" : "157585269917368320",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous you never know what ppl would find interesting..lol",
  "id" : 157585269917368320,
  "in_reply_to_status_id" : 157571727826759680,
  "created_at" : "2012-01-12 22:10:30 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "indices" : [ 3, 15 ],
      "id_str" : "27426615",
      "id" : 27426615
    }, {
      "name" : "Sukie Baxter",
      "screen_name" : "SukieBaxter",
      "indices" : [ 94, 106 ],
      "id_str" : "15800496",
      "id" : 15800496
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157562586995494913",
  "text" : "RT @DaveUrsillo: Ive yet to meet anyone who lives in a bubble :) We touch lives every day! RT @SukieBaxter: if no one's following, are y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Sukie Baxter",
        "screen_name" : "SukieBaxter",
        "indices" : [ 77, 89 ],
        "id_str" : "15800496",
        "id" : 15800496
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157560608533913600",
    "text" : "Ive yet to meet anyone who lives in a bubble :) We touch lives every day! RT @SukieBaxter: if no one's following, are you a leader or loner?",
    "id" : 157560608533913600,
    "created_at" : "2012-01-12 20:32:31 +0000",
    "user" : {
      "name" : "Dave Ursillo",
      "screen_name" : "DaveUrsillo",
      "protected" : false,
      "id_str" : "27426615",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/730048048202715137\/3hzFy3qT_normal.jpg",
      "id" : 27426615,
      "verified" : false
    }
  },
  "id" : 157562586995494913,
  "created_at" : "2012-01-12 20:40:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 26, 37 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157562285576032257",
  "text" : "Tomorrow, 2 of my tweeps, @dhammagirl @SamsaricWarrior are having surgery. Please keep them in your thoughts & prayers. TYVM \u2665",
  "id" : 157562285576032257,
  "created_at" : "2012-01-12 20:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    }, {
      "name" : "SagesandScientists",
      "screen_name" : "SagesScientists",
      "indices" : [ 21, 37 ],
      "id_str" : "4569640454",
      "id" : 4569640454
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157519975370854400",
  "text" : "RT @DeepakChopra: RT @SagesScientists Our most natural state is joy. It is the foundation for love, compassion, healing, & the desire to ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "SagesandScientists",
        "screen_name" : "SagesScientists",
        "indices" : [ 3, 19 ],
        "id_str" : "4569640454",
        "id" : 4569640454
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157519759049633792",
    "text" : "RT @SagesScientists Our most natural state is joy. It is the foundation for love, compassion, healing, & the desire to alleviate suffering.",
    "id" : 157519759049633792,
    "created_at" : "2012-01-12 17:50:11 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 157519975370854400,
  "created_at" : "2012-01-12 17:51:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Byron Katie",
      "screen_name" : "ByronKatie",
      "indices" : [ 22, 33 ],
      "id_str" : "22733967",
      "id" : 22733967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157519047330762752",
  "text" : "RT @TrishScott: :) RT @byronkatie: Our job is unconditional love. The job of everyone else in our life is to push our buttons.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Byron Katie",
        "screen_name" : "ByronKatie",
        "indices" : [ 6, 17 ],
        "id_str" : "22733967",
        "id" : 22733967
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157518842682281984",
    "text" : ":) RT @byronkatie: Our job is unconditional love. The job of everyone else in our life is to push our buttons.",
    "id" : 157518842682281984,
    "created_at" : "2012-01-12 17:46:33 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 157519047330762752,
  "created_at" : "2012-01-12 17:47:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157517843473240065",
  "text" : "but thats not my purpose.. and thats ok!",
  "id" : 157517843473240065,
  "created_at" : "2012-01-12 17:42:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157517356468416512",
  "text" : "when I was younger, I wanted to be great.. I wanted to do BIG things so the world would notice me.",
  "id" : 157517356468416512,
  "created_at" : "2012-01-12 17:40:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157516941014220800",
  "text" : "I love the story of St Therese of Liseux and her little way. I am reminded that the little things count.",
  "id" : 157516941014220800,
  "created_at" : "2012-01-12 17:38:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 3, 13 ],
      "id_str" : "15572724",
      "id" : 15572724
    }, {
      "name" : "Ethan",
      "screen_name" : "SatorriSynoptic",
      "indices" : [ 18, 34 ],
      "id_str" : "56459711",
      "id" : 56459711
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157515279914631170",
  "text" : "RT @ShhDragon: RT @SatorriSynoptic: Please rinse off before entering the stream of consciousness. Splashing is allowed.\nYay, splashing! :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Ethan",
        "screen_name" : "SatorriSynoptic",
        "indices" : [ 3, 19 ],
        "id_str" : "56459711",
        "id" : 56459711
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157514696730230784",
    "text" : "RT @SatorriSynoptic: Please rinse off before entering the stream of consciousness. Splashing is allowed.\nYay, splashing! :)",
    "id" : 157514696730230784,
    "created_at" : "2012-01-12 17:30:04 +0000",
    "user" : {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "protected" : false,
      "id_str" : "15572724",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/57131644\/SW_cattails_reeds_closeup_normal.JPG",
      "id" : 15572724,
      "verified" : false
    }
  },
  "id" : 157515279914631170,
  "created_at" : "2012-01-12 17:32:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157515182212513793",
  "text" : "RT @By_Bashar: Doubt is the same energy as Fear ~ bashar",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157515051681595392",
    "text" : "Doubt is the same energy as Fear ~ bashar",
    "id" : 157515051681595392,
    "created_at" : "2012-01-12 17:31:29 +0000",
    "user" : {
      "name" : "Shambra",
      "screen_name" : "_mind_yoga",
      "protected" : false,
      "id_str" : "232478575",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000247207235\/402bd230c7cd18910d505cce880bb56a_normal.jpeg",
      "id" : 232478575,
      "verified" : false
    }
  },
  "id" : 157515182212513793,
  "created_at" : "2012-01-12 17:32:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157515117435691008",
  "text" : "my purpose in life? to be me! right under my nose all this time...",
  "id" : 157515117435691008,
  "created_at" : "2012-01-12 17:31:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157512298255237120",
  "text" : "I sooo identify w the pisces symbol of 2 fish: one fish going 1 way, other going opposite direction",
  "id" : 157512298255237120,
  "created_at" : "2012-01-12 17:20:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157511412338536448",
  "text" : "its hard 2B me. im exactly half-n-half. a most unusual specimen.",
  "id" : 157511412338536448,
  "created_at" : "2012-01-12 17:17:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157504807031148544",
  "text" : "@BibleAlsoSays I'll have to check that out (On being certain.) I knew you would like that article!",
  "id" : 157504807031148544,
  "created_at" : "2012-01-12 16:50:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jennifer laughran",
      "screen_name" : "literaticat",
      "indices" : [ 3, 15 ],
      "id_str" : "17501549",
      "id" : 17501549
    }, {
      "name" : "Oblong Books & Music",
      "screen_name" : "OblongBooks",
      "indices" : [ 91, 103 ],
      "id_str" : "85684816",
      "id" : 85684816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157502796579610624",
  "text" : "RT @literaticat: Know a Hudson Valley kid or teen who loves to read? Tell them to join the @OblongBooks Read & Review program!  http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Oblong Books & Music",
        "screen_name" : "OblongBooks",
        "indices" : [ 74, 86 ],
        "id_str" : "85684816",
        "id" : 85684816
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 111, 131 ],
        "url" : "http:\/\/t.co\/1HhmiL1O",
        "expanded_url" : "http:\/\/lockerz.com\/s\/173666985",
        "display_url" : "lockerz.com\/s\/173666985"
      } ]
    },
    "geo" : { },
    "id_str" : "157268754198306817",
    "text" : "Know a Hudson Valley kid or teen who loves to read? Tell them to join the @OblongBooks Read & Review program!  http:\/\/t.co\/1HhmiL1O",
    "id" : 157268754198306817,
    "created_at" : "2012-01-12 01:12:47 +0000",
    "user" : {
      "name" : "jennifer laughran",
      "screen_name" : "literaticat",
      "protected" : false,
      "id_str" : "17501549",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/555095180034854912\/23RxP-Y0_normal.jpeg",
      "id" : 17501549,
      "verified" : false
    }
  },
  "id" : 157502796579610624,
  "created_at" : "2012-01-12 16:42:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 99, 106 ]
    }, {
      "text" : "amazon",
      "indices" : [ 107, 114 ]
    }, {
      "text" : "kindlefire",
      "indices" : [ 115, 126 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157499569737965568",
  "text" : "i cant be the only one who tried to collect those free apps while waiting for my Fire to arrive... #kindle #amazon #kindlefire",
  "id" : 157499569737965568,
  "created_at" : "2012-01-12 16:29:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157498548458500098",
  "text" : "im assuming that all those amazon apps were never there to being with. I cant believe no one can answer simple question...",
  "id" : 157498548458500098,
  "created_at" : "2012-01-12 16:25:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/1ThpIwka",
      "expanded_url" : "http:\/\/bit.ly\/xr8u8t",
      "display_url" : "bit.ly\/xr8u8t"
    } ]
  },
  "geo" : { },
  "id_str" : "157496456469684230",
  "text" : "@BibleAlsoSays  \"there is simply too much at stake for them\" http:\/\/t.co\/1ThpIwka",
  "id" : 157496456469684230,
  "created_at" : "2012-01-12 16:17:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 4, 18 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157495033795325952",
  "text" : "hey @biblealsosays did you see link I sent you yesterday? thoughts?",
  "id" : 157495033795325952,
  "created_at" : "2012-01-12 16:11:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157229884614246400",
  "geo" : { },
  "id_str" : "157231320240623616",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh if I could be a fly on the wall..lol",
  "id" : 157231320240623616,
  "in_reply_to_status_id" : 157229884614246400,
  "created_at" : "2012-01-11 22:44:02 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157202194771353600",
  "text" : "I know my Mommy is thoroughly enjoying this exchange! \u2665",
  "id" : 157202194771353600,
  "created_at" : "2012-01-11 20:48:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157200641842876416",
  "text" : "DH & DD are talking about politics and economics.. spurred on by curious DD asking questions. : )",
  "id" : 157200641842876416,
  "created_at" : "2012-01-11 20:42:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157176235301146625",
  "text" : "RT @scandinaviansec: nothing exists independently of your perception of it..",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153871036075622401",
    "text" : "nothing exists independently of your perception of it..",
    "id" : 153871036075622401,
    "created_at" : "2012-01-02 16:11:28 +0000",
    "user" : {
      "name" : "Alan Amstrup",
      "screen_name" : "alanamstrup",
      "protected" : false,
      "id_str" : "319840043",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618887134406160384\/bOYdv06-_normal.jpg",
      "id" : 319840043,
      "verified" : false
    }
  },
  "id" : 157176235301146625,
  "created_at" : "2012-01-11 19:05:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 63, 83 ],
      "url" : "http:\/\/t.co\/T2IT1niJ",
      "expanded_url" : "http:\/\/abfabgab.wordpress.com",
      "display_url" : "abfabgab.wordpress.com"
    } ]
  },
  "geo" : { },
  "id_str" : "157173830954139648",
  "text" : "want to see where I am online, etc? I have my links on my blog http:\/\/t.co\/T2IT1niJ",
  "id" : 157173830954139648,
  "created_at" : "2012-01-11 18:55:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birdtog",
      "indices" : [ 64, 72 ]
    } ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Izvrkaib",
      "expanded_url" : "http:\/\/bit.ly\/y9vp23",
      "display_url" : "bit.ly\/y9vp23"
    } ]
  },
  "geo" : { },
  "id_str" : "157160172563869696",
  "text" : "RT @screek: A Harris\u2019s Sparrow In The Snow http:\/\/t.co\/Izvrkaib #birdtog",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birdtog",
        "indices" : [ 52, 60 ]
      } ],
      "urls" : [ {
        "indices" : [ 31, 51 ],
        "url" : "http:\/\/t.co\/Izvrkaib",
        "expanded_url" : "http:\/\/bit.ly\/y9vp23",
        "display_url" : "bit.ly\/y9vp23"
      } ]
    },
    "geo" : { },
    "id_str" : "157156674761785344",
    "text" : "A Harris\u2019s Sparrow In The Snow http:\/\/t.co\/Izvrkaib #birdtog",
    "id" : 157156674761785344,
    "created_at" : "2012-01-11 17:47:25 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 157160172563869696,
  "created_at" : "2012-01-11 18:01:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "indices" : [ 3, 14 ],
      "id_str" : "283660852",
      "id" : 283660852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/7h4vlvTb",
      "expanded_url" : "http:\/\/www.youtube.com\/watch?v=q1mAGQAw3Oc&feature=youtu.be",
      "display_url" : "youtube.com\/watch?v=q1mAGQ\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "157154442628706304",
  "text" : "RT @slothville: Bath time makes baby sloths go 'meep' http:\/\/t.co\/7h4vlvTb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 38, 58 ],
        "url" : "http:\/\/t.co\/7h4vlvTb",
        "expanded_url" : "http:\/\/www.youtube.com\/watch?v=q1mAGQAw3Oc&feature=youtu.be",
        "display_url" : "youtube.com\/watch?v=q1mAGQ\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "157153532477308928",
    "text" : "Bath time makes baby sloths go 'meep' http:\/\/t.co\/7h4vlvTb",
    "id" : 157153532477308928,
    "created_at" : "2012-01-11 17:34:56 +0000",
    "user" : {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "protected" : false,
      "id_str" : "283660852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529221111280463872\/E06rTIEQ_normal.jpeg",
      "id" : 283660852,
      "verified" : false
    }
  },
  "id" : 157154442628706304,
  "created_at" : "2012-01-11 17:38:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157149132262342658",
  "geo" : { },
  "id_str" : "157150414054232064",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem you go, girl!! it's your b-day? well, Happy Birthday, Mindy! ((confettifalling)) ((hugs))",
  "id" : 157150414054232064,
  "in_reply_to_status_id" : 157149132262342658,
  "created_at" : "2012-01-11 17:22:33 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157149419295346689",
  "geo" : { },
  "id_str" : "157149854215315456",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time LOL .. does both for me.. depending on what Im focusing on..lol",
  "id" : 157149854215315456,
  "in_reply_to_status_id" : 157149419295346689,
  "created_at" : "2012-01-11 17:20:19 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 0, 14 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 94, 114 ],
      "url" : "http:\/\/t.co\/1ThpIwka",
      "expanded_url" : "http:\/\/bit.ly\/xr8u8t",
      "display_url" : "bit.ly\/xr8u8t"
    } ]
  },
  "geo" : { },
  "id_str" : "157149632936415232",
  "text" : "@biblealsosays you might find this interesting - \"there is simply too much at stake for them\" http:\/\/t.co\/1ThpIwka",
  "id" : 157149632936415232,
  "created_at" : "2012-01-11 17:19:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157144681979977728",
  "text" : "RT @CoyotesWisdom: Don't be fool enough to play the role you're given. There's more to life than following a script.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157141710923763712",
    "text" : "Don't be fool enough to play the role you're given. There's more to life than following a script.",
    "id" : 157141710923763712,
    "created_at" : "2012-01-11 16:47:58 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 157144681979977728,
  "created_at" : "2012-01-11 16:59:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "indices" : [ 3, 15 ],
      "id_str" : "18256901",
      "id" : 18256901
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getreal",
      "indices" : [ 93, 101 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157144608382533634",
  "text" : "RT @deonnakelli: Dear Candidates: America has some real problems. Muslims ain't one of them. #getreal",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getreal",
        "indices" : [ 76, 84 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "157142898297671681",
    "text" : "Dear Candidates: America has some real problems. Muslims ain't one of them. #getreal",
    "id" : 157142898297671681,
    "created_at" : "2012-01-11 16:52:41 +0000",
    "user" : {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "protected" : false,
      "id_str" : "18256901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796046774813200384\/-eoNtOic_normal.jpg",
      "id" : 18256901,
      "verified" : false
    }
  },
  "id" : 157144608382533634,
  "created_at" : "2012-01-11 16:59:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "157095417073500162",
  "geo" : { },
  "id_str" : "157144156265914368",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl @SamsaricWarrior 2 lovely ppl to pray for on Friday! : ) (((grouphug)))",
  "id" : 157144156265914368,
  "in_reply_to_status_id" : 157095417073500162,
  "created_at" : "2012-01-11 16:57:41 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin Trudeau",
      "screen_name" : "KevinTrudeau",
      "indices" : [ 35, 48 ],
      "id_str" : "17198504",
      "id" : 17198504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157126467455696897",
  "text" : "wanting that 1st cup of coffee! RT @KevinTrudeau: What drives you to get up in the morning?",
  "id" : 157126467455696897,
  "created_at" : "2012-01-11 15:47:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157124649065512961",
  "text" : "DD said to DH: \"You and mom are my white lines.\" referring to lines in the road, from discussion in school. She is so special! \u2665",
  "id" : 157124649065512961,
  "created_at" : "2012-01-11 15:40:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157123802030022656",
  "text" : "at testing the other night, a boy about 3yo asked me if I was a kid or a grown-up... lol",
  "id" : 157123802030022656,
  "created_at" : "2012-01-11 15:36:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/ngjrYiot",
      "expanded_url" : "http:\/\/ow.ly\/8lXnu",
      "display_url" : "ow.ly\/8lXnu"
    } ]
  },
  "geo" : { },
  "id_str" : "157123546231996418",
  "text" : "RT @ThrillersRockT: One of my top thrillers for 2011 is FREE for all on #kindle. THE NINTH DISTRICT Jan 11 & 12. http:\/\/t.co\/ngjrYiot Pl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 52, 59 ]
      }, {
        "text" : "IAN1",
        "indices" : [ 121, 126 ]
      }, {
        "text" : "WLC",
        "indices" : [ 127, 131 ]
      }, {
        "text" : "ebook",
        "indices" : [ 132, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/ngjrYiot",
        "expanded_url" : "http:\/\/ow.ly\/8lXnu",
        "display_url" : "ow.ly\/8lXnu"
      } ]
    },
    "geo" : { },
    "id_str" : "157117837528399873",
    "text" : "One of my top thrillers for 2011 is FREE for all on #kindle. THE NINTH DISTRICT Jan 11 & 12. http:\/\/t.co\/ngjrYiot Plz RT #IAN1 #WLC #ebook",
    "id" : 157117837528399873,
    "created_at" : "2012-01-11 15:13:06 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 157123546231996418,
  "created_at" : "2012-01-11 15:35:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "blog",
      "indices" : [ 82, 87 ]
    }, {
      "text" : "politics",
      "indices" : [ 88, 97 ]
    }, {
      "text" : "sc",
      "indices" : [ 98, 101 ]
    } ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/o8glYMKC",
      "expanded_url" : "http:\/\/bit.ly\/zIfDsZ",
      "display_url" : "bit.ly\/zIfDsZ"
    } ]
  },
  "geo" : { },
  "id_str" : "157115437539262464",
  "text" : "RT @DwayneReaves: It\u2019s not Social Media, It\u2019s Hateful Media! http:\/\/t.co\/o8glYMKC #blog #politics #sc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "blog",
        "indices" : [ 64, 69 ]
      }, {
        "text" : "politics",
        "indices" : [ 70, 79 ]
      }, {
        "text" : "sc",
        "indices" : [ 80, 83 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/o8glYMKC",
        "expanded_url" : "http:\/\/bit.ly\/zIfDsZ",
        "display_url" : "bit.ly\/zIfDsZ"
      } ]
    },
    "geo" : { },
    "id_str" : "157054155863769088",
    "text" : "It\u2019s not Social Media, It\u2019s Hateful Media! http:\/\/t.co\/o8glYMKC #blog #politics #sc",
    "id" : 157054155863769088,
    "created_at" : "2012-01-11 11:00:03 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 157115437539262464,
  "created_at" : "2012-01-11 15:03:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bradley Allen",
      "screen_name" : "ballenski91",
      "indices" : [ 3, 15 ],
      "id_str" : "119644985",
      "id" : 119644985
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/ballenski91\/status\/156701341803216896\/photo\/1",
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/ZlOB9rKl",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Aiy3CkZCAAEl-_J.jpg",
      "id_str" : "156701341807411201",
      "id" : 156701341807411201,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aiy3CkZCAAEl-_J.jpg",
      "sizes" : [ {
        "h" : 1920,
        "resize" : "fit",
        "w" : 2560
      }, {
        "h" : 255,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 450,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 768,
        "resize" : "fit",
        "w" : 1024
      } ],
      "display_url" : "pic.twitter.com\/ZlOB9rKl"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "157106579982909441",
  "text" : "RT @ballenski91: This baby rabbit is getting alot braver. And a little bit mental! http:\/\/t.co\/ZlOB9rKl",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/ballenski91\/status\/156701341803216896\/photo\/1",
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/ZlOB9rKl",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/Aiy3CkZCAAEl-_J.jpg",
        "id_str" : "156701341807411201",
        "id" : 156701341807411201,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Aiy3CkZCAAEl-_J.jpg",
        "sizes" : [ {
          "h" : 1920,
          "resize" : "fit",
          "w" : 2560
        }, {
          "h" : 255,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 450,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 768,
          "resize" : "fit",
          "w" : 1024
        } ],
        "display_url" : "pic.twitter.com\/ZlOB9rKl"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156701341803216896",
    "text" : "This baby rabbit is getting alot braver. And a little bit mental! http:\/\/t.co\/ZlOB9rKl",
    "id" : 156701341803216896,
    "created_at" : "2012-01-10 11:38:06 +0000",
    "user" : {
      "name" : "Bradley Allen",
      "screen_name" : "ballenski91",
      "protected" : false,
      "id_str" : "119644985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3029503218\/b8a70b8953e5953b7f83180f339b8b55_normal.jpeg",
      "id" : 119644985,
      "verified" : false
    }
  },
  "id" : 157106579982909441,
  "created_at" : "2012-01-11 14:28:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156907650993487872",
  "text" : "@SamsaricWarrior you will be in my thoughts and prayers. big big (((hugs)))",
  "id" : 156907650993487872,
  "created_at" : "2012-01-11 01:17:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 120, 140 ],
      "url" : "http:\/\/t.co\/1ThpIwka",
      "expanded_url" : "http:\/\/bit.ly\/xr8u8t",
      "display_url" : "bit.ly\/xr8u8t"
    } ]
  },
  "geo" : { },
  "id_str" : "156890705397161985",
  "text" : "And this is why we cannot argue with people who subscribe to this framework: there is simply too much at stake for them http:\/\/t.co\/1ThpIwka",
  "id" : 156890705397161985,
  "created_at" : "2012-01-11 00:10:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "indices" : [ 3, 17 ],
      "id_str" : "21729540",
      "id" : 21729540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/SO3xC7rb",
      "expanded_url" : "http:\/\/tmblr.co\/ZwRd3yEaARLE",
      "display_url" : "tmblr.co\/ZwRd3yEaARLE"
    } ]
  },
  "geo" : { },
  "id_str" : "156876375427526656",
  "text" : "RT @knittingknots: Have the Super-Rich Seceded From the United States? | Truthout http:\/\/t.co\/SO3xC7rb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/SO3xC7rb",
        "expanded_url" : "http:\/\/tmblr.co\/ZwRd3yEaARLE",
        "display_url" : "tmblr.co\/ZwRd3yEaARLE"
      } ]
    },
    "geo" : { },
    "id_str" : "156874870813245441",
    "text" : "Have the Super-Rich Seceded From the United States? | Truthout http:\/\/t.co\/SO3xC7rb",
    "id" : 156874870813245441,
    "created_at" : "2012-01-10 23:07:38 +0000",
    "user" : {
      "name" : "Sue Stone",
      "screen_name" : "knittingknots",
      "protected" : false,
      "id_str" : "21729540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/538577202426548224\/UtuDymz6_normal.jpeg",
      "id" : 21729540,
      "verified" : false
    }
  },
  "id" : 156876375427526656,
  "created_at" : "2012-01-10 23:13:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156874537034715136",
  "text" : "RT @DoreenVirtue444: Everything about you is based in love, and feeling it means that you\u2019re aware of your own self.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156873791631405056",
    "text" : "Everything about you is based in love, and feeling it means that you\u2019re aware of your own self.",
    "id" : 156873791631405056,
    "created_at" : "2012-01-10 23:03:21 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 156874537034715136,
  "created_at" : "2012-01-10 23:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156869642537807872",
  "geo" : { },
  "id_str" : "156872078988017666",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth heehee.. been playing it on my Fire.. mostly losing but its fun!",
  "id" : 156872078988017666,
  "in_reply_to_status_id" : 156869642537807872,
  "created_at" : "2012-01-10 22:56:32 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156871651869466625",
  "text" : "MIL strained her muscles and has pain... now I've got a pain in my hip.. sigh. Bengay tonight! lol",
  "id" : 156871651869466625,
  "created_at" : "2012-01-10 22:54:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156855486669537280",
  "text" : "fluffy birds on my kindle fire.. fun!",
  "id" : 156855486669537280,
  "created_at" : "2012-01-10 21:50:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "156830630372585473",
  "geo" : { },
  "id_str" : "156836700973309952",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous just read the article mentioned within about humans complex social network.. interesting",
  "id" : 156836700973309952,
  "in_reply_to_status_id" : 156830630372585473,
  "created_at" : "2012-01-10 20:35:58 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/idreambooks.com\/books\" rel=\"nofollow\"\u003EiDreamBooks\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dream",
      "screen_name" : "dreamonus",
      "indices" : [ 49, 59 ],
      "id_str" : "330444567",
      "id" : 330444567
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 61, 81 ],
      "url" : "http:\/\/t.co\/XrTyKHNk",
      "expanded_url" : "http:\/\/idre.am\/y3mOpm",
      "display_url" : "idre.am\/y3mOpm"
    } ]
  },
  "geo" : { },
  "id_str" : "156816560474951680",
  "text" : "I can\u2019t wait to read Nameless by Kyle Chais. via @dreamonus. http:\/\/t.co\/XrTyKHNk",
  "id" : 156816560474951680,
  "created_at" : "2012-01-10 19:15:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 3, 16 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156814377482334208",
  "text" : "RT @SignsOfKevin: People are funny.",
  "id" : 156814377482334208,
  "created_at" : "2012-01-10 19:07:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156813494728134658",
  "text" : "do not poke at it w a pencil, pen, marker of any kind.. and NO fly swatters! lol",
  "id" : 156813494728134658,
  "created_at" : "2012-01-10 19:03:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156813155849342976",
  "text" : "I love,love,love my new 14pt bible!! so much easier to follow along during bible study!",
  "id" : 156813155849342976,
  "created_at" : "2012-01-10 19:02:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "indices" : [ 3, 18 ],
      "id_str" : "104029814",
      "id" : 104029814
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156800362727219200",
  "text" : "RT @stream_enterer: After walk together cat decided a nap in my lap. So there I sit out of reach of remote and phone and computer. What  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156799081245708288",
    "text" : "After walk together cat decided a nap in my lap. So there I sit out of reach of remote and phone and computer. What else to do but meditate.",
    "id" : 156799081245708288,
    "created_at" : "2012-01-10 18:06:28 +0000",
    "user" : {
      "name" : "stream_enterer",
      "screen_name" : "stream_enterer",
      "protected" : false,
      "id_str" : "104029814",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2631535590\/d692302ccc01b28fa9ac5365d301a7ca_normal.jpeg",
      "id" : 104029814,
      "verified" : false
    }
  },
  "id" : 156800362727219200,
  "created_at" : "2012-01-10 18:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/disqus.com\/\" rel=\"nofollow\"\u003EDISQUS\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 56 ],
      "url" : "http:\/\/t.co\/NSCjCzgI",
      "expanded_url" : "http:\/\/disq.us\/4xg7em",
      "display_url" : "disq.us\/4xg7em"
    } ]
  },
  "geo" : { },
  "id_str" : "156799097137926144",
  "text" : "The Kindle Monologues - Questions?: http:\/\/t.co\/NSCjCzgI - about ppl who put Kindle users in the evil category (my words..lol)",
  "id" : 156799097137926144,
  "created_at" : "2012-01-10 18:06:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kenny Williams",
      "screen_name" : "KWilliams1984",
      "indices" : [ 3, 17 ],
      "id_str" : "22653799",
      "id" : 22653799
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156794315065135104",
  "text" : "RT @KWilliams1984: What others think of you is none of your business. All that matters is what YOU think of you. No one can change that. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "LoveYourself",
        "indices" : [ 118, 131 ]
      }, {
        "text" : "NoH8",
        "indices" : [ 132, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156788872313978881",
    "text" : "What others think of you is none of your business. All that matters is what YOU think of you. No one can change that. #LoveYourself #NoH8",
    "id" : 156788872313978881,
    "created_at" : "2012-01-10 17:25:54 +0000",
    "user" : {
      "name" : "Kenny Williams",
      "screen_name" : "KWilliams1984",
      "protected" : false,
      "id_str" : "22653799",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/787397284766056448\/RVgZVZvO_normal.jpg",
      "id" : 22653799,
      "verified" : false
    }
  },
  "id" : 156794315065135104,
  "created_at" : "2012-01-10 17:47:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156794179043868674",
  "text" : "RT @angelaharms: \u201CA good mystic knows that Religion, in general, answers far too many questions; a good skeptic knows that Science asks  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Brady",
        "screen_name" : "dbrady",
        "indices" : [ 133, 140 ],
        "id_str" : "14253546",
        "id" : 14253546
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156789660499181569",
    "text" : "\u201CA good mystic knows that Religion, in general, answers far too many questions; a good skeptic knows that Science asks far too few.\u201D-@dbrady",
    "id" : 156789660499181569,
    "created_at" : "2012-01-10 17:29:02 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 156794179043868674,
  "created_at" : "2012-01-10 17:47:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156737131446927361",
  "text" : "bible study w MIL this am w my new 14pt bible..lol",
  "id" : 156737131446927361,
  "created_at" : "2012-01-10 14:00:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156563021165105152",
  "text" : "belt testing tonight... sigh.. did NOT break board... again!! BUT, I AM a lot closer!!",
  "id" : 156563021165105152,
  "created_at" : "2012-01-10 02:28:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Jane",
      "screen_name" : "Jane_WI",
      "indices" : [ 16, 24 ],
      "id_str" : "266690646",
      "id" : 266690646
    }, {
      "name" : "Ray Lawson",
      "screen_name" : "Lawsonbulk",
      "indices" : [ 46, 57 ],
      "id_str" : "25605222",
      "id" : 25605222
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156513092551983104",
  "text" : "RT @SangyeH: RT @Jane_WI: Pot meet kettle? RT @Lawsonbulk Rick Santorum: We can't live w\/ Nuclear Iran because they're a Theocracy. http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jane",
        "screen_name" : "Jane_WI",
        "indices" : [ 3, 11 ],
        "id_str" : "266690646",
        "id" : 266690646
      }, {
        "name" : "Ray Lawson",
        "screen_name" : "Lawsonbulk",
        "indices" : [ 33, 44 ],
        "id_str" : "25605222",
        "id" : 25605222
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 119, 139 ],
        "url" : "http:\/\/t.co\/rfZOjxmn",
        "expanded_url" : "http:\/\/bit.ly\/x1OohQ",
        "display_url" : "bit.ly\/x1OohQ"
      } ]
    },
    "geo" : { },
    "id_str" : "156507551435980801",
    "text" : "RT @Jane_WI: Pot meet kettle? RT @Lawsonbulk Rick Santorum: We can't live w\/ Nuclear Iran because they're a Theocracy. http:\/\/t.co\/rfZOjxmn",
    "id" : 156507551435980801,
    "created_at" : "2012-01-09 22:48:02 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 156513092551983104,
  "created_at" : "2012-01-09 23:10:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "indices" : [ 3, 12 ],
      "id_str" : "972651",
      "id" : 972651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/dcBhB2WI",
      "expanded_url" : "http:\/\/on.mash.to\/y03kFc",
      "display_url" : "on.mash.to\/y03kFc"
    } ]
  },
  "geo" : { },
  "id_str" : "156456007466364929",
  "text" : "RT @mashable: FCC to Explore Helping Low-Income Americans Afford Internet Access - http:\/\/t.co\/dcBhB2WI",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 69, 89 ],
        "url" : "http:\/\/t.co\/dcBhB2WI",
        "expanded_url" : "http:\/\/on.mash.to\/y03kFc",
        "display_url" : "on.mash.to\/y03kFc"
      } ]
    },
    "geo" : { },
    "id_str" : "156455130454163456",
    "text" : "FCC to Explore Helping Low-Income Americans Afford Internet Access - http:\/\/t.co\/dcBhB2WI",
    "id" : 156455130454163456,
    "created_at" : "2012-01-09 19:19:44 +0000",
    "user" : {
      "name" : "Mashable",
      "screen_name" : "mashable",
      "protected" : false,
      "id_str" : "972651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760998040949841922\/XT79xzRT_normal.jpg",
      "id" : 972651,
      "verified" : true
    }
  },
  "id" : 156456007466364929,
  "created_at" : "2012-01-09 19:23:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156430293832699904",
  "text" : "RT @PeggySueCusses: Did you know once House and Senate members leave office they continue getting their salary FOR THE REST OF THEIR LIFE.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156428789952417794",
    "text" : "Did you know once House and Senate members leave office they continue getting their salary FOR THE REST OF THEIR LIFE.",
    "id" : 156428789952417794,
    "created_at" : "2012-01-09 17:35:04 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 156430293832699904,
  "created_at" : "2012-01-09 17:41:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156430217454419968",
  "text" : "RT @PeggySueCusses: I knew the President did, but I also didn't know the gawd dayum SPEAKER OF THE HOUSE gets salary for life. WTF?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156428936857923584",
    "text" : "I knew the President did, but I also didn't know the gawd dayum SPEAKER OF THE HOUSE gets salary for life. WTF?",
    "id" : 156428936857923584,
    "created_at" : "2012-01-09 17:35:39 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 156430217454419968,
  "created_at" : "2012-01-09 17:40:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156392525815480322",
  "text" : "RT @mssuzcatsilver: Remember money is another form of energy, an exchange. Bless all that U have & when you buy anything  & for the choi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "suzcat",
        "indices" : [ 131, 138 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156392281245626368",
    "text" : "Remember money is another form of energy, an exchange. Bless all that U have & when you buy anything  & for the choices it gives u #suzcat",
    "id" : 156392281245626368,
    "created_at" : "2012-01-09 15:10:00 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 156392525815480322,
  "created_at" : "2012-01-09 15:10:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156392428469895168",
  "text" : "I am very slow and methodical. It's very annoying to those who want to get things done! : )",
  "id" : 156392428469895168,
  "created_at" : "2012-01-09 15:10:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Danarchist",
      "screen_name" : "RelUnrelated",
      "indices" : [ 21, 34 ],
      "id_str" : "50666280",
      "id" : 50666280
    }, {
      "name" : "AnnraoiOD",
      "screen_name" : "AnnraoiOD",
      "indices" : [ 35, 45 ],
      "id_str" : "846195560",
      "id" : 846195560
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156078442318798848",
  "text" : "RT @MKellyIrishCath: @RelUnrelated @AnnraoiOD Rights are all directed towards flourishing...not the opposite...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Danarchist",
        "screen_name" : "RelUnrelated",
        "indices" : [ 0, 13 ],
        "id_str" : "50666280",
        "id" : 50666280
      }, {
        "name" : "AnnraoiOD",
        "screen_name" : "AnnraoiOD",
        "indices" : [ 14, 24 ],
        "id_str" : "846195560",
        "id" : 846195560
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "155968129829318657",
    "geo" : { },
    "id_str" : "155968503126560769",
    "in_reply_to_user_id" : 50666280,
    "text" : "@RelUnrelated @AnnraoiOD Rights are all directed towards flourishing...not the opposite...",
    "id" : 155968503126560769,
    "in_reply_to_status_id" : 155968129829318657,
    "created_at" : "2012-01-08 11:06:03 +0000",
    "in_reply_to_screen_name" : "RelUnrelated",
    "in_reply_to_user_id_str" : "50666280",
    "user" : {
      "name" : "Michael Kelly",
      "screen_name" : "MichaelKellyIC",
      "protected" : false,
      "id_str" : "124604416",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794972546772926464\/mT5t-ri0_normal.jpg",
      "id" : 124604416,
      "verified" : false
    }
  },
  "id" : 156078442318798848,
  "created_at" : "2012-01-08 18:22:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hugh",
      "screen_name" : "CoonCatt",
      "indices" : [ 3, 12 ],
      "id_str" : "18301626",
      "id" : 18301626
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156078302996611072",
  "text" : "RT @CoonCatt: My goal is simple. It is a complete understanding of the universe, why it is as it is and why it exists at all. ~ Stephen  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156076698432061441",
    "text" : "My goal is simple. It is a complete understanding of the universe, why it is as it is and why it exists at all. ~ Stephen Hawking",
    "id" : 156076698432061441,
    "created_at" : "2012-01-08 18:15:59 +0000",
    "user" : {
      "name" : "Hugh",
      "screen_name" : "CoonCatt",
      "protected" : false,
      "id_str" : "18301626",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/671237329047031809\/67OM3lfl_normal.png",
      "id" : 18301626,
      "verified" : false
    }
  },
  "id" : 156078302996611072,
  "created_at" : "2012-01-08 18:22:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "indices" : [ 3, 18 ],
      "id_str" : "60697262",
      "id" : 60697262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156076058167357440",
  "text" : "RT @Emmanueldagher: Miracles are all around us, we just have to be willing to see them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156075199534612480",
    "text" : "Miracles are all around us, we just have to be willing to see them.",
    "id" : 156075199534612480,
    "created_at" : "2012-01-08 18:10:01 +0000",
    "user" : {
      "name" : "Emmanuel Dagher",
      "screen_name" : "Emmanueldagher",
      "protected" : false,
      "id_str" : "60697262",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/705777106593001472\/xD7VBchf_normal.jpg",
      "id" : 60697262,
      "verified" : false
    }
  },
  "id" : 156076058167357440,
  "created_at" : "2012-01-08 18:13:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "indices" : [ 3, 10 ],
      "id_str" : "94143715",
      "id" : 94143715
    }, {
      "name" : "The New York Times",
      "screen_name" : "nytimes",
      "indices" : [ 27, 35 ],
      "id_str" : "807095",
      "id" : 807095
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156075586673061888",
  "text" : "RT @KatieS: Sad day for my @nytimes delivery man. Laid off as they find a cheaper delivery service. His classy farewell letter. http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "The New York Times",
        "screen_name" : "nytimes",
        "indices" : [ 15, 23 ],
        "id_str" : "807095",
        "id" : 807095
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/KatieS\/status\/156054514019995650\/photo\/1",
        "indices" : [ 116, 136 ],
        "url" : "http:\/\/t.co\/ggp072VL",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AipqwPJCEAIJkC7.jpg",
        "id_str" : "156054514028384258",
        "id" : 156054514028384258,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AipqwPJCEAIJkC7.jpg",
        "sizes" : [ {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        }, {
          "h" : 453,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 800,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1024,
          "resize" : "fit",
          "w" : 768
        } ],
        "display_url" : "pic.twitter.com\/ggp072VL"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156054514019995650",
    "text" : "Sad day for my @nytimes delivery man. Laid off as they find a cheaper delivery service. His classy farewell letter. http:\/\/t.co\/ggp072VL",
    "id" : 156054514019995650,
    "created_at" : "2012-01-08 16:47:52 +0000",
    "user" : {
      "name" : "Katie Jacobs Stanton",
      "screen_name" : "KatieS",
      "protected" : false,
      "id_str" : "94143715",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798702280333606912\/rTyHVoEQ_normal.jpg",
      "id" : 94143715,
      "verified" : true
    }
  },
  "id" : 156075586673061888,
  "created_at" : "2012-01-08 18:11:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sacred Witness",
      "screen_name" : "SacredWitness",
      "indices" : [ 114, 128 ],
      "id_str" : "3085133691",
      "id" : 3085133691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/3eScepY9",
      "expanded_url" : "http:\/\/j.mp\/AexIOD",
      "display_url" : "j.mp\/AexIOD"
    } ]
  },
  "geo" : { },
  "id_str" : "156068759507963904",
  "text" : "\"I know how to ascend a bad mood, yet there are times I simply choose not to.\" - Silly Me http:\/\/t.co\/3eScepY9 by @SacredWitness",
  "id" : 156068759507963904,
  "created_at" : "2012-01-08 17:44:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M.P. McDonald",
      "screen_name" : "MarkTaylorBooks",
      "indices" : [ 3, 19 ],
      "id_str" : "31386920",
      "id" : 31386920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 110, 130 ],
      "url" : "http:\/\/t.co\/lboMuSiU",
      "expanded_url" : "http:\/\/bit.ly\/x8rk3y",
      "display_url" : "bit.ly\/x8rk3y"
    } ]
  },
  "geo" : { },
  "id_str" : "156067970240614401",
  "text" : "RT @MarkTaylorBooks: I'm a long-time follower of this blog and the writer is going though really tough times. http:\/\/t.co\/lboMuSiU RT please",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 89, 109 ],
        "url" : "http:\/\/t.co\/lboMuSiU",
        "expanded_url" : "http:\/\/bit.ly\/x8rk3y",
        "display_url" : "bit.ly\/x8rk3y"
      } ]
    },
    "geo" : { },
    "id_str" : "156058712518295553",
    "text" : "I'm a long-time follower of this blog and the writer is going though really tough times. http:\/\/t.co\/lboMuSiU RT please",
    "id" : 156058712518295553,
    "created_at" : "2012-01-08 17:04:31 +0000",
    "user" : {
      "name" : "M.P. McDonald",
      "screen_name" : "MarkTaylorBooks",
      "protected" : false,
      "id_str" : "31386920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445911314838204416\/vaTQASPe_normal.jpeg",
      "id" : 31386920,
      "verified" : false
    }
  },
  "id" : 156067970240614401,
  "created_at" : "2012-01-08 17:41:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156067524780371969",
  "text" : "RT @TrishScott: RT @lumensilta: Dear Optimist,Pessimist&Realist. While you guys were arguing about the glass of water, I drank it. Signe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156063025269440512",
    "text" : "RT @lumensilta: Dear Optimist,Pessimist&Realist. While you guys were arguing about the glass of water, I drank it. Signed: The Opportunist.",
    "id" : 156063025269440512,
    "created_at" : "2012-01-08 17:21:39 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 156067524780371969,
  "created_at" : "2012-01-08 17:39:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Henry Cat",
      "screen_name" : "HenryCat3",
      "indices" : [ 3, 13 ],
      "id_str" : "609396605",
      "id" : 609396605
    }, {
      "name" : "Alley Mason",
      "screen_name" : "ConfuciusCat",
      "indices" : [ 18, 31 ],
      "id_str" : "31715541",
      "id" : 31715541
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Purrs4Peace",
      "indices" : [ 51, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "156067432371453952",
  "text" : "RT @HenryCat3: RT @ConfuciusCat: Three hours until #Purrs4Peace at 3 p.m. Eastern. Purriness is next to godliness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alley Mason",
        "screen_name" : "ConfuciusCat",
        "indices" : [ 3, 16 ],
        "id_str" : "31715541",
        "id" : 31715541
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Purrs4Peace",
        "indices" : [ 36, 48 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "156063730923356161",
    "text" : "RT @ConfuciusCat: Three hours until #Purrs4Peace at 3 p.m. Eastern. Purriness is next to godliness.",
    "id" : 156063730923356161,
    "created_at" : "2012-01-08 17:24:27 +0000",
    "user" : {
      "name" : "Henry Cat",
      "screen_name" : "HenryCatTwo",
      "protected" : true,
      "id_str" : "366576169",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2060224026\/Image0068-1_normal.jpg",
      "id" : 366576169,
      "verified" : false
    }
  },
  "id" : 156067432371453952,
  "created_at" : "2012-01-08 17:39:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Josh Cascio Fox13",
      "screen_name" : "joshcascio",
      "indices" : [ 3, 14 ],
      "id_str" : "22312894",
      "id" : 22312894
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155845969399910400",
  "text" : "RT @joshcascio: I've always said if u want to ban gay marriage you should also ban divorces.  They mess up families too.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155845239876222976",
    "text" : "I've always said if u want to ban gay marriage you should also ban divorces.  They mess up families too.",
    "id" : 155845239876222976,
    "created_at" : "2012-01-08 02:56:15 +0000",
    "user" : {
      "name" : "Josh Cascio Fox13",
      "screen_name" : "joshcascio",
      "protected" : false,
      "id_str" : "22312894",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3369629368\/913d3dde9796b5d97b95f98d97ef0d84_normal.jpeg",
      "id" : 22312894,
      "verified" : true
    }
  },
  "id" : 155845969399910400,
  "created_at" : "2012-01-08 02:59:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155844547228860418",
  "text" : "RT @CrystalLewis: I won't comment on \"Christians are persecuted in this country.\" I won't comment. I just won't.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155844211344801792",
    "text" : "I won't comment on \"Christians are persecuted in this country.\" I won't comment. I just won't.",
    "id" : 155844211344801792,
    "created_at" : "2012-01-08 02:52:10 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 155844547228860418,
  "created_at" : "2012-01-08 02:53:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155835343852154881",
  "geo" : { },
  "id_str" : "155838976517873664",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind yeah.. ive always had sensitive stomach. im not really sturdy.. I faint on hot days..lol",
  "id" : 155838976517873664,
  "in_reply_to_status_id" : 155835343852154881,
  "created_at" : "2012-01-08 02:31:22 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 2, 12 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155828423498006528",
  "geo" : { },
  "id_str" : "155835157797023744",
  "in_reply_to_user_id" : 16181537,
  "text" : ". @ZachsMind ugh.. not me. with hangovers, I'm sick as a dog all day.. which is why I rarely drink now.",
  "id" : 155835157797023744,
  "in_reply_to_status_id" : 155828423498006528,
  "created_at" : "2012-01-08 02:16:11 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 2, 14 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155808711124860928",
  "geo" : { },
  "id_str" : "155811105795616768",
  "in_reply_to_user_id" : 15349954,
  "text" : ". @angelaharms @SamsaricWarrior good point.. we must be good to ourselves as well : )",
  "id" : 155811105795616768,
  "in_reply_to_status_id" : 155808711124860928,
  "created_at" : "2012-01-08 00:40:37 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155807259262332928",
  "text" : "RT @CharlesBivona: Live w\/ sickness in the United States, with no health insurance, for five years.. then see how many flags you want wa ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ows",
        "indices" : [ 121, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155806878423711746",
    "text" : "Live w\/ sickness in the United States, with no health insurance, for five years.. then see how many flags you want wave. #ows",
    "id" : 155806878423711746,
    "created_at" : "2012-01-08 00:23:49 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 155807259262332928,
  "created_at" : "2012-01-08 00:25:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155805995132653568",
  "geo" : { },
  "id_str" : "155806562714259457",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts \"moves like Jagger\"? lol.. think he's talking about Mick Jagger. not a fan of Mick, myself.",
  "id" : 155806562714259457,
  "in_reply_to_status_id" : 155805995132653568,
  "created_at" : "2012-01-08 00:22:33 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155805969429966848",
  "text" : "my poor dear MIL.. their well is broken, phone blitzy. hubby's still at their house trying to fix. been there all day.",
  "id" : 155805969429966848,
  "created_at" : "2012-01-08 00:20:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "David Meikle",
      "screen_name" : "davemeiklephoto",
      "indices" : [ 16, 32 ],
      "id_str" : "221574977",
      "id" : 221574977
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "flickr",
      "indices" : [ 77, 84 ]
    }, {
      "text" : "photography",
      "indices" : [ 85, 97 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 98, 107 ]
    } ],
    "urls" : [ {
      "indices" : [ 56, 76 ],
      "url" : "http:\/\/t.co\/XeKvuKsr",
      "expanded_url" : "http:\/\/flic.kr\/p\/b99muD",
      "display_url" : "flic.kr\/p\/b99muD"
    } ]
  },
  "geo" : { },
  "id_str" : "155795699542401024",
  "text" : "RT @wildobs: RT @davemeiklephoto: Red Squirrel Snacking http:\/\/t.co\/XeKvuKsr #flickr #photography #wildlife",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "David Meikle",
        "screen_name" : "davemeiklephoto",
        "indices" : [ 3, 19 ],
        "id_str" : "221574977",
        "id" : 221574977
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "flickr",
        "indices" : [ 64, 71 ]
      }, {
        "text" : "photography",
        "indices" : [ 72, 84 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 85, 94 ]
      } ],
      "urls" : [ {
        "indices" : [ 43, 63 ],
        "url" : "http:\/\/t.co\/XeKvuKsr",
        "expanded_url" : "http:\/\/flic.kr\/p\/b99muD",
        "display_url" : "flic.kr\/p\/b99muD"
      } ]
    },
    "geo" : { },
    "id_str" : "155793624863477760",
    "text" : "RT @davemeiklephoto: Red Squirrel Snacking http:\/\/t.co\/XeKvuKsr #flickr #photography #wildlife",
    "id" : 155793624863477760,
    "created_at" : "2012-01-07 23:31:09 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 155795699542401024,
  "created_at" : "2012-01-07 23:39:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "p2",
      "indices" : [ 36, 39 ]
    }, {
      "text" : "tcot",
      "indices" : [ 40, 45 ]
    }, {
      "text" : "ows",
      "indices" : [ 46, 50 ]
    }, {
      "text" : "gop",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/E3MwE8VK",
      "expanded_url" : "http:\/\/selaniest.wordpress.com\/2012\/01\/06\/rick-santorum-dirty-sex-and-bad-haircuts\/",
      "display_url" : "selaniest.wordpress.com\/2012\/01\/06\/ric\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155791231849472000",
  "text" : "RT @Selaniest: http:\/\/t.co\/E3MwE8VK #p2 #tcot #ows #gop",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "p2",
        "indices" : [ 21, 24 ]
      }, {
        "text" : "tcot",
        "indices" : [ 25, 30 ]
      }, {
        "text" : "ows",
        "indices" : [ 31, 35 ]
      }, {
        "text" : "gop",
        "indices" : [ 36, 40 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/E3MwE8VK",
        "expanded_url" : "http:\/\/selaniest.wordpress.com\/2012\/01\/06\/rick-santorum-dirty-sex-and-bad-haircuts\/",
        "display_url" : "selaniest.wordpress.com\/2012\/01\/06\/ric\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "155790537704742913",
    "text" : "http:\/\/t.co\/E3MwE8VK #p2 #tcot #ows #gop",
    "id" : 155790537704742913,
    "created_at" : "2012-01-07 23:18:53 +0000",
    "user" : {
      "name" : "The Great Unwashed",
      "screen_name" : "UnwashedThe",
      "protected" : false,
      "id_str" : "233971651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672923186632216576\/tRMQmyrX_normal.jpg",
      "id" : 233971651,
      "verified" : false
    }
  },
  "id" : 155791231849472000,
  "created_at" : "2012-01-07 23:21:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155788867151204352",
  "text" : "RT @oshum: As long as we express Hate...even in just using the word itself 2 illustrate a dislike 4 some thing\/one ...we r lacking the L ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155786447767605248",
    "text" : "As long as we express Hate...even in just using the word itself 2 illustrate a dislike 4 some thing\/one ...we r lacking the LIGHT of PEACE.",
    "id" : 155786447767605248,
    "created_at" : "2012-01-07 23:02:38 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 155788867151204352,
  "created_at" : "2012-01-07 23:12:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155766485371994113",
  "text" : "RT @CrystalLewis: Spirituality is about the journey, not the destination.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155765440138842114",
    "text" : "Spirituality is about the journey, not the destination.",
    "id" : 155765440138842114,
    "created_at" : "2012-01-07 21:39:09 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 155766485371994113,
  "created_at" : "2012-01-07 21:43:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 3, 12 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155743483439755264",
  "text" : "RT @Fernwise: Okay, I frakkin' exercised. It was AWFUL. This really better help my blood pressure or I'm gonna be really pissed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155741681705156609",
    "text" : "Okay, I frakkin' exercised. It was AWFUL. This really better help my blood pressure or I'm gonna be really pissed.",
    "id" : 155741681705156609,
    "created_at" : "2012-01-07 20:04:45 +0000",
    "user" : {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "protected" : false,
      "id_str" : "23538653",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/253664055\/FernForTwitter_normal.png",
      "id" : 23538653,
      "verified" : false
    }
  },
  "id" : 155743483439755264,
  "created_at" : "2012-01-07 20:11:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 100 ],
      "url" : "http:\/\/t.co\/cbI3INL1",
      "expanded_url" : "http:\/\/bit.ly\/x0r2Oe",
      "display_url" : "bit.ly\/x0r2Oe"
    } ]
  },
  "geo" : { },
  "id_str" : "155734375256952833",
  "text" : "RT @Moonrust: This May Look Like an Ink Drawing, But It\u2019s Actually a Photograph http:\/\/t.co\/cbI3INL1",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feeddler-rss-reader-pro\/id365710282?mt=8\" rel=\"nofollow\"\u003EFeeddler\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 66, 86 ],
        "url" : "http:\/\/t.co\/cbI3INL1",
        "expanded_url" : "http:\/\/bit.ly\/x0r2Oe",
        "display_url" : "bit.ly\/x0r2Oe"
      } ]
    },
    "geo" : { },
    "id_str" : "155733373929783296",
    "text" : "This May Look Like an Ink Drawing, But It\u2019s Actually a Photograph http:\/\/t.co\/cbI3INL1",
    "id" : 155733373929783296,
    "created_at" : "2012-01-07 19:31:44 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 155734375256952833,
  "created_at" : "2012-01-07 19:35:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 2, 17 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155730041953718272",
  "geo" : { },
  "id_str" : "155731164672430080",
  "in_reply_to_user_id" : 30825946,
  "text" : ". @JonathanElliot I think it's your avatar pic! LOL ; )",
  "id" : 155731164672430080,
  "in_reply_to_status_id" : 155730041953718272,
  "created_at" : "2012-01-07 19:22:57 +0000",
  "in_reply_to_screen_name" : "JonathanElliot",
  "in_reply_to_user_id_str" : "30825946",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 0, 15 ],
      "id_str" : "23757784",
      "id" : 23757784
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155725397688975360",
  "geo" : { },
  "id_str" : "155730820601102336",
  "in_reply_to_user_id" : 23757784,
  "text" : "@MartijnLinssen I almost expect all the GOP 2 get on stage, point out and say \"Got ya!\"",
  "id" : 155730820601102336,
  "in_reply_to_status_id" : 155725397688975360,
  "created_at" : "2012-01-07 19:21:35 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/JTMrJf5T",
      "expanded_url" : "http:\/\/omgf.ac\/ts\/qlD",
      "display_url" : "omgf.ac\/ts\/qlD"
    } ]
  },
  "geo" : { },
  "id_str" : "155730271973548032",
  "text" : "RT @OMGFacts: Scientists have grown a functioning heart! Details --&gt; http:\/\/t.co\/JTMrJf5T",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/JTMrJf5T",
        "expanded_url" : "http:\/\/omgf.ac\/ts\/qlD",
        "display_url" : "omgf.ac\/ts\/qlD"
      } ]
    },
    "geo" : { },
    "id_str" : "155725487640023040",
    "text" : "Scientists have grown a functioning heart! Details --&gt; http:\/\/t.co\/JTMrJf5T",
    "id" : 155725487640023040,
    "created_at" : "2012-01-07 19:00:24 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 155730271973548032,
  "created_at" : "2012-01-07 19:19:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 136 ],
      "url" : "http:\/\/t.co\/7BIqkQU3",
      "expanded_url" : "http:\/\/tl.gd\/f6tu5p",
      "display_url" : "tl.gd\/f6tu5p"
    } ]
  },
  "geo" : { },
  "id_str" : "155717970637758464",
  "text" : "Does anyone know validity of this.. if student was Einstein? also, what about \"cold\"?\n\nProfessor : You are a (cont) http:\/\/t.co\/7BIqkQU3",
  "id" : 155717970637758464,
  "created_at" : "2012-01-07 18:30:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "indices" : [ 3, 16 ],
      "id_str" : "20065936",
      "id" : 20065936
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155715081747972096",
  "text" : "RT @mental_floss: The Pledge of Allegiance was originally written as part of a magazine's campaign to sell flags to schools \u2014\u00A0http:\/\/t.c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 108, 128 ],
        "url" : "http:\/\/t.co\/cPsIqHj0",
        "expanded_url" : "http:\/\/goo.gl\/pxnWl",
        "display_url" : "goo.gl\/pxnWl"
      } ]
    },
    "geo" : { },
    "id_str" : "155671259206778880",
    "text" : "The Pledge of Allegiance was originally written as part of a magazine's campaign to sell flags to schools \u2014\u00A0http:\/\/t.co\/cPsIqHj0",
    "id" : 155671259206778880,
    "created_at" : "2012-01-07 15:24:55 +0000",
    "user" : {
      "name" : "Mental Floss",
      "screen_name" : "mental_floss",
      "protected" : false,
      "id_str" : "20065936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/725736720327708672\/QHUualpe_normal.jpg",
      "id" : 20065936,
      "verified" : true
    }
  },
  "id" : 155715081747972096,
  "created_at" : "2012-01-07 18:19:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "Jean-Michel Leclercq",
      "screen_name" : "jmleclercq",
      "indices" : [ 21, 32 ],
      "id_str" : "17948250",
      "id" : 17948250
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "photography",
      "indices" : [ 111, 123 ]
    } ],
    "urls" : [ {
      "indices" : [ 90, 110 ],
      "url" : "http:\/\/t.co\/En0VDGyU",
      "expanded_url" : "http:\/\/togs.im\/uya8o",
      "display_url" : "togs.im\/uya8o"
    } ]
  },
  "geo" : { },
  "id_str" : "155713737121202176",
  "text" : "RT @DwayneReaves: RT @jmleclercq: 100 Bewitching And Colorful Examples Of Sky Photography http:\/\/t.co\/En0VDGyU #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jean-Michel Leclercq",
        "screen_name" : "jmleclercq",
        "indices" : [ 3, 14 ],
        "id_str" : "17948250",
        "id" : 17948250
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "photography",
        "indices" : [ 93, 105 ]
      } ],
      "urls" : [ {
        "indices" : [ 72, 92 ],
        "url" : "http:\/\/t.co\/En0VDGyU",
        "expanded_url" : "http:\/\/togs.im\/uya8o",
        "display_url" : "togs.im\/uya8o"
      } ]
    },
    "geo" : { },
    "id_str" : "155709968132218880",
    "text" : "RT @jmleclercq: 100 Bewitching And Colorful Examples Of Sky Photography http:\/\/t.co\/En0VDGyU #photography",
    "id" : 155709968132218880,
    "created_at" : "2012-01-07 17:58:44 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 155713737121202176,
  "created_at" : "2012-01-07 18:13:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155708273075552256",
  "text" : "her younger self was shy.. wouldnt get close and looked at her sadly.",
  "id" : 155708273075552256,
  "created_at" : "2012-01-07 17:51:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155705877356220416",
  "text" : "DD had cool dreams last night. she met her younger self.. almost tackled her..lol. cosplay, pikachu were involved.",
  "id" : 155705877356220416,
  "created_at" : "2012-01-07 17:42:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155699702166339585",
  "text" : "so.. new bible tabs came in. glad I like them this time. I think MIL will be pleased. also got her magnify bar.. nice!",
  "id" : 155699702166339585,
  "created_at" : "2012-01-07 17:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 2, 14 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155698268385452032",
  "geo" : { },
  "id_str" : "155699237491965952",
  "in_reply_to_user_id" : 20929609,
  "text" : ". @Silvercrone I thought it was 12 mill. saw pics of B4 and after. made me sad.",
  "id" : 155699237491965952,
  "in_reply_to_status_id" : 155698268385452032,
  "created_at" : "2012-01-07 17:16:05 +0000",
  "in_reply_to_screen_name" : "Silvercrone",
  "in_reply_to_user_id_str" : "20929609",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 14, 27 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "shortyawards",
      "indices" : [ 0, 13 ]
    }, {
      "text" : "author",
      "indices" : [ 28, 35 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155698169152409600",
  "text" : "#shortyawards @UnseeingEyes #author because... he tweets intelligently from the heart and cares for his followers.",
  "id" : 155698169152409600,
  "created_at" : "2012-01-07 17:11:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155690518226010116",
  "text" : "so.. I think I have to not eat any fried\/breaded items from chinese place. always makes me ill.",
  "id" : 155690518226010116,
  "created_at" : "2012-01-07 16:41:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 2, 14 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155683785906724865",
  "geo" : { },
  "id_str" : "155689488201424897",
  "in_reply_to_user_id" : 71118021,
  "text" : ". @CaroleODell I need a big dumpster right outside a window.. that would work for me! LOL",
  "id" : 155689488201424897,
  "in_reply_to_status_id" : 155683785906724865,
  "created_at" : "2012-01-07 16:37:21 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/PeggySueCusses\/status\/155682529448431616\/photo\/1",
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/lcDPwIe4",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AikYb4nCEAAbHky.jpg",
      "id_str" : "155682529452625920",
      "id" : 155682529452625920,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AikYb4nCEAAbHky.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 320
      }, {
        "h" : 251,
        "resize" : "fit",
        "w" : 320
      } ],
      "display_url" : "pic.twitter.com\/lcDPwIe4"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155684320806305793",
  "text" : "RT @PeggySueCusses: Isn't this the truth!! I couldn't have said it better. http:\/\/t.co\/lcDPwIe4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/PeggySueCusses\/status\/155682529448431616\/photo\/1",
        "indices" : [ 55, 75 ],
        "url" : "http:\/\/t.co\/lcDPwIe4",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AikYb4nCEAAbHky.jpg",
        "id_str" : "155682529452625920",
        "id" : 155682529452625920,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AikYb4nCEAAbHky.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 320
        }, {
          "h" : 251,
          "resize" : "fit",
          "w" : 320
        } ],
        "display_url" : "pic.twitter.com\/lcDPwIe4"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155682529448431616",
    "text" : "Isn't this the truth!! I couldn't have said it better. http:\/\/t.co\/lcDPwIe4",
    "id" : 155682529448431616,
    "created_at" : "2012-01-07 16:09:42 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 155684320806305793,
  "created_at" : "2012-01-07 16:16:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carl F.",
      "screen_name" : "oushadow",
      "indices" : [ 3, 12 ],
      "id_str" : "4555561",
      "id" : 4555561
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/oushadow\/status\/155674844560756736\/photo\/1",
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/Gjsh0tmE",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AikRckKCEAI0ZPb.jpg",
      "id_str" : "155674844560756738",
      "id" : 155674844560756738,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AikRckKCEAI0ZPb.jpg",
      "sizes" : [ {
        "h" : 448,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 254,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 484,
        "resize" : "fit",
        "w" : 648
      } ],
      "display_url" : "pic.twitter.com\/Gjsh0tmE"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155682176229314561",
  "text" : "RT @oushadow: Pay attention to me. Right meow! http:\/\/t.co\/Gjsh0tmE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003EPhotos on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/oushadow\/status\/155674844560756736\/photo\/1",
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/Gjsh0tmE",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AikRckKCEAI0ZPb.jpg",
        "id_str" : "155674844560756738",
        "id" : 155674844560756738,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AikRckKCEAI0ZPb.jpg",
        "sizes" : [ {
          "h" : 448,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 254,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 648
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 484,
          "resize" : "fit",
          "w" : 648
        } ],
        "display_url" : "pic.twitter.com\/Gjsh0tmE"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155674844560756736",
    "text" : "Pay attention to me. Right meow! http:\/\/t.co\/Gjsh0tmE",
    "id" : 155674844560756736,
    "created_at" : "2012-01-07 15:39:10 +0000",
    "user" : {
      "name" : "Carl F.",
      "screen_name" : "oushadow",
      "protected" : false,
      "id_str" : "4555561",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/582716916487221248\/9_iiI6m7_normal.jpg",
      "id" : 4555561,
      "verified" : false
    }
  },
  "id" : 155682176229314561,
  "created_at" : "2012-01-07 16:08:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 0, 12 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155486695263961089",
  "geo" : { },
  "id_str" : "155679676881321984",
  "in_reply_to_user_id" : 71118021,
  "text" : "@CaroleODell cute photo!",
  "id" : 155679676881321984,
  "in_reply_to_status_id" : 155486695263961089,
  "created_at" : "2012-01-07 15:58:22 +0000",
  "in_reply_to_screen_name" : "CaroleODell",
  "in_reply_to_user_id_str" : "71118021",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 3, 15 ],
      "id_str" : "71118021",
      "id" : 71118021
    }, {
      "name" : "Hope Cheri Thomas",
      "screen_name" : "LincolnvilleCat",
      "indices" : [ 79, 95 ],
      "id_str" : "312080937",
      "id" : 312080937
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 99, 110 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/2lfkDJDS",
      "expanded_url" : "http:\/\/www.lincolnvillecats.com\/post\/15423325522\/whats-up-there",
      "display_url" : "lincolnvillecats.com\/post\/154233255\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155679499684548608",
  "text" : "RT @CaroleODell: What\u2019s up there? | Lincolnville Cats http:\/\/t.co\/2lfkDJDS via @LincolnvilleCat cc @moosebegab :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hope Cheri Thomas",
        "screen_name" : "LincolnvilleCat",
        "indices" : [ 62, 78 ],
        "id_str" : "312080937",
        "id" : 312080937
      }, {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 82, 93 ],
        "id_str" : "93747129",
        "id" : 93747129
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/2lfkDJDS",
        "expanded_url" : "http:\/\/www.lincolnvillecats.com\/post\/15423325522\/whats-up-there",
        "display_url" : "lincolnvillecats.com\/post\/154233255\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "155486695263961089",
    "text" : "What\u2019s up there? | Lincolnville Cats http:\/\/t.co\/2lfkDJDS via @LincolnvilleCat cc @moosebegab :)",
    "id" : 155486695263961089,
    "created_at" : "2012-01-07 03:11:31 +0000",
    "user" : {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "protected" : false,
      "id_str" : "71118021",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445590236899192832\/0lpH2xrA_normal.jpeg",
      "id" : 71118021,
      "verified" : false
    }
  },
  "id" : 155679499684548608,
  "created_at" : "2012-01-07 15:57:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sacred Witness",
      "screen_name" : "SacredWitness",
      "indices" : [ 3, 17 ],
      "id_str" : "3085133691",
      "id" : 3085133691
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 39 ],
      "url" : "http:\/\/t.co\/oS8hvUPT",
      "expanded_url" : "http:\/\/carlaroyal.com\/2011\/01\/dealing-with-resistance\/",
      "display_url" : "carlaroyal.com\/2011\/01\/dealin\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155468901684224000",
  "text" : "RT @SacredWitness: http:\/\/t.co\/oS8hvUPT",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/oS8hvUPT",
        "expanded_url" : "http:\/\/carlaroyal.com\/2011\/01\/dealing-with-resistance\/",
        "display_url" : "carlaroyal.com\/2011\/01\/dealin\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "155467977368674306",
    "text" : "http:\/\/t.co\/oS8hvUPT",
    "id" : 155467977368674306,
    "created_at" : "2012-01-07 01:57:08 +0000",
    "user" : {
      "name" : "Carla Royal",
      "screen_name" : "CarlaRoyal",
      "protected" : false,
      "id_str" : "28894048",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2823476520\/13fdf78af18d23f2cf1dc63aceb88301_normal.jpeg",
      "id" : 28894048,
      "verified" : false
    }
  },
  "id" : 155468901684224000,
  "created_at" : "2012-01-07 02:00:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 3, 16 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155467321434050560",
  "text" : "RT @grouchypuppy: I kissed a dog, and I liked it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155465922155528193",
    "text" : "I kissed a dog, and I liked it.",
    "id" : 155465922155528193,
    "created_at" : "2012-01-07 01:48:58 +0000",
    "user" : {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "protected" : false,
      "id_str" : "29913475",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458335339\/gp_twitter_normal.jpg",
      "id" : 29913475,
      "verified" : false
    }
  },
  "id" : 155467321434050560,
  "created_at" : "2012-01-07 01:54:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155443209886113792",
  "text" : "I love it when Possum comes to visit the back porch for the cat food. I just want to huggle him..lol",
  "id" : 155443209886113792,
  "created_at" : "2012-01-07 00:18:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Marie Firth",
      "screen_name" : "JoanneMFirth",
      "indices" : [ 0, 13 ],
      "id_str" : "133780513",
      "id" : 133780513
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155434331173695489",
  "geo" : { },
  "id_str" : "155435591251673088",
  "in_reply_to_user_id" : 133780513,
  "text" : "@JoanneMFirth oh what a great link.. Thanks! sometimes my eyes and head hurt and I just dont know what to do w myself.",
  "id" : 155435591251673088,
  "in_reply_to_status_id" : 155434331173695489,
  "created_at" : "2012-01-06 23:48:27 +0000",
  "in_reply_to_screen_name" : "JoanneMFirth",
  "in_reply_to_user_id_str" : "133780513",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155433686270091265",
  "text" : "i'm thinking i should get used to audio books (not really my thing) as my eyes are so bad...",
  "id" : 155433686270091265,
  "created_at" : "2012-01-06 23:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    }, {
      "name" : "Matt Mira",
      "screen_name" : "MattMira",
      "indices" : [ 70, 79 ],
      "id_str" : "19430456",
      "id" : 19430456
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 83, 103 ],
      "url" : "http:\/\/t.co\/1WtG5ruA",
      "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/science-environment-16427876",
      "display_url" : "bbc.co.uk\/news\/science-e\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155432550498713600",
  "text" : "RT @Matth3ous: Astronaut to lead starship effort \/\/ Did you see this, @MattMira !? http:\/\/t.co\/1WtG5ruA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/bbc-news\/id364147881?mt=8&uo=4\" rel=\"nofollow\"\u003EBBC News on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Matt Mira",
        "screen_name" : "MattMira",
        "indices" : [ 55, 64 ],
        "id_str" : "19430456",
        "id" : 19430456
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 68, 88 ],
        "url" : "http:\/\/t.co\/1WtG5ruA",
        "expanded_url" : "http:\/\/www.bbc.co.uk\/news\/science-environment-16427876",
        "display_url" : "bbc.co.uk\/news\/science-e\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "155432187334885376",
    "text" : "Astronaut to lead starship effort \/\/ Did you see this, @MattMira !? http:\/\/t.co\/1WtG5ruA",
    "id" : 155432187334885376,
    "created_at" : "2012-01-06 23:34:55 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 155432550498713600,
  "created_at" : "2012-01-06 23:36:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155420800923598848",
  "text" : "me: I'm amazing, aren't I? DH: Yeah, something like that.",
  "id" : 155420800923598848,
  "created_at" : "2012-01-06 22:49:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155408700775993344",
  "text" : "got a song stuck in my head.. cant get it to stop and now have a headache.. bleh.",
  "id" : 155408700775993344,
  "created_at" : "2012-01-06 22:01:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 3, 14 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155393752444305409",
  "text" : "RT @dhammagirl: How does one pray to God for themselves while they harbor hate in their hearts for others. \nWhat am I missing??",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myplume.com\/\" rel=\"nofollow\"\u003EPlume\u00A0for\u00A0Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155389290761822208",
    "text" : "How does one pray to God for themselves while they harbor hate in their hearts for others. \nWhat am I missing??",
    "id" : 155389290761822208,
    "created_at" : "2012-01-06 20:44:28 +0000",
    "user" : {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "protected" : false,
      "id_str" : "39331231",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/212605780\/dhammagirl_normal.JPG",
      "id" : 39331231,
      "verified" : false
    }
  },
  "id" : 155393752444305409,
  "created_at" : "2012-01-06 21:02:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155378131904102400",
  "geo" : { },
  "id_str" : "155385514042728448",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker ahh.. I see.. yeah, bummer. : (",
  "id" : 155385514042728448,
  "in_reply_to_status_id" : 155378131904102400,
  "created_at" : "2012-01-06 20:29:28 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155368846931394561",
  "geo" : { },
  "id_str" : "155377367550922752",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker I have Kindle Fire but don't use it to read.. I use my Kindle 3g\/Wifi for reading. Love e-ink for reading!",
  "id" : 155377367550922752,
  "in_reply_to_status_id" : 155368846931394561,
  "created_at" : "2012-01-06 19:57:05 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155371581298851840",
  "geo" : { },
  "id_str" : "155376583782305792",
  "in_reply_to_user_id" : 25221139,
  "text" : "@WarriorBanker sorry you didn't like your kindles. I did use sony prs 505 before my kindle and loved it.",
  "id" : 155376583782305792,
  "in_reply_to_status_id" : 155371581298851840,
  "created_at" : "2012-01-06 19:53:58 +0000",
  "in_reply_to_screen_name" : "PisseArtiste",
  "in_reply_to_user_id_str" : "25221139",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slate",
      "screen_name" : "Slate",
      "indices" : [ 114, 120 ],
      "id_str" : "15164565",
      "id" : 15164565
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 89, 109 ],
      "url" : "http:\/\/t.co\/AeWe5IZ5",
      "expanded_url" : "http:\/\/www.slate.com\/slideshows\/arts\/year-in-review-caption-contest.html?tid=sm_tw_button_toolbar",
      "display_url" : "slate.com\/slideshows\/art\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155367668348747777",
  "text" : "LOL&gt;&gt; This Picture Is Worth 20 Words: Highlights from Slate's 2011 Caption Contest http:\/\/t.co\/AeWe5IZ5 via @slate",
  "id" : 155367668348747777,
  "created_at" : "2012-01-06 19:18:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155363515731943425",
  "text" : "RT @_TheBankers_: We are the bankers and we will work hard to privatize the water in poor countries, so that no one may drink without ou ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155357819900669952",
    "text" : "We are the bankers and we will work hard to privatize the water in poor countries, so that no one may drink without our permission.",
    "id" : 155357819900669952,
    "created_at" : "2012-01-06 18:39:25 +0000",
    "user" : {
      "name" : "John K. Galbraith",
      "screen_name" : "JohnK_Galbraith",
      "protected" : false,
      "id_str" : "254054375",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3626965838\/7e1de9c65074ec8ef97e4851fe3f9067_normal.jpeg",
      "id" : 254054375,
      "verified" : false
    }
  },
  "id" : 155363515731943425,
  "created_at" : "2012-01-06 19:02:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "choice",
      "indices" : [ 96, 103 ]
    }, {
      "text" : "TeaPuppets",
      "indices" : [ 104, 115 ]
    }, {
      "text" : "theocracy",
      "indices" : [ 116, 126 ]
    } ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/fpS0O0LS",
      "expanded_url" : "http:\/\/bit.ly\/xLjt5N",
      "display_url" : "bit.ly\/xLjt5N"
    } ]
  },
  "geo" : { },
  "id_str" : "155348119666688000",
  "text" : "RT @MWM4444: Nothing says \"pro-life\" like attempting to end a few of them. http:\/\/t.co\/fpS0O0LS #choice #TeaPuppets #theocracy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "choice",
        "indices" : [ 83, 90 ]
      }, {
        "text" : "TeaPuppets",
        "indices" : [ 91, 102 ]
      }, {
        "text" : "theocracy",
        "indices" : [ 103, 113 ]
      } ],
      "urls" : [ {
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/fpS0O0LS",
        "expanded_url" : "http:\/\/bit.ly\/xLjt5N",
        "display_url" : "bit.ly\/xLjt5N"
      } ]
    },
    "geo" : { },
    "id_str" : "155343128172314625",
    "text" : "Nothing says \"pro-life\" like attempting to end a few of them. http:\/\/t.co\/fpS0O0LS #choice #TeaPuppets #theocracy",
    "id" : 155343128172314625,
    "created_at" : "2012-01-06 17:41:02 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 155348119666688000,
  "created_at" : "2012-01-06 18:00:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155343809692172288",
  "geo" : { },
  "id_str" : "155347972861865985",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time LOLOL.. you're a hoot! ; )",
  "id" : 155347972861865985,
  "in_reply_to_status_id" : 155343809692172288,
  "created_at" : "2012-01-06 18:00:17 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155335412167094272",
  "text" : "I slid down the bank when getting the mail. I'm not hurt but I wanted to cry.",
  "id" : 155335412167094272,
  "created_at" : "2012-01-06 17:10:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "HappyPlace.com",
      "screen_name" : "HappyPlace",
      "indices" : [ 111, 122 ],
      "id_str" : "312240410",
      "id" : 312240410
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 86, 106 ],
      "url" : "http:\/\/t.co\/Y5D8pRpE",
      "expanded_url" : "http:\/\/funni.ly\/sJRD59",
      "display_url" : "funni.ly\/sJRD59"
    } ]
  },
  "geo" : { },
  "id_str" : "155331110929309698",
  "text" : "The 50 most brilliant, obnoxious, or delightfully sociopathic Facebook posts of 2011. http:\/\/t.co\/Y5D8pRpE via @HappyPlace",
  "id" : 155331110929309698,
  "created_at" : "2012-01-06 16:53:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lovely Lita's",
      "screen_name" : "sqrlady",
      "indices" : [ 3, 11 ],
      "id_str" : "134885838",
      "id" : 134885838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 54, 74 ],
      "url" : "http:\/\/t.co\/Qq5fkcJK",
      "expanded_url" : "http:\/\/fb.me\/11X05EdM1",
      "display_url" : "fb.me\/11X05EdM1"
    } ]
  },
  "geo" : { },
  "id_str" : "155327084024184834",
  "text" : "RT @sqrlady: Somebody enjoying a little bit of loving http:\/\/t.co\/Qq5fkcJK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 41, 61 ],
        "url" : "http:\/\/t.co\/Qq5fkcJK",
        "expanded_url" : "http:\/\/fb.me\/11X05EdM1",
        "display_url" : "fb.me\/11X05EdM1"
      } ]
    },
    "geo" : { },
    "id_str" : "155324937899487232",
    "text" : "Somebody enjoying a little bit of loving http:\/\/t.co\/Qq5fkcJK",
    "id" : 155324937899487232,
    "created_at" : "2012-01-06 16:28:45 +0000",
    "user" : {
      "name" : "Lovely Lita's",
      "screen_name" : "sqrlady",
      "protected" : false,
      "id_str" : "134885838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841619166\/twitterpic_normal.jpg",
      "id" : 134885838,
      "verified" : false
    }
  },
  "id" : 155327084024184834,
  "created_at" : "2012-01-06 16:37:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155324880072609792",
  "text" : "omg.. forgot to take bagels out of freezer! ((runsintokitchen))",
  "id" : 155324880072609792,
  "created_at" : "2012-01-06 16:28:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/RMoGib\/status\/155318441505603584\/photo\/1",
      "indices" : [ 24, 44 ],
      "url" : "http:\/\/t.co\/ZRVJHKGR",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AifNTLVCQAAnCd3.jpg",
      "id_str" : "155318441509797888",
      "id" : 155318441509797888,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AifNTLVCQAAnCd3.jpg",
      "sizes" : [ {
        "h" : 679,
        "resize" : "fit",
        "w" : 600
      }, {
        "h" : 858,
        "resize" : "fit",
        "w" : 758
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 385,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 858,
        "resize" : "fit",
        "w" : 758
      } ],
      "display_url" : "pic.twitter.com\/ZRVJHKGR"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155319177748553728",
  "text" : "RT @RMoGib: Puppy nest. http:\/\/t.co\/ZRVJHKGR",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.apple.com\" rel=\"nofollow\"\u003ECamera on iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/RMoGib\/status\/155318441505603584\/photo\/1",
        "indices" : [ 12, 32 ],
        "url" : "http:\/\/t.co\/ZRVJHKGR",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AifNTLVCQAAnCd3.jpg",
        "id_str" : "155318441509797888",
        "id" : 155318441509797888,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AifNTLVCQAAnCd3.jpg",
        "sizes" : [ {
          "h" : 679,
          "resize" : "fit",
          "w" : 600
        }, {
          "h" : 858,
          "resize" : "fit",
          "w" : 758
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 385,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 858,
          "resize" : "fit",
          "w" : 758
        } ],
        "display_url" : "pic.twitter.com\/ZRVJHKGR"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155318441505603584",
    "text" : "Puppy nest. http:\/\/t.co\/ZRVJHKGR",
    "id" : 155318441505603584,
    "created_at" : "2012-01-06 16:02:57 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 155319177748553728,
  "created_at" : "2012-01-06 16:05:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wildlife",
      "indices" : [ 61, 70 ]
    }, {
      "text" : "nature",
      "indices" : [ 71, 78 ]
    }, {
      "text" : "outdoors",
      "indices" : [ 79, 88 ]
    } ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/4XNeS9qo",
      "expanded_url" : "http:\/\/bit.ly\/uV3vNe",
      "display_url" : "bit.ly\/uV3vNe"
    } ]
  },
  "geo" : { },
  "id_str" : "155318911397670914",
  "text" : "RT @KerriFar: Meet \"Super Squirrel\" ~ http:\/\/t.co\/4XNeS9qo ~ #wildlife #nature #outdoors",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wildlife",
        "indices" : [ 47, 56 ]
      }, {
        "text" : "nature",
        "indices" : [ 57, 64 ]
      }, {
        "text" : "outdoors",
        "indices" : [ 65, 74 ]
      } ],
      "urls" : [ {
        "indices" : [ 24, 44 ],
        "url" : "http:\/\/t.co\/4XNeS9qo",
        "expanded_url" : "http:\/\/bit.ly\/uV3vNe",
        "display_url" : "bit.ly\/uV3vNe"
      } ]
    },
    "geo" : { },
    "id_str" : "155318709764886529",
    "text" : "Meet \"Super Squirrel\" ~ http:\/\/t.co\/4XNeS9qo ~ #wildlife #nature #outdoors",
    "id" : 155318709764886529,
    "created_at" : "2012-01-06 16:04:00 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 155318911397670914,
  "created_at" : "2012-01-06 16:04:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041A\u043E\u0442\u043A\u0438\u043Da \u0413\u0430\u043B\u0438\u043D\u0430",
      "screen_name" : "DoreenVirtue444",
      "indices" : [ 3, 19 ],
      "id_str" : "2813818578",
      "id" : 2813818578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155306645491154944",
  "text" : "RT @DoreenVirtue444: Thank you, Archangel Zadkiel, for helping me focus upon my beautiful memories and let the rest go.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.angeltherapy.com\/\" rel=\"nofollow\"\u003EDoreen Virtue\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155303811689349120",
    "text" : "Thank you, Archangel Zadkiel, for helping me focus upon my beautiful memories and let the rest go.",
    "id" : 155303811689349120,
    "created_at" : "2012-01-06 15:04:48 +0000",
    "user" : {
      "name" : "Doreen Virtue",
      "screen_name" : "DoreenVirtue",
      "protected" : false,
      "id_str" : "74924273",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/463066644453920768\/kcDW971C_normal.jpeg",
      "id" : 74924273,
      "verified" : true
    }
  },
  "id" : 155306645491154944,
  "created_at" : "2012-01-06 15:16:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 2, 13 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155305120710656001",
  "geo" : { },
  "id_str" : "155306488657747969",
  "in_reply_to_user_id" : 2772041,
  "text" : ". @adampknave snuggling the cat is always the right response! lol",
  "id" : 155306488657747969,
  "in_reply_to_status_id" : 155305120710656001,
  "created_at" : "2012-01-06 15:15:27 +0000",
  "in_reply_to_screen_name" : "adampknave",
  "in_reply_to_user_id_str" : "2772041",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 38, 58 ],
      "url" : "http:\/\/t.co\/sJ0fwgIx",
      "expanded_url" : "http:\/\/FunnyOrDie.com\/m\/6254",
      "display_url" : "FunnyOrDie.com\/m\/6254"
    } ]
  },
  "geo" : { },
  "id_str" : "155302274321752064",
  "text" : "A guy goes shopping for a new girl. - http:\/\/t.co\/sJ0fwgIx",
  "id" : 155302274321752064,
  "created_at" : "2012-01-06 14:58:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 18, 38 ],
      "url" : "http:\/\/t.co\/vqBAdWc7",
      "expanded_url" : "http:\/\/www.iusedtohatebirds.com\/2012\/01\/squirrel-vs-suet.html?spref=tw",
      "display_url" : "iusedtohatebirds.com\/2012\/01\/squirr\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "155080518004785152",
  "text" : "Squirrel vs. Suet http:\/\/t.co\/vqBAdWc7",
  "id" : 155080518004785152,
  "created_at" : "2012-01-06 00:17:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 21, 41 ],
      "url" : "http:\/\/t.co\/DMGy1YQC",
      "expanded_url" : "http:\/\/j.mp\/yQMXBC",
      "display_url" : "j.mp\/yQMXBC"
    } ]
  },
  "geo" : { },
  "id_str" : "155079091710734336",
  "text" : "Cultivating Patience http:\/\/t.co\/DMGy1YQC",
  "id" : 155079091710734336,
  "created_at" : "2012-01-06 00:11:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Alan Lucas",
      "screen_name" : "Owlkenpowriter",
      "indices" : [ 3, 18 ],
      "id_str" : "23521939",
      "id" : 23521939
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 73, 93 ],
      "url" : "http:\/\/t.co\/tx7varl5",
      "expanded_url" : "http:\/\/soc.li\/Gtr5Kre",
      "display_url" : "soc.li\/Gtr5Kre"
    } ]
  },
  "geo" : { },
  "id_str" : "155077913975332864",
  "text" : "RT @Owlkenpowriter: Researcher Discovers Gene That Regulates Body Weight http:\/\/t.co\/tx7varl5",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 53, 73 ],
        "url" : "http:\/\/t.co\/tx7varl5",
        "expanded_url" : "http:\/\/soc.li\/Gtr5Kre",
        "display_url" : "soc.li\/Gtr5Kre"
      } ]
    },
    "geo" : { },
    "id_str" : "155068620152647681",
    "text" : "Researcher Discovers Gene That Regulates Body Weight http:\/\/t.co\/tx7varl5",
    "id" : 155068620152647681,
    "created_at" : "2012-01-05 23:30:14 +0000",
    "user" : {
      "name" : "David Alan Lucas",
      "screen_name" : "Owlkenpowriter",
      "protected" : false,
      "id_str" : "23521939",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1685605927\/David_Logo_white_normal.jpg",
      "id" : 23521939,
      "verified" : false
    }
  },
  "id" : 155077913975332864,
  "created_at" : "2012-01-06 00:07:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 3, 12 ],
      "id_str" : "17341213",
      "id" : 17341213
    }, {
      "name" : "Robin Clifton",
      "screen_name" : "robinclifton",
      "indices" : [ 18, 31 ],
      "id_str" : "109356820",
      "id" : 109356820
    }, {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "indices" : [ 76, 85 ],
      "id_str" : "17341213",
      "id" : 17341213
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Nature",
      "indices" : [ 68, 75 ]
    } ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/obgQtxUD",
      "expanded_url" : "http:\/\/bit.ly\/x5jcjK",
      "display_url" : "bit.ly\/x5jcjK"
    } ]
  },
  "geo" : { },
  "id_str" : "155076325755977728",
  "text" : "RT @DawnFine: Via @robinclifton Saw a Crow ... http:\/\/t.co\/obgQtxUD #Nature @DawnFine",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Robin Clifton",
        "screen_name" : "robinclifton",
        "indices" : [ 4, 17 ],
        "id_str" : "109356820",
        "id" : 109356820
      }, {
        "name" : "Dawn",
        "screen_name" : "DawnFine",
        "indices" : [ 62, 71 ],
        "id_str" : "17341213",
        "id" : 17341213
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Nature",
        "indices" : [ 54, 61 ]
      } ],
      "urls" : [ {
        "indices" : [ 33, 53 ],
        "url" : "http:\/\/t.co\/obgQtxUD",
        "expanded_url" : "http:\/\/bit.ly\/x5jcjK",
        "display_url" : "bit.ly\/x5jcjK"
      } ]
    },
    "geo" : { },
    "id_str" : "155068769251762178",
    "text" : "Via @robinclifton Saw a Crow ... http:\/\/t.co\/obgQtxUD #Nature @DawnFine",
    "id" : 155068769251762178,
    "created_at" : "2012-01-05 23:30:50 +0000",
    "user" : {
      "name" : "Dawn",
      "screen_name" : "DawnFine",
      "protected" : false,
      "id_str" : "17341213",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/767506887747174400\/R6JN_zW5_normal.jpg",
      "id" : 17341213,
      "verified" : false
    }
  },
  "id" : 155076325755977728,
  "created_at" : "2012-01-06 00:00:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155066690294648833",
  "text" : "@Tideliar ((hugs))",
  "id" : 155066690294648833,
  "created_at" : "2012-01-05 23:22:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 0, 9 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "155047479778349058",
  "geo" : { },
  "id_str" : "155062008167936001",
  "in_reply_to_user_id" : 23538653,
  "text" : "@Fernwise LOL",
  "id" : 155062008167936001,
  "in_reply_to_status_id" : 155047479778349058,
  "created_at" : "2012-01-05 23:03:58 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "arphaus",
      "screen_name" : "arphaus",
      "indices" : [ 3, 11 ],
      "id_str" : "2500204890",
      "id" : 2500204890
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155044053321383938",
  "text" : "RT @arphaus: I believe I've already hit my manliness quota for the year - changed a tire, pulled down some dead branches & peed while ho ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "155042662301437953",
    "text" : "I believe I've already hit my manliness quota for the year - changed a tire, pulled down some dead branches & peed while holding the baby.",
    "id" : 155042662301437953,
    "created_at" : "2012-01-05 21:47:05 +0000",
    "user" : {
      "name" : "Arp Laszlo",
      "screen_name" : "thisisarp",
      "protected" : false,
      "id_str" : "7339162",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/773529857464688640\/ZPr3v43v_normal.jpg",
      "id" : 7339162,
      "verified" : false
    }
  },
  "id" : 155044053321383938,
  "created_at" : "2012-01-05 21:52:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "indices" : [ 3, 16 ],
      "id_str" : "8659362",
      "id" : 8659362
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 72, 92 ],
      "url" : "http:\/\/t.co\/cQdHjQVv",
      "expanded_url" : "http:\/\/wp.me\/paUB-hlD",
      "display_url" : "wp.me\/paUB-hlD"
    } ]
  },
  "geo" : { },
  "id_str" : "155027408393740288",
  "text" : "RT @CuteOverload: THIS JUST IN: Kitten and baby deer MAKING OUT! OMG!!! http:\/\/t.co\/cQdHjQVv",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 54, 74 ],
        "url" : "http:\/\/t.co\/cQdHjQVv",
        "expanded_url" : "http:\/\/wp.me\/paUB-hlD",
        "display_url" : "wp.me\/paUB-hlD"
      } ]
    },
    "geo" : { },
    "id_str" : "155025565596925953",
    "text" : "THIS JUST IN: Kitten and baby deer MAKING OUT! OMG!!! http:\/\/t.co\/cQdHjQVv",
    "id" : 155025565596925953,
    "created_at" : "2012-01-05 20:39:09 +0000",
    "user" : {
      "name" : "Cute Overload",
      "screen_name" : "CuteOverload",
      "protected" : false,
      "id_str" : "8659362",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/680609450495873025\/0RV8NzVo_normal.png",
      "id" : 8659362,
      "verified" : false
    }
  },
  "id" : 155027408393740288,
  "created_at" : "2012-01-05 20:46:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rafflecopter",
      "screen_name" : "rafflecopter",
      "indices" : [ 3, 16 ],
      "id_str" : "264897818",
      "id" : 264897818
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "155023108779147264",
  "text" : "RT @rafflecopter: Are you a blogger? Love Rafflecopter and want to help us spread the word? Sign up & get the inside scoop *final call*  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 120, 140 ],
        "url" : "http:\/\/t.co\/ec73Y7mC",
        "expanded_url" : "http:\/\/bit.ly\/s81W09",
        "display_url" : "bit.ly\/s81W09"
      } ]
    },
    "geo" : { },
    "id_str" : "155022480640188416",
    "text" : "Are you a blogger? Love Rafflecopter and want to help us spread the word? Sign up & get the inside scoop *final call* : http:\/\/t.co\/ec73Y7mC",
    "id" : 155022480640188416,
    "created_at" : "2012-01-05 20:26:54 +0000",
    "user" : {
      "name" : "Rafflecopter",
      "screen_name" : "rafflecopter",
      "protected" : false,
      "id_str" : "264897818",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454126572635574272\/LI9WeXKT_normal.png",
      "id" : 264897818,
      "verified" : false
    }
  },
  "id" : 155023108779147264,
  "created_at" : "2012-01-05 20:29:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 0, 14 ],
      "id_str" : "113395189",
      "id" : 113395189
    }, {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 44, 57 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "Ian Kingsley",
      "screen_name" : "authorkingsley",
      "indices" : [ 92, 107 ],
      "id_str" : "233966512",
      "id" : 233966512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154995767868801024",
  "geo" : { },
  "id_str" : "155002443950858240",
  "in_reply_to_user_id" : 113395189,
  "text" : "@ThisBlueWorld love Deepak. btw: your hubby @neardeathdoc was mentioned in abridged book by @authorkingsley that I read last night!",
  "id" : 155002443950858240,
  "in_reply_to_status_id" : 154995767868801024,
  "created_at" : "2012-01-05 19:07:17 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154996387220697088",
  "geo" : { },
  "id_str" : "155001552619315202",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl lol.. was looking at christian website.. didnt realize it was a parody!",
  "id" : 155001552619315202,
  "in_reply_to_status_id" : 154996387220697088,
  "created_at" : "2012-01-05 19:03:44 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "echofon",
      "screen_name" : "echofon",
      "indices" : [ 3, 11 ],
      "id_str" : "58166411",
      "id" : 58166411
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 62, 82 ],
      "url" : "http:\/\/t.co\/AnW7v2or",
      "expanded_url" : "http:\/\/cot.ag\/AwXj6P",
      "display_url" : "cot.ag\/AwXj6P"
    } ]
  },
  "geo" : { },
  "id_str" : "155001151824203776",
  "text" : "RT @echofon: Looks like Twitter is aware of the avatar issue: http:\/\/t.co\/AnW7v2or -Thanks for your patience as they sort it out.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 49, 69 ],
        "url" : "http:\/\/t.co\/AnW7v2or",
        "expanded_url" : "http:\/\/cot.ag\/AwXj6P",
        "display_url" : "cot.ag\/AwXj6P"
      } ]
    },
    "geo" : { },
    "id_str" : "154997379781767168",
    "text" : "Looks like Twitter is aware of the avatar issue: http:\/\/t.co\/AnW7v2or -Thanks for your patience as they sort it out.",
    "id" : 154997379781767168,
    "created_at" : "2012-01-05 18:47:09 +0000",
    "user" : {
      "name" : "echofon",
      "screen_name" : "echofon",
      "protected" : false,
      "id_str" : "58166411",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1308702722\/echofon_avatar_4_normal.png",
      "id" : 58166411,
      "verified" : false
    }
  },
  "id" : 155001151824203776,
  "created_at" : "2012-01-05 19:02:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 53, 73 ],
      "url" : "http:\/\/t.co\/7D1pbERC",
      "expanded_url" : "http:\/\/skygrid.me\/ypClSg",
      "display_url" : "skygrid.me\/ypClSg"
    } ]
  },
  "geo" : { },
  "id_str" : "154983231341596673",
  "text" : "RT @gemswinc: Scientists Invent Time Cloaking Device\nhttp:\/\/t.co\/7D1pbERC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/SkyGrid.com\/\" rel=\"nofollow\"\u003ESkyGrid\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 39, 59 ],
        "url" : "http:\/\/t.co\/7D1pbERC",
        "expanded_url" : "http:\/\/skygrid.me\/ypClSg",
        "display_url" : "skygrid.me\/ypClSg"
      } ]
    },
    "geo" : { },
    "id_str" : "154982694990786561",
    "text" : "Scientists Invent Time Cloaking Device\nhttp:\/\/t.co\/7D1pbERC",
    "id" : 154982694990786561,
    "created_at" : "2012-01-05 17:48:48 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 154983231341596673,
  "created_at" : "2012-01-05 17:50:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 117, 137 ],
      "url" : "http:\/\/t.co\/ugC8qQyd",
      "expanded_url" : "http:\/\/twitpic.com\/83jl64",
      "display_url" : "twitpic.com\/83jl64"
    } ]
  },
  "geo" : { },
  "id_str" : "154976787749814272",
  "text" : "RT @SangyeH: TENZIN is an adorable Aussie mix who's timid w\/ some people but great with calm women! tarasbabies.org  http:\/\/t.co\/ugC8qQyd",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 104, 124 ],
        "url" : "http:\/\/t.co\/ugC8qQyd",
        "expanded_url" : "http:\/\/twitpic.com\/83jl64",
        "display_url" : "twitpic.com\/83jl64"
      } ]
    },
    "geo" : { },
    "id_str" : "154975043787571200",
    "text" : "TENZIN is an adorable Aussie mix who's timid w\/ some people but great with calm women! tarasbabies.org  http:\/\/t.co\/ugC8qQyd",
    "id" : 154975043787571200,
    "created_at" : "2012-01-05 17:18:24 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 154976787749814272,
  "created_at" : "2012-01-05 17:25:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154968884087242752",
  "text" : "RT @GraveStomper: Just for today, try to meet each person without judgments based on your past experience.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154966425793081346",
    "text" : "Just for today, try to meet each person without judgments based on your past experience.",
    "id" : 154966425793081346,
    "created_at" : "2012-01-05 16:44:09 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 154968884087242752,
  "created_at" : "2012-01-05 16:53:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 0, 11 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154967395658772480",
  "geo" : { },
  "id_str" : "154968492687372288",
  "in_reply_to_user_id" : 15467920,
  "text" : "@taraburner omg'ness.. poor thing.. big big ((hugs))",
  "id" : 154968492687372288,
  "in_reply_to_status_id" : 154967395658772480,
  "created_at" : "2012-01-05 16:52:22 +0000",
  "in_reply_to_screen_name" : "taraburner",
  "in_reply_to_user_id_str" : "15467920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 2, 14 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154967018716667904",
  "text" : ". @JAScribbles I love your random blog posts..LOL",
  "id" : 154967018716667904,
  "created_at" : "2012-01-05 16:46:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "noh8",
      "indices" : [ 115, 120 ]
    } ],
    "urls" : [ {
      "indices" : [ 15, 35 ],
      "url" : "http:\/\/t.co\/rDM4vb5G",
      "expanded_url" : "http:\/\/wp.me\/p26qtE-6e",
      "display_url" : "wp.me\/p26qtE-6e"
    } ]
  },
  "geo" : { },
  "id_str" : "154965525104033792",
  "text" : "RT @Selaniest: http:\/\/t.co\/rDM4vb5G A short post to my friends and followers regarding my church, faith, and love. #noh8 #outlawpreacher ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "noh8",
        "indices" : [ 100, 105 ]
      }, {
        "text" : "outlawpreachers",
        "indices" : [ 106, 122 ]
      }, {
        "text" : "salvationarmy",
        "indices" : [ 123, 137 ]
      } ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/rDM4vb5G",
        "expanded_url" : "http:\/\/wp.me\/p26qtE-6e",
        "display_url" : "wp.me\/p26qtE-6e"
      } ]
    },
    "geo" : { },
    "id_str" : "154964372119240704",
    "text" : "http:\/\/t.co\/rDM4vb5G A short post to my friends and followers regarding my church, faith, and love. #noh8 #outlawpreachers #salvationarmy",
    "id" : 154964372119240704,
    "created_at" : "2012-01-05 16:36:00 +0000",
    "user" : {
      "name" : "The Great Unwashed",
      "screen_name" : "UnwashedThe",
      "protected" : false,
      "id_str" : "233971651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672923186632216576\/tRMQmyrX_normal.jpg",
      "id" : 233971651,
      "verified" : false
    }
  },
  "id" : 154965525104033792,
  "created_at" : "2012-01-05 16:40:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154965128515825664",
  "text" : "must.not.get.too.excited.. hear \"spring\" bird..",
  "id" : 154965128515825664,
  "created_at" : "2012-01-05 16:39:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154963981306560515",
  "geo" : { },
  "id_str" : "154964749161988096",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time lol.. I suppose I did. it was too funny!",
  "id" : 154964749161988096,
  "in_reply_to_status_id" : 154963981306560515,
  "created_at" : "2012-01-05 16:37:29 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154963816025829376",
  "text" : "jeepers.. i've been had.. lol",
  "id" : 154963816025829376,
  "created_at" : "2012-01-05 16:33:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Marianne Williamson",
      "screen_name" : "marwilliamson",
      "indices" : [ 17, 31 ],
      "id_str" : "21522338",
      "id" : 21522338
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154960804481990656",
  "text" : "RT @JohnCali: RT @marwilliamson: Whoever doesn't love you doesn't know you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Marianne Williamson",
        "screen_name" : "marwilliamson",
        "indices" : [ 3, 17 ],
        "id_str" : "21522338",
        "id" : 21522338
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154960269926334464",
    "text" : "RT @marwilliamson: Whoever doesn't love you doesn't know you.",
    "id" : 154960269926334464,
    "created_at" : "2012-01-05 16:19:42 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 154960804481990656,
  "created_at" : "2012-01-05 16:21:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "indices" : [ 3, 14 ],
      "id_str" : "94608663",
      "id" : 94608663
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 113, 133 ],
      "url" : "http:\/\/t.co\/h2koNd2Y",
      "expanded_url" : "http:\/\/bit.ly\/aLw5mJ",
      "display_url" : "bit.ly\/aLw5mJ"
    } ]
  },
  "geo" : { },
  "id_str" : "154960604799582208",
  "text" : "RT @MEDGESTORE: Yes, the e-Luminator is great for late night reading on e-ink screens. Use this code for 20% off http:\/\/t.co\/h2koNd2Y",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/h2koNd2Y",
        "expanded_url" : "http:\/\/bit.ly\/aLw5mJ",
        "display_url" : "bit.ly\/aLw5mJ"
      } ]
    },
    "geo" : { },
    "id_str" : "154960035250839554",
    "text" : "Yes, the e-Luminator is great for late night reading on e-ink screens. Use this code for 20% off http:\/\/t.co\/h2koNd2Y",
    "id" : 154960035250839554,
    "created_at" : "2012-01-05 16:18:46 +0000",
    "user" : {
      "name" : "M-Edge",
      "screen_name" : "MEDGESTORE",
      "protected" : false,
      "id_str" : "94608663",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/684834758027681792\/AxmlNGOl_normal.jpg",
      "id" : 94608663,
      "verified" : false
    }
  },
  "id" : 154960604799582208,
  "created_at" : "2012-01-05 16:21:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Pescalune",
      "screen_name" : "Pescalune",
      "indices" : [ 27, 37 ],
      "id_str" : "60838336",
      "id" : 60838336
    }, {
      "name" : "Allen Boynton",
      "screen_name" : "afocusonnature",
      "indices" : [ 46, 61 ],
      "id_str" : "156454750",
      "id" : 156454750
    }, {
      "name" : "Rachid H",
      "screen_name" : "rachidH",
      "indices" : [ 75, 83 ],
      "id_str" : "18059728",
      "id" : 18059728
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mammals",
      "indices" : [ 126, 134 ]
    } ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/y3xvIwiD",
      "expanded_url" : "http:\/\/twitpic.com\/83frqw",
      "display_url" : "twitpic.com\/83frqw"
    } ]
  },
  "geo" : { },
  "id_str" : "154959246587469826",
  "text" : "RT @KerriFar: Adorable! RT @Pescalune: :)) RT @afocusonnature: LOL &gt; RT @rachidH: Im growing a beard http:\/\/t.co\/y3xvIwiD  #mammals # ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pescalune",
        "screen_name" : "Pescalune",
        "indices" : [ 13, 23 ],
        "id_str" : "60838336",
        "id" : 60838336
      }, {
        "name" : "Allen Boynton",
        "screen_name" : "afocusonnature",
        "indices" : [ 32, 47 ],
        "id_str" : "156454750",
        "id" : 156454750
      }, {
        "name" : "Rachid H",
        "screen_name" : "rachidH",
        "indices" : [ 61, 69 ],
        "id_str" : "18059728",
        "id" : 18059728
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mammals",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "squirrels",
        "indices" : [ 121, 131 ]
      } ],
      "urls" : [ {
        "indices" : [ 90, 110 ],
        "url" : "http:\/\/t.co\/y3xvIwiD",
        "expanded_url" : "http:\/\/twitpic.com\/83frqw",
        "display_url" : "twitpic.com\/83frqw"
      } ]
    },
    "geo" : { },
    "id_str" : "154958338289971200",
    "text" : "Adorable! RT @Pescalune: :)) RT @afocusonnature: LOL &gt; RT @rachidH: Im growing a beard http:\/\/t.co\/y3xvIwiD  #mammals #squirrels",
    "id" : 154958338289971200,
    "created_at" : "2012-01-05 16:12:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 154959246587469826,
  "created_at" : "2012-01-05 16:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Taylor",
      "screen_name" : "Taylorpiano1811",
      "indices" : [ 0, 16 ],
      "id_str" : "425196663",
      "id" : 425196663
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 17, 31 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154954743398146048",
  "geo" : { },
  "id_str" : "154958653282205696",
  "in_reply_to_user_id" : 425196663,
  "text" : "@Taylorpiano1811 @BibleAlsoSays umm.. did u see the underwear thread? o-O is this stuff for real?",
  "id" : 154958653282205696,
  "in_reply_to_status_id" : 154954743398146048,
  "created_at" : "2012-01-05 16:13:16 +0000",
  "in_reply_to_screen_name" : "Taylorpiano1811",
  "in_reply_to_user_id_str" : "425196663",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 3, 17 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154948073284567040",
  "text" : "RT @ThisBlueWorld: My cats are playing hunt & chase with each other. It's like hide & seek only funnier.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tweetli.st\/\" rel=\"nofollow\"\u003ETweetList!\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154947720795267072",
    "text" : "My cats are playing hunt & chase with each other. It's like hide & seek only funnier.",
    "id" : 154947720795267072,
    "created_at" : "2012-01-05 15:29:50 +0000",
    "user" : {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "protected" : false,
      "id_str" : "113395189",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2547962249\/image_normal.jpg",
      "id" : 113395189,
      "verified" : false
    }
  },
  "id" : 154948073284567040,
  "created_at" : "2012-01-05 15:31:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sew Witchy",
      "screen_name" : "SisterSorcha",
      "indices" : [ 0, 13 ],
      "id_str" : "36200541",
      "id" : 36200541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154946275740090369",
  "geo" : { },
  "id_str" : "154947540880596992",
  "in_reply_to_user_id" : 36200541,
  "text" : "@SisterSorcha a very wonderful birthday to you, sister sorcha!",
  "id" : 154947540880596992,
  "in_reply_to_status_id" : 154946275740090369,
  "created_at" : "2012-01-05 15:29:07 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 0, 12 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154937061374312448",
  "geo" : { },
  "id_str" : "154941749540823041",
  "in_reply_to_user_id" : 143654638,
  "text" : "@JAScribbles no.. didnt even try. but title did make me LOL",
  "id" : 154941749540823041,
  "in_reply_to_status_id" : 154937061374312448,
  "created_at" : "2012-01-05 15:06:06 +0000",
  "in_reply_to_screen_name" : "JAScribbles",
  "in_reply_to_user_id_str" : "143654638",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "indices" : [ 3, 19 ],
      "id_str" : "362487813",
      "id" : 362487813
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154941204889481217",
  "text" : "RT @MysteriousPress: Val McDermid giveaway! We're giving away a copy of Val's phenomenal new novel THE RETRIBUTION today. Reply RT or us ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "retribution",
        "indices" : [ 117, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154937982900637698",
    "text" : "Val McDermid giveaway! We're giving away a copy of Val's phenomenal new novel THE RETRIBUTION today. Reply RT or use #retribution to enter!",
    "id" : 154937982900637698,
    "created_at" : "2012-01-05 14:51:08 +0000",
    "user" : {
      "name" : "MysteriousPress",
      "screen_name" : "MysteriousPress",
      "protected" : false,
      "id_str" : "362487813",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1514323844\/mysterious_normal.jpg",
      "id" : 362487813,
      "verified" : false
    }
  },
  "id" : 154941204889481217,
  "created_at" : "2012-01-05 15:03:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    }, {
      "name" : "Kirk Norbury",
      "screen_name" : "KirkNorbury",
      "indices" : [ 13, 25 ],
      "id_str" : "23232545",
      "id" : 23232545
    }, {
      "name" : "Will Burrard-Lucas",
      "screen_name" : "willbl",
      "indices" : [ 48, 55 ],
      "id_str" : "14384317",
      "id" : 14384317
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 125 ],
      "url" : "http:\/\/t.co\/XTClngjX",
      "expanded_url" : "http:\/\/flic.kr\/p\/b7RRE6",
      "display_url" : "flic.kr\/p\/b7RRE6"
    } ]
  },
  "geo" : { },
  "id_str" : "154934878989852674",
  "text" : "RT @screek: \u201C@KirkNorbury: Beautiful shot :) RT @willbl: New image from Ethiopia... Four Tiny Wolf Pups! http:\/\/t.co\/XTClngjX\u201D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kirk Norbury",
        "screen_name" : "KirkNorbury",
        "indices" : [ 1, 13 ],
        "id_str" : "23232545",
        "id" : 23232545
      }, {
        "name" : "Will Burrard-Lucas",
        "screen_name" : "willbl",
        "indices" : [ 36, 43 ],
        "id_str" : "14384317",
        "id" : 14384317
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 93, 113 ],
        "url" : "http:\/\/t.co\/XTClngjX",
        "expanded_url" : "http:\/\/flic.kr\/p\/b7RRE6",
        "display_url" : "flic.kr\/p\/b7RRE6"
      } ]
    },
    "geo" : { },
    "id_str" : "154934298280075264",
    "text" : "\u201C@KirkNorbury: Beautiful shot :) RT @willbl: New image from Ethiopia... Four Tiny Wolf Pups! http:\/\/t.co\/XTClngjX\u201D",
    "id" : 154934298280075264,
    "created_at" : "2012-01-05 14:36:29 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 154934878989852674,
  "created_at" : "2012-01-05 14:38:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 75, 95 ],
      "url" : "http:\/\/t.co\/TUJNFjT7",
      "expanded_url" : "http:\/\/thebooksnoop.blogspot.com\/2012\/01\/guess-title-of-this-book.html?spref=tw",
      "display_url" : "thebooksnoop.blogspot.com\/2012\/01\/guess-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154927038258622465",
  "text" : "RT @JAScribbles: Bah!! Guess the Title of This Book. You will never guess. http:\/\/t.co\/TUJNFjT7",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 58, 78 ],
        "url" : "http:\/\/t.co\/TUJNFjT7",
        "expanded_url" : "http:\/\/thebooksnoop.blogspot.com\/2012\/01\/guess-title-of-this-book.html?spref=tw",
        "display_url" : "thebooksnoop.blogspot.com\/2012\/01\/guess-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154921239104851968",
    "text" : "Bah!! Guess the Title of This Book. You will never guess. http:\/\/t.co\/TUJNFjT7",
    "id" : 154921239104851968,
    "created_at" : "2012-01-05 13:44:36 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 154927038258622465,
  "created_at" : "2012-01-05 14:07:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 47, 67 ],
      "url" : "http:\/\/t.co\/LI6n9oHL",
      "expanded_url" : "http:\/\/bit.ly\/wyfPeY",
      "display_url" : "bit.ly\/wyfPeY"
    } ]
  },
  "geo" : { },
  "id_str" : "154923946368700416",
  "text" : "RT @screek: I\u2019m Not Seeing Many Snow Geese Now http:\/\/t.co\/LI6n9oHL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 35, 55 ],
        "url" : "http:\/\/t.co\/LI6n9oHL",
        "expanded_url" : "http:\/\/bit.ly\/wyfPeY",
        "display_url" : "bit.ly\/wyfPeY"
      } ]
    },
    "geo" : { },
    "id_str" : "154913799718187008",
    "text" : "I\u2019m Not Seeing Many Snow Geese Now http:\/\/t.co\/LI6n9oHL",
    "id" : 154913799718187008,
    "created_at" : "2012-01-05 13:15:02 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 154923946368700416,
  "created_at" : "2012-01-05 13:55:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154914616802148352",
  "geo" : { },
  "id_str" : "154923493933322240",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem I still see it...",
  "id" : 154923493933322240,
  "in_reply_to_status_id" : 154914616802148352,
  "created_at" : "2012-01-05 13:53:33 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 46, 66 ],
      "url" : "http:\/\/t.co\/OUsUfJid",
      "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2012\/01\/yes-pit-bulls-suddenly-snap\/",
      "display_url" : "lifewithdogs.tv\/2012\/01\/yes-pi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154923277192667137",
  "text" : "RT @Nigelbugger: Yes, Pit Bulls Suddenly Snap http:\/\/t.co\/OUsUfJid",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 29, 49 ],
        "url" : "http:\/\/t.co\/OUsUfJid",
        "expanded_url" : "http:\/\/www.lifewithdogs.tv\/2012\/01\/yes-pit-bulls-suddenly-snap\/",
        "display_url" : "lifewithdogs.tv\/2012\/01\/yes-pi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154915596822253569",
    "text" : "Yes, Pit Bulls Suddenly Snap http:\/\/t.co\/OUsUfJid",
    "id" : 154915596822253569,
    "created_at" : "2012-01-05 13:22:11 +0000",
    "user" : {
      "name" : "Life With Dogs",
      "screen_name" : "LifeWithDogsTV",
      "protected" : false,
      "id_str" : "18418936",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/788959945546993664\/nOy2XTo5_normal.jpg",
      "id" : 18418936,
      "verified" : false
    }
  },
  "id" : 154923277192667137,
  "created_at" : "2012-01-05 13:52:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "indices" : [ 3, 15 ],
      "id_str" : "75544059",
      "id" : 75544059
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154735936222150656",
  "text" : "RT @TheGodLight: Live & let live, give others the same rights you seek for yourself, give life & free yourself of judgements.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154731057239965697",
    "text" : "Live & let live, give others the same rights you seek for yourself, give life & free yourself of judgements.",
    "id" : 154731057239965697,
    "created_at" : "2012-01-05 01:08:53 +0000",
    "user" : {
      "name" : "Spiritual Truths",
      "screen_name" : "TheGodLight",
      "protected" : false,
      "id_str" : "75544059",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/652997140940222464\/XEmR_61__normal.png",
      "id" : 75544059,
      "verified" : false
    }
  },
  "id" : 154735936222150656,
  "created_at" : "2012-01-05 01:28:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 76, 96 ],
      "url" : "http:\/\/t.co\/JOzecBpG",
      "expanded_url" : "http:\/\/latimesblogs.latimes.com\/culturemonster\/2011\/12\/sarah-palin-fox-news-attack-white-house-holiday-card-design.html",
      "display_url" : "latimesblogs.latimes.com\/culturemonster\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154677781605793793",
  "text" : "Really??? &gt;&gt; Sarah Palin criticizes Obama holiday card -- and the dog http:\/\/t.co\/JOzecBpG",
  "id" : 154677781605793793,
  "created_at" : "2012-01-04 21:37:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DAR",
      "screen_name" : "Silvercrone",
      "indices" : [ 87, 99 ],
      "id_str" : "20929609",
      "id" : 20929609
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 66, 86 ],
      "url" : "http:\/\/t.co\/dAZe4dGt",
      "expanded_url" : "http:\/\/silvercroneponders.blogspot.com\/2012\/01\/something-with-soul.html?spref=tw",
      "display_url" : "silvercroneponders.blogspot.com\/2012\/01\/someth\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154676489697243137",
  "text" : "Love #7..lol &gt;&gt; Silvercrone Ponders: Something with soul... http:\/\/t.co\/dAZe4dGt @silvercrone",
  "id" : 154676489697243137,
  "created_at" : "2012-01-04 21:32:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 35, 50 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 102 ],
      "url" : "http:\/\/t.co\/hw6TlZHY",
      "expanded_url" : "http:\/\/twitpic.com\/836zfq",
      "display_url" : "twitpic.com\/836zfq"
    } ]
  },
  "geo" : { },
  "id_str" : "154674292104237058",
  "text" : "kitty smooches dear henry! xoxo RT @mssuzcatsilver: Who r u looking at ? Purrrzz  http:\/\/t.co\/hw6TlZHY",
  "id" : 154674292104237058,
  "created_at" : "2012-01-04 21:23:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "indices" : [ 3, 12 ],
      "id_str" : "14986977",
      "id" : 14986977
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154671443991465984",
  "text" : "RT @Teawench: Holy Twitplosion, guys! Geez, go fax a few things and you run amok.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154671243205951488",
    "text" : "Holy Twitplosion, guys! Geez, go fax a few things and you run amok.",
    "id" : 154671243205951488,
    "created_at" : "2012-01-04 21:11:12 +0000",
    "user" : {
      "name" : "Pumpkin Queen",
      "screen_name" : "Teawench",
      "protected" : false,
      "id_str" : "14986977",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2242418648\/lanoire_blond_256x256_normal.jpg",
      "id" : 14986977,
      "verified" : false
    }
  },
  "id" : 154671443991465984,
  "created_at" : "2012-01-04 21:12:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154670172668571649",
  "text" : "my stomach is still off a bit. not sure if virus or my liver\/bile issue. bleh.",
  "id" : 154670172668571649,
  "created_at" : "2012-01-04 21:06:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154668525464719360",
  "geo" : { },
  "id_str" : "154669642969923584",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl I found some sites online.. was investigating.",
  "id" : 154669642969923584,
  "in_reply_to_status_id" : 154668525464719360,
  "created_at" : "2012-01-04 21:04:51 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154668525464719360",
  "geo" : { },
  "id_str" : "154669398844653568",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl lol.. no.. you understood. Im just running low on pills and worried I'll run out before I get program app in.",
  "id" : 154669398844653568,
  "in_reply_to_status_id" : 154668525464719360,
  "created_at" : "2012-01-04 21:03:52 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154662915356626944",
  "text" : "RT @wow_trees: I sometimes find myself observing the behaviors of others...and man, humans are weird!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154660898697527296",
    "text" : "I sometimes find myself observing the behaviors of others...and man, humans are weird!",
    "id" : 154660898697527296,
    "created_at" : "2012-01-04 20:30:06 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 154662915356626944,
  "created_at" : "2012-01-04 20:38:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154659867951501312",
  "text" : "RT @GeneDoucette: between tumblr, facebook and twitter, I now have to stop and think about where I want to be clever every time I want t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154659655103152128",
    "text" : "between tumblr, facebook and twitter, I now have to stop and think about where I want to be clever every time I want to be clever.",
    "id" : 154659655103152128,
    "created_at" : "2012-01-04 20:25:09 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 154659867951501312,
  "created_at" : "2012-01-04 20:26:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154645133919399937",
  "geo" : { },
  "id_str" : "154650082904510464",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl pfizer took over wyeth program. have to enroll again.. was trying to get refill but they denied.",
  "id" : 154650082904510464,
  "in_reply_to_status_id" : 154645133919399937,
  "created_at" : "2012-01-04 19:47:07 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154645849991938049",
  "geo" : { },
  "id_str" : "154648563459174400",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem love your avi..lol. you are adorable! : )",
  "id" : 154648563459174400,
  "in_reply_to_status_id" : 154645849991938049,
  "created_at" : "2012-01-04 19:41:05 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "indices" : [ 3, 15 ],
      "id_str" : "26762692",
      "id" : 26762692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154635989984350208",
  "text" : "RT @DuttonBooks: Non-joke library news of the day: \"Police enforcement of library lending leaves 5 year-old in tears\" http:\/\/t.co\/Ro4j0s ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CNN",
        "screen_name" : "CNN",
        "indices" : [ 126, 130 ],
        "id_str" : "759251",
        "id" : 759251
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 101, 121 ],
        "url" : "http:\/\/t.co\/Ro4j0s4Q",
        "expanded_url" : "http:\/\/ow.ly\/8hV3i",
        "display_url" : "ow.ly\/8hV3i"
      } ]
    },
    "geo" : { },
    "id_str" : "154631943240155136",
    "text" : "Non-joke library news of the day: \"Police enforcement of library lending leaves 5 year-old in tears\" http:\/\/t.co\/Ro4j0s4Q via @CNN",
    "id" : 154631943240155136,
    "created_at" : "2012-01-04 18:35:02 +0000",
    "user" : {
      "name" : "Dutton Books",
      "screen_name" : "DuttonBooks",
      "protected" : false,
      "id_str" : "26762692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/771707421492449280\/68ucSdhT_normal.jpg",
      "id" : 26762692,
      "verified" : true
    }
  },
  "id" : 154635989984350208,
  "created_at" : "2012-01-04 18:51:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 0, 10 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154612877670625281",
  "geo" : { },
  "id_str" : "154613990343979009",
  "in_reply_to_user_id" : 48215218,
  "text" : "@bend_time Thanks!",
  "id" : 154613990343979009,
  "in_reply_to_status_id" : 154612877670625281,
  "created_at" : "2012-01-04 17:23:42 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "indices" : [ 0, 11 ],
      "id_str" : "76225852",
      "id" : 76225852
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154612210893717505",
  "geo" : { },
  "id_str" : "154612914479824897",
  "in_reply_to_user_id" : 76225852,
  "text" : "@TraLeeFitz ((hugs)) wonderful, wonderful!",
  "id" : 154612914479824897,
  "in_reply_to_status_id" : 154612210893717505,
  "created_at" : "2012-01-04 17:19:26 +0000",
  "in_reply_to_screen_name" : "TraLeeFitz",
  "in_reply_to_user_id_str" : "76225852",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154611510071668737",
  "text" : "anyone familiar w buying prescription drugs online?",
  "id" : 154611510071668737,
  "created_at" : "2012-01-04 17:13:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154609741224611841",
  "text" : "the end of the world doesnt scare me but the thought of running out of my effexor gives me nightmares (withdrawal)",
  "id" : 154609741224611841,
  "created_at" : "2012-01-04 17:06:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam P. Knave",
      "screen_name" : "adampknave",
      "indices" : [ 0, 11 ],
      "id_str" : "2772041",
      "id" : 2772041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154608182759653377",
  "geo" : { },
  "id_str" : "154609148544286720",
  "in_reply_to_user_id" : 2772041,
  "text" : "@adampknave of the two, adam.pk is much easier to remember",
  "id" : 154609148544286720,
  "in_reply_to_status_id" : 154608182759653377,
  "created_at" : "2012-01-04 17:04:28 +0000",
  "in_reply_to_screen_name" : "adampknave",
  "in_reply_to_user_id_str" : "2772041",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154595861844856832",
  "text" : "RT @NelsonFiction: Any YA enthusiasts out there? Alienation is here! For book bloggers request your free copy on www.netgalley.com . htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 114, 134 ],
        "url" : "http:\/\/t.co\/kwPauVL5",
        "expanded_url" : "http:\/\/yfrog.com\/nte0mnij",
        "display_url" : "yfrog.com\/nte0mnij"
      } ]
    },
    "geo" : { },
    "id_str" : "154594185733873664",
    "text" : "Any YA enthusiasts out there? Alienation is here! For book bloggers request your free copy on www.netgalley.com . http:\/\/t.co\/kwPauVL5",
    "id" : 154594185733873664,
    "created_at" : "2012-01-04 16:05:00 +0000",
    "user" : {
      "name" : "TNZFiction",
      "screen_name" : "TNZFiction",
      "protected" : false,
      "id_str" : "113483630",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3476074316\/bb1f0680a3472e1f316fb930048ce35d_normal.jpeg",
      "id" : 113483630,
      "verified" : false
    }
  },
  "id" : 154595861844856832,
  "created_at" : "2012-01-04 16:11:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "indices" : [ 3, 17 ],
      "id_str" : "45254966",
      "id" : 45254966
    }, {
      "name" : "Manny Jalonschi",
      "screen_name" : "MJalonschi",
      "indices" : [ 78, 89 ],
      "id_str" : "450025350",
      "id" : 450025350
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ows",
      "indices" : [ 90, 94 ]
    }, {
      "text" : "poem",
      "indices" : [ 95, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154590782572072960",
  "text" : "RT @CharlesBivona: American politics is like watching Three's Company reruns. @MJalonschi #ows #poem",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Manny Jalonschi",
        "screen_name" : "MJalonschi",
        "indices" : [ 59, 70 ],
        "id_str" : "450025350",
        "id" : 450025350
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ows",
        "indices" : [ 71, 75 ]
      }, {
        "text" : "poem",
        "indices" : [ 76, 81 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154589541691437056",
    "text" : "American politics is like watching Three's Company reruns. @MJalonschi #ows #poem",
    "id" : 154589541691437056,
    "created_at" : "2012-01-04 15:46:33 +0000",
    "user" : {
      "name" : "Charles Bivona",
      "screen_name" : "CharlesBivona",
      "protected" : false,
      "id_str" : "45254966",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799096271818604544\/y1NfeSZm_normal.jpg",
      "id" : 45254966,
      "verified" : false
    }
  },
  "id" : 154590782572072960,
  "created_at" : "2012-01-04 15:51:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "indices" : [ 3, 15 ],
      "id_str" : "14702533",
      "id" : 14702533
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 95, 115 ],
      "url" : "http:\/\/t.co\/raCMSgfb",
      "expanded_url" : "http:\/\/bit.ly\/wLk7Aa",
      "display_url" : "bit.ly\/wLk7Aa"
    } ]
  },
  "geo" : { },
  "id_str" : "154587117052366849",
  "text" : "RT @dailygalaxy: An Area 1\/400th of Milky Way is Changing Mankind's View of Life in the Cosmos\nhttp:\/\/t.co\/raCMSgfb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 78, 98 ],
        "url" : "http:\/\/t.co\/raCMSgfb",
        "expanded_url" : "http:\/\/bit.ly\/wLk7Aa",
        "display_url" : "bit.ly\/wLk7Aa"
      } ]
    },
    "geo" : { },
    "id_str" : "154585552493092864",
    "text" : "An Area 1\/400th of Milky Way is Changing Mankind's View of Life in the Cosmos\nhttp:\/\/t.co\/raCMSgfb",
    "id" : 154585552493092864,
    "created_at" : "2012-01-04 15:30:42 +0000",
    "user" : {
      "name" : "The Daily Galaxy",
      "screen_name" : "dailygalaxy",
      "protected" : false,
      "id_str" : "14702533",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707625542976057344\/kg6a9cYg_normal.jpg",
      "id" : 14702533,
      "verified" : false
    }
  },
  "id" : 154587117052366849,
  "created_at" : "2012-01-04 15:36:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 18, 30 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 92, 112 ],
      "url" : "http:\/\/t.co\/xYrVf4w3",
      "expanded_url" : "http:\/\/bit.ly\/pPSP6X",
      "display_url" : "bit.ly\/pPSP6X"
    } ]
  },
  "geo" : { },
  "id_str" : "154581863053262849",
  "text" : "READ! &gt;&gt; RT @angelaharms: What happened when this person spoke up, gently, to the TSA http:\/\/t.co\/xYrVf4w3",
  "id" : 154581863053262849,
  "created_at" : "2012-01-04 15:16:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "indices" : [ 3, 18 ],
      "id_str" : "32435460",
      "id" : 32435460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154378765638705152",
  "text" : "RT @SpiritualNurse: \"Every situation, properly perceived, becomes an opportunity to heal.\" ~ A Course in Miracles",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154378410834141184",
    "text" : "\"Every situation, properly perceived, becomes an opportunity to heal.\" ~ A Course in Miracles",
    "id" : 154378410834141184,
    "created_at" : "2012-01-04 01:47:36 +0000",
    "user" : {
      "name" : "SpiritualNurse Sandy",
      "screen_name" : "SpiritualNurse",
      "protected" : false,
      "id_str" : "32435460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797221776803577856\/4TV_dp65_normal.jpg",
      "id" : 32435460,
      "verified" : false
    }
  },
  "id" : 154378765638705152,
  "created_at" : "2012-01-04 01:49:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dhamma Girl",
      "screen_name" : "DhammaGirl",
      "indices" : [ 0, 11 ],
      "id_str" : "39331231",
      "id" : 39331231
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154366397445718018",
  "geo" : { },
  "id_str" : "154373737494482944",
  "in_reply_to_user_id" : 39331231,
  "text" : "@dhammagirl and I am grateful you have a super great friend to do that. blessings, dear one!",
  "id" : 154373737494482944,
  "in_reply_to_status_id" : 154366397445718018,
  "created_at" : "2012-01-04 01:29:01 +0000",
  "in_reply_to_screen_name" : "DhammaGirl",
  "in_reply_to_user_id_str" : "39331231",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Patrick Star",
      "screen_name" : "Patrick_Star",
      "indices" : [ 3, 16 ],
      "id_str" : "266020924",
      "id" : 266020924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154372571209535489",
  "text" : "RT @Patrick_Star: Sometimes my brain gets in the way when I\u2019m thinking.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/adobe.com\" rel=\"nofollow\"\u003EAdobe\u00AE Social\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154325330549673984",
    "text" : "Sometimes my brain gets in the way when I\u2019m thinking.",
    "id" : 154325330549673984,
    "created_at" : "2012-01-03 22:16:40 +0000",
    "user" : {
      "name" : "Patrick Star",
      "screen_name" : "Patrick_Star",
      "protected" : false,
      "id_str" : "266020924",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000303523651\/315e7425ef4a1cc0e247bf7d784afdbd_normal.jpeg",
      "id" : 266020924,
      "verified" : true
    }
  },
  "id" : 154372571209535489,
  "created_at" : "2012-01-04 01:24:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 0, 16 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154357885399347200",
  "geo" : { },
  "id_str" : "154358306431959040",
  "in_reply_to_user_id" : 111579405,
  "text" : "@thDigitalReader hmm.. well, I like it.",
  "id" : 154358306431959040,
  "in_reply_to_status_id" : 154357885399347200,
  "created_at" : "2012-01-04 00:27:42 +0000",
  "in_reply_to_screen_name" : "thDigitalReader",
  "in_reply_to_user_id_str" : "111579405",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154351469494140928",
  "text" : "@SamsaricWarrior thx 4 keeping us updated! ((hugs))",
  "id" : 154351469494140928,
  "created_at" : "2012-01-04 00:00:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 49, 69 ],
      "url" : "http:\/\/t.co\/FDMDZDUj",
      "expanded_url" : "http:\/\/pulse.me\/s\/4Doe5",
      "display_url" : "pulse.me\/s\/4Doe5"
    } ]
  },
  "geo" : { },
  "id_str" : "154345900330860544",
  "text" : "RT @screek: This Squirrel Likes to Paint [Video] http:\/\/t.co\/FDMDZDUj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/FDMDZDUj",
        "expanded_url" : "http:\/\/pulse.me\/s\/4Doe5",
        "display_url" : "pulse.me\/s\/4Doe5"
      } ]
    },
    "geo" : { },
    "id_str" : "154345297189933056",
    "text" : "This Squirrel Likes to Paint [Video] http:\/\/t.co\/FDMDZDUj",
    "id" : 154345297189933056,
    "created_at" : "2012-01-03 23:36:01 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 154345900330860544,
  "created_at" : "2012-01-03 23:38:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154345623695523840",
  "text" : "RT @bunnybuddhism: On a good day, I am a bunny. On a bad day, I am still a bunny.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial for BlackBerry\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154344060155469824",
    "text" : "On a good day, I am a bunny. On a bad day, I am still a bunny.",
    "id" : 154344060155469824,
    "created_at" : "2012-01-03 23:31:06 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 154345623695523840,
  "created_at" : "2012-01-03 23:37:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 3, 12 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "S.H. Photography",
      "screen_name" : "S_H_Photography",
      "indices" : [ 23, 39 ],
      "id_str" : "301075028",
      "id" : 301075028
    }, {
      "name" : "FrackingTestSubject",
      "screen_name" : "gardencatlady",
      "indices" : [ 45, 59 ],
      "id_str" : "221707278",
      "id" : 221707278
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154343483736473601",
  "text" : "RT @KerriFar: WOW! RT  @S_H_Photography   RT @gardencatlady: 500px \/ Photo \"Cypress Dome Barred Owl\" by Jennifer Nestler http:\/\/t.co\/tyn ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "S.H. Photography",
        "screen_name" : "S_H_Photography",
        "indices" : [ 9, 25 ],
        "id_str" : "301075028",
        "id" : 301075028
      }, {
        "name" : "FrackingTestSubject",
        "screen_name" : "gardencatlady",
        "indices" : [ 31, 45 ],
        "id_str" : "221707278",
        "id" : 221707278
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/tynyNsyg",
        "expanded_url" : "http:\/\/bit.ly\/ytvi1B",
        "display_url" : "bit.ly\/ytvi1B"
      } ]
    },
    "geo" : { },
    "id_str" : "154340265828679682",
    "text" : "WOW! RT  @S_H_Photography   RT @gardencatlady: 500px \/ Photo \"Cypress Dome Barred Owl\" by Jennifer Nestler http:\/\/t.co\/tynyNsyg",
    "id" : 154340265828679682,
    "created_at" : "2012-01-03 23:16:01 +0000",
    "user" : {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "protected" : false,
      "id_str" : "12088232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/269225527\/Pink_Flowers__069_06-13-09_normal.jpg",
      "id" : 12088232,
      "verified" : false
    }
  },
  "id" : 154343483736473601,
  "created_at" : "2012-01-03 23:28:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154343337346871298",
  "text" : "RT @RMoGib: I'm tired. This savin the world stuff requires quite the badassness.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154341430830186496",
    "text" : "I'm tired. This savin the world stuff requires quite the badassness.",
    "id" : 154341430830186496,
    "created_at" : "2012-01-03 23:20:39 +0000",
    "user" : {
      "name" : "That Blonde Girl.",
      "screen_name" : "OhYouGirl",
      "protected" : false,
      "id_str" : "23539037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/793979165737250816\/xBoQTxQT_normal.jpg",
      "id" : 23539037,
      "verified" : false
    }
  },
  "id" : 154343337346871298,
  "created_at" : "2012-01-03 23:28:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "indices" : [ 3, 19 ],
      "id_str" : "128763392",
      "id" : 128763392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154330268231155713",
  "text" : "RT @TheChristianLft: \"We Christians are good at a lot of things. Helping others. Dressing up on Sunday.  Quoting scripture. Pot luck...  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/B0VSRmvf",
        "expanded_url" : "http:\/\/fb.me\/KmWsguPm",
        "display_url" : "fb.me\/KmWsguPm"
      } ]
    },
    "geo" : { },
    "id_str" : "154328560545443841",
    "text" : "\"We Christians are good at a lot of things. Helping others. Dressing up on Sunday.  Quoting scripture. Pot luck... http:\/\/t.co\/B0VSRmvf",
    "id" : 154328560545443841,
    "created_at" : "2012-01-03 22:29:30 +0000",
    "user" : {
      "name" : "The Christian Left",
      "screen_name" : "TheChristianLft",
      "protected" : false,
      "id_str" : "128763392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2106579975\/TCL_Painting_normal.jpg",
      "id" : 128763392,
      "verified" : false
    }
  },
  "id" : 154330268231155713,
  "created_at" : "2012-01-03 22:36:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154327378875785216",
  "text" : "RT @UndertheNeonSky: When you judge another, you do not define them, you define yourself. Wayne Dyer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154326815991799808",
    "text" : "When you judge another, you do not define them, you define yourself. Wayne Dyer",
    "id" : 154326815991799808,
    "created_at" : "2012-01-03 22:22:34 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 154327378875785216,
  "created_at" : "2012-01-03 22:24:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "April Slaughter",
      "screen_name" : "April_Slaughter",
      "indices" : [ 3, 19 ],
      "id_str" : "26490825",
      "id" : 26490825
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154327185740673024",
  "text" : "RT @April_Slaughter: I don't grieve as others do when loved ones pass. I grieve the loss of physicality, but I know they live on. Not be ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154325686071476224",
    "text" : "I don't grieve as others do when loved ones pass. I grieve the loss of physicality, but I know they live on. Not believe... know.",
    "id" : 154325686071476224,
    "created_at" : "2012-01-03 22:18:05 +0000",
    "user" : {
      "name" : "April Slaughter",
      "screen_name" : "April_Slaughter",
      "protected" : false,
      "id_str" : "26490825",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/794212200009191425\/8tLSbz-S_normal.jpg",
      "id" : 26490825,
      "verified" : false
    }
  },
  "id" : 154327185740673024,
  "created_at" : "2012-01-03 22:24:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154319741199204352",
  "geo" : { },
  "id_str" : "154326633321480192",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope sigh.. so peaceful. love sunsets..",
  "id" : 154326633321480192,
  "in_reply_to_status_id" : 154319741199204352,
  "created_at" : "2012-01-03 22:21:51 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154285987265126400",
  "text" : "RT @TyrusBooks: Hey Authors & Web Designers! Does anybody have a favorite WordPress theme for an author website? Suggestions, team?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154285881757401088",
    "text" : "Hey Authors & Web Designers! Does anybody have a favorite WordPress theme for an author website? Suggestions, team?",
    "id" : 154285881757401088,
    "created_at" : "2012-01-03 19:39:55 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 154285987265126400,
  "created_at" : "2012-01-03 19:40:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "indices" : [ 3, 11 ],
      "id_str" : "59574144",
      "id" : 59574144
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "GOP",
      "indices" : [ 73, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154283115496484864",
  "text" : "RT @MWM4444: Jesus: Let the one who is without sin cast the first stone. #GOP candidates for POTUS: Hand over the rocks, you damn hippie ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "GOP",
        "indices" : [ 60, 64 ]
      }, {
        "text" : "p2",
        "indices" : [ 125, 128 ]
      }, {
        "text" : "tcot",
        "indices" : [ 129, 134 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154282652571156480",
    "text" : "Jesus: Let the one who is without sin cast the first stone. #GOP candidates for POTUS: Hand over the rocks, you damn hippie. #p2 #tcot",
    "id" : 154282652571156480,
    "created_at" : "2012-01-03 19:27:05 +0000",
    "user" : {
      "name" : "Mary W. Matthews",
      "screen_name" : "MWM4444",
      "protected" : false,
      "id_str" : "59574144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/734202902781300736\/JjH6rNH9_normal.jpg",
      "id" : 59574144,
      "verified" : false
    }
  },
  "id" : 154283115496484864,
  "created_at" : "2012-01-03 19:28:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154282618941218816",
  "text" : "RT @AntiWarProtests: The rich are cowards who call for wars on their media outlets, but they never fight in wars, they just sell billion ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154277125275385856",
    "text" : "The rich are cowards who call for wars on their media outlets, but they never fight in wars, they just sell billions of dollars of weapons.",
    "id" : 154277125275385856,
    "created_at" : "2012-01-03 19:05:07 +0000",
    "user" : {
      "name" : "Mahatma Gandhi",
      "screen_name" : "MahatmaGandhiii",
      "protected" : false,
      "id_str" : "278066224",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3741215394\/d699e9e43ae32cc0f47cb70ea3d57b2e_normal.jpeg",
      "id" : 278066224,
      "verified" : false
    }
  },
  "id" : 154282618941218816,
  "created_at" : "2012-01-03 19:26:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jesse Dymond",
      "screen_name" : "jesse_dymond",
      "indices" : [ 7, 20 ],
      "id_str" : "34152409",
      "id" : 34152409
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154279706512994305",
  "text" : "LOL RT @jesse_dymond: Introverts get their energy from being alone. Extroverts get theirs by sucking it out of the introverts.",
  "id" : 154279706512994305,
  "created_at" : "2012-01-03 19:15:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 0, 12 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154273974912679936",
  "geo" : { },
  "id_str" : "154275391434014720",
  "in_reply_to_user_id" : 24736943,
  "text" : "@mindymayhem glad to hear its improving! : )",
  "id" : 154275391434014720,
  "in_reply_to_status_id" : 154273974912679936,
  "created_at" : "2012-01-03 18:58:14 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "indices" : [ 3, 14 ],
      "id_str" : "283660852",
      "id" : 283660852
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/slothville\/status\/154268932491055105\/photo\/1",
      "indices" : [ 78, 98 ],
      "url" : "http:\/\/t.co\/Dr3V04gg",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/AiQSxtlCEAIP_zj.jpg",
      "id_str" : "154268932495249410",
      "id" : 154268932495249410,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiQSxtlCEAIP_zj.jpg",
      "sizes" : [ {
        "h" : 669,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 455,
        "resize" : "fit",
        "w" : 340
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 669,
        "resize" : "fit",
        "w" : 500
      } ],
      "display_url" : "pic.twitter.com\/Dr3V04gg"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154269576656457729",
  "text" : "RT @slothville: This is when a sloth obsession has gone too far. Way too far. http:\/\/t.co\/Dr3V04gg",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/slothville\/status\/154268932491055105\/photo\/1",
        "indices" : [ 62, 82 ],
        "url" : "http:\/\/t.co\/Dr3V04gg",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/AiQSxtlCEAIP_zj.jpg",
        "id_str" : "154268932495249410",
        "id" : 154268932495249410,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/AiQSxtlCEAIP_zj.jpg",
        "sizes" : [ {
          "h" : 669,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 455,
          "resize" : "fit",
          "w" : 340
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 500
        }, {
          "h" : 669,
          "resize" : "fit",
          "w" : 500
        } ],
        "display_url" : "pic.twitter.com\/Dr3V04gg"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154268932491055105",
    "text" : "This is when a sloth obsession has gone too far. Way too far. http:\/\/t.co\/Dr3V04gg",
    "id" : 154268932491055105,
    "created_at" : "2012-01-03 18:32:35 +0000",
    "user" : {
      "name" : "Slothville",
      "screen_name" : "slothville",
      "protected" : false,
      "id_str" : "283660852",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/529221111280463872\/E06rTIEQ_normal.jpeg",
      "id" : 283660852,
      "verified" : false
    }
  },
  "id" : 154269576656457729,
  "created_at" : "2012-01-03 18:35:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154269174045220864",
  "geo" : { },
  "id_str" : "154269427318263809",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope ((chuckles)) : )",
  "id" : 154269427318263809,
  "in_reply_to_status_id" : 154269174045220864,
  "created_at" : "2012-01-03 18:34:32 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154269207859695616",
  "text" : "good thing I don't drive anymore (well, minimally) .. so obsessed w license plates.",
  "id" : 154269207859695616,
  "created_at" : "2012-01-03 18:33:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen D. Yeo",
      "screen_name" : "SkypilotOfHope",
      "indices" : [ 0, 15 ],
      "id_str" : "140291463",
      "id" : 140291463
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154266537694478337",
  "geo" : { },
  "id_str" : "154266933607407617",
  "in_reply_to_user_id" : 140291463,
  "text" : "@skypilotofhope oh nice view! feel better soon!",
  "id" : 154266933607407617,
  "in_reply_to_status_id" : 154266537694478337,
  "created_at" : "2012-01-03 18:24:37 +0000",
  "in_reply_to_screen_name" : "SkypilotOfHope",
  "in_reply_to_user_id_str" : "140291463",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154258720853999616",
  "geo" : { },
  "id_str" : "154264893946724352",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses pretty!",
  "id" : 154264893946724352,
  "in_reply_to_status_id" : 154258720853999616,
  "created_at" : "2012-01-03 18:16:31 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "indices" : [ 3, 19 ],
      "id_str" : "104302000",
      "id" : 104302000
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154249783752654848",
  "text" : "RT @UndertheNeonSky: Women are like cell phones. They like to be held & talked to, but push the wrong button & youll be disconnected.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154248819167608833",
    "text" : "Women are like cell phones. They like to be held & talked to, but push the wrong button & youll be disconnected.",
    "id" : 154248819167608833,
    "created_at" : "2012-01-03 17:12:38 +0000",
    "user" : {
      "name" : "Jay Rankin",
      "screen_name" : "UndertheNeonSky",
      "protected" : false,
      "id_str" : "104302000",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1374022558\/Untitled-3_normal.jpg",
      "id" : 104302000,
      "verified" : false
    }
  },
  "id" : 154249783752654848,
  "created_at" : "2012-01-03 17:16:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154239600196468736",
  "text" : "RT @CoyotesWisdom: Sanity is in the eye of the beholder.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "151702194113097728",
    "text" : "Sanity is in the eye of the beholder.",
    "id" : 151702194113097728,
    "created_at" : "2011-12-27 16:33:16 +0000",
    "user" : {
      "name" : "WEREWOLF IN HEAT",
      "screen_name" : "LilMissCoyote",
      "protected" : false,
      "id_str" : "260028159",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/545299179921108992\/WzKnfHE8_normal.png",
      "id" : 260028159,
      "verified" : false
    }
  },
  "id" : 154239600196468736,
  "created_at" : "2012-01-03 16:36:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michelle",
      "screen_name" : "Michelle9647",
      "indices" : [ 3, 16 ],
      "id_str" : "75630518",
      "id" : 75630518
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Virginia",
      "indices" : [ 41, 50 ]
    }, {
      "text" : "GOP",
      "indices" : [ 51, 55 ]
    } ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/ZeOayw3F",
      "expanded_url" : "http:\/\/thinkprogress.org\/politics\/2012\/01\/03\/396323\/virginia-gop-will-require-primary-voters-to-sign-party-loyalty-oath\/",
      "display_url" : "thinkprogress.org\/politics\/2012\/\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154238862548418561",
  "text" : "RT @Michelle9647: OMG!! WTF is THIS CRAP #Virginia #GOP Will Require Primary Voters To Sign Party Loyalty Oath  | \nhttp:\/\/t.co\/ZeOayw3F",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Virginia",
        "indices" : [ 23, 32 ]
      }, {
        "text" : "GOP",
        "indices" : [ 33, 37 ]
      } ],
      "urls" : [ {
        "indices" : [ 97, 117 ],
        "url" : "http:\/\/t.co\/ZeOayw3F",
        "expanded_url" : "http:\/\/thinkprogress.org\/politics\/2012\/01\/03\/396323\/virginia-gop-will-require-primary-voters-to-sign-party-loyalty-oath\/",
        "display_url" : "thinkprogress.org\/politics\/2012\/\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154234765422231552",
    "text" : "OMG!! WTF is THIS CRAP #Virginia #GOP Will Require Primary Voters To Sign Party Loyalty Oath  | \nhttp:\/\/t.co\/ZeOayw3F",
    "id" : 154234765422231552,
    "created_at" : "2012-01-03 16:16:48 +0000",
    "user" : {
      "name" : "Michelle",
      "screen_name" : "Michelle9647",
      "protected" : false,
      "id_str" : "75630518",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/519174269511954432\/CnsXIjCo_normal.jpeg",
      "id" : 75630518,
      "verified" : false
    }
  },
  "id" : 154238862548418561,
  "created_at" : "2012-01-03 16:33:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 11, 20 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154234888206286849",
  "geo" : { },
  "id_str" : "154237162458591233",
  "in_reply_to_user_id" : 233971651,
  "text" : "@Selaniest @bcmouser good to hear.. glad you got it! : )",
  "id" : 154237162458591233,
  "in_reply_to_status_id" : 154234888206286849,
  "created_at" : "2012-01-03 16:26:19 +0000",
  "in_reply_to_screen_name" : "UnwashedThe",
  "in_reply_to_user_id_str" : "233971651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    }, {
      "name" : "KerriFar",
      "screen_name" : "KerriFar",
      "indices" : [ 13, 22 ],
      "id_str" : "12088232",
      "id" : 12088232
    }, {
      "name" : "Sue Melvin",
      "screen_name" : "birdersue",
      "indices" : [ 33, 43 ],
      "id_str" : "26605939",
      "id" : 26605939
    }, {
      "name" : "Sue Melvin",
      "screen_name" : "birdersue",
      "indices" : [ 128, 138 ],
      "id_str" : "26605939",
      "id" : 26605939
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "squirrel",
      "indices" : [ 61, 70 ]
    } ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/Kh0iS2Ft",
      "expanded_url" : "http:\/\/bit.ly\/uMZwt5",
      "display_url" : "bit.ly\/uMZwt5"
    } ]
  },
  "geo" : { },
  "id_str" : "154236726192254977",
  "text" : "RT @screek: \u201C@KerriFar: Cute! RT @birdersue: Have you seen a #squirrel pose like this? - 'The Show Off' -  http:\/\/t.co\/Kh0iS2Ft @birdersue",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "KerriFar",
        "screen_name" : "KerriFar",
        "indices" : [ 1, 10 ],
        "id_str" : "12088232",
        "id" : 12088232
      }, {
        "name" : "Sue Melvin",
        "screen_name" : "birdersue",
        "indices" : [ 21, 31 ],
        "id_str" : "26605939",
        "id" : 26605939
      }, {
        "name" : "Sue Melvin",
        "screen_name" : "birdersue",
        "indices" : [ 116, 126 ],
        "id_str" : "26605939",
        "id" : 26605939
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "squirrel",
        "indices" : [ 49, 58 ]
      } ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/Kh0iS2Ft",
        "expanded_url" : "http:\/\/bit.ly\/uMZwt5",
        "display_url" : "bit.ly\/uMZwt5"
      } ]
    },
    "geo" : { },
    "id_str" : "154235221896732672",
    "text" : "\u201C@KerriFar: Cute! RT @birdersue: Have you seen a #squirrel pose like this? - 'The Show Off' -  http:\/\/t.co\/Kh0iS2Ft @birdersue",
    "id" : 154235221896732672,
    "created_at" : "2012-01-03 16:18:37 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 154236726192254977,
  "created_at" : "2012-01-03 16:24:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "indices" : [ 3, 15 ],
      "id_str" : "32585384",
      "id" : 32585384
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "154231820421046273",
  "text" : "RT @intuitivedm: The JOURNEY is the point!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "154230557599993857",
    "text" : "The JOURNEY is the point!",
    "id" : 154230557599993857,
    "created_at" : "2012-01-03 16:00:05 +0000",
    "user" : {
      "name" : "danielle mackinnon",
      "screen_name" : "intuitivedm",
      "protected" : false,
      "id_str" : "32585384",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/509424532495429633\/3M8ImHNe_normal.jpeg",
      "id" : 32585384,
      "verified" : false
    }
  },
  "id" : 154231820421046273,
  "created_at" : "2012-01-03 16:05:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "KindleFireDept",
      "screen_name" : "KindleFireDept",
      "indices" : [ 3, 18 ],
      "id_str" : "867417752",
      "id" : 867417752
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ {
      "indices" : [ 108, 128 ],
      "url" : "http:\/\/t.co\/iwvYLAeg",
      "expanded_url" : "http:\/\/fireapps.blogspot.com\/2012\/01\/kindle-fire-department-gives-away.html",
      "display_url" : "fireapps.blogspot.com\/2012\/01\/kindle\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154231692108902400",
  "text" : "RT @KindleFireDept: Want to win a #Kindle Fire? We're giving one away! Click Retweet to get an extra entry! http:\/\/t.co\/iwvYLAeg #Kindle ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 14, 21 ]
      }, {
        "text" : "KindleFire",
        "indices" : [ 109, 120 ]
      }, {
        "text" : "Amazon",
        "indices" : [ 121, 128 ]
      }, {
        "text" : "giveaway",
        "indices" : [ 129, 138 ]
      } ],
      "urls" : [ {
        "indices" : [ 88, 108 ],
        "url" : "http:\/\/t.co\/iwvYLAeg",
        "expanded_url" : "http:\/\/fireapps.blogspot.com\/2012\/01\/kindle-fire-department-gives-away.html",
        "display_url" : "fireapps.blogspot.com\/2012\/01\/kindle\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "154230994218663936",
    "text" : "Want to win a #Kindle Fire? We're giving one away! Click Retweet to get an extra entry! http:\/\/t.co\/iwvYLAeg #KindleFire #Amazon #giveaway",
    "id" : 154230994218663936,
    "created_at" : "2012-01-03 16:01:49 +0000",
    "user" : {
      "name" : "BookSends",
      "screen_name" : "BookSends",
      "protected" : false,
      "id_str" : "398225352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/520255313811755008\/WYb6d_5Y_normal.png",
      "id" : 398225352,
      "verified" : false
    }
  },
  "id" : 154231692108902400,
  "created_at" : "2012-01-03 16:04:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154217873101959168",
  "geo" : { },
  "id_str" : "154226760370757633",
  "in_reply_to_user_id" : 233971651,
  "text" : "@Selaniest dashboard\/myblogs\/changeblogaddress (hover over address in title bar to get this option) ...not sure of results, tho",
  "id" : 154226760370757633,
  "in_reply_to_status_id" : 154217873101959168,
  "created_at" : "2012-01-03 15:44:59 +0000",
  "in_reply_to_screen_name" : "UnwashedThe",
  "in_reply_to_user_id_str" : "233971651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154217873101959168",
  "geo" : { },
  "id_str" : "154225876031115264",
  "in_reply_to_user_id" : 233971651,
  "text" : "@Selaniest old blog:dashboard\/tools\/export (save file) new blog: tools\/import (the file you saved)",
  "id" : 154225876031115264,
  "in_reply_to_status_id" : 154217873101959168,
  "created_at" : "2012-01-03 15:41:28 +0000",
  "in_reply_to_screen_name" : "UnwashedThe",
  "in_reply_to_user_id_str" : "233971651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 0, 9 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154222864122384384",
  "geo" : { },
  "id_str" : "154225296575430658",
  "in_reply_to_user_id" : 16649649,
  "text" : "@bcmouser thanks",
  "id" : 154225296575430658,
  "in_reply_to_status_id" : 154222864122384384,
  "created_at" : "2012-01-03 15:39:10 +0000",
  "in_reply_to_screen_name" : "bcmouser",
  "in_reply_to_user_id_str" : "16649649",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 11, 20 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 58, 78 ],
      "url" : "http:\/\/t.co\/CtaSHDL7",
      "expanded_url" : "http:\/\/wp.com",
      "display_url" : "wp.com"
    } ]
  },
  "in_reply_to_status_id_str" : "154217873101959168",
  "geo" : { },
  "id_str" : "154222624724103168",
  "in_reply_to_user_id" : 233971651,
  "text" : "@Selaniest @bcmouser which blog? what platform (blogspot, http:\/\/t.co\/CtaSHDL7 or wp self hosted?)",
  "id" : 154222624724103168,
  "in_reply_to_status_id" : 154217873101959168,
  "created_at" : "2012-01-03 15:28:33 +0000",
  "in_reply_to_screen_name" : "UnwashedThe",
  "in_reply_to_user_id_str" : "233971651",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154033773489569792",
  "geo" : { },
  "id_str" : "154035191302729729",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ahhh.. after cold snow, hot shower was needed!",
  "id" : 154035191302729729,
  "in_reply_to_status_id" : 154033773489569792,
  "created_at" : "2012-01-03 03:03:46 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154024945993781248",
  "geo" : { },
  "id_str" : "154026229182369792",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous ahahaha.. rofl..",
  "id" : 154026229182369792,
  "in_reply_to_status_id" : 154024945993781248,
  "created_at" : "2012-01-03 02:28:09 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "154022414483853312",
  "geo" : { },
  "id_str" : "154024142633570304",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous LOL",
  "id" : 154024142633570304,
  "in_reply_to_status_id" : 154022414483853312,
  "created_at" : "2012-01-03 02:19:51 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "indices" : [ 3, 15 ],
      "id_str" : "14345566",
      "id" : 14345566
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 17, 37 ],
      "url" : "http:\/\/t.co\/v7WLxV88",
      "expanded_url" : "http:\/\/thebloggess.com\/2012\/01\/the-fight-goes-on\/",
      "display_url" : "thebloggess.com\/2012\/01\/the-fi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "154014184990982145",
  "text" : "RT @TheBloggess: http:\/\/t.co\/v7WLxV88  The hardest post I ever had to write.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 0, 20 ],
        "url" : "http:\/\/t.co\/v7WLxV88",
        "expanded_url" : "http:\/\/thebloggess.com\/2012\/01\/the-fight-goes-on\/",
        "display_url" : "thebloggess.com\/2012\/01\/the-fi\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "153983709203279872",
    "text" : "http:\/\/t.co\/v7WLxV88  The hardest post I ever had to write.",
    "id" : 153983709203279872,
    "created_at" : "2012-01-02 23:39:11 +0000",
    "user" : {
      "name" : "TheBloggess",
      "screen_name" : "TheBloggess",
      "protected" : false,
      "id_str" : "14345566",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1459362861\/cheesecake_copy2_normal.jpg",
      "id" : 14345566,
      "verified" : true
    }
  },
  "id" : 154014184990982145,
  "created_at" : "2012-01-03 01:40:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 43, 63 ],
      "url" : "http:\/\/t.co\/Wqtxm681",
      "expanded_url" : "http:\/\/bit.ly\/st8wNw",
      "display_url" : "bit.ly\/st8wNw"
    } ]
  },
  "geo" : { },
  "id_str" : "153991011255848960",
  "text" : "went on the antipsychotic on Christmas Day http:\/\/t.co\/Wqtxm681 6yo - sudden hallucinations..DRs dont know why.",
  "id" : 153991011255848960,
  "created_at" : "2012-01-03 00:08:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mariah McCourt",
      "screen_name" : "TiredFairy",
      "indices" : [ 3, 14 ],
      "id_str" : "50549602",
      "id" : 50549602
    }, {
      "name" : "Tim Beedle",
      "screen_name" : "Tim_Beedle",
      "indices" : [ 102, 113 ],
      "id_str" : "108214303",
      "id" : 108214303
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 115, 135 ],
      "url" : "http:\/\/t.co\/cy4JAxOp",
      "expanded_url" : "http:\/\/bit.ly\/uONFWy",
      "display_url" : "bit.ly\/uONFWy"
    } ]
  },
  "geo" : { },
  "id_str" : "153989476362891264",
  "text" : "RT @TiredFairy: And even if you don't know what to do, pls RT and maybe help a father help his son: RT@Tim_Beedle: http:\/\/t.co\/cy4JAxOp",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tim Beedle",
        "screen_name" : "Tim_Beedle",
        "indices" : [ 86, 97 ],
        "id_str" : "108214303",
        "id" : 108214303
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 99, 119 ],
        "url" : "http:\/\/t.co\/cy4JAxOp",
        "expanded_url" : "http:\/\/bit.ly\/uONFWy",
        "display_url" : "bit.ly\/uONFWy"
      } ]
    },
    "geo" : { },
    "id_str" : "153981821368025088",
    "text" : "And even if you don't know what to do, pls RT and maybe help a father help his son: RT@Tim_Beedle: http:\/\/t.co\/cy4JAxOp",
    "id" : 153981821368025088,
    "created_at" : "2012-01-02 23:31:41 +0000",
    "user" : {
      "name" : "Mariah McCourt",
      "screen_name" : "TiredFairy",
      "protected" : false,
      "id_str" : "50549602",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/668833670053015552\/GfARH_Hd_normal.jpg",
      "id" : 50549602,
      "verified" : false
    }
  },
  "id" : 153989476362891264,
  "created_at" : "2012-01-03 00:02:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153977921294438400",
  "text" : "watching twilight zone \"to see the invisible man\" .. interesting..",
  "id" : 153977921294438400,
  "created_at" : "2012-01-02 23:16:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "indices" : [ 3, 13 ],
      "id_str" : "22380908",
      "id" : 22380908
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153977301338558465",
  "text" : "RT @BethLayne: Forgive. It frees you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153976608858963969",
    "text" : "Forgive. It frees you.",
    "id" : 153976608858963969,
    "created_at" : "2012-01-02 23:10:58 +0000",
    "user" : {
      "name" : "Beth Layne",
      "screen_name" : "BethLayne",
      "protected" : false,
      "id_str" : "22380908",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796841124904116224\/6H0GAfoZ_normal.jpg",
      "id" : 22380908,
      "verified" : false
    }
  },
  "id" : 153977301338558465,
  "created_at" : "2012-01-02 23:13:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 0, 10 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153967178901762048",
  "geo" : { },
  "id_str" : "153967935386435584",
  "in_reply_to_user_id" : 77106578,
  "text" : "@Matth3ous oh..my..goodness..",
  "id" : 153967935386435584,
  "in_reply_to_status_id" : 153967178901762048,
  "created_at" : "2012-01-02 22:36:31 +0000",
  "in_reply_to_screen_name" : "Matth3ous",
  "in_reply_to_user_id_str" : "77106578",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153957539959144449",
  "text" : "@SamsaricWarrior years ago.. thought hubby was crazy when said he talked to trees. now he thinks Im crazy on some things!",
  "id" : 153957539959144449,
  "created_at" : "2012-01-02 21:55:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 75 ],
      "url" : "http:\/\/t.co\/0hZHYkFs",
      "expanded_url" : "http:\/\/nblo.gs\/sgQok",
      "display_url" : "nblo.gs\/sgQok"
    } ]
  },
  "geo" : { },
  "id_str" : "153956877854720000",
  "text" : "RT @DwayneReaves: I let the word Money drive me crazy! http:\/\/t.co\/0hZHYkFs",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.networkedblogs.com\/\" rel=\"nofollow\"\u003ENetworkedBlogs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 37, 57 ],
        "url" : "http:\/\/t.co\/0hZHYkFs",
        "expanded_url" : "http:\/\/nblo.gs\/sgQok",
        "display_url" : "nblo.gs\/sgQok"
      } ]
    },
    "geo" : { },
    "id_str" : "153941724283142144",
    "text" : "I let the word Money drive me crazy! http:\/\/t.co\/0hZHYkFs",
    "id" : 153941724283142144,
    "created_at" : "2012-01-02 20:52:21 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 153956877854720000,
  "created_at" : "2012-01-02 21:52:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153954697991041024",
  "text" : "tree is down.. have my spot back! yay!",
  "id" : 153954697991041024,
  "created_at" : "2012-01-02 21:43:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153952274329243649",
  "text" : "@SamsaricWarrior aww.. I love this pic!",
  "id" : 153952274329243649,
  "created_at" : "2012-01-02 21:34:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ExpectYourGoodNow",
      "indices" : [ 116, 134 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153907002085609472",
  "text" : "RT @TheEntertainer: When the Universe delivers good in your life, say thank you, thank you, thank you, more please. #ExpectYourGoodNow",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ExpectYourGoodNow",
        "indices" : [ 96, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153904133072617473",
    "text" : "When the Universe delivers good in your life, say thank you, thank you, thank you, more please. #ExpectYourGoodNow",
    "id" : 153904133072617473,
    "created_at" : "2012-01-02 18:22:59 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 153907002085609472,
  "created_at" : "2012-01-02 18:34:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Turtle Tears",
      "screen_name" : "TurtleTears",
      "indices" : [ 3, 15 ],
      "id_str" : "244787190",
      "id" : 244787190
    }, {
      "name" : "shondi99",
      "screen_name" : "shondi99",
      "indices" : [ 17, 26 ],
      "id_str" : "168524035",
      "id" : 168524035
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153904263431602177",
  "text" : "RT @TurtleTears: @shondi99 One fifth of our nation now living in poverty...the 1% doesn't have a clue what it's like.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "shondi99",
        "screen_name" : "shondi99",
        "indices" : [ 0, 9 ],
        "id_str" : "168524035",
        "id" : 168524035
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "153900703092457472",
    "geo" : { },
    "id_str" : "153901159021682690",
    "in_reply_to_user_id" : 168524035,
    "text" : "@shondi99 One fifth of our nation now living in poverty...the 1% doesn't have a clue what it's like.",
    "id" : 153901159021682690,
    "in_reply_to_status_id" : 153900703092457472,
    "created_at" : "2012-01-02 18:11:10 +0000",
    "in_reply_to_screen_name" : "shondi99",
    "in_reply_to_user_id_str" : "168524035",
    "user" : {
      "name" : "Turtle Tears",
      "screen_name" : "TurtleTears",
      "protected" : false,
      "id_str" : "244787190",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/558702408814313473\/Q6ENx8V2_normal.jpeg",
      "id" : 244787190,
      "verified" : false
    }
  },
  "id" : 153904263431602177,
  "created_at" : "2012-01-02 18:23:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joanne Aitken",
      "screen_name" : "Doziej",
      "indices" : [ 11, 18 ],
      "id_str" : "19228649",
      "id" : 19228649
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quickpoll",
      "indices" : [ 83, 93 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153897399130128384",
  "text" : "twitter RT @Doziej: If you had to choose only one would it be Twitter or Facebook. #quickpoll",
  "id" : 153897399130128384,
  "created_at" : "2012-01-02 17:56:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 3, 12 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 35, 55 ],
      "url" : "http:\/\/t.co\/vEM93bCL",
      "expanded_url" : "http:\/\/bit.ly\/siEpST",
      "display_url" : "bit.ly\/siEpST"
    } ]
  },
  "geo" : { },
  "id_str" : "153890113573752832",
  "text" : "RT @Moonrust: Pigeon Vs. Escalator http:\/\/t.co\/vEM93bCL",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/feeddler-rss-reader-pro\/id365710282?mt=8\" rel=\"nofollow\"\u003EFeeddler\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 21, 41 ],
        "url" : "http:\/\/t.co\/vEM93bCL",
        "expanded_url" : "http:\/\/bit.ly\/siEpST",
        "display_url" : "bit.ly\/siEpST"
      } ]
    },
    "geo" : { },
    "id_str" : "153888579788087296",
    "text" : "Pigeon Vs. Escalator http:\/\/t.co\/vEM93bCL",
    "id" : 153888579788087296,
    "created_at" : "2012-01-02 17:21:11 +0000",
    "user" : {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "protected" : false,
      "id_str" : "15396585",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/777918231470338048\/eRAp-YX2_normal.jpg",
      "id" : 15396585,
      "verified" : false
    }
  },
  "id" : 153890113573752832,
  "created_at" : "2012-01-02 17:27:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "AVMAvets",
      "screen_name" : "AVMAvets",
      "indices" : [ 3, 12 ],
      "id_str" : "90452704",
      "id" : 90452704
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "pets",
      "indices" : [ 51, 56 ]
    } ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/IsI5Not9",
      "expanded_url" : "http:\/\/bit.ly\/uxqf4k",
      "display_url" : "bit.ly\/uxqf4k"
    } ]
  },
  "geo" : { },
  "id_str" : "153888932252229632",
  "text" : "RT @AVMAvets: N.J. petfood pantry helps people and #pets through hard times. http:\/\/t.co\/IsI5Not9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "pets",
        "indices" : [ 37, 42 ]
      } ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/IsI5Not9",
        "expanded_url" : "http:\/\/bit.ly\/uxqf4k",
        "display_url" : "bit.ly\/uxqf4k"
      } ]
    },
    "geo" : { },
    "id_str" : "153885795802038272",
    "text" : "N.J. petfood pantry helps people and #pets through hard times. http:\/\/t.co\/IsI5Not9",
    "id" : 153885795802038272,
    "created_at" : "2012-01-02 17:10:07 +0000",
    "user" : {
      "name" : "AVMAvets",
      "screen_name" : "AVMAvets",
      "protected" : false,
      "id_str" : "90452704",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/620002737275695104\/YtCX9h4i_normal.jpg",
      "id" : 90452704,
      "verified" : false
    }
  },
  "id" : 153888932252229632,
  "created_at" : "2012-01-02 17:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 0, 11 ],
      "id_str" : "15467920",
      "id" : 15467920
    }, {
      "name" : "Tracy Carroll",
      "screen_name" : "Tradledee85",
      "indices" : [ 12, 24 ],
      "id_str" : "39399394",
      "id" : 39399394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 31, 36 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153886952649785344",
  "geo" : { },
  "id_str" : "153888677943181313",
  "in_reply_to_user_id" : 15467920,
  "text" : "@taraburner @tradledee85 ouch! #fail is right!",
  "id" : 153888677943181313,
  "in_reply_to_status_id" : 153886952649785344,
  "created_at" : "2012-01-02 17:21:34 +0000",
  "in_reply_to_screen_name" : "taraburner",
  "in_reply_to_user_id_str" : "15467920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 3, 14 ],
      "id_str" : "15467920",
      "id" : 15467920
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 16, 27 ],
      "id_str" : "93747129",
      "id" : 93747129
    }, {
      "name" : "Tracy Carroll",
      "screen_name" : "Tradledee85",
      "indices" : [ 28, 40 ],
      "id_str" : "39399394",
      "id" : 39399394
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fail",
      "indices" : [ 122, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153888353190821888",
  "text" : "RT @taraburner: @moosebegab @tradledee85 private owned :( I havent been able to get my mail or packages since thursday!!! #fail",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 0, 11 ],
        "id_str" : "93747129",
        "id" : 93747129
      }, {
        "name" : "Tracy Carroll",
        "screen_name" : "Tradledee85",
        "indices" : [ 12, 24 ],
        "id_str" : "39399394",
        "id" : 39399394
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fail",
        "indices" : [ 106, 111 ]
      } ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "153886419562151936",
    "geo" : { },
    "id_str" : "153886952649785344",
    "in_reply_to_user_id" : 93747129,
    "text" : "@moosebegab @tradledee85 private owned :( I havent been able to get my mail or packages since thursday!!! #fail",
    "id" : 153886952649785344,
    "in_reply_to_status_id" : 153886419562151936,
    "created_at" : "2012-01-02 17:14:43 +0000",
    "in_reply_to_screen_name" : "moosebegab",
    "in_reply_to_user_id_str" : "93747129",
    "user" : {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "protected" : false,
      "id_str" : "15467920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/776570467859726336\/jVhCBsn-_normal.jpg",
      "id" : 15467920,
      "verified" : false
    }
  },
  "id" : 153888353190821888,
  "created_at" : "2012-01-02 17:20:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 0, 11 ],
      "id_str" : "15467920",
      "id" : 15467920
    }, {
      "name" : "Tracy Carroll",
      "screen_name" : "Tradledee85",
      "indices" : [ 12, 24 ],
      "id_str" : "39399394",
      "id" : 39399394
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153884615667499009",
  "geo" : { },
  "id_str" : "153886419562151936",
  "in_reply_to_user_id" : 15467920,
  "text" : "@taraburner @tradledee85 wow.. ups store 5 day w\/e?? very weird for store that ships stuff!",
  "id" : 153886419562151936,
  "in_reply_to_status_id" : 153884615667499009,
  "created_at" : "2012-01-02 17:12:36 +0000",
  "in_reply_to_screen_name" : "taraburner",
  "in_reply_to_user_id_str" : "15467920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "DogWalkBlog",
      "screen_name" : "dogwalkblog",
      "indices" : [ 3, 15 ],
      "id_str" : "16237734",
      "id" : 16237734
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153884233394434048",
  "text" : "RT @dogwalkblog: In 2012, we should stop treating poverty as if it were a crime. Most of us are one heart attack, one paycheck away from ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153882522319720448",
    "text" : "In 2012, we should stop treating poverty as if it were a crime. Most of us are one heart attack, one paycheck away from  \"those people\"",
    "id" : 153882522319720448,
    "created_at" : "2012-01-02 16:57:06 +0000",
    "user" : {
      "name" : "DogWalkBlog",
      "screen_name" : "dogwalkblog",
      "protected" : false,
      "id_str" : "16237734",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/548329660363587584\/cql3Xdnm_normal.jpeg",
      "id" : 16237734,
      "verified" : false
    }
  },
  "id" : 153884233394434048,
  "created_at" : "2012-01-02 17:03:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kevin",
      "screen_name" : "SignsOfKevin",
      "indices" : [ 0, 13 ],
      "id_str" : "21812702",
      "id" : 21812702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153882751379058689",
  "geo" : { },
  "id_str" : "153883176392069121",
  "in_reply_to_user_id" : 21812702,
  "text" : "@SignsOfKevin me, either... and I didnt even drink! bleh.",
  "id" : 153883176392069121,
  "in_reply_to_status_id" : 153882751379058689,
  "created_at" : "2012-01-02 16:59:42 +0000",
  "in_reply_to_screen_name" : "SignsOfKevin",
  "in_reply_to_user_id_str" : "21812702",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tara Burner",
      "screen_name" : "taraburner",
      "indices" : [ 0, 11 ],
      "id_str" : "15467920",
      "id" : 15467920
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153871488825569281",
  "geo" : { },
  "id_str" : "153872585459896320",
  "in_reply_to_user_id" : 15467920,
  "text" : "@taraburner yeah.. bcuz holiday fell on sun, many are off today.",
  "id" : 153872585459896320,
  "in_reply_to_status_id" : 153871488825569281,
  "created_at" : "2012-01-02 16:17:37 +0000",
  "in_reply_to_screen_name" : "taraburner",
  "in_reply_to_user_id_str" : "15467920",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153870746211467265",
  "text" : "so excited.. might get my spot back today. hubby has boxes out!",
  "id" : 153870746211467265,
  "created_at" : "2012-01-02 16:10:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153866309501853697",
  "geo" : { },
  "id_str" : "153868204450643968",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind aren't you always the bad guy? lol",
  "id" : 153868204450643968,
  "in_reply_to_status_id" : 153866309501853697,
  "created_at" : "2012-01-02 16:00:13 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Musa Askari",
      "screen_name" : "Alone2Alone",
      "indices" : [ 3, 15 ],
      "id_str" : "245137425",
      "id" : 245137425
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153866189909655552",
  "text" : "RT @Alone2Alone: To honour one's parents is a life long purpose, while they are alive and after they have passed on. Peaceful Blessings  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153864240455892992",
    "text" : "To honour one's parents is a life long purpose, while they are alive and after they have passed on. Peaceful Blessings for the departed.",
    "id" : 153864240455892992,
    "created_at" : "2012-01-02 15:44:28 +0000",
    "user" : {
      "name" : "Musa Askari",
      "screen_name" : "Alone2Alone",
      "protected" : false,
      "id_str" : "245137425",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1412775786\/Room_-_Copy_normal.JPG",
      "id" : 245137425,
      "verified" : false
    }
  },
  "id" : 153866189909655552,
  "created_at" : "2012-01-02 15:52:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.tweetcaster.com\" rel=\"nofollow\"\u003ETweetCaster for Android\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153678390623338497",
  "text" : "RT @GraveStomper: You're 2012 challenge should you choose to accept it: Learn one new skill you always wanted to learn.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153678194988417024",
    "text" : "You're 2012 challenge should you choose to accept it: Learn one new skill you always wanted to learn.",
    "id" : 153678194988417024,
    "created_at" : "2012-01-02 03:25:11 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 153678390623338497,
  "created_at" : "2012-01-02 03:25:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 3, 15 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 28, 48 ],
      "url" : "http:\/\/t.co\/iv2osuGi",
      "expanded_url" : "http:\/\/fb.me\/1ovtU3q1J",
      "display_url" : "fb.me\/1ovtU3q1J"
    } ]
  },
  "geo" : { },
  "id_str" : "153660505926549506",
  "text" : "RT @PuaTamandua: Sleepy Pua http:\/\/t.co\/iv2osuGi",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 11, 31 ],
        "url" : "http:\/\/t.co\/iv2osuGi",
        "expanded_url" : "http:\/\/fb.me\/1ovtU3q1J",
        "display_url" : "fb.me\/1ovtU3q1J"
      } ]
    },
    "geo" : { },
    "id_str" : "153660001666351104",
    "text" : "Sleepy Pua http:\/\/t.co\/iv2osuGi",
    "id" : 153660001666351104,
    "created_at" : "2012-01-02 02:12:53 +0000",
    "user" : {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "protected" : false,
      "id_str" : "17218256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63782435\/shirt_normal.jpg",
      "id" : 17218256,
      "verified" : false
    }
  },
  "id" : 153660505926549506,
  "created_at" : "2012-01-02 02:14:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Janlynne",
      "screen_name" : "PeriodPiece",
      "indices" : [ 0, 12 ],
      "id_str" : "192399051",
      "id" : 192399051
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153652084888174592",
  "geo" : { },
  "id_str" : "153660390419607554",
  "in_reply_to_user_id" : 192399051,
  "text" : "@PeriodPiece why the heck that would make her angry anyway???",
  "id" : 153660390419607554,
  "in_reply_to_status_id" : 153652084888174592,
  "created_at" : "2012-01-02 02:14:26 +0000",
  "in_reply_to_screen_name" : "PeriodPiece",
  "in_reply_to_user_id_str" : "192399051",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    }, {
      "name" : "weywerdSun",
      "screen_name" : "weywerdSun",
      "indices" : [ 17, 28 ],
      "id_str" : "302745757",
      "id" : 302745757
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 97 ],
      "url" : "http:\/\/t.co\/5nqdbeyZ",
      "expanded_url" : "http:\/\/abcn.ws\/tGCwYK",
      "display_url" : "abcn.ws\/tGCwYK"
    } ]
  },
  "geo" : { },
  "id_str" : "153653310644166656",
  "text" : "RT @gemswinc: RT @weywerdSun: Court OKs Barring High IQs for Cops - ABC News http:\/\/t.co\/5nqdbeyZ &lt; speaks volumes!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "weywerdSun",
        "screen_name" : "weywerdSun",
        "indices" : [ 3, 14 ],
        "id_str" : "302745757",
        "id" : 302745757
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 83 ],
        "url" : "http:\/\/t.co\/5nqdbeyZ",
        "expanded_url" : "http:\/\/abcn.ws\/tGCwYK",
        "display_url" : "abcn.ws\/tGCwYK"
      } ]
    },
    "geo" : { },
    "id_str" : "153652397321891840",
    "text" : "RT @weywerdSun: Court OKs Barring High IQs for Cops - ABC News http:\/\/t.co\/5nqdbeyZ &lt; speaks volumes!",
    "id" : 153652397321891840,
    "created_at" : "2012-01-02 01:42:40 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 153653310644166656,
  "created_at" : "2012-01-02 01:46:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "indices" : [ 3, 16 ],
      "id_str" : "15588657",
      "id" : 15588657
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 53 ],
      "url" : "http:\/\/t.co\/WzEw92Hr",
      "expanded_url" : "http:\/\/bit.ly\/vsxleB",
      "display_url" : "bit.ly\/vsxleB"
    } ]
  },
  "geo" : { },
  "id_str" : "153652721885515779",
  "text" : "RT @DeepakChopra: What is God ?  http:\/\/t.co\/WzEw92Hr",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 15, 35 ],
        "url" : "http:\/\/t.co\/WzEw92Hr",
        "expanded_url" : "http:\/\/bit.ly\/vsxleB",
        "display_url" : "bit.ly\/vsxleB"
      } ]
    },
    "geo" : { },
    "id_str" : "153650757999149056",
    "text" : "What is God ?  http:\/\/t.co\/WzEw92Hr",
    "id" : 153650757999149056,
    "created_at" : "2012-01-02 01:36:10 +0000",
    "user" : {
      "name" : "Deepak Chopra",
      "screen_name" : "DeepakChopra",
      "protected" : false,
      "id_str" : "15588657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/623927221565149184\/frv5TJs6_normal.jpg",
      "id" : 15588657,
      "verified" : true
    }
  },
  "id" : 153652721885515779,
  "created_at" : "2012-01-02 01:43:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153640564401770497",
  "geo" : { },
  "id_str" : "153641948144611328",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts very excited for 2012. I expect wonderful things to happen. HNY!",
  "id" : 153641948144611328,
  "in_reply_to_status_id" : 153640564401770497,
  "created_at" : "2012-01-02 01:01:09 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153640564401770497",
  "geo" : { },
  "id_str" : "153641666111209473",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts glasses on \/ off .. squintsquintsquint .. eyes hurt. bleh.",
  "id" : 153641666111209473,
  "in_reply_to_status_id" : 153640564401770497,
  "created_at" : "2012-01-02 01:00:02 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lovely Lita's",
      "screen_name" : "sqrlady",
      "indices" : [ 3, 11 ],
      "id_str" : "134885838",
      "id" : 134885838
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153640656831660032",
  "text" : "RT @sqrlady: This crow makes raccoon noises every day for me.  Sounds just like a raccoon and for a while I kept looking for... http:\/\/t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 115, 135 ],
        "url" : "http:\/\/t.co\/SuyGC6wQ",
        "expanded_url" : "http:\/\/fb.me\/12vRXzhWU",
        "display_url" : "fb.me\/12vRXzhWU"
      } ]
    },
    "geo" : { },
    "id_str" : "153639445797683201",
    "text" : "This crow makes raccoon noises every day for me.  Sounds just like a raccoon and for a while I kept looking for... http:\/\/t.co\/SuyGC6wQ",
    "id" : 153639445797683201,
    "created_at" : "2012-01-02 00:51:13 +0000",
    "user" : {
      "name" : "Lovely Lita's",
      "screen_name" : "sqrlady",
      "protected" : false,
      "id_str" : "134885838",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/841619166\/twitterpic_normal.jpg",
      "id" : 134885838,
      "verified" : false
    }
  },
  "id" : 153640656831660032,
  "created_at" : "2012-01-02 00:56:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153638027065958400",
  "text" : "I have to make all the text on my pc bigger...",
  "id" : 153638027065958400,
  "created_at" : "2012-01-02 00:45:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153610396585046016",
  "geo" : { },
  "id_str" : "153611984078770177",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses im playing on Kindle Fire.. mine says \"create a game\" at bottom and I have green button w plus sign.",
  "id" : 153611984078770177,
  "in_reply_to_status_id" : 153610396585046016,
  "created_at" : "2012-01-01 23:02:05 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "indices" : [ 3, 13 ],
      "id_str" : "77106578",
      "id" : 77106578
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iowa",
      "indices" : [ 80, 85 ]
    } ],
    "urls" : [ {
      "indices" : [ 59, 79 ],
      "url" : "http:\/\/t.co\/mbLLaoo6",
      "expanded_url" : "http:\/\/tmblr.co\/ZpBICyE6eczz",
      "display_url" : "tmblr.co\/ZpBICyE6eczz"
    } ]
  },
  "geo" : { },
  "id_str" : "153602588833628161",
  "text" : "RT @Matth3ous: Rick Santorum: \"Diversity Causes Conflict.\" http:\/\/t.co\/mbLLaoo6 #iowa",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iowa",
        "indices" : [ 65, 70 ]
      } ],
      "urls" : [ {
        "indices" : [ 44, 64 ],
        "url" : "http:\/\/t.co\/mbLLaoo6",
        "expanded_url" : "http:\/\/tmblr.co\/ZpBICyE6eczz",
        "display_url" : "tmblr.co\/ZpBICyE6eczz"
      } ]
    },
    "geo" : { },
    "id_str" : "153598282084515840",
    "text" : "Rick Santorum: \"Diversity Causes Conflict.\" http:\/\/t.co\/mbLLaoo6 #iowa",
    "id" : 153598282084515840,
    "created_at" : "2012-01-01 22:07:38 +0000",
    "user" : {
      "name" : "Math\u00E6y\u00F3s",
      "screen_name" : "Matth3ous",
      "protected" : false,
      "id_str" : "77106578",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1564496742\/Gravatar_normal.jpg",
      "id" : 77106578,
      "verified" : false
    }
  },
  "id" : 153602588833628161,
  "created_at" : "2012-01-01 22:24:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 0, 15 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153600917046960130",
  "geo" : { },
  "id_str" : "153601982907686912",
  "in_reply_to_user_id" : 63804234,
  "text" : "@PeggySueCusses what device u playing on? see a green button w white plus sign? that gives options to add ppl.",
  "id" : 153601982907686912,
  "in_reply_to_status_id" : 153600917046960130,
  "created_at" : "2012-01-01 22:22:21 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153595363389997057",
  "text" : "RT @parkstepp: \"We might dislike various people and condemn their behaviour. Yet \u2014 once we understand why they act as...\" http:\/\/t.co\/Pe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 107, 127 ],
        "url" : "http:\/\/t.co\/PeCSUIEm",
        "expanded_url" : "http:\/\/tmblr.co\/ZwrrNyE6ZFWN",
        "display_url" : "tmblr.co\/ZwrrNyE6ZFWN"
      } ]
    },
    "geo" : { },
    "id_str" : "153591502793228290",
    "text" : "\"We might dislike various people and condemn their behaviour. Yet \u2014 once we understand why they act as...\" http:\/\/t.co\/PeCSUIEm",
    "id" : 153591502793228290,
    "created_at" : "2012-01-01 21:40:42 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 153595363389997057,
  "created_at" : "2012-01-01 21:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 44, 64 ],
      "url" : "http:\/\/t.co\/MktlQ9Od",
      "expanded_url" : "http:\/\/bit.ly\/sRqu7H",
      "display_url" : "bit.ly\/sRqu7H"
    } ]
  },
  "geo" : { },
  "id_str" : "153594619882520577",
  "text" : "Neil deGrasse Tyson shares a cool thought - http:\/\/t.co\/MktlQ9Od \"Tyson is the most spiritual atheist ever, This man is a great thinker\"",
  "id" : 153594619882520577,
  "created_at" : "2012-01-01 21:53:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 104, 124 ],
      "url" : "http:\/\/t.co\/ilWFwEsq",
      "expanded_url" : "http:\/\/bit.ly\/tBzwWj",
      "display_url" : "bit.ly\/tBzwWj"
    } ]
  },
  "geo" : { },
  "id_str" : "153593677665681409",
  "text" : "I believe in God but this is LOL .. love him &gt;&gt; Neil deGrasse Tyson DESTROYS intelligent design - http:\/\/t.co\/ilWFwEsq",
  "id" : 153593677665681409,
  "created_at" : "2012-01-01 21:49:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153571175421853696",
  "text" : "RT @neardeathdoc: So far the New Years resolutions on Facebook and Twitter feel like posturing: how about \"I will be a nicer person\"!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153569453945257985",
    "text" : "So far the New Years resolutions on Facebook and Twitter feel like posturing: how about \"I will be a nicer person\"!",
    "id" : 153569453945257985,
    "created_at" : "2012-01-01 20:13:05 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 153571175421853696,
  "created_at" : "2012-01-01 20:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "Pauline (I\u2764\u266B)",
      "screen_name" : "ThisBlueWorld",
      "indices" : [ 26, 40 ],
      "id_str" : "113395189",
      "id" : 113395189
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153571067997339648",
  "text" : "RT @neardeathdoc: My wife @ThisBlueWorld is reading me various pious sounding resolutions for others to fulfill! How about \"I will change\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pauline (I\u2764\u266B)",
        "screen_name" : "ThisBlueWorld",
        "indices" : [ 8, 22 ],
        "id_str" : "113395189",
        "id" : 113395189
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153569827288649728",
    "text" : "My wife @ThisBlueWorld is reading me various pious sounding resolutions for others to fulfill! How about \"I will change\"",
    "id" : 153569827288649728,
    "created_at" : "2012-01-01 20:14:34 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 153571067997339648,
  "created_at" : "2012-01-01 20:19:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 67, 74 ]
    }, {
      "text" : "ebook",
      "indices" : [ 75, 81 ]
    }, {
      "text" : "giveaway",
      "indices" : [ 82, 91 ]
    } ],
    "urls" : [ {
      "indices" : [ 26, 46 ],
      "url" : "http:\/\/t.co\/XogWf6br",
      "expanded_url" : "http:\/\/wp.me\/p1KXzf-Rj",
      "display_url" : "wp.me\/p1KXzf-Rj"
    } ]
  },
  "geo" : { },
  "id_str" : "153553701565501440",
  "text" : "Happy New Year New Book!  http:\/\/t.co\/XogWf6br via @theCheapKindle #kindle #ebook #giveaway",
  "id" : 153553701565501440,
  "created_at" : "2012-01-01 19:10:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "indices" : [ 3, 15 ],
      "id_str" : "18256901",
      "id" : 18256901
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153550062063075328",
  "text" : "RT @deonnakelli: Someone just told me they look forward to my 2012 \"incites\" (rather than insights). You know, I can work with that. I c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153539246123266048",
    "text" : "Someone just told me they look forward to my 2012 \"incites\" (rather than insights). You know, I can work with that. I can be \"inciteful.\"",
    "id" : 153539246123266048,
    "created_at" : "2012-01-01 18:13:03 +0000",
    "user" : {
      "name" : "(((dksayed)))",
      "screen_name" : "deonnakelli",
      "protected" : false,
      "id_str" : "18256901",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796046774813200384\/-eoNtOic_normal.jpg",
      "id" : 18256901,
      "verified" : false
    }
  },
  "id" : 153550062063075328,
  "created_at" : "2012-01-01 18:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "indices" : [ 3, 18 ],
      "id_str" : "7981702",
      "id" : 7981702
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153549843116199937",
  "text" : "RT @TheEntertainer: Welcome 2012, I expect BIG ASS AWESOME things from you, let's make it so, I'm READY, WILLING, and ABLE! Let DO this!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153543126156460032",
    "text" : "Welcome 2012, I expect BIG ASS AWESOME things from you, let's make it so, I'm READY, WILLING, and ABLE! Let DO this!",
    "id" : 153543126156460032,
    "created_at" : "2012-01-01 18:28:28 +0000",
    "user" : {
      "name" : "ScottBrandonHoffman",
      "screen_name" : "TheEntertainer",
      "protected" : false,
      "id_str" : "7981702",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/606241225562189824\/dT_l2CXD_normal.jpg",
      "id" : 7981702,
      "verified" : false
    }
  },
  "id" : 153549843116199937,
  "created_at" : "2012-01-01 18:55:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "aliceinthewater",
      "screen_name" : "aliceinthewater",
      "indices" : [ 0, 16 ],
      "id_str" : "17489079",
      "id" : 17489079
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153540377612255232",
  "geo" : { },
  "id_str" : "153549733229633536",
  "in_reply_to_user_id" : 17489079,
  "text" : "@aliceinthewater LOL",
  "id" : 153549733229633536,
  "in_reply_to_status_id" : 153540377612255232,
  "created_at" : "2012-01-01 18:54:43 +0000",
  "in_reply_to_screen_name" : "aliceinthewater",
  "in_reply_to_user_id_str" : "17489079",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153549587121057793",
  "text" : "RT @oshum: The statement ..\"I Want\"....implies Lack and will not bring the results desired.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153541394017947650",
    "text" : "The statement ..\"I Want\"....implies Lack and will not bring the results desired.",
    "id" : 153541394017947650,
    "created_at" : "2012-01-01 18:21:35 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 153549587121057793,
  "created_at" : "2012-01-01 18:54:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gina Ann Huckaby",
      "screen_name" : "Ginaration",
      "indices" : [ 3, 14 ],
      "id_str" : "106882460",
      "id" : 106882460
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153549190650281985",
  "text" : "RT @Ginaration: Wipe the slate clean everyday and envision how you want your world to be. If you feel a shift towards negativity  focus  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153543890559959040",
    "text" : "Wipe the slate clean everyday and envision how you want your world to be. If you feel a shift towards negativity  focus back on the positive",
    "id" : 153543890559959040,
    "created_at" : "2012-01-01 18:31:30 +0000",
    "user" : {
      "name" : "Gina Ann Huckaby",
      "screen_name" : "Ginaration",
      "protected" : false,
      "id_str" : "106882460",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2613291732\/image_normal.jpg",
      "id" : 106882460,
      "verified" : false
    }
  },
  "id" : 153549190650281985,
  "created_at" : "2012-01-01 18:52:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iWatch News",
      "screen_name" : "iWatch",
      "indices" : [ 3, 10 ],
      "id_str" : "304126466",
      "id" : 304126466
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 107, 127 ],
      "url" : "http:\/\/t.co\/UtsiIAIk",
      "expanded_url" : "http:\/\/bit.ly\/tHc9Ii",
      "display_url" : "bit.ly\/tHc9Ii"
    } ]
  },
  "geo" : { },
  "id_str" : "153549081132806144",
  "text" : "RT @iWatch: Tax gift to the rich: How a $2 billion-a-year loophole helps wealthy Americans pay less taxes: http:\/\/t.co\/UtsiIAIk",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 95, 115 ],
        "url" : "http:\/\/t.co\/UtsiIAIk",
        "expanded_url" : "http:\/\/bit.ly\/tHc9Ii",
        "display_url" : "bit.ly\/tHc9Ii"
      } ]
    },
    "geo" : { },
    "id_str" : "153538929612689409",
    "text" : "Tax gift to the rich: How a $2 billion-a-year loophole helps wealthy Americans pay less taxes: http:\/\/t.co\/UtsiIAIk",
    "id" : 153538929612689409,
    "created_at" : "2012-01-01 18:11:48 +0000",
    "user" : {
      "name" : "Public Integrity",
      "screen_name" : "Publici",
      "protected" : false,
      "id_str" : "19034656",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/539523590702395392\/UksSDUqp_normal.png",
      "id" : 19034656,
      "verified" : true
    }
  },
  "id" : 153549081132806144,
  "created_at" : "2012-01-01 18:52:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "indices" : [ 3, 14 ],
      "id_str" : "141944109",
      "id" : 141944109
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153547517412392960",
  "text" : "RT @LSFProgram: If a person remains cheerful and loving towards everyone, life will be an absolute joy.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153547321060229120",
    "text" : "If a person remains cheerful and loving towards everyone, life will be an absolute joy.",
    "id" : 153547321060229120,
    "created_at" : "2012-01-01 18:45:08 +0000",
    "user" : {
      "name" : "Lou & Marilyn",
      "screen_name" : "LSFProgram",
      "protected" : false,
      "id_str" : "141944109",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/467407886235103233\/6oMRriCj_normal.jpeg",
      "id" : 141944109,
      "verified" : false
    }
  },
  "id" : 153547517412392960,
  "created_at" : "2012-01-01 18:45:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "indices" : [ 3, 16 ],
      "id_str" : "45450889",
      "id" : 45450889
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153536690546409472",
  "text" : "RT @Squirrely007: Every time I eat something sweet, I need something salty and vice versa. It's a never ending cycle.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153534876614787072",
    "text" : "Every time I eat something sweet, I need something salty and vice versa. It's a never ending cycle.",
    "id" : 153534876614787072,
    "created_at" : "2012-01-01 17:55:41 +0000",
    "user" : {
      "name" : "Nope Not Today",
      "screen_name" : "Squirrely007",
      "protected" : false,
      "id_str" : "45450889",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797216432752836608\/WyvB8s79_normal.jpg",
      "id" : 45450889,
      "verified" : false
    }
  },
  "id" : 153536690546409472,
  "created_at" : "2012-01-01 18:02:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153533314416910338",
  "text" : "RT @JohnCali: ...every day is a New Beginning. A new cycle begins this day, yet a new cycle begins every day. Indeed, every moment. ~ Ne ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153525937571508226",
    "text" : "...every day is a New Beginning. A new cycle begins this day, yet a new cycle begins every day. Indeed, every moment. ~ Neale Donald Walsch",
    "id" : 153525937571508226,
    "created_at" : "2012-01-01 17:20:10 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 153533314416910338,
  "created_at" : "2012-01-01 17:49:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jewels Of Saraswati",
      "screen_name" : "SaraswatiJewels",
      "indices" : [ 3, 19 ],
      "id_str" : "48357761",
      "id" : 48357761
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153533189711867904",
  "text" : "RT @SaraswatiJewels: Happy new year loves! Sensing a beautiful year ahead.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153526461683343360",
    "text" : "Happy new year loves! Sensing a beautiful year ahead.",
    "id" : 153526461683343360,
    "created_at" : "2012-01-01 17:22:15 +0000",
    "user" : {
      "name" : "Jewels Of Saraswati",
      "screen_name" : "SaraswatiJewels",
      "protected" : false,
      "id_str" : "48357761",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/497549397228400640\/ZwcA-Ape_normal.jpeg",
      "id" : 48357761,
      "verified" : false
    }
  },
  "id" : 153533189711867904,
  "created_at" : "2012-01-01 17:48:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153533041095081984",
  "text" : "RT @oshum: I AM ......World Peace.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153528023537299457",
    "text" : "I AM ......World Peace.",
    "id" : 153528023537299457,
    "created_at" : "2012-01-01 17:28:27 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 153533041095081984,
  "created_at" : "2012-01-01 17:48:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "indices" : [ 3, 16 ],
      "id_str" : "73908822",
      "id" : 73908822
    }, {
      "name" : "e e \u00AE",
      "screen_name" : "lelly28461",
      "indices" : [ 21, 32 ],
      "id_str" : "18427660",
      "id" : 18427660
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153532499199393792",
  "text" : "RT @DwayneReaves: RT @lelly28461: I challenge you to Entertain ALL Possibilities in the coming year!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "e e \u00AE",
        "screen_name" : "lelly28461",
        "indices" : [ 3, 14 ],
        "id_str" : "18427660",
        "id" : 18427660
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153530859880845312",
    "text" : "RT @lelly28461: I challenge you to Entertain ALL Possibilities in the coming year!",
    "id" : 153530859880845312,
    "created_at" : "2012-01-01 17:39:44 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 153532499199393792,
  "created_at" : "2012-01-01 17:46:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 0, 6 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153523546042286082",
  "geo" : { },
  "id_str" : "153524581330731009",
  "in_reply_to_user_id" : 33033233,
  "text" : "@oshum yeah.. this whole \"borders\" thing is weird..",
  "id" : 153524581330731009,
  "in_reply_to_status_id" : 153523546042286082,
  "created_at" : "2012-01-01 17:14:47 +0000",
  "in_reply_to_screen_name" : "Oshum",
  "in_reply_to_user_id_str" : "33033233",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "indices" : [ 3, 9 ],
      "id_str" : "33033233",
      "id" : 33033233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153524354876059648",
  "text" : "RT @oshum: Who \"owns\" Earth? who has created Borders and Barriers? who has forgotten the Unity of Humanity? Who sows seeds of Fear of Lack?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "153523546042286082",
    "text" : "Who \"owns\" Earth? who has created Borders and Barriers? who has forgotten the Unity of Humanity? Who sows seeds of Fear of Lack?",
    "id" : 153523546042286082,
    "created_at" : "2012-01-01 17:10:40 +0000",
    "user" : {
      "name" : "oshum",
      "screen_name" : "Oshum",
      "protected" : false,
      "id_str" : "33033233",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/782359775594082304\/VkU1XQFo_normal.jpg",
      "id" : 33033233,
      "verified" : false
    }
  },
  "id" : 153524354876059648,
  "created_at" : "2012-01-01 17:13:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 0, 10 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "153518745514553345",
  "geo" : { },
  "id_str" : "153519788101091329",
  "in_reply_to_user_id" : 16181537,
  "text" : "@ZachsMind ??",
  "id" : 153519788101091329,
  "in_reply_to_status_id" : 153518745514553345,
  "created_at" : "2012-01-01 16:55:44 +0000",
  "in_reply_to_screen_name" : "ZachsMind",
  "in_reply_to_user_id_str" : "16181537",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "153516640233979904",
  "text" : "2012!!! I have waited so long for you...",
  "id" : 153516640233979904,
  "created_at" : "2012-01-01 16:43:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]