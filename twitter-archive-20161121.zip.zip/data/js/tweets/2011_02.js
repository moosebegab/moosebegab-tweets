Grailbird.data.tweets_2011_02 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 52, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42403261310967808",
  "text" : "RT @hauntedcomputer: if anyone wants to give away a #mystery\/thriller\/paranormal ebook in a promotion, please email me at hauntedcompute ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mystery",
        "indices" : [ 31, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42394585045008384",
    "text" : "if anyone wants to give away a #mystery\/thriller\/paranormal ebook in a promotion, please email me at hauntedcomputer at yahoo or DM me",
    "id" : 42394585045008384,
    "created_at" : "2011-03-01 01:23:51 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 42403261310967808,
  "created_at" : "2011-03-01 01:58:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 24, 33 ]
    }, {
      "text" : "kindle",
      "indices" : [ 106, 113 ]
    }, {
      "text" : "mustread",
      "indices" : [ 114, 123 ]
    }, {
      "text" : "awesome",
      "indices" : [ 124, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42393964078313472",
  "text" : "RT @KreelanWarrior: For #thriller fans, you've got to check out SEASON OF THE HARVEST! http:\/\/ow.ly\/3S0oQ #kindle #mustread #awesome #go ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thriller",
        "indices" : [ 4, 13 ]
      }, {
        "text" : "kindle",
        "indices" : [ 86, 93 ]
      }, {
        "text" : "mustread",
        "indices" : [ 94, 103 ]
      }, {
        "text" : "awesome",
        "indices" : [ 104, 112 ]
      }, {
        "text" : "goodbooks",
        "indices" : [ 113, 123 ]
      }, {
        "text" : "GMO",
        "indices" : [ 124, 128 ]
      }, {
        "text" : "RT",
        "indices" : [ 129, 132 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42393693688311809",
    "text" : "For #thriller fans, you've got to check out SEASON OF THE HARVEST! http:\/\/ow.ly\/3S0oQ #kindle #mustread #awesome #goodbooks #GMO #RT",
    "id" : 42393693688311809,
    "created_at" : "2011-03-01 01:20:18 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 42393964078313472,
  "created_at" : "2011-03-01 01:21:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42393355405103104",
  "text" : "RT @TrishScott: All those get up and be a good person now quotes drive me nuts. If I get up it will be because the house is on fire.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42391428579606528",
    "text" : "All those get up and be a good person now quotes drive me nuts. If I get up it will be because the house is on fire.",
    "id" : 42391428579606528,
    "created_at" : "2011-03-01 01:11:18 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 42393355405103104,
  "created_at" : "2011-03-01 01:18:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 119, 125 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42390602163294209",
  "text" : "RT @AnAmericanMonk: The Twelve Sacred Principles of Karma is one of the most empowering books that you may find today. #books",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 99, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42386657210667009",
    "text" : "The Twelve Sacred Principles of Karma is one of the most empowering books that you may find today. #books",
    "id" : 42386657210667009,
    "created_at" : "2011-03-01 00:52:21 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 42390602163294209,
  "created_at" : "2011-03-01 01:08:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42296106251591681",
  "text" : "RT @TyrusBooks: No good deeds...Somebody has figured out how to get free ebooks when we're not offering. Trying to figure out how to pat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42294504262340608",
    "text" : "No good deeds...Somebody has figured out how to get free ebooks when we're not offering. Trying to figure out how to patch the hole.",
    "id" : 42294504262340608,
    "created_at" : "2011-02-28 18:46:10 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 42296106251591681,
  "created_at" : "2011-02-28 18:52:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 38, 43 ]
    }, {
      "text" : "ebook",
      "indices" : [ 44, 50 ]
    }, {
      "text" : "Lost",
      "indices" : [ 113, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42294724794662912",
  "text" : "RT @byoung210: Don't forget about the #free #ebook available tomorrow only! Details here: http:\/\/wp.me\/p15Plj-60 #Lost fans should like  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 23, 28 ]
      }, {
        "text" : "ebook",
        "indices" : [ 29, 35 ]
      }, {
        "text" : "Lost",
        "indices" : [ 98, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "42292963367329792",
    "text" : "Don't forget about the #free #ebook available tomorrow only! Details here: http:\/\/wp.me\/p15Plj-60 #Lost fans should like this one!",
    "id" : 42292963367329792,
    "created_at" : "2011-02-28 18:40:02 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 42294724794662912,
  "created_at" : "2011-02-28 18:47:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 0, 7 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "42222787430981633",
  "text" : "#kindle jokes http:\/\/bit.ly\/eyFd7Y",
  "id" : 42222787430981633,
  "created_at" : "2011-02-28 14:01:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 61, 72 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "42030525719908352",
  "geo" : { },
  "id_str" : "42036111861616640",
  "in_reply_to_user_id" : 6994832,
  "text" : "but while I'm encased in it, this body thing worries me..lol @TrishScott",
  "id" : 42036111861616640,
  "in_reply_to_status_id" : 42030525719908352,
  "created_at" : "2011-02-28 01:39:24 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "indices" : [ 3, 15 ],
      "id_str" : "143654638",
      "id" : 143654638
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 56, 63 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41944714387136513",
  "text" : "RT @JAScribbles: Would u like at least 10 ebooks for ur #Kindle? You ask, they're urs. http:\/\/www.one-mystake-at-a-tyme.blogspot.com End ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 39, 46 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41935713347973120",
    "text" : "Would u like at least 10 ebooks for ur #Kindle? You ask, they're urs. http:\/\/www.one-mystake-at-a-tyme.blogspot.com Ends today",
    "id" : 41935713347973120,
    "created_at" : "2011-02-27 19:00:27 +0000",
    "user" : {
      "name" : "JennaScribbles",
      "screen_name" : "JAScribbles",
      "protected" : false,
      "id_str" : "143654638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3248131975\/2365a206600b3ca1bf4ae12f5c194d8f_normal.jpeg",
      "id" : 143654638,
      "verified" : false
    }
  },
  "id" : 41944714387136513,
  "created_at" : "2011-02-27 19:36:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 26, 45 ],
      "url" : "http:\/\/t.co\/zmWqBQL",
      "expanded_url" : "http:\/\/wp.me\/p15Plj-60",
      "display_url" : "wp.me\/p15Plj-60"
    } ]
  },
  "geo" : { },
  "id_str" : "41902810492710912",
  "text" : "Ebook Giveaway on March 1 http:\/\/t.co\/zmWqBQL @byoung210",
  "id" : 41902810492710912,
  "created_at" : "2011-02-27 16:49:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebook",
      "indices" : [ 69, 75 ]
    }, {
      "text" : "kindle",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ {
      "indices" : [ 49, 68 ],
      "url" : "http:\/\/t.co\/Vj4BBS6",
      "expanded_url" : "http:\/\/one-mystake-at-a-tyme.blogspot.com\/2011\/02\/let-giveaway-continue.html?spref=tw",
      "display_url" : "one-mystake-at-a-tyme.blogspot.com\/2011\/02\/let-gi\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "41898487666839552",
  "text" : "One Mystake at a Tyme: Let the Giveaway Continue http:\/\/t.co\/Vj4BBS6 #ebook #kindle",
  "id" : 41898487666839552,
  "created_at" : "2011-02-27 16:32:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41867568591536128",
  "text" : "RT @JulzMayBe: Good Morning!  May everyone have an amazing day today!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41866114132606978",
    "text" : "Good Morning!  May everyone have an amazing day today!!",
    "id" : 41866114132606978,
    "created_at" : "2011-02-27 14:23:54 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 41867568591536128,
  "created_at" : "2011-02-27 14:29:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "samplesunday",
      "indices" : [ 25, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41867348004712448",
  "text" : "Check out Indie Writers! #samplesunday http:\/\/budurl.com\/samplesunday",
  "id" : 41867348004712448,
  "created_at" : "2011-02-27 14:28:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 62, 72 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41716377307983872",
  "geo" : { },
  "id_str" : "41863090223972353",
  "in_reply_to_user_id" : 15572724,
  "text" : "I voted on plixi from where you linked pics. smooches 2 Saki! @ShhDragon",
  "id" : 41863090223972353,
  "in_reply_to_status_id" : 41716377307983872,
  "created_at" : "2011-02-27 14:11:53 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 42, 56 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 57, 67 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    }, {
      "name" : "adamsbaldwin",
      "screen_name" : "adamsbaldwin",
      "indices" : [ 68, 81 ],
      "id_str" : "1908147181",
      "id" : 1908147181
    }, {
      "name" : "Kimmy Smith",
      "screen_name" : "kimworleysmith",
      "indices" : [ 82, 97 ],
      "id_str" : "64601185",
      "id" : 64601185
    }, {
      "name" : "Katie",
      "screen_name" : "katie_aa",
      "indices" : [ 98, 107 ],
      "id_str" : "164070262",
      "id" : 164070262
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41680642731151360",
  "text" : "we're all learning together : ) nice post @BibleAlsoSays @ID_vs_EGO @adamsbaldwin @kimworleysmith @katie_aa",
  "id" : 41680642731151360,
  "created_at" : "2011-02-27 02:06:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 61, 74 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41661586779144194",
  "text" : "yeah, ppl r big on \"justice\"... sigh..that's a peeve of mine @CrystalLewis",
  "id" : 41661586779144194,
  "created_at" : "2011-02-27 00:51:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41661167126589440",
  "text" : "RT @CrystalLewis: 5.) Some anti-universalists are unable to get past the problem of *justice*, but forget that our *justice* is a flawed ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41658006550757376",
    "text" : "5.) Some anti-universalists are unable to get past the problem of *justice*, but forget that our *justice* is a flawed human construct(more)",
    "id" : 41658006550757376,
    "created_at" : "2011-02-27 00:36:57 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 41661167126589440,
  "created_at" : "2011-02-27 00:49:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41645200317235200",
  "text" : "why do ppl insult sheep so??",
  "id" : 41645200317235200,
  "created_at" : "2011-02-26 23:46:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41642004777672704",
  "text" : "pitiful.. I upped the screen to 144 so I can read the screen!",
  "id" : 41642004777672704,
  "created_at" : "2011-02-26 23:33:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 52, 62 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41605053986906113",
  "geo" : { },
  "id_str" : "41641606557872128",
  "in_reply_to_user_id" : 15572724,
  "text" : "I had to sign in to vote so I signed in via twitter @ShhDragon",
  "id" : 41641606557872128,
  "in_reply_to_status_id" : 41605053986906113,
  "created_at" : "2011-02-26 23:31:47 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 69, 79 ],
      "id_str" : "15572724",
      "id" : 15572724
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41605053986906113",
  "geo" : { },
  "id_str" : "41641433496551424",
  "in_reply_to_user_id" : 15572724,
  "text" : "above pic or to the right there are thumbs up or down,heart,FBlike.. @ShhDragon",
  "id" : 41641433496551424,
  "in_reply_to_status_id" : 41605053986906113,
  "created_at" : "2011-02-26 23:31:06 +0000",
  "in_reply_to_screen_name" : "ShhDragon",
  "in_reply_to_user_id_str" : "15572724",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 93, 103 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41637927566057472",
  "geo" : { },
  "id_str" : "41640951650721793",
  "in_reply_to_user_id" : 48215218,
  "text" : "Ive got lots of freebies, 99cent & 2.99 books. I \u26652 read in bed & its ezr 2 hold,turn pages. @bend_time",
  "id" : 41640951650721793,
  "in_reply_to_status_id" : 41637927566057472,
  "created_at" : "2011-02-26 23:29:11 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 106, 113 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41635365467070464",
  "text" : "finished Show No Mercy: A Michael Dodge Thriller by Brian Drake and gave it 3 stars http:\/\/amzn.to\/gAzTos #Kindle",
  "id" : 41635365467070464,
  "created_at" : "2011-02-26 23:06:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 91, 106 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41629631840915456",
  "geo" : { },
  "id_str" : "41629995944263680",
  "in_reply_to_user_id" : 63804234,
  "text" : "I have a lot of ppl from various forums on FB plus some fam. Im more vocal on twitter..lol @PeggySueCusses",
  "id" : 41629995944263680,
  "in_reply_to_status_id" : 41629631840915456,
  "created_at" : "2011-02-26 22:45:39 +0000",
  "in_reply_to_screen_name" : "PeggySueCusses",
  "in_reply_to_user_id_str" : "63804234",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41629154965340160",
  "text" : "law & order likes to make it all look black & white. drives me crazy!",
  "id" : 41629154965340160,
  "created_at" : "2011-02-26 22:42:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 3, 15 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41628797023436800",
  "text" : "RT @angelaharms: Maybe hell is something we create when we turn away from love? Seems more plausible than that some god made it as a pla ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41625673479098368",
    "text" : "Maybe hell is something we create when we turn away from love? Seems more plausible than that some god made it as a place for us to suffer.",
    "id" : 41625673479098368,
    "created_at" : "2011-02-26 22:28:28 +0000",
    "user" : {
      "name" : "Alex Harms",
      "screen_name" : "onealexharms",
      "protected" : false,
      "id_str" : "15349954",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/630207898816266240\/3wXyHNXk_normal.jpg",
      "id" : 15349954,
      "verified" : false
    }
  },
  "id" : 41628797023436800,
  "created_at" : "2011-02-26 22:40:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41628292557578240",
  "text" : "YouTube - flying girl in russian wood http:\/\/bit.ly\/dFXAfJ",
  "id" : 41628292557578240,
  "created_at" : "2011-02-26 22:38:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/plixi.com\" rel=\"nofollow\"\u003EPlixi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41595035468173312",
  "text" : "I just voted for this photo  http:\/\/plixi.com\/p\/71762723",
  "id" : 41595035468173312,
  "created_at" : "2011-02-26 20:26:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/plixi.com\" rel=\"nofollow\"\u003EPlixi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41594714125910016",
  "text" : "I just voted for this photo  http:\/\/plixi.com\/p\/72794460",
  "id" : 41594714125910016,
  "created_at" : "2011-02-26 20:25:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/plixi.com\" rel=\"nofollow\"\u003EPlixi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41594480532529152",
  "text" : "I just voted for this photo  http:\/\/plixi.com\/p\/77000898",
  "id" : 41594480532529152,
  "created_at" : "2011-02-26 20:24:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/plixi.com\" rel=\"nofollow\"\u003EPlixi\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41594339578617856",
  "text" : "I just voted for this photo  http:\/\/plixi.com\/p\/75448124",
  "id" : 41594339578617856,
  "created_at" : "2011-02-26 20:23:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 73, 87 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41589317822316544",
  "text" : "\"...you are existing in an odd assed alternate version of my reality.\" - @HEATHENRABBIT",
  "id" : 41589317822316544,
  "created_at" : "2011-02-26 20:04:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41581819321122816",
  "text" : "working on my site today...",
  "id" : 41581819321122816,
  "created_at" : "2011-02-26 19:34:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41342457442611201",
  "text" : "I need new eyes. laptop is blurry.",
  "id" : 41342457442611201,
  "created_at" : "2011-02-26 03:43:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "indices" : [ 3, 11 ],
      "id_str" : "50815971",
      "id" : 50815971
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41316703421992960",
  "text" : "RT @Palidan: \"To feel for others, to restrain our selfishness and exercise our benevolence, constitute the perfection of human nature.\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41315797343285248",
    "text" : "\"To feel for others, to restrain our selfishness and exercise our benevolence, constitute the perfection of human nature.\" Adam Smith",
    "id" : 41315797343285248,
    "created_at" : "2011-02-26 01:57:08 +0000",
    "user" : {
      "name" : "Michael A Williams",
      "screen_name" : "Palidan",
      "protected" : false,
      "id_str" : "50815971",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/747718513\/twitter_background_normal.jpg",
      "id" : 50815971,
      "verified" : false
    }
  },
  "id" : 41316703421992960,
  "created_at" : "2011-02-26 02:00:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41228775182188544",
  "text" : "RT @mindymayhem: The same people who told me not to disrepect our POTUS when Bush was in office say Obama has a secret muslim plan to ta ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ubersocial.com\" rel=\"nofollow\"\u003EUberSocial Pro for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "tcot",
        "indices" : [ 135, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41226734154031104",
    "text" : "The same people who told me not to disrepect our POTUS when Bush was in office say Obama has a secret muslim plan to take over the US. #tcot",
    "id" : 41226734154031104,
    "created_at" : "2011-02-25 20:03:14 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 41228775182188544,
  "created_at" : "2011-02-25 20:11:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    }, {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 19, 32 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 15, 18 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41191154976440320",
  "text" : "RT @DougDorow: #ff @genedoucette he's looking for bloggers\/reviewers to spread the word on his book Immortal.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gene Doucette",
        "screen_name" : "GeneDoucette",
        "indices" : [ 4, 17 ],
        "id_str" : "123068593",
        "id" : 123068593
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ff",
        "indices" : [ 0, 3 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41190717871235072",
    "text" : "#ff @genedoucette he's looking for bloggers\/reviewers to spread the word on his book Immortal.",
    "id" : 41190717871235072,
    "created_at" : "2011-02-25 17:40:07 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 41191154976440320,
  "created_at" : "2011-02-25 17:41:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 18, 32 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41190982515048448",
  "text" : "I agree with this @biblealsosays \"Believe it or not, the burning question now isn\u2019t whether God exists, but (cont) http:\/\/tl.gd\/90nbnf",
  "id" : 41190982515048448,
  "created_at" : "2011-02-25 17:41:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 64, 78 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41190025194512384",
  "text" : "absolutely. this I agree with. this thought got me \"past\" bible @BibleAlsoSays",
  "id" : 41190025194512384,
  "created_at" : "2011-02-25 17:37:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 22, 36 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Nanete Petersen",
      "screen_name" : "SWIMCREDIBLE",
      "indices" : [ 37, 50 ],
      "id_str" : "765711277138345984",
      "id" : 765711277138345984
    }, {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 61, 71 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41185123785375744",
  "text" : "yes.. heard about him @BibleAlsoSays @swimcredible @melsite1 @ID_vs_EGO",
  "id" : 41185123785375744,
  "created_at" : "2011-02-25 17:17:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 54, 68 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41184339962236928",
  "text" : "then futile 2 argue so hard against believers ; ) lol @BibleAlsoSays",
  "id" : 41184339962236928,
  "created_at" : "2011-02-25 17:14:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 113, 127 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41182486952157184",
  "text" : "good question. gut feeling. life experience. my belief in God & what God is has metamorphed a lot over the years @BibleAlsoSays",
  "id" : 41182486952157184,
  "created_at" : "2011-02-25 17:07:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41178184028397568",
  "text" : "RT @DarciaHelle: Still handing out free books. My arms are getting tired. Someone please come take them from me. http:\/\/j.mp\/gEgeg9 #giv ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaways",
        "indices" : [ 115, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41176317378568192",
    "text" : "Still handing out free books. My arms are getting tired. Someone please come take them from me. http:\/\/j.mp\/gEgeg9 #giveaways",
    "id" : 41176317378568192,
    "created_at" : "2011-02-25 16:42:53 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 41178184028397568,
  "created_at" : "2011-02-25 16:50:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 52, 66 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41174854510198784",
  "text" : "while I dont agree w it, would make a great Tshirt! @BibleAlsoSays",
  "id" : 41174854510198784,
  "created_at" : "2011-02-25 16:37:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41174309997121536",
  "text" : "RT @Dwayne_Reaves: RT @kcsfann: Your smallest act of kindness could be the biggest event in someones day. :))",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41173317197103104",
    "text" : "RT @kcsfann: Your smallest act of kindness could be the biggest event in someones day. :))",
    "id" : 41173317197103104,
    "created_at" : "2011-02-25 16:30:58 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 41174309997121536,
  "created_at" : "2011-02-25 16:34:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 4, 17 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 25, 39 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41165594791387136",
  "text" : "1 4 @neardeathdoc : ) RT @biblealsosays Some New Scientific facts or very soon to be facts: Near Death (cont) http:\/\/tl.gd\/90lsu4",
  "id" : 41165594791387136,
  "created_at" : "2011-02-25 16:00:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 25, 39 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41165227219357696",
  "text" : "will B intrstng 2 see RT @biblealsosays Some New Scientific facts or very soon to be facts:The\"Soul\"is an (cont) http:\/\/tl.gd\/90ls52",
  "id" : 41165227219357696,
  "created_at" : "2011-02-25 15:58:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 23, 38 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 39, 53 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "41160270818582528",
  "geo" : { },
  "id_str" : "41161691387543552",
  "in_reply_to_user_id" : 23757784,
  "text" : "good point martin! : ) @MartijnLinssen @BibleAlsoSays",
  "id" : 41161691387543552,
  "in_reply_to_status_id" : 41160270818582528,
  "created_at" : "2011-02-25 15:44:46 +0000",
  "in_reply_to_screen_name" : "MartijnLinssen",
  "in_reply_to_user_id_str" : "23757784",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 15, 29 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41159986449100801",
  "text" : "your proof? RT @biblealsosays Theres no way our\"Self\"resides outside of our Brain\/Body it is a direct result of (cont) http:\/\/tl.gd\/90lgd6",
  "id" : 41159986449100801,
  "created_at" : "2011-02-25 15:38:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 70, 81 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ff",
      "indices" : [ 46, 49 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41158752870604800",
  "text" : "TYVM ((hugs)) RT @darkelms: A forth and final #ff for this morning -- @moosebegab -- who can keep you up-to-date with all your indie ebooks.",
  "id" : 41158752870604800,
  "created_at" : "2011-02-25 15:33:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Martijn Linssen",
      "screen_name" : "MartijnLinssen",
      "indices" : [ 9, 24 ],
      "id_str" : "23757784",
      "id" : 23757784
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 26, 37 ],
      "id_str" : "93747129",
      "id" : 93747129
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 54, 68 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41158523857408000",
  "text" : "Proof RT @MartijnLinssen: @moosebegab: Clarify plz RT @BibleAlsoSays: Dualistic soul is impossible , because there is no soul?",
  "id" : 41158523857408000,
  "created_at" : "2011-02-25 15:32:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "free",
      "indices" : [ 48, 53 ]
    }, {
      "text" : "ebook",
      "indices" : [ 54, 60 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41157486815739904",
  "text" : "RT @byoung210: Want to solve a puzzle and win a #free #ebook! You can. Check out my site tomorrow at 12 pm EST. http:\/\/j.mp\/eorzKn #kind ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "free",
        "indices" : [ 33, 38 ]
      }, {
        "text" : "ebook",
        "indices" : [ 39, 45 ]
      }, {
        "text" : "kindle",
        "indices" : [ 116, 123 ]
      }, {
        "text" : "nook",
        "indices" : [ 124, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41156081258471424",
    "text" : "Want to solve a puzzle and win a #free #ebook! You can. Check out my site tomorrow at 12 pm EST. http:\/\/j.mp\/eorzKn #kindle #nook",
    "id" : 41156081258471424,
    "created_at" : "2011-02-25 15:22:29 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 41157486815739904,
  "created_at" : "2011-02-25 15:28:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 7, 21 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 23, 34 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41157092551299072",
  "text" : "Yes RT @BibleAlsoSays: @moosebegab There are many books on this subject now and a bunch coming out very soon, want a list?",
  "id" : 41157092551299072,
  "created_at" : "2011-02-25 15:26:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 15, 29 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41156910531096576",
  "text" : "Clarify plz RT @BibleAlsoSays: Dualistic soul is impossible",
  "id" : 41156910531096576,
  "created_at" : "2011-02-25 15:25:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wolfram|Alpha",
      "screen_name" : "Wolfram_Alpha",
      "indices" : [ 3, 17 ],
      "id_str" : "35005086",
      "id" : 35005086
    }, {
      "name" : "Wendy Boswell",
      "screen_name" : "wboswell",
      "indices" : [ 34, 43 ],
      "id_str" : "763877",
      "id" : 763877
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41154688120389633",
  "text" : "RT @Wolfram_Alpha: Great list! RT @wboswell: Ten Things You Can Do With Wolfram Alpha To Make You Look Like The Smartest Person in the R ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Wendy Boswell",
        "screen_name" : "wboswell",
        "indices" : [ 15, 24 ],
        "id_str" : "763877",
        "id" : 763877
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 121, 140 ],
        "url" : "http:\/\/t.co\/2blYiQ3",
        "expanded_url" : "http:\/\/websearch.about.com\/od\/enginesanddirectories\/tp\/wolfram-alpha.htm",
        "display_url" : "websearch.about.com\/od\/enginesandd\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "41154036652720128",
    "text" : "Great list! RT @wboswell: Ten Things You Can Do With Wolfram Alpha To Make You Look Like The Smartest Person in the Room http:\/\/t.co\/2blYiQ3",
    "id" : 41154036652720128,
    "created_at" : "2011-02-25 15:14:21 +0000",
    "user" : {
      "name" : "Wolfram|Alpha",
      "screen_name" : "Wolfram_Alpha",
      "protected" : false,
      "id_str" : "35005086",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489803647153217537\/NH6ZQxzT_normal.png",
      "id" : 35005086,
      "verified" : true
    }
  },
  "id" : 41154688120389633,
  "created_at" : "2011-02-25 15:16:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 61, 75 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41153109824778240",
  "text" : "think I missed something.. how does science prove \"no soul\"? @BibleAlsoSays",
  "id" : 41153109824778240,
  "created_at" : "2011-02-25 15:10:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41150493497626624",
  "text" : "RT @TyrusBooks: FREE EBOOKS are available until 12 p.m. (Central). Go through the motions of buying from our site, enter promo code \"rea ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41145178752430080",
    "text" : "FREE EBOOKS are available until 12 p.m. (Central). Go through the motions of buying from our site, enter promo code \"readmore\" for 100% off.",
    "id" : 41145178752430080,
    "created_at" : "2011-02-25 14:39:09 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 41150493497626624,
  "created_at" : "2011-02-25 15:00:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Immortal",
      "screen_name" : "AdamtheImmortal",
      "indices" : [ 3, 19 ],
      "id_str" : "123093858",
      "id" : 123093858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "41137656918327296",
  "text" : "RT @AdamtheImmortal: But education is like clean drinking water: it's easy to forget what it was like before you had it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "41136982717501440",
    "text" : "But education is like clean drinking water: it's easy to forget what it was like before you had it.",
    "id" : 41136982717501440,
    "created_at" : "2011-02-25 14:06:35 +0000",
    "user" : {
      "name" : "Adam Immortal",
      "screen_name" : "AdamtheImmortal",
      "protected" : false,
      "id_str" : "123093858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822528305\/01.early.history_normal.jpeg",
      "id" : 123093858,
      "verified" : false
    }
  },
  "id" : 41137656918327296,
  "created_at" : "2011-02-25 14:09:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40958870042058752",
  "text" : "zombie pit was so much fun!!",
  "id" : 40958870042058752,
  "created_at" : "2011-02-25 02:18:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 40, 53 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40918880067141632",
  "geo" : { },
  "id_str" : "40920856142024704",
  "in_reply_to_user_id" : 123068593,
  "text" : "cuz its just too funny to watch you ; ) @GeneDoucette",
  "id" : 40920856142024704,
  "in_reply_to_status_id" : 40918880067141632,
  "created_at" : "2011-02-24 23:47:47 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Daniel",
      "screen_name" : "InnerWorth",
      "indices" : [ 23, 34 ],
      "id_str" : "76257178",
      "id" : 76257178
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40833690955157504",
  "text" : "RT @mssuzcatsilver: RT @InnerWorth: Tripped over my shadow, and fell into the Light......",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Daniel",
        "screen_name" : "InnerWorth",
        "indices" : [ 3, 14 ],
        "id_str" : "76257178",
        "id" : 76257178
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40829806333399040",
    "text" : "RT @InnerWorth: Tripped over my shadow, and fell into the Light......",
    "id" : 40829806333399040,
    "created_at" : "2011-02-24 17:45:59 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 40833690955157504,
  "created_at" : "2011-02-24 18:01:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40803033952559104",
  "geo" : { },
  "id_str" : "40810124368936960",
  "in_reply_to_user_id" : 113395189,
  "text" : "I \u2665 your kitties @Jeansandpolo",
  "id" : 40810124368936960,
  "in_reply_to_status_id" : 40803033952559104,
  "created_at" : "2011-02-24 16:27:46 +0000",
  "in_reply_to_screen_name" : "ThisBlueWorld",
  "in_reply_to_user_id_str" : "113395189",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allow Happiness",
      "screen_name" : "AllowHappiness",
      "indices" : [ 3, 18 ],
      "id_str" : "47121030",
      "id" : 47121030
    }, {
      "name" : "Steven Farmer",
      "screen_name" : "DrStevenFarmer",
      "indices" : [ 89, 104 ],
      "id_str" : "47465764",
      "id" : 47465764
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40793915921539072",
  "text" : "RT @allowhappiness: \"There are no facts, only interpretations.\"  ~Friedrich Nietzsche RT @DrStevenFarmer",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Steven Farmer",
        "screen_name" : "DrStevenFarmer",
        "indices" : [ 69, 84 ],
        "id_str" : "47465764",
        "id" : 47465764
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40792263994900482",
    "text" : "\"There are no facts, only interpretations.\"  ~Friedrich Nietzsche RT @DrStevenFarmer",
    "id" : 40792263994900482,
    "created_at" : "2011-02-24 15:16:48 +0000",
    "user" : {
      "name" : "Allow Happiness",
      "screen_name" : "AllowHappiness",
      "protected" : false,
      "id_str" : "47121030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654135358435688448\/sk_Xk1CG_normal.jpg",
      "id" : 47121030,
      "verified" : false
    }
  },
  "id" : 40793915921539072,
  "created_at" : "2011-02-24 15:23:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Doris Koren",
      "screen_name" : "csareb",
      "indices" : [ 3, 10 ],
      "id_str" : "53754783",
      "id" : 53754783
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40792514969477120",
  "text" : "RT @csareb: Did you know that Toronto is the raccoon capital of the world? It has 150 raccoons per square kilometer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40790779714748416",
    "text" : "Did you know that Toronto is the raccoon capital of the world? It has 150 raccoons per square kilometer.",
    "id" : 40790779714748416,
    "created_at" : "2011-02-24 15:10:54 +0000",
    "user" : {
      "name" : "Doris Koren",
      "screen_name" : "csareb",
      "protected" : false,
      "id_str" : "53754783",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000589977131\/34d3a7c4c94e678f3580fa6fe54f9573_normal.jpeg",
      "id" : 53754783,
      "verified" : false
    }
  },
  "id" : 40792514969477120,
  "created_at" : "2011-02-24 15:17:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pixel of Ink",
      "screen_name" : "PixelofInk",
      "indices" : [ 3, 14 ],
      "id_str" : "190004285",
      "id" : 190004285
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Knitting",
      "indices" : [ 38, 47 ]
    }, {
      "text" : "under1bargainbin",
      "indices" : [ 100, 117 ]
    }, {
      "text" : "craftshobbies",
      "indices" : [ 118, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40792459202002944",
  "text" : "RT @PixelofInk: [Bargain Kindle Book] #Knitting For Dummies \u2013 Only 99 Cents! http:\/\/goo.gl\/fb\/kZtxl #under1bargainbin #craftshobbies",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.google.com\/\" rel=\"nofollow\"\u003EGoogle\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Knitting",
        "indices" : [ 22, 31 ]
      }, {
        "text" : "under1bargainbin",
        "indices" : [ 84, 101 ]
      }, {
        "text" : "craftshobbies",
        "indices" : [ 102, 116 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40790911189254144",
    "text" : "[Bargain Kindle Book] #Knitting For Dummies \u2013 Only 99 Cents! http:\/\/goo.gl\/fb\/kZtxl #under1bargainbin #craftshobbies",
    "id" : 40790911189254144,
    "created_at" : "2011-02-24 15:11:25 +0000",
    "user" : {
      "name" : "Pixel of Ink",
      "screen_name" : "PixelofInk",
      "protected" : false,
      "id_str" : "190004285",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1954428066\/PixelOfInk_Avatar_200x200_normal.png",
      "id" : 190004285,
      "verified" : false
    }
  },
  "id" : 40792459202002944,
  "created_at" : "2011-02-24 15:17:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40771294567866368",
  "text" : "RT @Buddhaworld: you are what you think, so trust who you are.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40762479684489216",
    "text" : "you are what you think, so trust who you are.",
    "id" : 40762479684489216,
    "created_at" : "2011-02-24 13:18:27 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 40771294567866368,
  "created_at" : "2011-02-24 13:53:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40770234793074688",
  "text" : "RT @Soulseedzforall: Just when the caterpillar thought the world was over, it became a butterfly.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40769570142691328",
    "text" : "Just when the caterpillar thought the world was over, it became a butterfly.",
    "id" : 40769570142691328,
    "created_at" : "2011-02-24 13:46:37 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 40770234793074688,
  "created_at" : "2011-02-24 13:49:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Glitz boutique",
      "screen_name" : "RiyaneW",
      "indices" : [ 3, 11 ],
      "id_str" : "505273589",
      "id" : 505273589
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40750246073991168",
  "text" : "RT @riyanew: When you mess things up, never say \"OOPS!\" Always say \"Ah, Interesting!\" =D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.twitgether.com\" rel=\"nofollow\"\u003Etwitgether\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40658620748283904",
    "text" : "When you mess things up, never say \"OOPS!\" Always say \"Ah, Interesting!\" =D",
    "id" : 40658620748283904,
    "created_at" : "2011-02-24 06:25:45 +0000",
    "user" : {
      "name" : "\u221E",
      "screen_name" : "riane__",
      "protected" : false,
      "id_str" : "28478541",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/495208745388236801\/iqKnCmVH_normal.jpeg",
      "id" : 28478541,
      "verified" : false
    }
  },
  "id" : 40750246073991168,
  "created_at" : "2011-02-24 12:29:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40611234676088832",
  "text" : "sometimes it seems like I can actually see my awareness growing. fascinating...",
  "id" : 40611234676088832,
  "created_at" : "2011-02-24 03:17:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40598244081938432",
  "text" : "RT @scottsigler: Good writing: When you make someone that you've never met care deeply about someone that never existed.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40597395771232257",
    "text" : "Good writing: When you make someone that you've never met care deeply about someone that never existed.",
    "id" : 40597395771232257,
    "created_at" : "2011-02-24 02:22:28 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 40598244081938432,
  "created_at" : "2011-02-24 02:25:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40593190218244096",
  "text" : "RT @TyrusBooks: I'm gonna tell you like Casmir told me, \"It don't matter how much gas costs, learn to be happy where you're at, young buck.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40591522365710336",
    "text" : "I'm gonna tell you like Casmir told me, \"It don't matter how much gas costs, learn to be happy where you're at, young buck.\"",
    "id" : 40591522365710336,
    "created_at" : "2011-02-24 01:59:07 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 40593190218244096,
  "created_at" : "2011-02-24 02:05:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40591012246069248",
  "text" : "RT @PortalChronicle: My dog is whining at me because I put her food in a new bowl. She doesn't like it :( and won't eat her bacon.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40590237369368576",
    "text" : "My dog is whining at me because I put her food in a new bowl. She doesn't like it :( and won't eat her bacon.",
    "id" : 40590237369368576,
    "created_at" : "2011-02-24 01:54:01 +0000",
    "user" : {
      "name" : "IMOGEN ROSE",
      "screen_name" : "ImogenRoseTweet",
      "protected" : false,
      "id_str" : "102568232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1265710799\/profile1_normal.jpg",
      "id" : 102568232,
      "verified" : false
    }
  },
  "id" : 40591012246069248,
  "created_at" : "2011-02-24 01:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "jen",
      "screen_name" : "jennyrecommends",
      "indices" : [ 22, 38 ],
      "id_str" : "22444210",
      "id" : 22444210
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40590828103540736",
  "text" : "RT @Dwayne_Reaves: RT @JennyRecommends: Twitter makes talking to myself feel a little less lonely.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "jen",
        "screen_name" : "jennyrecommends",
        "indices" : [ 3, 19 ],
        "id_str" : "22444210",
        "id" : 22444210
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40586749444890624",
    "text" : "RT @JennyRecommends: Twitter makes talking to myself feel a little less lonely.",
    "id" : 40586749444890624,
    "created_at" : "2011-02-24 01:40:09 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 40590828103540736,
  "created_at" : "2011-02-24 01:56:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40585284001337344",
  "text" : "RT @derekrootboy: Twitter says it's reasonable everyone's unique follow limit is kept from them. http:\/\/twitter.com\/#!\/derekrootboy\/stat ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40569442681233408",
    "text" : "Twitter says it's reasonable everyone's unique follow limit is kept from them. http:\/\/twitter.com\/#!\/derekrootboy\/status\/40568379706187776",
    "id" : 40569442681233408,
    "created_at" : "2011-02-24 00:31:23 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 40585284001337344,
  "created_at" : "2011-02-24 01:34:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "iBird Explorer",
      "screen_name" : "iBirdExplorer",
      "indices" : [ 3, 17 ],
      "id_str" : "19044595",
      "id" : 19044595
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40581659522764800",
  "text" : "RT @iBirdExplorer: Wonderful Story to Share. About a bird in a church. http:\/\/bit.ly\/hbPD9l",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/seesmic_desktop\/sd2\" rel=\"nofollow\"\u003ESeesmic Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40579417017155584",
    "text" : "Wonderful Story to Share. About a bird in a church. http:\/\/bit.ly\/hbPD9l",
    "id" : 40579417017155584,
    "created_at" : "2011-02-24 01:11:01 +0000",
    "user" : {
      "name" : "iBird Explorer",
      "screen_name" : "iBirdExplorer",
      "protected" : false,
      "id_str" : "19044595",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/103983092\/iBird_Plus_normal.png",
      "id" : 19044595,
      "verified" : false
    }
  },
  "id" : 40581659522764800,
  "created_at" : "2011-02-24 01:19:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40578978527842304",
  "text" : "Libyan pilots refuse to bomb city, eject from plane http:\/\/bit.ly\/eIcbJZ",
  "id" : 40578978527842304,
  "created_at" : "2011-02-24 01:09:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "indices" : [ 3, 12 ],
      "id_str" : "77888423",
      "id" : 77888423
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40536038636134400",
  "text" : "RT @OMGFacts: This BAT is the size of a HUMAN! Look! --&gt; http:\/\/bit.ly\/eociaA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/tplus.me\" rel=\"nofollow\"\u003EtPlus.me\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40533389668777984",
    "text" : "This BAT is the size of a HUMAN! Look! --&gt; http:\/\/bit.ly\/eociaA",
    "id" : 40533389668777984,
    "created_at" : "2011-02-23 22:08:07 +0000",
    "user" : {
      "name" : "OMG Facts",
      "screen_name" : "OMGFacts",
      "protected" : false,
      "id_str" : "77888423",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/766714587156738048\/jXuhWZ0-_normal.jpg",
      "id" : 77888423,
      "verified" : true
    }
  },
  "id" : 40536038636134400,
  "created_at" : "2011-02-23 22:18:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TK",
      "screen_name" : "GodsDontExist",
      "indices" : [ 49, 63 ],
      "id_str" : "4770922980",
      "id" : 4770922980
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40532688221769728",
  "text" : "hmm.. dont see it but she does seem interesting! @GodsDontExist",
  "id" : 40532688221769728,
  "created_at" : "2011-02-23 22:05:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40531047791861760",
  "text" : "my eyes are just not working today. cant focus at all w both eyes.",
  "id" : 40531047791861760,
  "created_at" : "2011-02-23 21:58:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40487309606518784",
  "text" : "RT @thesexyatheist: The crazy just got crazier (and I thought that was impossible). http:\/\/bit.ly\/etvw2f  Georgia proposes death penalty ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40486145548619776",
    "text" : "The crazy just got crazier (and I thought that was impossible). http:\/\/bit.ly\/etvw2f  Georgia proposes death penalty for miscarriages.",
    "id" : 40486145548619776,
    "created_at" : "2011-02-23 19:00:23 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 40487309606518784,
  "created_at" : "2011-02-23 19:05:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "FeistyBlonde",
      "screen_name" : "1FeistyBlonde",
      "indices" : [ 22, 36 ],
      "id_str" : "776301329345982464",
      "id" : 776301329345982464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40475449574424577",
  "text" : "RT @Dwayne_Reaves: RT @1feistyblonde: I've spent the last month researching my family tree...so far I've found 3 squirrels and a whole b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "FeistyBlonde",
        "screen_name" : "1FeistyBlonde",
        "indices" : [ 3, 17 ],
        "id_str" : "776301329345982464",
        "id" : 776301329345982464
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40474965580972032",
    "text" : "RT @1feistyblonde: I've spent the last month researching my family tree...so far I've found 3 squirrels and a whole bunch of nuts!",
    "id" : 40474965580972032,
    "created_at" : "2011-02-23 18:15:58 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 40475449574424577,
  "created_at" : "2011-02-23 18:17:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 33, 40 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40472317746352128",
  "geo" : { },
  "id_str" : "40475330766577664",
  "in_reply_to_user_id" : 122393631,
  "text" : "hmm.. there is no correct answer @SsmDad",
  "id" : 40475330766577664,
  "in_reply_to_status_id" : 40472317746352128,
  "created_at" : "2011-02-23 18:17:25 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Graham",
      "screen_name" : "MaxGraham",
      "indices" : [ 3, 13 ],
      "id_str" : "15574534",
      "id" : 15574534
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40474628824641536",
  "text" : "RT @MaxGraham: I hear ppl say \"the $ spent on A (war etc) could have been used to solve B!! (hunger etc)!\" but since B doesn't \"profit\"  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterrific.com\" rel=\"nofollow\"\u003ETwitterrific for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40460476655742976",
    "text" : "I hear ppl say \"the $ spent on A (war etc) could have been used to solve B!! (hunger etc)!\" but since B doesn't \"profit\" its nevr gonna hpn.",
    "id" : 40460476655742976,
    "created_at" : "2011-02-23 17:18:24 +0000",
    "user" : {
      "name" : "Max Graham",
      "screen_name" : "MaxGraham",
      "protected" : false,
      "id_str" : "15574534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755423478140899329\/2nNjROz9_normal.jpg",
      "id" : 15574534,
      "verified" : true
    }
  },
  "id" : 40474628824641536,
  "created_at" : "2011-02-23 18:14:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40474385395630080",
  "text" : "RT @Wylieknowords: \"Your Tweetstream is empirical data--yet more; metaphors and memories--a view. Part of your world.\" N. Wylie Jones  w ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40461871718993920",
    "text" : "\"Your Tweetstream is empirical data--yet more; metaphors and memories--a view. Part of your world.\" N. Wylie Jones  www.knowords.com",
    "id" : 40461871718993920,
    "created_at" : "2011-02-23 17:23:56 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 40474385395630080,
  "created_at" : "2011-02-23 18:13:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    }, {
      "name" : "Dabney Porte",
      "screen_name" : "DabneyPorte",
      "indices" : [ 22, 34 ],
      "id_str" : "17543438",
      "id" : 17543438
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40473684384681984",
  "text" : "RT @Dwayne_Reaves: RT @DabneyPorte: Any fool can criticize, condemn and complain and most fools do. By Benjamin Franklin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dabney Porte",
        "screen_name" : "DabneyPorte",
        "indices" : [ 3, 15 ],
        "id_str" : "17543438",
        "id" : 17543438
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40466876207341568",
    "text" : "RT @DabneyPorte: Any fool can criticize, condemn and complain and most fools do. By Benjamin Franklin",
    "id" : 40466876207341568,
    "created_at" : "2011-02-23 17:43:49 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 40473684384681984,
  "created_at" : "2011-02-23 18:10:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "indices" : [ 3, 16 ],
      "id_str" : "95730042",
      "id" : 95730042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BookPromotion",
      "indices" : [ 69, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40473631406424065",
  "text" : "RT @GoblinWriter: Twitter Basics for Authors -- http:\/\/bit.ly\/e5JtQc #BookPromotion",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BookPromotion",
        "indices" : [ 51, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40466943102287872",
    "text" : "Twitter Basics for Authors -- http:\/\/bit.ly\/e5JtQc #BookPromotion",
    "id" : 40466943102287872,
    "created_at" : "2011-02-23 17:44:05 +0000",
    "user" : {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "protected" : false,
      "id_str" : "95730042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1558192985\/goblin-pic_normal.jpg",
      "id" : 95730042,
      "verified" : false
    }
  },
  "id" : 40473631406424065,
  "created_at" : "2011-02-23 18:10:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 38, 45 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40473122037567488",
  "text" : "RT @byoung210: Do you like the recent #Kindle update? Vote now! http:\/\/wp.me\/p15Plj-4E",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 23, 30 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40468453601198080",
    "text" : "Do you like the recent #Kindle update? Vote now! http:\/\/wp.me\/p15Plj-4E",
    "id" : 40468453601198080,
    "created_at" : "2011-02-23 17:50:05 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 40473122037567488,
  "created_at" : "2011-02-23 18:08:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40458089358426112",
  "text" : "RT @PeggySueCusses: It's funny though I work for 10 minutes and break for 30 minutes. I think that may be backwards but it works for me. =)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40457477875171329",
    "text" : "It's funny though I work for 10 minutes and break for 30 minutes. I think that may be backwards but it works for me. =)",
    "id" : 40457477875171329,
    "created_at" : "2011-02-23 17:06:29 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 40458089358426112,
  "created_at" : "2011-02-23 17:08:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GlobalHealingCenter",
      "screen_name" : "GHChealth",
      "indices" : [ 3, 13 ],
      "id_str" : "19082879",
      "id" : 19082879
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "su",
      "indices" : [ 81, 84 ]
    }, {
      "text" : "nutrition",
      "indices" : [ 85, 95 ]
    }, {
      "text" : "wellnesswed",
      "indices" : [ 96, 108 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40453589830733824",
  "text" : "RT @GHChealth: Top 10 Probiotic Foods to Add to Your Diet - http:\/\/su.pr\/3Xd5hl \u007B#su #nutrition #wellnesswed\u007D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "su",
        "indices" : [ 66, 69 ]
      }, {
        "text" : "nutrition",
        "indices" : [ 70, 80 ]
      }, {
        "text" : "wellnesswed",
        "indices" : [ 81, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40450905958518784",
    "text" : "Top 10 Probiotic Foods to Add to Your Diet - http:\/\/su.pr\/3Xd5hl \u007B#su #nutrition #wellnesswed\u007D",
    "id" : 40450905958518784,
    "created_at" : "2011-02-23 16:40:22 +0000",
    "user" : {
      "name" : "GlobalHealingCenter",
      "screen_name" : "GHChealth",
      "protected" : false,
      "id_str" : "19082879",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/672813924253753344\/uRKqCkzy_normal.jpg",
      "id" : 19082879,
      "verified" : false
    }
  },
  "id" : 40453589830733824,
  "created_at" : "2011-02-23 16:51:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40452349067661312",
  "text" : "great. now I cant mute tv. waiting 4 song 2 play again so I can find it!",
  "id" : 40452349067661312,
  "created_at" : "2011-02-23 16:46:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 34, 46 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40442644240928768",
  "geo" : { },
  "id_str" : "40447512791879680",
  "in_reply_to_user_id" : 15349954,
  "text" : "what a beautiful baby... ((hugs)) @angelaharms",
  "id" : 40447512791879680,
  "in_reply_to_status_id" : 40442644240928768,
  "created_at" : "2011-02-23 16:26:53 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40435865608130560",
  "text" : "liked a song on the weather channel. will go crazy trying to find it.",
  "id" : 40435865608130560,
  "created_at" : "2011-02-23 15:40:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 27, 46 ],
      "url" : "http:\/\/t.co\/sXAkPdX",
      "expanded_url" : "http:\/\/www.thereformedbuddhist.com\/2011\/02\/arizona-state-of-disgrace.html?spref=tw",
      "display_url" : "thereformedbuddhist.com\/2011\/02\/arizon\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "40427861252915200",
  "text" : "Arizona wants to ban Karma http:\/\/t.co\/sXAkPdX",
  "id" : 40427861252915200,
  "created_at" : "2011-02-23 15:08:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Allow Happiness",
      "screen_name" : "AllowHappiness",
      "indices" : [ 3, 18 ],
      "id_str" : "47121030",
      "id" : 47121030
    }, {
      "name" : "Christina Merkley",
      "screen_name" : "ChristinaMerk",
      "indices" : [ 23, 37 ],
      "id_str" : "15428012",
      "id" : 15428012
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40424606049382400",
  "text" : "RT @allowhappiness: RT @ChristinaMerk: [busted!] \"Complaining about complaining is also complaining\" ~Abraham-Hicks",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Christina Merkley",
        "screen_name" : "ChristinaMerk",
        "indices" : [ 3, 17 ],
        "id_str" : "15428012",
        "id" : 15428012
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40423210382135296",
    "text" : "RT @ChristinaMerk: [busted!] \"Complaining about complaining is also complaining\" ~Abraham-Hicks",
    "id" : 40423210382135296,
    "created_at" : "2011-02-23 14:50:19 +0000",
    "user" : {
      "name" : "Allow Happiness",
      "screen_name" : "AllowHappiness",
      "protected" : false,
      "id_str" : "47121030",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/654135358435688448\/sk_Xk1CG_normal.jpg",
      "id" : 47121030,
      "verified" : false
    }
  },
  "id" : 40424606049382400,
  "created_at" : "2011-02-23 14:55:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40209170116378624",
  "text" : "Menus of the Future http:\/\/bit.ly\/elchIV",
  "id" : 40209170116378624,
  "created_at" : "2011-02-23 00:39:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40189381402824704",
  "text" : "RT @ZachsMind: Dear Governments Of Earth: Shooting at your own citizens is not good governing. It's more like poor gardening. Treating f ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40188556165124096",
    "text" : "Dear Governments Of Earth: Shooting at your own citizens is not good governing. It's more like poor gardening. Treating flowers like weeds.",
    "id" : 40188556165124096,
    "created_at" : "2011-02-22 23:17:53 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 40189381402824704,
  "created_at" : "2011-02-22 23:21:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40188295321370624",
  "text" : "RT @fearfuldogs: punishing a dog 4 being scared, even if they r behaving badly doesn't make any sense! tssss yourself.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40184745530753024",
    "text" : "punishing a dog 4 being scared, even if they r behaving badly doesn't make any sense! tssss yourself.",
    "id" : 40184745530753024,
    "created_at" : "2011-02-22 23:02:44 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 40188295321370624,
  "created_at" : "2011-02-22 23:16:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 14, 26 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40157826407989248",
  "geo" : { },
  "id_str" : "40163208539029504",
  "in_reply_to_user_id" : 90733366,
  "text" : "thanks hun. \u2665 @AlisynGayle",
  "id" : 40163208539029504,
  "in_reply_to_status_id" : 40157826407989248,
  "created_at" : "2011-02-22 21:37:09 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 55, 67 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40144695631941632",
  "geo" : { },
  "id_str" : "40146335348957184",
  "in_reply_to_user_id" : 90733366,
  "text" : "wondering if thats it. so I guess abx wldnt help that. @AlisynGayle",
  "id" : 40146335348957184,
  "in_reply_to_status_id" : 40144695631941632,
  "created_at" : "2011-02-22 20:30:06 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 97, 108 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40144809691713537",
  "geo" : { },
  "id_str" : "40145904405200896",
  "in_reply_to_user_id" : 176864114,
  "text" : "if I eat a fatty meal & feel \"off\" it sometimes helps. wld drink apple juice 4 gallstone attacks @mimismutts",
  "id" : 40145904405200896,
  "in_reply_to_status_id" : 40144809691713537,
  "created_at" : "2011-02-22 20:28:24 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40144064682663936",
  "text" : "I often get discomfort in sinus area but no congestion...",
  "id" : 40144064682663936,
  "created_at" : "2011-02-22 20:21:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 17, 28 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40142314991001601",
  "geo" : { },
  "id_str" : "40143083936948224",
  "in_reply_to_user_id" : 176864114,
  "text" : "1tb to 8oz water @mimismutts sometimes hard to tell whats upsetting my system... blah.",
  "id" : 40143083936948224,
  "in_reply_to_status_id" : 40142314991001601,
  "created_at" : "2011-02-22 20:17:11 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40140092957925376",
  "text" : "bleh.",
  "id" : 40140092957925376,
  "created_at" : "2011-02-22 20:05:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40139734042812416",
  "text" : "wonder if its the ACV upsetting my tummy? havent had any awhile then drank some today.",
  "id" : 40139734042812416,
  "created_at" : "2011-02-22 20:03:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "indices" : [ 3, 13 ],
      "id_str" : "126764612",
      "id" : 126764612
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40138189859586048",
  "text" : "RT @RuffHaven: We have room for 3 more dogs. Ruffhaven is a private Sanctuary located in Maryland. \n10 dog limit -  so they receive the  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40137176754827264",
    "text" : "We have room for 3 more dogs. Ruffhaven is a private Sanctuary located in Maryland. \n10 dog limit -  so they receive the best possible care.",
    "id" : 40137176754827264,
    "created_at" : "2011-02-22 19:53:43 +0000",
    "user" : {
      "name" : "Marianne",
      "screen_name" : "RuffHaven",
      "protected" : false,
      "id_str" : "126764612",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/459086546319056896\/W1rXvAEz_normal.jpeg",
      "id" : 126764612,
      "verified" : false
    }
  },
  "id" : 40138189859586048,
  "created_at" : "2011-02-22 19:57:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40118397031157761",
  "text" : "Why We Need Government-Run Universal Socialized Health Insurance http:\/\/bit.ly\/gDLyHL",
  "id" : 40118397031157761,
  "created_at" : "2011-02-22 18:39:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40107048234393601",
  "text" : "BILL MOYERS JOURNAL Single Payer Health Insurance PBS http:\/\/bit.ly\/fkVLuP",
  "id" : 40107048234393601,
  "created_at" : "2011-02-22 17:54:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "indices" : [ 3, 13 ],
      "id_str" : "24636191",
      "id" : 24636191
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40096799729393664",
  "text" : "RT @LukeRomyn: Big bodies need bigger holes to bury them. Remember that when your spouse tries to get you to go on a diet.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40087823910576128",
    "text" : "Big bodies need bigger holes to bury them. Remember that when your spouse tries to get you to go on a diet.",
    "id" : 40087823910576128,
    "created_at" : "2011-02-22 16:37:36 +0000",
    "user" : {
      "name" : "Luke Romyn",
      "screen_name" : "LukeRomyn",
      "protected" : false,
      "id_str" : "24636191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/775603198677495808\/ok1qt3uy_normal.jpg",
      "id" : 24636191,
      "verified" : false
    }
  },
  "id" : 40096799729393664,
  "created_at" : "2011-02-22 17:13:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryl Sedore",
      "screen_name" : "DarylSedore",
      "indices" : [ 3, 15 ],
      "id_str" : "3419972170",
      "id" : 3419972170
    }, {
      "name" : "gary ponzo",
      "screen_name" : "AuthorPonzo",
      "indices" : [ 20, 32 ],
      "id_str" : "94497610",
      "id" : 94497610
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40083606684700672",
  "text" : "RT @darylsedore: RT @AuthorPonzo: Send your opening line and receive $25 Amazon Gift Card if you win.  So far only 7 entries.  http:\/\/bi ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "gary ponzo",
        "screen_name" : "AuthorPonzo",
        "indices" : [ 3, 15 ],
        "id_str" : "94497610",
        "id" : 94497610
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40067785933463552",
    "text" : "RT @AuthorPonzo: Send your opening line and receive $25 Amazon Gift Card if you win.  So far only 7 entries.  http:\/\/bit.ly\/hNwKJZ",
    "id" : 40067785933463552,
    "created_at" : "2011-02-22 15:17:59 +0000",
    "user" : {
      "name" : "Jonas Saul",
      "screen_name" : "jonassaul",
      "protected" : false,
      "id_str" : "127322699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1568329636\/Jonas-Saul_normal.jpg",
      "id" : 127322699,
      "verified" : false
    }
  },
  "id" : 40083606684700672,
  "created_at" : "2011-02-22 16:20:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "indices" : [ 3, 17 ],
      "id_str" : "253228348",
      "id" : 253228348
    }, {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "indices" : [ 103, 117 ],
      "id_str" : "253228348",
      "id" : 253228348
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40083296713048064",
  "text" : "RT @GreyMuzzleOrg: Hey all u spry, tweeter-pups out there, can u help us old dogs find more followers? @GreyMuzzleOrg is new 2 Twitter b ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "GreyMuzzleOrg",
        "screen_name" : "GreyMuzzleOrg",
        "indices" : [ 84, 98 ],
        "id_str" : "253228348",
        "id" : 253228348
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40071385212665856",
    "text" : "Hey all u spry, tweeter-pups out there, can u help us old dogs find more followers? @GreyMuzzleOrg is new 2 Twitter but loyal 2 old dogs.",
    "id" : 40071385212665856,
    "created_at" : "2011-02-22 15:32:17 +0000",
    "user" : {
      "name" : "GreyMuzzleOrg",
      "screen_name" : "GreyMuzzleOrg",
      "protected" : false,
      "id_str" : "253228348",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/770761270416908289\/ZOXprD-__normal.jpg",
      "id" : 253228348,
      "verified" : false
    }
  },
  "id" : 40083296713048064,
  "created_at" : "2011-02-22 16:19:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40082711926423552",
  "text" : "RT @scottsigler: If it's wrong for people to do it to you, it's wrong for you to do it to other people. Apply at will to politics\/racism ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40077039427911680",
    "text" : "If it's wrong for people to do it to you, it's wrong for you to do it to other people. Apply at will to politics\/racism\/sexism.",
    "id" : 40077039427911680,
    "created_at" : "2011-02-22 15:54:45 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 40082711926423552,
  "created_at" : "2011-02-22 16:17:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40062245757140992",
  "text" : "RT @morsemusings: Each new day is a blank page in the diary of your life. -Douglas Pagels",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40061692406665216",
    "text" : "Each new day is a blank page in the diary of your life. -Douglas Pagels",
    "id" : 40061692406665216,
    "created_at" : "2011-02-22 14:53:46 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 40062245757140992,
  "created_at" : "2011-02-22 14:55:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 94, 110 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "paranormal",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "mystery",
      "indices" : [ 63, 71 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40060886999629824",
  "text" : "RT @indiebooksblog: RT to enter for $10 gift cert: #paranormal #mystery TRANSPARENT LOVERS by @hauntedcomputer http:\/\/amzn.to\/frO8WB #ki ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Counting Bankroll",
        "screen_name" : "hauntedcomputer",
        "indices" : [ 74, 90 ],
        "id_str" : "2553401966",
        "id" : 2553401966
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "paranormal",
        "indices" : [ 31, 42 ]
      }, {
        "text" : "mystery",
        "indices" : [ 43, 51 ]
      }, {
        "text" : "kindle",
        "indices" : [ 113, 120 ]
      }, {
        "text" : "romance",
        "indices" : [ 121, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40057430318514176",
    "text" : "RT to enter for $10 gift cert: #paranormal #mystery TRANSPARENT LOVERS by @hauntedcomputer http:\/\/amzn.to\/frO8WB #kindle #romance",
    "id" : 40057430318514176,
    "created_at" : "2011-02-22 14:36:50 +0000",
    "user" : {
      "name" : "eBooks Blog",
      "screen_name" : "ebooksblog",
      "protected" : false,
      "id_str" : "152238836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1020901565\/HC_logo_normal.jpg",
      "id" : 152238836,
      "verified" : false
    }
  },
  "id" : 40060886999629824,
  "created_at" : "2011-02-22 14:50:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 60, 72 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "40056975018434561",
  "geo" : { },
  "id_str" : "40057601425281024",
  "in_reply_to_user_id" : 90733366,
  "text" : "hubby should be able to claim me as dependent.. really! lol @AlisynGayle",
  "id" : 40057601425281024,
  "in_reply_to_status_id" : 40056975018434561,
  "created_at" : "2011-02-22 14:37:31 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40055926669053953",
  "text" : "Hubby has play date today. I'm glad he gets to play but I miss him when he's not here. Who will take care of me?",
  "id" : 40055926669053953,
  "created_at" : "2011-02-22 14:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "indices" : [ 3, 15 ],
      "id_str" : "45727491",
      "id" : 45727491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ereader",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40053611266449408",
  "text" : "RT @kindleworld: iTunes gives gifter info on giftee's owned books (while Amazon doesn't).  http:\/\/bit.ly\/itunes-privacy-prob #ereader #e ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ereader",
        "indices" : [ 108, 116 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 117, 124 ]
      }, {
        "text" : "privacy",
        "indices" : [ 125, 133 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40052596441878530",
    "text" : "iTunes gives gifter info on giftee's owned books (while Amazon doesn't).  http:\/\/bit.ly\/itunes-privacy-prob #ereader #ebooks #privacy",
    "id" : 40052596441878530,
    "created_at" : "2011-02-22 14:17:37 +0000",
    "user" : {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "protected" : false,
      "id_str" : "45727491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477176032563167233\/rnTxZldx_normal.jpeg",
      "id" : 45727491,
      "verified" : false
    }
  },
  "id" : 40053611266449408,
  "created_at" : "2011-02-22 14:21:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40047510584172545",
  "text" : "icu been busy playing rift..lol @Skandhasattva",
  "id" : 40047510584172545,
  "created_at" : "2011-02-22 13:57:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40047121411489792",
  "text" : "maybe should not have had donut.. or coffee.. or both. ugh.",
  "id" : 40047121411489792,
  "created_at" : "2011-02-22 13:55:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debbie Howard",
      "screen_name" : "DebbieMoans",
      "indices" : [ 3, 15 ],
      "id_str" : "42596397",
      "id" : 42596397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40045464996937728",
  "text" : "RT @DebbieMoans: I want to get a pet and name him Peeve. \"This is my pet, Peeve.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "40033560995827712",
    "text" : "I want to get a pet and name him Peeve. \"This is my pet, Peeve.\"",
    "id" : 40033560995827712,
    "created_at" : "2011-02-22 13:01:59 +0000",
    "user" : {
      "name" : "Debbie Howard",
      "screen_name" : "DebbieMoans",
      "protected" : false,
      "id_str" : "42596397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/661781697948598273\/WDiDXTUh_normal.jpg",
      "id" : 42596397,
      "verified" : false
    }
  },
  "id" : 40045464996937728,
  "created_at" : "2011-02-22 13:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 79, 93 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40041127642009601",
  "text" : "boston cream is my fave. dont go 4 jelly-filled..lol cinnamon donut this morn. @HEATHENRABBIT",
  "id" : 40041127642009601,
  "created_at" : "2011-02-22 13:32:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "40036022347628544",
  "text" : "coffee & donut",
  "id" : 40036022347628544,
  "created_at" : "2011-02-22 13:11:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    }, {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 102, 111 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39874944674447360",
  "text" : "RT @UnseeingEyes: This is only because we have detached ourselves from the rest of the animal kingdom @gemswinc & we see ourselves \"abov ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Cindy",
        "screen_name" : "gemswinc",
        "indices" : [ 84, 93 ],
        "id_str" : "13112692",
        "id" : 13112692
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39874617015271424",
    "text" : "This is only because we have detached ourselves from the rest of the animal kingdom @gemswinc & we see ourselves \"above\" animals.",
    "id" : 39874617015271424,
    "created_at" : "2011-02-22 02:30:24 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 39874944674447360,
  "created_at" : "2011-02-22 02:31:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39873291959148544",
  "text" : "RT @UnseeingEyes: The answers were astounding. Although many people picked the same shades...many did not. Different eyes see differently.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39870538918666240",
    "text" : "The answers were astounding. Although many people picked the same shades...many did not. Different eyes see differently.",
    "id" : 39870538918666240,
    "created_at" : "2011-02-22 02:14:11 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 39873291959148544,
  "created_at" : "2011-02-22 02:25:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39873249047224320",
  "text" : "RT @UnseeingEyes: I once conducted a study with different shades of the same colors...& asked people to pick out the \"truest\" blue, or y ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39870298639572992",
    "text" : "I once conducted a study with different shades of the same colors...& asked people to pick out the \"truest\" blue, or yellow, or red...",
    "id" : 39870298639572992,
    "created_at" : "2011-02-22 02:13:14 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 39873249047224320,
  "created_at" : "2011-02-22 02:24:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39764539176271872",
  "text" : "finished The Color of Heaven by Julianne MacLean and E.V. Mitchell and gave it 4 stars http:\/\/amzn.to\/eyEMyX #Kindle",
  "id" : 39764539176271872,
  "created_at" : "2011-02-21 19:12:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mobiustrip",
      "screen_name" : "bend_time",
      "indices" : [ 51, 61 ],
      "id_str" : "48215218",
      "id" : 48215218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39734446823309312",
  "geo" : { },
  "id_str" : "39736607489789952",
  "in_reply_to_user_id" : 48215218,
  "text" : "read yr blog. smooches 2 yr new love bug, Sully! \u2665 @bend_time",
  "id" : 39736607489789952,
  "in_reply_to_status_id" : 39734446823309312,
  "created_at" : "2011-02-21 17:22:00 +0000",
  "in_reply_to_screen_name" : "bend_time",
  "in_reply_to_user_id_str" : "48215218",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39732117902606337",
  "geo" : { },
  "id_str" : "39733422528139265",
  "in_reply_to_user_id" : 18219084,
  "text" : "@byoung210 @PortalChronicle http:\/\/www.facebook.com\/pages\/PORTAL\/243074017116",
  "id" : 39733422528139265,
  "in_reply_to_status_id" : 39732117902606337,
  "created_at" : "2011-02-21 17:09:20 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39722977100705792",
  "text" : "RT @GraveStomper: Define yourself as powerless and that's just what you will be.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39722382843187200",
    "text" : "Define yourself as powerless and that's just what you will be.",
    "id" : 39722382843187200,
    "created_at" : "2011-02-21 16:25:28 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 39722977100705792,
  "created_at" : "2011-02-21 16:27:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Egyptocracy",
      "screen_name" : "Egyptocracy",
      "indices" : [ 3, 15 ],
      "id_str" : "176797045",
      "id" : 176797045
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 130, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39488831589720064",
  "text" : "RT @Egyptocracy: Whoever handed out \"how to suppress a revolution\" manual to the region's dictators is really screwing with them. #Egypt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egypt",
        "indices" : [ 113, 119 ]
      }, {
        "text" : "Libya",
        "indices" : [ 120, 126 ]
      }, {
        "text" : "Tunis",
        "indices" : [ 127, 133 ]
      }, {
        "text" : "Yemen",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39486998670475264",
    "text" : "Whoever handed out \"how to suppress a revolution\" manual to the region's dictators is really screwing with them. #Egypt #Libya #Tunis #Yemen",
    "id" : 39486998670475264,
    "created_at" : "2011-02-21 00:50:08 +0000",
    "user" : {
      "name" : "Egyptocracy",
      "screen_name" : "Egyptocracy",
      "protected" : false,
      "id_str" : "176797045",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1242274323\/TwitBrush1_normal.jpg",
      "id" : 176797045,
      "verified" : false
    }
  },
  "id" : 39488831589720064,
  "created_at" : "2011-02-21 00:57:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39446974595866624",
  "text" : "ouch. feel better! @bookhound78",
  "id" : 39446974595866624,
  "created_at" : "2011-02-20 22:11:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39429241216962560",
  "text" : "Gabrielle's Reading http:\/\/bit.ly\/f0zleM",
  "id" : 39429241216962560,
  "created_at" : "2011-02-20 21:00:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39429007254491136",
  "text" : "Ebook Authors I Follow \u00AB My Ebook Blog http:\/\/bit.ly\/g5G7KI",
  "id" : 39429007254491136,
  "created_at" : "2011-02-20 20:59:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 82, 91 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39408764125851649",
  "geo" : { },
  "id_str" : "39409069336969216",
  "in_reply_to_user_id" : 15396585,
  "text" : "I dont like to kill anything. DD hates spiders, tho, so good I found him 1st..lol @Moonrust",
  "id" : 39409069336969216,
  "in_reply_to_status_id" : 39408764125851649,
  "created_at" : "2011-02-20 19:40:28 +0000",
  "in_reply_to_screen_name" : "Moonrust",
  "in_reply_to_user_id_str" : "15396585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39408115484991488",
  "text" : "put a spider outside. hope he doesnt freeze to death...",
  "id" : 39408115484991488,
  "created_at" : "2011-02-20 19:36:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39371508887330816",
  "text" : "\u201CPayback?\u201D Komick asked quietly. \u201CWhat about justice?\u201D \u201CIs there a difference, Jeff?\u201D Curtis asked caustically. - http:\/\/bit.ly\/g6UTEt",
  "id" : 39371508887330816,
  "created_at" : "2011-02-20 17:11:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SampleSunday",
      "indices" : [ 5, 18 ]
    }, {
      "text" : "ss",
      "indices" : [ 67, 70 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39348588915986432",
  "text" : "It's #SampleSunday - check out Indie Writers! http:\/\/bit.ly\/hBv990 #ss",
  "id" : 39348588915986432,
  "created_at" : "2011-02-20 15:40:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 18, 30 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39338182285721600",
  "geo" : { },
  "id_str" : "39342389697052672",
  "in_reply_to_user_id" : 15349954,
  "text" : "awwww..poor babe. @angelaharms",
  "id" : 39342389697052672,
  "in_reply_to_status_id" : 39338182285721600,
  "created_at" : "2011-02-20 15:15:31 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 121, 136 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39302368885616640",
  "geo" : { },
  "id_str" : "39337444281290752",
  "in_reply_to_user_id" : 16114141,
  "text" : "didnt review yet,just rated from last page (rate&share.) not sure WHERE the rating goes, tho. Amazon needs 2 work on it. @KreelanWarrior",
  "id" : 39337444281290752,
  "in_reply_to_status_id" : 39302368885616640,
  "created_at" : "2011-02-20 14:55:52 +0000",
  "in_reply_to_screen_name" : "KreelanWarrior",
  "in_reply_to_user_id_str" : "16114141",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39183155185328128",
  "text" : "finished Season Of The Harvest by Michael R. Hicks and gave it 4 stars http:\/\/amzn.to\/eVLmOU #Kindle",
  "id" : 39183155185328128,
  "created_at" : "2011-02-20 04:42:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39160752325529600",
  "text" : "\"Humanity is not a species. It's a state of mind.\" Annie - Being Human",
  "id" : 39160752325529600,
  "created_at" : "2011-02-20 03:13:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Max Graham",
      "screen_name" : "MaxGraham",
      "indices" : [ 3, 13 ],
      "id_str" : "15574534",
      "id" : 15574534
    }, {
      "name" : "-The Tarty Ho-",
      "screen_name" : "H0llywoodWh0re",
      "indices" : [ 23, 38 ],
      "id_str" : "26878297",
      "id" : 26878297
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39158289874812928",
  "text" : "RT @MaxGraham: @#$% RT @h0llywoodwh0re: De-funding Planned Parenthood yields a savings of $75 million annually, or 3 hours & 51.2 minute ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "-The Tarty Ho-",
        "screen_name" : "H0llywoodWh0re",
        "indices" : [ 8, 23 ],
        "id_str" : "26878297",
        "id" : 26878297
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39134872857481216",
    "text" : "@#$% RT @h0llywoodwh0re: De-funding Planned Parenthood yields a savings of $75 million annually, or 3 hours & 51.2 minutes of war",
    "id" : 39134872857481216,
    "created_at" : "2011-02-20 01:30:55 +0000",
    "user" : {
      "name" : "Max Graham",
      "screen_name" : "MaxGraham",
      "protected" : false,
      "id_str" : "15574534",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/755423478140899329\/2nNjROz9_normal.jpg",
      "id" : 15574534,
      "verified" : true
    }
  },
  "id" : 39158289874812928,
  "created_at" : "2011-02-20 03:03:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 3, 16 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39143826568388608",
  "text" : "RT @golden_books: You would be surprised how a kind word or a smile to a stranger goes a long way!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39142275275563008",
    "text" : "You would be surprised how a kind word or a smile to a stranger goes a long way!",
    "id" : 39142275275563008,
    "created_at" : "2011-02-20 02:00:20 +0000",
    "user" : {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "protected" : false,
      "id_str" : "124594428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707724561714905089\/xr54lDFv_normal.jpg",
      "id" : 124594428,
      "verified" : false
    }
  },
  "id" : 39143826568388608,
  "created_at" : "2011-02-20 02:06:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "A",
      "screen_name" : "brite2briter",
      "indices" : [ 3, 16 ],
      "id_str" : "17518748",
      "id" : 17518748
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39131865092866048",
  "text" : "RT @brite2briter: Be especially kind to those you dislike. They are your best teachers and mirrors.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38127062489239552",
    "text" : "Be especially kind to those you dislike. They are your best teachers and mirrors.",
    "id" : 38127062489239552,
    "created_at" : "2011-02-17 06:46:14 +0000",
    "user" : {
      "name" : "A",
      "screen_name" : "brite2briter",
      "protected" : false,
      "id_str" : "17518748",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2585331241\/k80cs53578kznin488q3_normal.jpeg",
      "id" : 17518748,
      "verified" : false
    }
  },
  "id" : 39131865092866048,
  "created_at" : "2011-02-20 01:18:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39127555814600704",
  "text" : "being human (bbc) season premiere at 9pm tonight",
  "id" : 39127555814600704,
  "created_at" : "2011-02-20 01:01:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39090808556748801",
  "text" : "omg'ness the dog stinks! what in tarnation did she eat??",
  "id" : 39090808556748801,
  "created_at" : "2011-02-19 22:35:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39090419270815744",
  "text" : "survived going out. head is a bit better. its settled into neck now.",
  "id" : 39090419270815744,
  "created_at" : "2011-02-19 22:34:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39018359542517760",
  "text" : "weird cuz I dont get congestion illness anymore. just weird head & GI illness. also my GI issues from liver (chronic)",
  "id" : 39018359542517760,
  "created_at" : "2011-02-19 17:47:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39017960974581760",
  "text" : "going to look into silver. supposed 2B good against viruses.",
  "id" : 39017960974581760,
  "created_at" : "2011-02-19 17:46:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39008971964694528",
  "text" : "more pepto & a shower. possibly going 2 mall today. not sure how I feel.",
  "id" : 39008971964694528,
  "created_at" : "2011-02-19 17:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39007912449933312",
  "geo" : { },
  "id_str" : "39008773221789696",
  "in_reply_to_user_id" : 40585382,
  "text" : "just being kids.. exactly. obv this mom has issues of her own and needs help. @Reverend_Sue",
  "id" : 39008773221789696,
  "in_reply_to_status_id" : 39007912449933312,
  "created_at" : "2011-02-19 17:09:50 +0000",
  "in_reply_to_screen_name" : "ReverendSue",
  "in_reply_to_user_id_str" : "40585382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 9, 21 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39007896465313792",
  "geo" : { },
  "id_str" : "39008561698832384",
  "in_reply_to_user_id" : 90733366,
  "text" : "awesome! @AlisynGayle",
  "id" : 39008561698832384,
  "in_reply_to_status_id" : 39007896465313792,
  "created_at" : "2011-02-19 17:09:00 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "39005513282879489",
  "geo" : { },
  "id_str" : "39006908023185408",
  "in_reply_to_user_id" : 40585382,
  "text" : "really made me sad. Ive had 2 fight 2 raise my child my way which inc. seeing her as a person not property. @Reverend_Sue",
  "id" : 39006908023185408,
  "in_reply_to_status_id" : 39005513282879489,
  "created_at" : "2011-02-19 17:02:26 +0000",
  "in_reply_to_screen_name" : "ReverendSue",
  "in_reply_to_user_id_str" : "40585382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "eBay",
      "indices" : [ 42, 47 ]
    }, {
      "text" : "parenting",
      "indices" : [ 89, 99 ]
    }, {
      "text" : "children",
      "indices" : [ 100, 109 ]
    }, {
      "text" : "psychology",
      "indices" : [ 110, 121 ]
    }, {
      "text" : "abuse",
      "indices" : [ 122, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39004729920987136",
  "text" : "RT @Reverend_Sue: Mom sells kids' toys on #eBay as punishment http:\/\/on.msnbc.com\/furiDl #parenting #children #psychology #abuse",
  "id" : 39004729920987136,
  "created_at" : "2011-02-19 16:53:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39003591570104320",
  "text" : "products-under-$5-that-made-millions http:\/\/yhoo.it\/gtM1x4",
  "id" : 39003591570104320,
  "created_at" : "2011-02-19 16:49:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39002368125321216",
  "text" : "watching \"being human\" (bbc version!) marathon. seen B4 but really seeing how funny it is. cant got stop laughing! love it!",
  "id" : 39002368125321216,
  "created_at" : "2011-02-19 16:44:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "indices" : [ 3, 11 ],
      "id_str" : "14232408",
      "id" : 14232408
    }, {
      "name" : "CHRIS VOSS",
      "screen_name" : "CHRISVOSS",
      "indices" : [ 16, 26 ],
      "id_str" : "23172966",
      "id" : 23172966
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39001592241987584",
  "text" : "RT @offgrid: RT @CHRISVOSS  You never fail until you stop trying.  - Albert Einstein",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "CHRIS VOSS",
        "screen_name" : "CHRISVOSS",
        "indices" : [ 3, 13 ],
        "id_str" : "23172966",
        "id" : 23172966
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39000385058246656",
    "text" : "RT @CHRISVOSS  You never fail until you stop trying.  - Albert Einstein",
    "id" : 39000385058246656,
    "created_at" : "2011-02-19 16:36:31 +0000",
    "user" : {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "protected" : false,
      "id_str" : "14232408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658770933063151617\/yzshyxdA_normal.jpg",
      "id" : 14232408,
      "verified" : false
    }
  },
  "id" : 39001592241987584,
  "created_at" : "2011-02-19 16:41:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39001566505607169",
  "text" : "RT @GraveStomper: Spring's in a few weeks : will you make something incredible of the new, warming energy or  let momentum drive  you th ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "39000486036246529",
    "text" : "Spring's in a few weeks : will you make something incredible of the new, warming energy or  let momentum drive  you thru more of the same?",
    "id" : 39000486036246529,
    "created_at" : "2011-02-19 16:36:55 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 39001566505607169,
  "created_at" : "2011-02-19 16:41:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39001070013390849",
  "text" : "RT @wow_trees: My dog wearing my bra. http:\/\/twitpic.com\/41hq51",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38997913749159936",
    "text" : "My dog wearing my bra. http:\/\/twitpic.com\/41hq51",
    "id" : 38997913749159936,
    "created_at" : "2011-02-19 16:26:41 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 39001070013390849,
  "created_at" : "2011-02-19 16:39:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "39000309850316801",
  "text" : "RT @bunnybuddhism: When I hop into a bush of thorns, I must remember there are bushes that do not have thorns and I will find them again.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38999303620009984",
    "text" : "When I hop into a bush of thorns, I must remember there are bushes that do not have thorns and I will find them again.",
    "id" : 38999303620009984,
    "created_at" : "2011-02-19 16:32:13 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 39000309850316801,
  "created_at" : "2011-02-19 16:36:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 70, 82 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38996029806223360",
  "geo" : { },
  "id_str" : "38996948107268096",
  "in_reply_to_user_id" : 24736943,
  "text" : "I keep changing twitter apps. cant seem to find perfect match.. sigh. @mindymayhem",
  "id" : 38996948107268096,
  "in_reply_to_status_id" : 38996029806223360,
  "created_at" : "2011-02-19 16:22:51 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 12, 25 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38995675400118272",
  "geo" : { },
  "id_str" : "38995992875507712",
  "in_reply_to_user_id" : 124594428,
  "text" : "thx hun : ) @golden_books",
  "id" : 38995992875507712,
  "in_reply_to_status_id" : 38995675400118272,
  "created_at" : "2011-02-19 16:19:03 +0000",
  "in_reply_to_screen_name" : "golden_books",
  "in_reply_to_user_id_str" : "124594428",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38995325565927425",
  "text" : "head still not right. benadryl luckily knocked me out last night so I slept.",
  "id" : 38995325565927425,
  "created_at" : "2011-02-19 16:16:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 84, 95 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38991457398300672",
  "geo" : { },
  "id_str" : "38994878272782336",
  "in_reply_to_user_id" : 176864114,
  "text" : "watching \"being human\" george (werewolf) getting attacked by vampire made me wonder @mimismutts",
  "id" : 38994878272782336,
  "in_reply_to_status_id" : 38991457398300672,
  "created_at" : "2011-02-19 16:14:38 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "andjelija",
      "screen_name" : "andjelija",
      "indices" : [ 31, 41 ],
      "id_str" : "923895937",
      "id" : 923895937
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38994279619629056",
  "text" : "oh no. hope it passes quickly! @Andjelija",
  "id" : 38994279619629056,
  "created_at" : "2011-02-19 16:12:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 31, 43 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38993327374204929",
  "geo" : { },
  "id_str" : "38994054406475776",
  "in_reply_to_user_id" : 24736943,
  "text" : "((hugs)) feel better soon love @mindymayhem",
  "id" : 38994054406475776,
  "in_reply_to_status_id" : 38993327374204929,
  "created_at" : "2011-02-19 16:11:21 +0000",
  "in_reply_to_screen_name" : "mindymayhem",
  "in_reply_to_user_id_str" : "24736943",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38990145264959489",
  "text" : "\"There must be more to life than wondering if there's more to life, right?\" - @InfantileAdult",
  "id" : 38990145264959489,
  "created_at" : "2011-02-19 15:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38782668619382784",
  "geo" : { },
  "id_str" : "38989567788978176",
  "in_reply_to_user_id" : 159213309,
  "text" : "im so sorry things changed for you : ( ((hugs)) @InfantileAdult",
  "id" : 38989567788978176,
  "in_reply_to_status_id" : 38782668619382784,
  "created_at" : "2011-02-19 15:53:32 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38988500489601025",
  "text" : "wondering if werewolf can be turned to vampire?",
  "id" : 38988500489601025,
  "created_at" : "2011-02-19 15:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38986685391839232",
  "text" : "\u200E\"well, that was pathetic. we're like the world's gayest ninjas.\" george - being human",
  "id" : 38986685391839232,
  "created_at" : "2011-02-19 15:42:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38751455603068929",
  "text" : "Now it's raining.. But I don't recall seeing clouds earlier.",
  "id" : 38751455603068929,
  "created_at" : "2011-02-19 00:07:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38751044557221888",
  "text" : "It's thundering!",
  "id" : 38751044557221888,
  "created_at" : "2011-02-19 00:05:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38750100994002944",
  "text" : "I'm enjoying all the pics that @InfantileAdult is posting of childhood. : )",
  "id" : 38750100994002944,
  "created_at" : "2011-02-19 00:01:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 67, 75 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38748170599010304",
  "geo" : { },
  "id_str" : "38749172316241920",
  "in_reply_to_user_id" : 54744689,
  "text" : "No just local clinic. I'll have 2 bring up next time I go 4 my rx. @SangyeH",
  "id" : 38749172316241920,
  "in_reply_to_status_id" : 38748170599010304,
  "created_at" : "2011-02-18 23:58:17 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38747189895241728",
  "text" : "Seems I have more \"sick\" days then not btwn head & GI...",
  "id" : 38747189895241728,
  "created_at" : "2011-02-18 23:50:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38746804858134528",
  "text" : "Ugh. decong didnt help. Not dizzy but dizzy feeling in middle of head. I'm tired of this crap...",
  "id" : 38746804858134528,
  "created_at" : "2011-02-18 23:48:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38746185468485632",
  "text" : "RT @neardeathdoc: Science of Prayer: plants grow best if prayer is for \"god's will\", healthier than if prayer is for \"healthy plants\".",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38744115197771776",
    "text" : "Science of Prayer: plants grow best if prayer is for \"god's will\", healthier than if prayer is for \"healthy plants\".",
    "id" : 38744115197771776,
    "created_at" : "2011-02-18 23:38:11 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 38746185468485632,
  "created_at" : "2011-02-18 23:46:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38744982051360770",
  "text" : "Priceless expression! : ) RT @InfantileAdult: LOL, this photo makes me laugh http:\/\/twitpic.com\/417ge5",
  "id" : 38744982051360770,
  "created_at" : "2011-02-18 23:41:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "indices" : [ 3, 14 ],
      "id_str" : "67336993",
      "id" : 67336993
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38710447104458752",
  "text" : "RT @TyrusBooks: Last call for FREE EBOOKS. I'm locking up shop at 5 (cst), until then, the shop is yours. Promo code \"zero\" for 100% dis ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fridayreads",
        "indices" : [ 127, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38698911682011137",
    "text" : "Last call for FREE EBOOKS. I'm locking up shop at 5 (cst), until then, the shop is yours. Promo code \"zero\" for 100% discount. #fridayreads",
    "id" : 38698911682011137,
    "created_at" : "2011-02-18 20:38:34 +0000",
    "user" : {
      "name" : "Tyrus Books",
      "screen_name" : "TyrusBooks",
      "protected" : false,
      "id_str" : "67336993",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/762984955865477120\/-Zjmevtn_normal.jpg",
      "id" : 67336993,
      "verified" : false
    }
  },
  "id" : 38710447104458752,
  "created_at" : "2011-02-18 21:24:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sew Witchy",
      "screen_name" : "SisterSorcha",
      "indices" : [ 27, 40 ],
      "id_str" : "36200541",
      "id" : 36200541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38669638476890112",
  "geo" : { },
  "id_str" : "38674212268945408",
  "in_reply_to_user_id" : 36200541,
  "text" : "((hugs)) feel better soon! @SisterSorcha",
  "id" : 38674212268945408,
  "in_reply_to_status_id" : 38669638476890112,
  "created_at" : "2011-02-18 19:00:25 +0000",
  "in_reply_to_screen_name" : "SisterSorcha",
  "in_reply_to_user_id_str" : "36200541",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 15, 23 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38670125330595840",
  "geo" : { },
  "id_str" : "38673310321479680",
  "in_reply_to_user_id" : 54744689,
  "text" : "awww..so cute! @SangyeH",
  "id" : 38673310321479680,
  "in_reply_to_status_id" : 38670125330595840,
  "created_at" : "2011-02-18 18:56:50 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Moaweya",
      "screen_name" : "Moaweya",
      "indices" : [ 16, 24 ],
      "id_str" : "517322002",
      "id" : 517322002
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bahrain",
      "indices" : [ 127, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38673044264189952",
  "text" : "RT @SangyeH: RT @Moaweya: A soldier is being carried on shoulders because he refused to shoot people http:\/\/yfrog.com\/gzzw7iij #bahrain  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Moaweya",
        "screen_name" : "Moaweya",
        "indices" : [ 3, 11 ],
        "id_str" : "517322002",
        "id" : 517322002
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bahrain",
        "indices" : [ 114, 122 ]
      }, {
        "text" : "feb14",
        "indices" : [ 123, 129 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38670598204817408",
    "text" : "RT @Moaweya: A soldier is being carried on shoulders because he refused to shoot people http:\/\/yfrog.com\/gzzw7iij #bahrain #feb14",
    "id" : 38670598204817408,
    "created_at" : "2011-02-18 18:46:03 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 38673044264189952,
  "created_at" : "2011-02-18 18:55:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38666464131026944",
  "text" : "Worst of New York Fashion Week Fall 2011: Seriously? You want us to wear this stuff? on Shine http:\/\/yhoo.it\/gofwZm",
  "id" : 38666464131026944,
  "created_at" : "2011-02-18 18:29:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Everyday Health",
      "screen_name" : "EverydayHealth",
      "indices" : [ 3, 18 ],
      "id_str" : "17393790",
      "id" : 17393790
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Obama",
      "indices" : [ 29, 35 ]
    }, {
      "text" : "Pailn",
      "indices" : [ 73, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38644567632904192",
  "text" : "RT @EverydayHealth: Michelle #Obama supports tax cuts for breastfeeding, #Pailn slams her. What do you think? Should you breastfeed? htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Obama",
        "indices" : [ 9, 15 ]
      }, {
        "text" : "Pailn",
        "indices" : [ 53, 59 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38623556329803776",
    "text" : "Michelle #Obama supports tax cuts for breastfeeding, #Pailn slams her. What do you think? Should you breastfeed? http:\/\/ow.ly\/3Z3B2",
    "id" : 38623556329803776,
    "created_at" : "2011-02-18 15:39:08 +0000",
    "user" : {
      "name" : "Everyday Health",
      "screen_name" : "EverydayHealth",
      "protected" : false,
      "id_str" : "17393790",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/695992404374122496\/URP3kg1S_normal.jpg",
      "id" : 17393790,
      "verified" : true
    }
  },
  "id" : 38644567632904192,
  "created_at" : "2011-02-18 17:02:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Hadeel Al-Shalchi",
      "screen_name" : "hadeelalsh",
      "indices" : [ 16, 27 ],
      "id_str" : "96104822",
      "id" : 96104822
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38643991461363712",
  "text" : "RT @SangyeH: RT @hadeelalsh: Protesters were carrying flowers saying they wanted to deliver it to police. Were shot instead. Blood on st ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Hadeel Al-Shalchi",
        "screen_name" : "hadeelalsh",
        "indices" : [ 3, 14 ],
        "id_str" : "96104822",
        "id" : 96104822
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bahrain",
        "indices" : [ 132, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38642786228109313",
    "text" : "RT @hadeelalsh: Protesters were carrying flowers saying they wanted to deliver it to police. Were shot instead. Blood on street now #bahrain",
    "id" : 38642786228109313,
    "created_at" : "2011-02-18 16:55:32 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 38643991461363712,
  "created_at" : "2011-02-18 17:00:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FFs",
      "indices" : [ 36, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38639691410575360",
  "text" : "RT @PortalChronicle: Too lazy to do #FFs, but I love you all xoxo",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "FFs",
        "indices" : [ 15, 19 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38632939285647360",
    "text" : "Too lazy to do #FFs, but I love you all xoxo",
    "id" : 38632939285647360,
    "created_at" : "2011-02-18 16:16:25 +0000",
    "user" : {
      "name" : "IMOGEN ROSE",
      "screen_name" : "ImogenRoseTweet",
      "protected" : false,
      "id_str" : "102568232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1265710799\/profile1_normal.jpg",
      "id" : 102568232,
      "verified" : false
    }
  },
  "id" : 38639691410575360,
  "created_at" : "2011-02-18 16:43:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ScienceDaily",
      "screen_name" : "ScienceDaily",
      "indices" : [ 3, 16 ],
      "id_str" : "18700629",
      "id" : 18700629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38632406592262144",
  "text" : "RT @sciencedaily: Scientists steer car with the power of thought: Computer scientists have developed a system making it possible t... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38624675760177152",
    "text" : "Scientists steer car with the power of thought: Computer scientists have developed a system making it possible t... http:\/\/bit.ly\/f7VpF9",
    "id" : 38624675760177152,
    "created_at" : "2011-02-18 15:43:34 +0000",
    "user" : {
      "name" : "ScienceDaily",
      "screen_name" : "ScienceDaily",
      "protected" : false,
      "id_str" : "18700629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/69944301\/apple-touch-icon_normal.png",
      "id" : 18700629,
      "verified" : false
    }
  },
  "id" : 38632406592262144,
  "created_at" : "2011-02-18 16:14:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Arwa Salah Mahmoud",
      "screen_name" : "arwasm",
      "indices" : [ 3, 10 ],
      "id_str" : "63693027",
      "id" : 63693027
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Libya",
      "indices" : [ 34, 40 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38632138110672896",
  "text" : "RT @arwasm: First woman killed in #Libya, shot dead by a sniper as she took pictures of foreign mercenaries hired by Qaddafi 2 disperse  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Libya",
        "indices" : [ 22, 28 ]
      }, {
        "text" : "feb17",
        "indices" : [ 134, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38631492473196544",
    "text" : "First woman killed in #Libya, shot dead by a sniper as she took pictures of foreign mercenaries hired by Qaddafi 2 disperse protests. #feb17",
    "id" : 38631492473196544,
    "created_at" : "2011-02-18 16:10:40 +0000",
    "user" : {
      "name" : "Arwa Salah Mahmoud",
      "screen_name" : "arwasm",
      "protected" : false,
      "id_str" : "63693027",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/675820448148496386\/ZH_7bxs8_normal.jpg",
      "id" : 63693027,
      "verified" : false
    }
  },
  "id" : 38632138110672896,
  "created_at" : "2011-02-18 16:13:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "IndieAuthors",
      "indices" : [ 15, 28 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38631914206134272",
  "text" : "RT @byoung210: #IndieAuthors would you rather have a bad review of your book than no review at all? Me? I'd take the bad review. #amwrit ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "IndieAuthors",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 114, 124 ]
      }, {
        "text" : "selfpublish",
        "indices" : [ 125, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38631483761635328",
    "text" : "#IndieAuthors would you rather have a bad review of your book than no review at all? Me? I'd take the bad review. #amwriting #selfpublish",
    "id" : 38631483761635328,
    "created_at" : "2011-02-18 16:10:38 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 38631914206134272,
  "created_at" : "2011-02-18 16:12:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 72, 80 ]
    }, {
      "text" : "kindle",
      "indices" : [ 115, 122 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38629625877905408",
  "text" : "RT @hauntedcomputer: still time!: RT to enter for $10 gift certificate: #mystery Crime Beat by Scott Nicholson for #kindle http:\/\/amzn.t ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mystery",
        "indices" : [ 51, 59 ]
      }, {
        "text" : "kindle",
        "indices" : [ 94, 101 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38629503387451392",
    "text" : "still time!: RT to enter for $10 gift certificate: #mystery Crime Beat by Scott Nicholson for #kindle http:\/\/amzn.to\/e5tGqB 99 cents",
    "id" : 38629503387451392,
    "created_at" : "2011-02-18 16:02:45 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 38629625877905408,
  "created_at" : "2011-02-18 16:03:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38629095776600064",
  "text" : ":\/ \"No wonder Michelle Obama is telling everybody 'you'd better breastfeed your baby,'\" Palin said, after (cont) http:\/\/tl.gd\/8tqrpv",
  "id" : 38629095776600064,
  "created_at" : "2011-02-18 16:01:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "aspie",
      "indices" : [ 135, 141 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38624257432879104",
  "text" : "agree? or no? &gt;&gt; It's just a way of seeing\/interacting with the world.. not so much a \"medical\" condition http:\/\/on.fb.me\/dYN4bs #aspie",
  "id" : 38624257432879104,
  "created_at" : "2011-02-18 15:41:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38622682488639488",
  "text" : "and then sometimes he's not mad anymore but IM mad cuz he was mad...",
  "id" : 38622682488639488,
  "created_at" : "2011-02-18 15:35:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38622496622256128",
  "text" : "hmm.. sometimes its depressed 4 NO reason. other times its cuz hubby mad at me.",
  "id" : 38622496622256128,
  "created_at" : "2011-02-18 15:34:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38609557014061056",
  "geo" : { },
  "id_str" : "38621409626439681",
  "in_reply_to_user_id" : 75708394,
  "text" : "What a sweet thing to say! : ) @JulzMayBe",
  "id" : 38621409626439681,
  "in_reply_to_status_id" : 38609557014061056,
  "created_at" : "2011-02-18 15:30:36 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 20, 31 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38606329664765952",
  "geo" : { },
  "id_str" : "38621078532272128",
  "in_reply_to_user_id" : 176864114,
  "text" : "True. Good call : ) @mimismutts",
  "id" : 38621078532272128,
  "in_reply_to_status_id" : 38606329664765952,
  "created_at" : "2011-02-18 15:29:17 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 24, 34 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    }, {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 35, 46 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 58, 70 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38620861418315776",
  "text" : "Thanks tweeps! ((hugs)) @ID_vs_EGO @mimismutts @JulzMayBe @angelaharms",
  "id" : 38620861418315776,
  "created_at" : "2011-02-18 15:28:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38613333418590208",
  "geo" : { },
  "id_str" : "38619300075933696",
  "in_reply_to_user_id" : 18219084,
  "text" : "aww thats sweet! anytime we go to cvs, etc alone I consider a \"date\"..lol  @byoung210",
  "id" : 38619300075933696,
  "in_reply_to_status_id" : 38613333418590208,
  "created_at" : "2011-02-18 15:22:13 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "indices" : [ 3, 12 ],
      "id_str" : "127070349",
      "id" : 127070349
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38618906109157377",
  "text" : "RT @Jambodhi: We have time, there's no big rush.  ~ Jimi Hendrix",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38613854397145089",
    "text" : "We have time, there's no big rush.  ~ Jimi Hendrix",
    "id" : 38613854397145089,
    "created_at" : "2011-02-18 15:00:34 +0000",
    "user" : {
      "name" : "Jambodhi",
      "screen_name" : "Jambodhi",
      "protected" : false,
      "id_str" : "127070349",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/552124981002248197\/t93KWlEi_normal.jpeg",
      "id" : 127070349,
      "verified" : false
    }
  },
  "id" : 38618906109157377,
  "created_at" : "2011-02-18 15:20:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 32, 41 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38618713670287360",
  "text" : "((hugs)) glad u got support : ) @Tideliar",
  "id" : 38618713670287360,
  "created_at" : "2011-02-18 15:19:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38605731452293120",
  "text" : "I often wonder if I werent on effexor, how much crazier Id be...",
  "id" : 38605731452293120,
  "created_at" : "2011-02-18 14:28:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38605475587170304",
  "text" : "I would like to have a lobotomy so I dont feel anything.",
  "id" : 38605475587170304,
  "created_at" : "2011-02-18 14:27:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "indices" : [ 3, 19 ],
      "id_str" : "120083514",
      "id" : 120083514
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38602923122368512",
  "text" : "RT @Soulseedzforall: Be willing to be a beginner every single morning. Meister Eckhart",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38602428307734528",
    "text" : "Be willing to be a beginner every single morning. Meister Eckhart",
    "id" : 38602428307734528,
    "created_at" : "2011-02-18 14:15:10 +0000",
    "user" : {
      "name" : "Soulseeds",
      "screen_name" : "Soulseedzforall",
      "protected" : false,
      "id_str" : "120083514",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/733848675\/Soulseedz_image_normal.jpg",
      "id" : 120083514,
      "verified" : false
    }
  },
  "id" : 38602923122368512,
  "created_at" : "2011-02-18 14:17:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 38, 45 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38586523377074177",
  "geo" : { },
  "id_str" : "38588228999184384",
  "in_reply_to_user_id" : 122393631,
  "text" : "no (no patience) & no (no energy) ; ) @SsmDad",
  "id" : 38588228999184384,
  "in_reply_to_status_id" : 38586523377074177,
  "created_at" : "2011-02-18 13:18:45 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 36, 51 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38586543732043776",
  "geo" : { },
  "id_str" : "38587831106535424",
  "in_reply_to_user_id" : 25846336,
  "text" : "ive been blaming it on poles moving @mssuzcatsilver",
  "id" : 38587831106535424,
  "in_reply_to_status_id" : 38586543732043776,
  "created_at" : "2011-02-18 13:17:10 +0000",
  "in_reply_to_screen_name" : "mssuzcatsilver",
  "in_reply_to_user_id_str" : "25846336",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 87, 94 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38581329708843008",
  "geo" : { },
  "id_str" : "38582541103398912",
  "in_reply_to_user_id" : 122393631,
  "text" : "I have done things that at the time I did not believe was wrong. its hard to be human. @SsmDad",
  "id" : 38582541103398912,
  "in_reply_to_status_id" : 38581329708843008,
  "created_at" : "2011-02-18 12:56:09 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 10, 14 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38582034033025024",
  "text" : "I love my #TKD family",
  "id" : 38582034033025024,
  "created_at" : "2011-02-18 12:54:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Romeo & Juliet",
      "screen_name" : "RomeoandJuLlet",
      "indices" : [ 15, 30 ],
      "id_str" : "177378541",
      "id" : 177378541
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38427591950086144",
  "text" : "RT @BestAt: RT @ROMEOandJULlET: Dear past, stop tapping me on the shoulders, I don't want to look back.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Romeo & Juliet",
        "screen_name" : "RomeoandJuLlet",
        "indices" : [ 3, 18 ],
        "id_str" : "177378541",
        "id" : 177378541
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38418218372567040",
    "text" : "RT @ROMEOandJULlET: Dear past, stop tapping me on the shoulders, I don't want to look back.",
    "id" : 38418218372567040,
    "created_at" : "2011-02-18 02:03:11 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 38427591950086144,
  "created_at" : "2011-02-18 02:40:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38373258168369152",
  "text" : "http:\/\/amzn.com\/k\/1BLDE86KSM5R3 #Kindle",
  "id" : 38373258168369152,
  "created_at" : "2011-02-17 23:04:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38366965005422592",
  "text" : "11,22,33,44,55,66,77,99&lt;--saw these pairs in parking lot last night",
  "id" : 38366965005422592,
  "created_at" : "2011-02-17 22:39:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elegia",
      "screen_name" : "luv_vigilante",
      "indices" : [ 3, 17 ],
      "id_str" : "229916922",
      "id" : 229916922
    }, {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 19, 32 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38366714907332608",
  "text" : "RT @luv_vigilante: @derekrootboy Eccentricity is good. It means you are interesting.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Tom Delargy",
        "screen_name" : "derekrootboy",
        "indices" : [ 0, 13 ],
        "id_str" : "35585695",
        "id" : 35585695
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "38324271747047424",
    "geo" : { },
    "id_str" : "38342753184124928",
    "in_reply_to_user_id" : 35585695,
    "text" : "@derekrootboy Eccentricity is good. It means you are interesting.",
    "id" : 38342753184124928,
    "in_reply_to_status_id" : 38324271747047424,
    "created_at" : "2011-02-17 21:03:19 +0000",
    "in_reply_to_screen_name" : "derekrootboy",
    "in_reply_to_user_id_str" : "35585695",
    "user" : {
      "name" : "Elegia",
      "screen_name" : "luv_vigilante",
      "protected" : false,
      "id_str" : "229916922",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3313580863\/a80cf29cc6d80adca2d86b109f9d21e2_normal.jpeg",
      "id" : 229916922,
      "verified" : false
    }
  },
  "id" : 38366714907332608,
  "created_at" : "2011-02-17 22:38:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "indices" : [ 3, 12 ],
      "id_str" : "18581294",
      "id" : 18581294
    }, {
      "name" : "Luria Petrucci",
      "screen_name" : "CaliLewis",
      "indices" : [ 34, 44 ],
      "id_str" : "132658390",
      "id" : 132658390
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38363805675294721",
  "text" : "RT @namenick: True, true, true RT @CaliLewis: Never judge a book by its movie.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Luria Petrucci",
        "screen_name" : "CaliLewis",
        "indices" : [ 20, 30 ],
        "id_str" : "132658390",
        "id" : 132658390
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38362582918107137",
    "text" : "True, true, true RT @CaliLewis: Never judge a book by its movie.",
    "id" : 38362582918107137,
    "created_at" : "2011-02-17 22:22:07 +0000",
    "user" : {
      "name" : "Piotr Kowalczyk",
      "screen_name" : "namenick",
      "protected" : false,
      "id_str" : "18581294",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/739156618710024192\/iSvI5Blh_normal.jpg",
      "id" : 18581294,
      "verified" : false
    }
  },
  "id" : 38363805675294721,
  "created_at" : "2011-02-17 22:26:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 3, 14 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38354816682041344",
  "text" : "RT @quantafire: Hot!!! No kidding... RT @CtKscribe A 72-yr-old woman with a 20-yr-old body: http:\/\/bit.ly\/gB3HO5  via @SiDawson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twidroyd.com\" rel=\"nofollow\"\u003Etwidroyd (original)\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "si dawson",
        "screen_name" : "SiDawson",
        "indices" : [ 102, 111 ],
        "id_str" : "15203375",
        "id" : 15203375
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38350483085209600",
    "text" : "Hot!!! No kidding... RT @CtKscribe A 72-yr-old woman with a 20-yr-old body: http:\/\/bit.ly\/gB3HO5  via @SiDawson",
    "id" : 38350483085209600,
    "created_at" : "2011-02-17 21:34:02 +0000",
    "user" : {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "protected" : false,
      "id_str" : "8449382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2943941501\/b15b399a7823bad25f64b6482704e678_normal.jpeg",
      "id" : 8449382,
      "verified" : false
    }
  },
  "id" : 38354816682041344,
  "created_at" : "2011-02-17 21:51:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SharedMinds",
      "screen_name" : "SharedMinds",
      "indices" : [ 3, 15 ],
      "id_str" : "20355125",
      "id" : 20355125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38353276940464129",
  "text" : "RT @SharedMinds: Peeps YOU are Wonderful! Watch this short film (16 min). It will bring a smile to your face! http:\/\/bSix12.com\/validation\/",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bSix12.com\/smd\/\" rel=\"nofollow\"\u003ESharedMinds Desktop\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38352171405819904",
    "text" : "Peeps YOU are Wonderful! Watch this short film (16 min). It will bring a smile to your face! http:\/\/bSix12.com\/validation\/",
    "id" : 38352171405819904,
    "created_at" : "2011-02-17 21:40:44 +0000",
    "user" : {
      "name" : "SharedMinds",
      "screen_name" : "SharedMinds",
      "protected" : false,
      "id_str" : "20355125",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2354711308\/lr2cwrzsn625gu0givhu_normal.png",
      "id" : 20355125,
      "verified" : false
    }
  },
  "id" : 38353276940464129,
  "created_at" : "2011-02-17 21:45:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 23, 34 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38352717873295360",
  "geo" : { },
  "id_str" : "38353175937417217",
  "in_reply_to_user_id" : 6994832,
  "text" : "I saw that..so weird.. @TrishScott",
  "id" : 38353175937417217,
  "in_reply_to_status_id" : 38352717873295360,
  "created_at" : "2011-02-17 21:44:44 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38348042394406912",
  "text" : "Fishy trick: Magic with goldfish stokes anger http:\/\/yhoo.it\/i0N8KG",
  "id" : 38348042394406912,
  "created_at" : "2011-02-17 21:24:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38346586308345856",
  "text" : "Umm... RT @Skandhasattva: Either my hand are getting bigger or they're making tools to fucking small lol http:\/\/yfrog.com\/gz2vtxj",
  "id" : 38346586308345856,
  "created_at" : "2011-02-17 21:18:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38341441189199872",
  "geo" : { },
  "id_str" : "38341921143402496",
  "in_reply_to_user_id" : 18219084,
  "text" : "yes, why yes I do..lol .. I \u2665 Twitter! @byoung210",
  "id" : 38341921143402496,
  "in_reply_to_status_id" : 38341441189199872,
  "created_at" : "2011-02-17 21:00:01 +0000",
  "in_reply_to_screen_name" : "DesShep",
  "in_reply_to_user_id_str" : "18219084",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chantelle Aim\u00E9e",
      "screen_name" : "SuspenseSirens",
      "indices" : [ 3, 18 ],
      "id_str" : "107218304",
      "id" : 107218304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38339805750366208",
  "text" : "RT @SuspenseSirens: Did you know custody is all about perception? 10 Little-known facts about interrogation http:\/\/bit.ly\/dH3PeJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38313251783716864",
    "text" : "Did you know custody is all about perception? 10 Little-known facts about interrogation http:\/\/bit.ly\/dH3PeJ",
    "id" : 38313251783716864,
    "created_at" : "2011-02-17 19:06:05 +0000",
    "user" : {
      "name" : "Chantelle Aim\u00E9e",
      "screen_name" : "SuspenseSirens",
      "protected" : false,
      "id_str" : "107218304",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2275835292\/vertigosirentwit_normal.jpg",
      "id" : 107218304,
      "verified" : false
    }
  },
  "id" : 38339805750366208,
  "created_at" : "2011-02-17 20:51:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 42, 55 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 80, 87 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 88, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38339674825179136",
  "text" : "LOL - Top Ten Reasons to Read Immortal by @GeneDoucette  http:\/\/on.fb.me\/fGK5en #kindle #ebooks",
  "id" : 38339674825179136,
  "created_at" : "2011-02-17 20:51:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 3, 15 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38324760924536832",
  "text" : "RT @Jeweldspear: Another belly laugh for ya. China Bans Reincarnation Without Government Permission http:\/\/tinyurl.com\/23wvjuh",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38324460452847616",
    "text" : "Another belly laugh for ya. China Bans Reincarnation Without Government Permission http:\/\/tinyurl.com\/23wvjuh",
    "id" : 38324460452847616,
    "created_at" : "2011-02-17 19:50:38 +0000",
    "user" : {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "protected" : false,
      "id_str" : "51846392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655444947940823041\/ORiamX3x_normal.jpg",
      "id" : 51846392,
      "verified" : false
    }
  },
  "id" : 38324760924536832,
  "created_at" : "2011-02-17 19:51:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 64, 71 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38315866366033921",
  "geo" : { },
  "id_str" : "38317582486478848",
  "in_reply_to_user_id" : 122393631,
  "text" : "cant go wrong if u follow yr heart.. yr soul knows what u need. @SsmDad",
  "id" : 38317582486478848,
  "in_reply_to_status_id" : 38315866366033921,
  "created_at" : "2011-02-17 19:23:18 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 78, 89 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 40, 47 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38265012334239744",
  "geo" : { },
  "id_str" : "38312014493392896",
  "in_reply_to_user_id" : 7482152,
  "text" : "are u referring 2 editing it? I read on #kindle .. have 2 look up on amazon.. @modernevil",
  "id" : 38312014493392896,
  "in_reply_to_status_id" : 38265012334239744,
  "created_at" : "2011-02-17 19:01:10 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 74, 85 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38309599518007296",
  "geo" : { },
  "id_str" : "38311088747450368",
  "in_reply_to_user_id" : 199743576,
  "text" : "omg..hehe.. I thought same thing! glad u reminded me..lol @squintinginfog @modernevil",
  "id" : 38311088747450368,
  "in_reply_to_status_id" : 38309599518007296,
  "created_at" : "2011-02-17 18:57:30 +0000",
  "in_reply_to_screen_name" : "fastingfoody",
  "in_reply_to_user_id_str" : "199743576",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38301935924822016",
  "text" : "RT @TrishScott: Defining yourself could be hazardous to your BEING",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38301652272431104",
    "text" : "Defining yourself could be hazardous to your BEING",
    "id" : 38301652272431104,
    "created_at" : "2011-02-17 18:20:00 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 38301935924822016,
  "created_at" : "2011-02-17 18:21:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 25, 32 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38299159387709440",
  "geo" : { },
  "id_str" : "38300996660764672",
  "in_reply_to_user_id" : 122393631,
  "text" : "yes I am, TY4asking. : ) @SsmDad",
  "id" : 38300996660764672,
  "in_reply_to_status_id" : 38299159387709440,
  "created_at" : "2011-02-17 18:17:23 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 41, 52 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38299890119475200",
  "geo" : { },
  "id_str" : "38300527402037248",
  "in_reply_to_user_id" : 6994832,
  "text" : "a mouse is a mouse, not an elephant..lol @TrishScott",
  "id" : 38300527402037248,
  "in_reply_to_status_id" : 38299890119475200,
  "created_at" : "2011-02-17 18:15:31 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38300174543618048",
  "text" : "I like SW but do prefer getting from Amazon due to lending (if enabled) plus I have kindle credit @darkelms @byoung210",
  "id" : 38300174543618048,
  "created_at" : "2011-02-17 18:14:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "followers",
      "indices" : [ 25, 35 ]
    }, {
      "text" : "youarebeautiful",
      "indices" : [ 36, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38299536120090624",
  "text" : "RT @JulzMayBe: To all my #followers #youarebeautiful !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "followers",
        "indices" : [ 10, 20 ]
      }, {
        "text" : "youarebeautiful",
        "indices" : [ 21, 37 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38290041323270144",
    "text" : "To all my #followers #youarebeautiful !",
    "id" : 38290041323270144,
    "created_at" : "2011-02-17 17:33:51 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 38299536120090624,
  "created_at" : "2011-02-17 18:11:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 76, 87 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38290515938123776",
  "geo" : { },
  "id_str" : "38299384059797504",
  "in_reply_to_user_id" : 6994832,
  "text" : "omg.. me, too! Im not much of a \"doer\".. I think, ponder, contemplate.. : ) @TrishScott",
  "id" : 38299384059797504,
  "in_reply_to_status_id" : 38290515938123776,
  "created_at" : "2011-02-17 18:10:59 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mike Dolan",
      "screen_name" : "HawaiianLife",
      "indices" : [ 3, 16 ],
      "id_str" : "41899172",
      "id" : 41899172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38298562467086336",
  "text" : "RT @HawaiianLife: The struggle fades as you become aware...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38292288903987200",
    "text" : "The struggle fades as you become aware...",
    "id" : 38292288903987200,
    "created_at" : "2011-02-17 17:42:47 +0000",
    "user" : {
      "name" : "Mike Dolan",
      "screen_name" : "HawaiianLife",
      "protected" : false,
      "id_str" : "41899172",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/502096910\/My_Mug_normal.jpg",
      "id" : 41899172,
      "verified" : false
    }
  },
  "id" : 38298562467086336,
  "created_at" : "2011-02-17 18:07:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 116, 123 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38293087323168768",
  "geo" : { },
  "id_str" : "38298459819872256",
  "in_reply_to_user_id" : 122393631,
  "text" : "have 1 for each interest.. or just write! start somewhere..lol.. no law says you cant combine 'em all in 1 blog : ) @SsmDad",
  "id" : 38298459819872256,
  "in_reply_to_status_id" : 38293087323168768,
  "created_at" : "2011-02-17 18:07:19 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 44, 55 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38271961930932225",
  "geo" : { },
  "id_str" : "38272366874329088",
  "in_reply_to_user_id" : 176864114,
  "text" : "same here.. I mean you my friend..lol muah! @mimismutts",
  "id" : 38272366874329088,
  "in_reply_to_status_id" : 38271961930932225,
  "created_at" : "2011-02-17 16:23:37 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 63, 74 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38269491548786688",
  "geo" : { },
  "id_str" : "38272189040046080",
  "in_reply_to_user_id" : 176864114,
  "text" : "the cash represents power to me (due 2 family upbringing, etc) @mimismutts",
  "id" : 38272189040046080,
  "in_reply_to_status_id" : 38269491548786688,
  "created_at" : "2011-02-17 16:22:55 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 110, 121 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38269491548786688",
  "geo" : { },
  "id_str" : "38272016494764032",
  "in_reply_to_user_id" : 176864114,
  "text" : "I understand that concept of wanting what money buys but have hard time getting past that.. wanting the cash. @mimismutts",
  "id" : 38272016494764032,
  "in_reply_to_status_id" : 38269491548786688,
  "created_at" : "2011-02-17 16:22:14 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 26, 37 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38270218929180672",
  "geo" : { },
  "id_str" : "38271577837539328",
  "in_reply_to_user_id" : 176864114,
  "text" : "oh, im happy 4 most part. @mimismutts",
  "id" : 38271577837539328,
  "in_reply_to_status_id" : 38270218929180672,
  "created_at" : "2011-02-17 16:20:29 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38265618381668352",
  "text" : "RT @modernevil: Just got through the 40-minute sex scene in Untrue Tales... Book Two. Whew! That was intense!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38265012334239744",
    "text" : "Just got through the 40-minute sex scene in Untrue Tales... Book Two. Whew! That was intense!",
    "id" : 38265012334239744,
    "created_at" : "2011-02-17 15:54:24 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 38265618381668352,
  "created_at" : "2011-02-17 15:56:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 82, 101 ],
      "url" : "http:\/\/t.co\/6YPQzmr",
      "expanded_url" : "http:\/\/www.oprah.com\/odbimage\/db_203278028_1",
      "display_url" : "oprah.com\/odbimage\/db_20\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "38265293927088128",
  "text" : "my first try at it. used supplied images. needs work! lol Gabrielle's Dream Board http:\/\/t.co\/6YPQzmr",
  "id" : 38265293927088128,
  "created_at" : "2011-02-17 15:55:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 113, 124 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38259618123620352",
  "geo" : { },
  "id_str" : "38265018734751744",
  "in_reply_to_user_id" : 176864114,
  "text" : "true..mine is effecting us now, tho..financial. so hubbys stressing. it'll work itself out somehow. always does! @mimismutts",
  "id" : 38265018734751744,
  "in_reply_to_status_id" : 38259618123620352,
  "created_at" : "2011-02-17 15:54:26 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moved: @onealexharms",
      "screen_name" : "angelaharms",
      "indices" : [ 42, 54 ],
      "id_str" : "2922137304",
      "id" : 2922137304
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38256778235879424",
  "geo" : { },
  "id_str" : "38264470736343041",
  "in_reply_to_user_id" : 15349954,
  "text" : "they all look so happy.. very nice! : ) \u2665 @angelaharms",
  "id" : 38264470736343041,
  "in_reply_to_status_id" : 38256778235879424,
  "created_at" : "2011-02-17 15:52:15 +0000",
  "in_reply_to_screen_name" : "onealexharms",
  "in_reply_to_user_id_str" : "15349954",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38263495552278528",
  "text" : "RT @JulzMayBe: Try writing your to-do list in your gratitude journal--as if it's already done.  And, say Thank You.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38262541201321985",
    "text" : "Try writing your to-do list in your gratitude journal--as if it's already done.  And, say Thank You.",
    "id" : 38262541201321985,
    "created_at" : "2011-02-17 15:44:35 +0000",
    "user" : {
      "name" : "Julianne Garska",
      "screen_name" : "JulianneGarska",
      "protected" : false,
      "id_str" : "75708394",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000744006540\/e88db1e4c59d154f53d5514b8533b746_normal.jpeg",
      "id" : 75708394,
      "verified" : false
    }
  },
  "id" : 38263495552278528,
  "created_at" : "2011-02-17 15:48:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "indices" : [ 3, 13 ],
      "id_str" : "23812887",
      "id" : 23812887
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "getconfusedwhenthingsareputaway",
      "indices" : [ 97, 129 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38263449976975360",
  "text" : "RT @LizBorino: Me:Where is my hairbrush? BF: In the drawer. Me: What the hell is it doing there? #getconfusedwhenthingsareputaway",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "getconfusedwhenthingsareputaway",
        "indices" : [ 82, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38262611552370688",
    "text" : "Me:Where is my hairbrush? BF: In the drawer. Me: What the hell is it doing there? #getconfusedwhenthingsareputaway",
    "id" : 38262611552370688,
    "created_at" : "2011-02-17 15:44:52 +0000",
    "user" : {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "protected" : false,
      "id_str" : "23812887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489066924773371905\/AJv5YOCl_normal.jpeg",
      "id" : 23812887,
      "verified" : false
    }
  },
  "id" : 38263449976975360,
  "created_at" : "2011-02-17 15:48:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "love",
      "indices" : [ 42, 47 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38257301412515840",
  "text" : "RT @mssuzcatsilver: Bless everything with #love & appreciate everything for the lesson it can teach you whether it be deemed good or bad ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 22, 27 ]
      }, {
        "text" : "gratitude",
        "indices" : [ 117, 127 ]
      }, {
        "text" : "suzcat",
        "indices" : [ 128, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38256576066355200",
    "text" : "Bless everything with #love & appreciate everything for the lesson it can teach you whether it be deemed good or bad #gratitude #suzcat",
    "id" : 38256576066355200,
    "created_at" : "2011-02-17 15:20:53 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 38257301412515840,
  "created_at" : "2011-02-17 15:23:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 37, 46 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38252700294455297",
  "geo" : { },
  "id_str" : "38254741964328960",
  "in_reply_to_user_id" : 15396585,
  "text" : "Happy Birthday, Vinnie! ((smooches)) @Moonrust",
  "id" : 38254741964328960,
  "in_reply_to_status_id" : 38252700294455297,
  "created_at" : "2011-02-17 15:13:35 +0000",
  "in_reply_to_screen_name" : "Moonrust",
  "in_reply_to_user_id_str" : "15396585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 23, 34 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38251191947231232",
  "geo" : { },
  "id_str" : "38254611756359680",
  "in_reply_to_user_id" : 176864114,
  "text" : "lol..yes,figuretively. @mimismutts",
  "id" : 38254611756359680,
  "in_reply_to_status_id" : 38251191947231232,
  "created_at" : "2011-02-17 15:13:04 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Harmon Hathaway",
      "screen_name" : "38harmony",
      "indices" : [ 23, 33 ],
      "id_str" : "41457590",
      "id" : 41457590
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38250653713305600",
  "text" : "RT @mssuzcatsilver: RT @38harmony: ~ There are many ways to serve the world. You can serve, if not actively, at least by your serenity.  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Harmon Hathaway",
        "screen_name" : "38harmony",
        "indices" : [ 3, 13 ],
        "id_str" : "41457590",
        "id" : 41457590
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38249334306766848",
    "text" : "RT @38harmony: ~ There are many ways to serve the world. You can serve, if not actively, at least by your serenity. ~ Sai Baba",
    "id" : 38249334306766848,
    "created_at" : "2011-02-17 14:52:06 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 38250653713305600,
  "created_at" : "2011-02-17 14:57:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "indices" : [ 3, 13 ],
      "id_str" : "23812887",
      "id" : 23812887
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38250418119254016",
  "text" : "RT @LizBorino: Something good is going to happen today. I know it.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38248330437996544",
    "text" : "Something good is going to happen today. I know it.",
    "id" : 38248330437996544,
    "created_at" : "2011-02-17 14:48:07 +0000",
    "user" : {
      "name" : "Liz Borino",
      "screen_name" : "LizBorino",
      "protected" : false,
      "id_str" : "23812887",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/489066924773371905\/AJv5YOCl_normal.jpeg",
      "id" : 23812887,
      "verified" : false
    }
  },
  "id" : 38250418119254016,
  "created_at" : "2011-02-17 14:56:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "indices" : [ 3, 18 ],
      "id_str" : "25846336",
      "id" : 25846336
    }, {
      "name" : "Noemi S",
      "screen_name" : "NoemiFairy",
      "indices" : [ 23, 34 ],
      "id_str" : "186050218",
      "id" : 186050218
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38250289370902528",
  "text" : "RT @mssuzcatsilver: RT @NoemiFairy: Why is it that good things start to happen when you least expect it? Because you have released all r ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Noemi S",
        "screen_name" : "NoemiFairy",
        "indices" : [ 3, 14 ],
        "id_str" : "186050218",
        "id" : 186050218
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "loa",
        "indices" : [ 127, 131 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38248814330515456",
    "text" : "RT @NoemiFairy: Why is it that good things start to happen when you least expect it? Because you have released all resistance. #loa",
    "id" : 38248814330515456,
    "created_at" : "2011-02-17 14:50:02 +0000",
    "user" : {
      "name" : "suzcat",
      "screen_name" : "mssuzcatsilver",
      "protected" : false,
      "id_str" : "25846336",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1694602741\/Moi_14_Dec_2011_normal.JPG",
      "id" : 25846336,
      "verified" : false
    }
  },
  "id" : 38250289370902528,
  "created_at" : "2011-02-17 14:55:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 65, 76 ],
      "id_str" : "176864114",
      "id" : 176864114
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 78, 89 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38250164829433857",
  "text" : "Ehh. Hubbys upset. Past biting me in butt. He'll get over it. RT @mimismutts: @moosebegab Hey Gabby what's happening want to talk about it",
  "id" : 38250164829433857,
  "created_at" : "2011-02-17 14:55:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38247650734247936",
  "geo" : { },
  "id_str" : "38249825736736768",
  "in_reply_to_user_id" : 75708394,
  "text" : "I've read a lot of LOA stuff & have improved thoughts. : ) @JulzMayBe",
  "id" : 38249825736736768,
  "in_reply_to_status_id" : 38247650734247936,
  "created_at" : "2011-02-17 14:54:03 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 11, 18 ],
      "id_str" : "122393631",
      "id" : 122393631
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 60, 71 ],
      "id_str" : "93747129",
      "id" : 93747129
    }, {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 75, 90 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38249264480133120",
  "text" : "Never!! RT @SsmDad: mine is more like one big mistake :P RT @moosebegab RT @ReformedBuddha: I'm beginning to think my life is just one long",
  "id" : 38249264480133120,
  "created_at" : "2011-02-17 14:51:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 82, 89 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38205188648992768",
  "geo" : { },
  "id_str" : "38247843227643904",
  "in_reply_to_user_id" : 122393631,
  "text" : "((hugs)) its tough sometimes. I know hubby wants 2 strangle me every other day... @SsmDad",
  "id" : 38247843227643904,
  "in_reply_to_status_id" : 38205188648992768,
  "created_at" : "2011-02-17 14:46:11 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38245694737358848",
  "geo" : { },
  "id_str" : "38247316838285312",
  "in_reply_to_user_id" : 75708394,
  "text" : "Im playing w it now..lol : ) @JulzMayBe",
  "id" : 38247316838285312,
  "in_reply_to_status_id" : 38245694737358848,
  "created_at" : "2011-02-17 14:44:05 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38242412786745344",
  "geo" : { },
  "id_str" : "38244265888841729",
  "in_reply_to_user_id" : 75708394,
  "text" : "i'll take a look. I knew about dream\/vision boards.. just never actually created one. I should, tho. @JulzMayBe",
  "id" : 38244265888841729,
  "in_reply_to_status_id" : 38242412786745344,
  "created_at" : "2011-02-17 14:31:58 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38241266995179520",
  "geo" : { },
  "id_str" : "38241633321500672",
  "in_reply_to_user_id" : 75708394,
  "text" : "O Dream Board? @JulzMayBe",
  "id" : 38241633321500672,
  "in_reply_to_status_id" : 38241266995179520,
  "created_at" : "2011-02-17 14:21:30 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott J Klein",
      "screen_name" : "ScottJKlein",
      "indices" : [ 3, 15 ],
      "id_str" : "26628931",
      "id" : 26628931
    }, {
      "name" : "Dr. Rus Jeffrey",
      "screen_name" : "DrRus",
      "indices" : [ 17, 23 ],
      "id_str" : "11006552",
      "id" : 11006552
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38241544997842944",
  "text" : "RT @ScottJKlein: @DrRus Walk around naked !",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Dr. Rus Jeffrey",
        "screen_name" : "DrRus",
        "indices" : [ 0, 6 ],
        "id_str" : "11006552",
        "id" : 11006552
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "in_reply_to_status_id_str" : "38239192857317376",
    "geo" : { },
    "id_str" : "38241382925746176",
    "in_reply_to_user_id" : 11006552,
    "text" : "@DrRus Walk around naked !",
    "id" : 38241382925746176,
    "in_reply_to_status_id" : 38239192857317376,
    "created_at" : "2011-02-17 14:20:30 +0000",
    "in_reply_to_screen_name" : "DrRus",
    "in_reply_to_user_id_str" : "11006552",
    "user" : {
      "name" : "Scott J Klein",
      "screen_name" : "ScottJKlein",
      "protected" : false,
      "id_str" : "26628931",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/418425979347173376\/iOAZgfM8_normal.jpeg",
      "id" : 26628931,
      "verified" : false
    }
  },
  "id" : 38241544997842944,
  "created_at" : "2011-02-17 14:21:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38238714354343936",
  "geo" : { },
  "id_str" : "38240383146131456",
  "in_reply_to_user_id" : 75708394,
  "text" : "thx. not depressed but frustrated w something. @JulzMayBe",
  "id" : 38240383146131456,
  "in_reply_to_status_id" : 38238714354343936,
  "created_at" : "2011-02-17 14:16:32 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38237957513027584",
  "text" : "theres a stupid quote about being alive better than alternative.. Says who? I hate that quote. Being alive is f'ing hard work! ugh.",
  "id" : 38237957513027584,
  "created_at" : "2011-02-17 14:06:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38237543929614336",
  "text" : "Life. Dont talk to me about life.",
  "id" : 38237543929614336,
  "created_at" : "2011-02-17 14:05:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38237351360733184",
  "text" : "I cant seem to stay out of trouble..bleh.",
  "id" : 38237351360733184,
  "created_at" : "2011-02-17 14:04:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38236672361500672",
  "text" : "im up the creek without a paddle. sigh.",
  "id" : 38236672361500672,
  "created_at" : "2011-02-17 14:01:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38213369198686208",
  "text" : "RT @thDigitalReader: Another WTF moment in ebooks http:\/\/bit.ly\/fR3uZA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wordpress.org\/extend\/plugins\/twitter-publisher\/\" rel=\"nofollow\"\u003ETwitPublisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "38202375508336640",
    "text" : "Another WTF moment in ebooks http:\/\/bit.ly\/fR3uZA",
    "id" : 38202375508336640,
    "created_at" : "2011-02-17 11:45:30 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 38213369198686208,
  "created_at" : "2011-02-17 12:29:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grouchy Puppy\u00AE",
      "screen_name" : "grouchypuppy",
      "indices" : [ 35, 48 ],
      "id_str" : "29913475",
      "id" : 29913475
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "38048463518314496",
  "geo" : { },
  "id_str" : "38051493667934208",
  "in_reply_to_user_id" : 29913475,
  "text" : "feel better dear Cleo ((smooches)) @grouchypuppy",
  "id" : 38051493667934208,
  "in_reply_to_status_id" : 38048463518314496,
  "created_at" : "2011-02-17 01:45:57 +0000",
  "in_reply_to_screen_name" : "grouchypuppy",
  "in_reply_to_user_id_str" : "29913475",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "38001316412264448",
  "text" : "Puppy Army Siezes Control - The Animal Rescue Site http:\/\/bit.ly\/fuQ9ZI",
  "id" : 38001316412264448,
  "created_at" : "2011-02-16 22:26:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 3, 15 ],
      "id_str" : "24736943",
      "id" : 24736943
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37997031024898049",
  "text" : "RT @mindymayhem: The 10 Commandments From a Pet's Point of View http:\/\/www.doglistener.co.uk\/humour\/commandments.shtml This was posted a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37995777171263488",
    "text" : "The 10 Commandments From a Pet's Point of View http:\/\/www.doglistener.co.uk\/humour\/commandments.shtml This was posted at our vet's office. \u263A",
    "id" : 37995777171263488,
    "created_at" : "2011-02-16 22:04:33 +0000",
    "user" : {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "protected" : false,
      "id_str" : "24736943",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/656345451650650112\/VVyOZS8y_normal.png",
      "id" : 24736943,
      "verified" : false
    }
  },
  "id" : 37997031024898049,
  "created_at" : "2011-02-16 22:09:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37987373237141504",
  "text" : "Cool &gt;&gt; Electronic Eyes for Blinds http:\/\/bit.ly\/gKxeCS",
  "id" : 37987373237141504,
  "created_at" : "2011-02-16 21:31:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37982798111444992",
  "text" : "RT @Buddhaworld: i have to inform you, what you call your life is nothing but a cosmic joke.-love buddha volko",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37982484067135488",
    "text" : "i have to inform you, what you call your life is nothing but a cosmic joke.-love buddha volko",
    "id" : 37982484067135488,
    "created_at" : "2011-02-16 21:11:44 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 37982798111444992,
  "created_at" : "2011-02-16 21:12:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 39, 50 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37978602360422400",
  "geo" : { },
  "id_str" : "37982449585758208",
  "in_reply_to_user_id" : 6994832,
  "text" : "now you now how weird I really am! lol @TrishScott",
  "id" : 37982449585758208,
  "in_reply_to_status_id" : 37978602360422400,
  "created_at" : "2011-02-16 21:11:36 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37976715229659136",
  "text" : "RT @DougDorow: New Author FB page, could use some Love or pick the Like button. Thx. http:\/\/ow.ly\/3XM40",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37966948088152065",
    "text" : "New Author FB page, could use some Love or pick the Like button. Thx. http:\/\/ow.ly\/3XM40",
    "id" : 37966948088152065,
    "created_at" : "2011-02-16 20:10:00 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 37976715229659136,
  "created_at" : "2011-02-16 20:48:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37959424320475136",
  "text" : "My Comments on: Adults With Aspergers: What Other Family Members Need To Know http:\/\/on.fb.me\/hGMzPj",
  "id" : 37959424320475136,
  "created_at" : "2011-02-16 19:40:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Charlotte",
      "screen_name" : "KindleAuthors",
      "indices" : [ 3, 17 ],
      "id_str" : "911559336",
      "id" : 911559336
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "SampleSunday",
      "indices" : [ 19, 32 ]
    }, {
      "text" : "kindle",
      "indices" : [ 95, 102 ]
    }, {
      "text" : "ebook",
      "indices" : [ 103, 109 ]
    }, {
      "text" : "book",
      "indices" : [ 110, 115 ]
    }, {
      "text" : "writing",
      "indices" : [ 116, 124 ]
    }, {
      "text" : "publishing",
      "indices" : [ 125, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37937271021903872",
  "text" : "RT @kindleauthors: #SampleSunday\u2014a FREE and FUN way to promote your book! http:\/\/bit.ly\/eofpmo #kindle #ebook #book #writing #publishing ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/futuretweets.com\" rel=\"nofollow\"\u003E Futuretweets V2 - old\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SampleSunday",
        "indices" : [ 0, 13 ]
      }, {
        "text" : "kindle",
        "indices" : [ 76, 83 ]
      }, {
        "text" : "ebook",
        "indices" : [ 84, 90 ]
      }, {
        "text" : "book",
        "indices" : [ 91, 96 ]
      }, {
        "text" : "writing",
        "indices" : [ 97, 105 ]
      }, {
        "text" : "publishing",
        "indices" : [ 106, 117 ]
      }, {
        "text" : "nook",
        "indices" : [ 118, 123 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37936524435652608",
    "text" : "#SampleSunday\u2014a FREE and FUN way to promote your book! http:\/\/bit.ly\/eofpmo #kindle #ebook #book #writing #publishing #nook\u2014PLZ RT!",
    "id" : 37936524435652608,
    "created_at" : "2011-02-16 18:09:06 +0000",
    "user" : {
      "name" : "David Wisehart",
      "screen_name" : "ebookimpresario",
      "protected" : false,
      "id_str" : "181461227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1583967511\/devils-lair-twitter-sm_normal.jpg",
      "id" : 181461227,
      "verified" : false
    }
  },
  "id" : 37937271021903872,
  "created_at" : "2011-02-16 18:12:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "atheistsixpacksrawesome",
      "indices" : [ 104, 128 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37937161386999808",
  "text" : "RT @thesexyatheist: Dammmm my avatar got a not PG rating for Garvatar\/wordpress. Must be run by 'them.' #atheistsixpacksrawesome",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "atheistsixpacksrawesome",
        "indices" : [ 84, 108 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37933251876233216",
    "text" : "Dammmm my avatar got a not PG rating for Garvatar\/wordpress. Must be run by 'them.' #atheistsixpacksrawesome",
    "id" : 37933251876233216,
    "created_at" : "2011-02-16 17:56:06 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 37937161386999808,
  "created_at" : "2011-02-16 18:11:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37934718380933120",
  "text" : "10 Islands to Explore Before You Die http:\/\/yhoo.it\/g8NUKi",
  "id" : 37934718380933120,
  "created_at" : "2011-02-16 18:01:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37919136549965824",
  "text" : "My Aspergers Child: Adults With Aspergers: What Other Family Members Need To Know http:\/\/bit.ly\/iijM8a",
  "id" : 37919136549965824,
  "created_at" : "2011-02-16 17:00:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 3, 17 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37917262291804160",
  "text" : "RT @Dwayne_Reaves: RT @JDorsettKoch: Respect yourself everyday! Don't let anyone push you into something that is not you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37914286579781632",
    "text" : "RT @JDorsettKoch: Respect yourself everyday! Don't let anyone push you into something that is not you.",
    "id" : 37914286579781632,
    "created_at" : "2011-02-16 16:40:44 +0000",
    "user" : {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwaynereaves",
      "protected" : false,
      "id_str" : "73908822",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/800696562456428544\/3cCyzA8R_normal.jpg",
      "id" : 73908822,
      "verified" : false
    }
  },
  "id" : 37917262291804160,
  "created_at" : "2011-02-16 16:52:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Old Dog Haven",
      "screen_name" : "OldDogHaven",
      "indices" : [ 3, 15 ],
      "id_str" : "30454230",
      "id" : 30454230
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37915051197345792",
  "text" : "RT @OldDogHaven: Final Refuge home needed:big shepherd or rottie mix lady, spayed and 15 years old, from hoarding situation, total... ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37912696393449472",
    "text" : "Final Refuge home needed:big shepherd or rottie mix lady, spayed and 15 years old, from hoarding situation, total... http:\/\/fb.me\/T9H97s8j",
    "id" : 37912696393449472,
    "created_at" : "2011-02-16 16:34:25 +0000",
    "user" : {
      "name" : "Old Dog Haven",
      "screen_name" : "OldDogHaven",
      "protected" : false,
      "id_str" : "30454230",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590689116565676033\/9ClwTfrJ_normal.png",
      "id" : 30454230,
      "verified" : false
    }
  },
  "id" : 37915051197345792,
  "created_at" : "2011-02-16 16:43:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37905447222513664",
  "text" : "RT @scottsigler: Whoever said \"there are no stupid questions\" hasn't hung out with me all that much.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37904842848600065",
    "text" : "Whoever said \"there are no stupid questions\" hasn't hung out with me all that much.",
    "id" : 37904842848600065,
    "created_at" : "2011-02-16 16:03:13 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 37905447222513664,
  "created_at" : "2011-02-16 16:05:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37903734793043968",
  "geo" : { },
  "id_str" : "37905043432673281",
  "in_reply_to_user_id" : 75708394,
  "text" : "how's he doing? @JulzMayBe",
  "id" : 37905043432673281,
  "in_reply_to_status_id" : 37903734793043968,
  "created_at" : "2011-02-16 16:04:01 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 35, 46 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37904767808319488",
  "text" : "hey, authors\/readers - please give @modernevil feedback on New Untrue Tales - book covers http:\/\/bit.ly\/fKUDVj",
  "id" : 37904767808319488,
  "created_at" : "2011-02-16 16:02:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 116, 135 ],
      "url" : "http:\/\/t.co\/gPc3nE9",
      "expanded_url" : "http:\/\/lessthanthis.com\/2011\/02\/new-untrue-tales-covers\/",
      "display_url" : "lessthanthis.com\/2011\/02\/new-un\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "37901777089200128",
  "text" : "RT @modernevil: New post about my new books\/covers, including spines & back-cover copy. I would love your feedback: http:\/\/t.co\/gPc3nE9",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 119 ],
        "url" : "http:\/\/t.co\/gPc3nE9",
        "expanded_url" : "http:\/\/lessthanthis.com\/2011\/02\/new-untrue-tales-covers\/",
        "display_url" : "lessthanthis.com\/2011\/02\/new-un\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "37897349447692288",
    "text" : "New post about my new books\/covers, including spines & back-cover copy. I would love your feedback: http:\/\/t.co\/gPc3nE9",
    "id" : 37897349447692288,
    "created_at" : "2011-02-16 15:33:26 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 37901777089200128,
  "created_at" : "2011-02-16 15:51:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ArrestRoveNow3",
      "screen_name" : "ArrestRoveNow3",
      "indices" : [ 3, 18 ],
      "id_str" : "24521540",
      "id" : 24521540
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37892372666785794",
  "text" : "RT @ArrestRoveNow3: Glenn Beck:\"I have felt a growing evil & I don't know if anyone else has felt it.\" Wouldn't it be great if an alien  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37883349196349441",
    "text" : "Glenn Beck:\"I have felt a growing evil & I don't know if anyone else has felt it.\" Wouldn't it be great if an alien popped out of his chest?",
    "id" : 37883349196349441,
    "created_at" : "2011-02-16 14:37:48 +0000",
    "user" : {
      "name" : "ArrestRoveNow3",
      "screen_name" : "ArrestRoveNow3",
      "protected" : false,
      "id_str" : "24521540",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797227218711744512\/iJtsOpLS_normal.jpg",
      "id" : 24521540,
      "verified" : false
    }
  },
  "id" : 37892372666785794,
  "created_at" : "2011-02-16 15:13:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    }, {
      "name" : "Darlene Arden, CABC",
      "screen_name" : "petxpert",
      "indices" : [ 28, 37 ],
      "id_str" : "15324184",
      "id" : 15324184
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37663822823170048",
  "text" : "RT @fearfuldogs: love it RT @petxpert: YouTube - Foxes Jumping on my Trampoline http:\/\/youtu.be\/c8xJtH6UcQY",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Darlene Arden, CABC",
        "screen_name" : "petxpert",
        "indices" : [ 11, 20 ],
        "id_str" : "15324184",
        "id" : 15324184
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37659825622093824",
    "text" : "love it RT @petxpert: YouTube - Foxes Jumping on my Trampoline http:\/\/youtu.be\/c8xJtH6UcQY",
    "id" : 37659825622093824,
    "created_at" : "2011-02-15 23:49:36 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 37663822823170048,
  "created_at" : "2011-02-16 00:05:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Damien Fahey",
      "screen_name" : "DamienFahey",
      "indices" : [ 15, 27 ],
      "id_str" : "21215371",
      "id" : 21215371
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37658092309053441",
  "text" : "RT @BestAt: RT @DamienFahey: If I'm reading this correctly the Second Amendment allows me to shoot a bear, tear off his arms and keep them.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Damien Fahey",
        "screen_name" : "DamienFahey",
        "indices" : [ 3, 15 ],
        "id_str" : "21215371",
        "id" : 21215371
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37656303044141056",
    "text" : "RT @DamienFahey: If I'm reading this correctly the Second Amendment allows me to shoot a bear, tear off his arms and keep them.",
    "id" : 37656303044141056,
    "created_at" : "2011-02-15 23:35:36 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 37658092309053441,
  "created_at" : "2011-02-15 23:42:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 3, 18 ],
      "id_str" : "30825946",
      "id" : 30825946
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37658016731893760",
  "text" : "RT @JonathanElliot: Have you got an interesting idea for a study topic? I need ideas http:\/\/bit.ly\/h9ZXss Thanks! :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37656113046503424",
    "text" : "Have you got an interesting idea for a study topic? I need ideas http:\/\/bit.ly\/h9ZXss Thanks! :)",
    "id" : 37656113046503424,
    "created_at" : "2011-02-15 23:34:51 +0000",
    "user" : {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "protected" : false,
      "id_str" : "30825946",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1534911961\/black_square_normal.jpg",
      "id" : 30825946,
      "verified" : false
    }
  },
  "id" : 37658016731893760,
  "created_at" : "2011-02-15 23:42:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 3, 14 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37657755481419777",
  "text" : "RT @quantafire: Anyone want a free massage on Thursday in Central London? I'm serious. I can't go. Please RT!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37653879403315200",
    "text" : "Anyone want a free massage on Thursday in Central London? I'm serious. I can't go. Please RT!",
    "id" : 37653879403315200,
    "created_at" : "2011-02-15 23:25:59 +0000",
    "user" : {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "protected" : false,
      "id_str" : "8449382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2943941501\/b15b399a7823bad25f64b6482704e678_normal.jpeg",
      "id" : 8449382,
      "verified" : false
    }
  },
  "id" : 37657755481419777,
  "created_at" : "2011-02-15 23:41:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37657381953474560",
  "text" : "RT @AnAmericanMonk: Is 2012 Real is this the end times see the video here. http:\/\/lnk.ms\/KY9lx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myspace.com\/sync\" rel=\"nofollow\"\u003EMySpace\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37649018616029184",
    "text" : "Is 2012 Real is this the end times see the video here. http:\/\/lnk.ms\/KY9lx",
    "id" : 37649018616029184,
    "created_at" : "2011-02-15 23:06:40 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 37657381953474560,
  "created_at" : "2011-02-15 23:39:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 13, 28 ],
      "id_str" : "16114141",
      "id" : 16114141
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 30, 41 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37657246368411648",
  "text" : "Lol..Yes! RT @KreelanWarrior: @moosebegab Does the 52% mean how much you've read? :-)",
  "id" : 37657246368411648,
  "created_at" : "2011-02-15 23:39:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "giveaways",
      "indices" : [ 90, 100 ]
    }, {
      "text" : "contests",
      "indices" : [ 101, 110 ]
    }, {
      "text" : "books",
      "indices" : [ 111, 117 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 118, 125 ]
    }, {
      "text" : "free",
      "indices" : [ 126, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37656085762408448",
  "text" : "RT @DarciaHelle: Valentine\u2019s Day Giveaway! Print books, ebooks & more! http:\/\/j.mp\/gEgeg9 #giveaways #contests #books #ebooks #free",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "giveaways",
        "indices" : [ 73, 83 ]
      }, {
        "text" : "contests",
        "indices" : [ 84, 93 ]
      }, {
        "text" : "books",
        "indices" : [ 94, 100 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 101, 108 ]
      }, {
        "text" : "free",
        "indices" : [ 109, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37653221870673921",
    "text" : "Valentine\u2019s Day Giveaway! Print books, ebooks & more! http:\/\/j.mp\/gEgeg9 #giveaways #contests #books #ebooks #free",
    "id" : 37653221870673921,
    "created_at" : "2011-02-15 23:23:22 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 37656085762408448,
  "created_at" : "2011-02-15 23:34:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "indices" : [ 3, 17 ],
      "id_str" : "151971904",
      "id" : 151971904
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37655761647710208",
  "text" : "RT @bunnybuddhism: May I be true to my bunny nature even when faced with those who want me to be a fish or a bird.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37654927996100609",
    "text" : "May I be true to my bunny nature even when faced with those who want me to be a fish or a bird.",
    "id" : 37654927996100609,
    "created_at" : "2011-02-15 23:30:09 +0000",
    "user" : {
      "name" : "Bunny Buddhism",
      "screen_name" : "bunnybuddhism",
      "protected" : false,
      "id_str" : "151971904",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447374371917922304\/P4BzupWu_normal.jpeg",
      "id" : 151971904,
      "verified" : false
    }
  },
  "id" : 37655761647710208,
  "created_at" : "2011-02-15 23:33:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 41, 55 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37644939647123456",
  "geo" : { },
  "id_str" : "37645635612192768",
  "in_reply_to_user_id" : 73908822,
  "text" : "very glad 2 hear that! Im a wuss w pain. @Dwayne_Reaves",
  "id" : 37645635612192768,
  "in_reply_to_status_id" : 37644939647123456,
  "created_at" : "2011-02-15 22:53:13 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 50, 64 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37384016923463681",
  "geo" : { },
  "id_str" : "37644452164157440",
  "in_reply_to_user_id" : 73908822,
  "text" : "how are the valiums working out for you? helping? @Dwayne_Reaves",
  "id" : 37644452164157440,
  "in_reply_to_status_id" : 37384016923463681,
  "created_at" : "2011-02-15 22:48:31 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Sherry Reed",
      "screen_name" : "SherryPCMO",
      "indices" : [ 3, 14 ],
      "id_str" : "29262732",
      "id" : 29262732
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37641032774451201",
  "text" : "RT @SherryPCMO: RT @CNNLive: Are redheads really distracting? One school says yes and suspends a student for getting ginger locks.  http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37639553670066176",
    "text" : "RT @CNNLive: Are redheads really distracting? One school says yes and suspends a student for getting ginger locks.  http:\/\/on.cnn.com\/gx0FXe",
    "id" : 37639553670066176,
    "created_at" : "2011-02-15 22:29:03 +0000",
    "user" : {
      "name" : "Sherry Reed",
      "screen_name" : "SherryPCMO",
      "protected" : false,
      "id_str" : "29262732",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797197307796144128\/iMQxez4Z_normal.jpg",
      "id" : 29262732,
      "verified" : false
    }
  },
  "id" : 37641032774451201,
  "created_at" : "2011-02-15 22:34:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 7, 17 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    }, {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 19, 33 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37633810505924609",
  "text" : "LOL RT @ID_vs_EGO: @HEATHENRABBIT whom shall I say is asking?",
  "id" : 37633810505924609,
  "created_at" : "2011-02-15 22:06:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 3, 19 ],
      "id_str" : "26547903",
      "id" : 26547903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37632868066787328",
  "text" : "RT @SparklingReview: We only need 12 more followers before I giveaway a NookColor! www.sparklingreviews.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37629234138710016",
    "text" : "We only need 12 more followers before I giveaway a NookColor! www.sparklingreviews.com",
    "id" : 37629234138710016,
    "created_at" : "2011-02-15 21:48:03 +0000",
    "user" : {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "protected" : false,
      "id_str" : "26547903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535442186964176897\/q9jfS0U4_normal.png",
      "id" : 26547903,
      "verified" : false
    }
  },
  "id" : 37632868066787328,
  "created_at" : "2011-02-15 22:02:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 25, 40 ],
      "id_str" : "16114141",
      "id" : 16114141
    }, {
      "name" : "Elizabeth Brown",
      "screen_name" : "FrugaleReader",
      "indices" : [ 47, 61 ],
      "id_str" : "199456136",
      "id" : 199456136
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37607426723151872",
  "geo" : { },
  "id_str" : "37608260416712704",
  "in_reply_to_user_id" : 199456136,
  "text" : "Season of the Harvest by @KreelanWarrior (52%) @FrugaleReader",
  "id" : 37608260416712704,
  "in_reply_to_status_id" : 37607426723151872,
  "created_at" : "2011-02-15 20:24:42 +0000",
  "in_reply_to_screen_name" : "FrugaleReader",
  "in_reply_to_user_id_str" : "199456136",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "indices" : [ 3, 15 ],
      "id_str" : "51846392",
      "id" : 51846392
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37606057975095296",
  "text" : "RT @Jeweldspear: I had a nice visit from a J Witness gentleman who promptly informed me that I'm \"Evil'. I horse laughed him right off m ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37599026463379456",
    "text" : "I had a nice visit from a J Witness gentleman who promptly informed me that I'm \"Evil'. I horse laughed him right off my porch.",
    "id" : 37599026463379456,
    "created_at" : "2011-02-15 19:48:01 +0000",
    "user" : {
      "name" : "Julie Spear",
      "screen_name" : "Jeweldspear",
      "protected" : false,
      "id_str" : "51846392",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655444947940823041\/ORiamX3x_normal.jpg",
      "id" : 51846392,
      "verified" : false
    }
  },
  "id" : 37606057975095296,
  "created_at" : "2011-02-15 20:15:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37555541416873984",
  "text" : "Nine Pictures of the Extreme Income\/Wealth Gap http:\/\/bit.ly\/hJEYv4",
  "id" : 37555541416873984,
  "created_at" : "2011-02-15 16:55:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37546106040623104",
  "text" : "found a beautiful dog poem. added it to Kari's page: http:\/\/www.abfabgab.com\/the-dog\/",
  "id" : 37546106040623104,
  "created_at" : "2011-02-15 16:17:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37544859648659456",
  "text" : "Secret formula for Coca-Cola found in old newspaper column http:\/\/bit.ly\/exK1qg",
  "id" : 37544859648659456,
  "created_at" : "2011-02-15 16:12:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 3, 10 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Iran",
      "indices" : [ 12, 17 ]
    }, {
      "text" : "HR",
      "indices" : [ 79, 82 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37502076497960960",
  "text" : "RT @SsmDad: #Iran murder regime calls for execution of two opposition leaders. #HR http:\/\/bit.ly\/fPHdaB (I bet they'd love nothing more)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twicca.r246.jp\/\" rel=\"nofollow\"\u003Etwicca\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Iran",
        "indices" : [ 0, 5 ]
      }, {
        "text" : "HR",
        "indices" : [ 67, 70 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37500259236052993",
    "text" : "#Iran murder regime calls for execution of two opposition leaders. #HR http:\/\/bit.ly\/fPHdaB (I bet they'd love nothing more)",
    "id" : 37500259236052993,
    "created_at" : "2011-02-15 13:15:33 +0000",
    "user" : {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "protected" : false,
      "id_str" : "122393631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/649760376880525312\/faJeQ4K3_normal.jpg",
      "id" : 122393631,
      "verified" : false
    }
  },
  "id" : 37502076497960960,
  "created_at" : "2011-02-15 13:22:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 107, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37497069090377729",
  "text" : "RT @hauntedcomputer: RT The Skull Ring link today and be entered for $10 gift certificate for Amazon or BN #kindle http:\/\/amzn.to\/9Ii8kC ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 86, 93 ]
      }, {
        "text" : "mystery",
        "indices" : [ 116, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37495038774607872",
    "text" : "RT The Skull Ring link today and be entered for $10 gift certificate for Amazon or BN #kindle http:\/\/amzn.to\/9Ii8kC #mystery",
    "id" : 37495038774607872,
    "created_at" : "2011-02-15 12:54:48 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 37497069090377729,
  "created_at" : "2011-02-15 13:02:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37496830417707009",
  "text" : "dog kept me up all night.",
  "id" : 37496830417707009,
  "created_at" : "2011-02-15 13:01:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    }, {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 97, 108 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Dobby the Capybara",
      "screen_name" : "hippopotatomus",
      "indices" : [ 113, 128 ],
      "id_str" : "48001363",
      "id" : 48001363
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37324391620546560",
  "text" : "RT @GaribaldiRous: Don't forget to vote on your favorite capybara puzzle possibilities featuring @CaplinRous and @hippopotatomus' Dobby. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Caplin Rous",
        "screen_name" : "CaplinROUS",
        "indices" : [ 78, 89 ],
        "id_str" : "18840386",
        "id" : 18840386
      }, {
        "name" : "Dobby the Capybara",
        "screen_name" : "hippopotatomus",
        "indices" : [ 94, 109 ],
        "id_str" : "48001363",
        "id" : 48001363
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37321629151268864",
    "text" : "Don't forget to vote on your favorite capybara puzzle possibilities featuring @CaplinRous and @hippopotatomus' Dobby. http:\/\/bit.ly\/g0fXZ0",
    "id" : 37321629151268864,
    "created_at" : "2011-02-15 01:25:44 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 37324391620546560,
  "created_at" : "2011-02-15 01:36:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 67, 75 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37293681883099136",
  "geo" : { },
  "id_str" : "37297217228251136",
  "in_reply_to_user_id" : 54744689,
  "text" : "you're amazing Ani-La. someday may I be as strong as you! ((hugs)) @SangyeH",
  "id" : 37297217228251136,
  "in_reply_to_status_id" : 37293681883099136,
  "created_at" : "2011-02-14 23:48:44 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37296605203791873",
  "text" : "RT @hvspca: Tully our pittie from nyc acc is up and running around 2wks in icu and $9,000 later. Donations for vet bill r needed hvspca. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/blackberry.com\/twitter\" rel=\"nofollow\"\u003ETwitter for BlackBerry\u00AE\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37296373124562944",
    "text" : "Tully our pittie from nyc acc is up and running around 2wks in icu and $9,000 later. Donations for vet bill r needed hvspca.org paypal",
    "id" : 37296373124562944,
    "created_at" : "2011-02-14 23:45:22 +0000",
    "user" : {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "protected" : false,
      "id_str" : "99531497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638069419164454913\/KeccRrpI_normal.jpg",
      "id" : 99531497,
      "verified" : false
    }
  },
  "id" : 37296605203791873,
  "created_at" : "2011-02-14 23:46:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Elijah",
      "screen_name" : "Keldraan",
      "indices" : [ 3, 12 ],
      "id_str" : "91947124",
      "id" : 91947124
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37261366389641216",
  "text" : "RT @Keldraan: To declare something is bad or evil without truly knowing what there is to know about it is to be in ignorant denial.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37257636034514944",
    "text" : "To declare something is bad or evil without truly knowing what there is to know about it is to be in ignorant denial.",
    "id" : 37257636034514944,
    "created_at" : "2011-02-14 21:11:27 +0000",
    "user" : {
      "name" : "Elijah",
      "screen_name" : "Keldraan",
      "protected" : true,
      "id_str" : "91947124",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/590581022405881856\/9aiyWglz_normal.jpg",
      "id" : 91947124,
      "verified" : false
    }
  },
  "id" : 37261366389641216,
  "created_at" : "2011-02-14 21:26:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 106, 117 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37232285371596800",
  "geo" : { },
  "id_str" : "37233363848929280",
  "in_reply_to_user_id" : 7482152,
  "text" : "the one from a few weeks ago was better, tho. Forget Spaghetti. No one can recreate my Mom's sauce..sigh. @modernevil",
  "id" : 37233363848929280,
  "in_reply_to_status_id" : 37232285371596800,
  "created_at" : "2011-02-14 19:35:00 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 63, 74 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37231263576231937",
  "geo" : { },
  "id_str" : "37231891346104321",
  "in_reply_to_user_id" : 7482152,
  "text" : "hubs made lasagna yesterday. sauce was a tad sweet 4 me.. sigh @modernevil",
  "id" : 37231891346104321,
  "in_reply_to_status_id" : 37231263576231937,
  "created_at" : "2011-02-14 19:29:09 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 74, 88 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37220089317040128",
  "text" : "\"...you are existing in an odd assed alternate version of my reality.\" in @heathenrabbit blog post. I love that! hehe",
  "id" : 37220089317040128,
  "created_at" : "2011-02-14 18:42:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thrillers",
      "indices" : [ 23, 33 ]
    }, {
      "text" : "bookgeek",
      "indices" : [ 101, 110 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37211686813310977",
  "text" : "RT @ThrillersRockT: In #thrillers, I love a good explosion. In my life? A nice night at the library. #bookgeek",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thrillers",
        "indices" : [ 3, 13 ]
      }, {
        "text" : "bookgeek",
        "indices" : [ 81, 90 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37203296217210880",
    "text" : "In #thrillers, I love a good explosion. In my life? A nice night at the library. #bookgeek",
    "id" : 37203296217210880,
    "created_at" : "2011-02-14 17:35:31 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 37211686813310977,
  "created_at" : "2011-02-14 18:08:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37193434473177088",
  "text" : "robostir",
  "id" : 37193434473177088,
  "created_at" : "2011-02-14 16:56:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "indices" : [ 3, 18 ],
      "id_str" : "31986700",
      "id" : 31986700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37193358661128192",
  "text" : "RT @VeryShortStory: Cupid came to help. He drew his bow and fired an arrow at Raina, but his aim was low. I was forever in love with her ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37193236057432065",
    "text" : "Cupid came to help. He drew his bow and fired an arrow at Raina, but his aim was low. I was forever in love with her feet.",
    "id" : 37193236057432065,
    "created_at" : "2011-02-14 16:55:33 +0000",
    "user" : {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "protected" : false,
      "id_str" : "31986700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/141070636\/42291_normal.jpg",
      "id" : 31986700,
      "verified" : false
    }
  },
  "id" : 37193358661128192,
  "created_at" : "2011-02-14 16:56:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37191168815013889",
  "text" : "you are existing in an odd assed alternate version of my reality. http:\/\/bit.ly\/fL5JkW",
  "id" : 37191168815013889,
  "created_at" : "2011-02-14 16:47:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37190056632385536",
  "text" : "I am whatever distinction that you perceive me as. You will have a name for me... http:\/\/bit.ly\/fL5JkW",
  "id" : 37190056632385536,
  "created_at" : "2011-02-14 16:42:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    }, {
      "name" : "Pax Paxochka",
      "screen_name" : "Paxochka",
      "indices" : [ 15, 24 ],
      "id_str" : "35888311",
      "id" : 35888311
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37188328931463170",
  "text" : "RT @BestAt: RT @Paxochka: I think I accidentally swallowed a whole bottle of Vitamin Evil this morning.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pax Paxochka",
        "screen_name" : "Paxochka",
        "indices" : [ 3, 12 ],
        "id_str" : "35888311",
        "id" : 35888311
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37188214833815552",
    "text" : "RT @Paxochka: I think I accidentally swallowed a whole bottle of Vitamin Evil this morning.",
    "id" : 37188214833815552,
    "created_at" : "2011-02-14 16:35:35 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 37188328931463170,
  "created_at" : "2011-02-14 16:36:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37188257217253377",
  "text" : "and.. im NOT going to DR..",
  "id" : 37188257217253377,
  "created_at" : "2011-02-14 16:35:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37187988504973312",
  "text" : "hubs didnt get me kindle credit.. that should piss me off not make me cry..",
  "id" : 37187988504973312,
  "created_at" : "2011-02-14 16:34:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37186289878958082",
  "text" : "The poles are shifting... is that it? cuz nothing else makes sense...",
  "id" : 37186289878958082,
  "created_at" : "2011-02-14 16:27:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37186124514332673",
  "text" : "Why do I feel like crying? Whats wrong w me?",
  "id" : 37186124514332673,
  "created_at" : "2011-02-14 16:27:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37179262729457664",
  "text" : "Egyptian Protesters Did in 2 1\/2 Weeks What the American Military Could Not Do in 9 Years of War ...  http:\/\/bit.ly\/e6SVmE",
  "id" : 37179262729457664,
  "created_at" : "2011-02-14 16:00:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37176177160486912",
  "text" : "I HATE ALL holidays!!",
  "id" : 37176177160486912,
  "created_at" : "2011-02-14 15:47:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37176109372153856",
  "text" : "being married does not make Valentines Day a good thing! bleh",
  "id" : 37176109372153856,
  "created_at" : "2011-02-14 15:47:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37167373186236418",
  "text" : "still no Kindle credit 4 me.. hmmm.. I am sad.",
  "id" : 37167373186236418,
  "created_at" : "2011-02-14 15:12:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Grim Reaper",
      "screen_name" : "DeathMacabre",
      "indices" : [ 3, 16 ],
      "id_str" : "119727875",
      "id" : 119727875
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37165279066861568",
  "text" : "RT @DeathMacabre: I prefer the long, unending sleep of the dead. NO drugs necessary,",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37163196930334720",
    "text" : "I prefer the long, unending sleep of the dead. NO drugs necessary,",
    "id" : 37163196930334720,
    "created_at" : "2011-02-14 14:56:11 +0000",
    "user" : {
      "name" : "Grim Reaper",
      "screen_name" : "DeathMacabre",
      "protected" : false,
      "id_str" : "119727875",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000808403820\/23afd2905a658e2b23ac9e274a66c2c9_normal.jpeg",
      "id" : 119727875,
      "verified" : false
    }
  },
  "id" : 37165279066861568,
  "created_at" : "2011-02-14 15:04:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37156336437301248",
  "text" : "Funny dog pictures, unless you\u2019re the dog \u00AB Fearfuldogs' Blog http:\/\/bit.ly\/fGO2IZ",
  "id" : 37156336437301248,
  "created_at" : "2011-02-14 14:28:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 45, 55 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    }, {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 56, 70 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37155158483800066",
  "text" : "referring to HR writing a new blog post..lol @ID_vs_EGO @HEATHENRABBIT",
  "id" : 37155158483800066,
  "created_at" : "2011-02-14 14:24:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "RedRabbit",
      "screen_name" : "DonkeyPr",
      "indices" : [ 3, 12 ],
      "id_str" : "4437188367",
      "id" : 4437188367
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37154280414773248",
  "text" : "RT @DonkeyPR: Love begins at forty, even for some donkeys!! http:\/\/bit.ly\/fagPq4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37151989691326464",
    "text" : "Love begins at forty, even for some donkeys!! http:\/\/bit.ly\/fagPq4",
    "id" : 37151989691326464,
    "created_at" : "2011-02-14 14:11:39 +0000",
    "user" : {
      "name" : "The Donkey Sanctuary",
      "screen_name" : "DonkeySanctuary",
      "protected" : false,
      "id_str" : "95607516",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/710457498201952257\/F4zdnP4M_normal.jpg",
      "id" : 95607516,
      "verified" : true
    }
  },
  "id" : 37154280414773248,
  "created_at" : "2011-02-14 14:20:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 15, 29 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "37122200490217472",
  "geo" : { },
  "id_str" : "37153406334271488",
  "in_reply_to_user_id" : 73908822,
  "text" : "ouch! ((hugs)) @Dwayne_Reaves",
  "id" : 37153406334271488,
  "in_reply_to_status_id" : 37122200490217472,
  "created_at" : "2011-02-14 14:17:17 +0000",
  "in_reply_to_screen_name" : "dwaynereaves",
  "in_reply_to_user_id_str" : "73908822",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "indices" : [ 3, 18 ],
      "id_str" : "63804234",
      "id" : 63804234
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37152262409162752",
  "text" : "RT @PeggySueCusses: I hate watching the news. It feels like I'm being assaulted. All the bad news and useless news.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.cloudhopper.com\/\" rel=\"nofollow\"\u003ECloudhopper\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "37133097912770560",
    "text" : "I hate watching the news. It feels like I'm being assaulted. All the bad news and useless news.",
    "id" : 37133097912770560,
    "created_at" : "2011-02-14 12:56:35 +0000",
    "user" : {
      "name" : "PeggySueConservative",
      "screen_name" : "PeggySueCusses",
      "protected" : false,
      "id_str" : "63804234",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/464607556824879104\/Ffa8JBJv_normal.jpeg",
      "id" : 63804234,
      "verified" : false
    }
  },
  "id" : 37152262409162752,
  "created_at" : "2011-02-14 14:12:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 24, 38 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    }, {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 39, 49 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "37151557334212608",
  "text" : "another blog post? yay! @HEATHENRABBIT @ID_vs_EGO",
  "id" : 37151557334212608,
  "created_at" : "2011-02-14 14:09:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 90, 103 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "Carl Barbarotto",
      "screen_name" : "Carlolight",
      "indices" : [ 104, 115 ],
      "id_str" : "146324614",
      "id" : 146324614
    }, {
      "name" : "Alexandra Folz",
      "screen_name" : "AlexandraFolz",
      "indices" : [ 116, 130 ],
      "id_str" : "214695172",
      "id" : 214695172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36950219471978496",
  "geo" : { },
  "id_str" : "36958423295725568",
  "in_reply_to_user_id" : 113458113,
  "text" : "THIS \"cant tolerate negativity\" \"sparks in me meant 2 shine were stifled\" (by negativity) @neardeathdoc @Carlolight @AlexandraFolz",
  "id" : 36958423295725568,
  "in_reply_to_status_id" : 36950219471978496,
  "created_at" : "2011-02-14 01:22:29 +0000",
  "in_reply_to_screen_name" : "neardeathdoc",
  "in_reply_to_user_id_str" : "113458113",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "indices" : [ 3, 13 ],
      "id_str" : "38944844",
      "id" : 38944844
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "quote",
      "indices" : [ 121, 127 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36952291068092416",
  "text" : "RT @TracyLatz: Love takes off masks that we fear we cannot live without and know we cannot live within. James A. Baldwin #quote",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "quote",
        "indices" : [ 106, 112 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36951913069019136",
    "text" : "Love takes off masks that we fear we cannot live without and know we cannot live within. James A. Baldwin #quote",
    "id" : 36951913069019136,
    "created_at" : "2011-02-14 00:56:37 +0000",
    "user" : {
      "name" : "Tracy Latz MD",
      "screen_name" : "TracyLatz",
      "protected" : false,
      "id_str" : "38944844",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3613255912\/6231c73638d3ac954d0e9984376a6eb9_normal.jpeg",
      "id" : 38944844,
      "verified" : false
    }
  },
  "id" : 36952291068092416,
  "created_at" : "2011-02-14 00:58:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "Carl Barbarotto",
      "screen_name" : "Carlolight",
      "indices" : [ 21, 32 ],
      "id_str" : "146324614",
      "id" : 146324614
    }, {
      "name" : "Alexandra Folz",
      "screen_name" : "AlexandraFolz",
      "indices" : [ 34, 48 ],
      "id_str" : "214695172",
      "id" : 214695172
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36951472264450049",
  "text" : "RT @neardeathdoc: RT @Carlolight: @AlexandraFolz YouTube video -Group Discussion: Death is Not to Be Feared Dr Morse Pres... http:\/\/yout ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Carl Barbarotto",
        "screen_name" : "Carlolight",
        "indices" : [ 3, 14 ],
        "id_str" : "146324614",
        "id" : 146324614
      }, {
        "name" : "Alexandra Folz",
        "screen_name" : "AlexandraFolz",
        "indices" : [ 16, 30 ],
        "id_str" : "214695172",
        "id" : 214695172
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36950219471978496",
    "text" : "RT @Carlolight: @AlexandraFolz YouTube video -Group Discussion: Death is Not to Be Feared Dr Morse Pres... http:\/\/youtu.be\/11Q8RX5bxwA?",
    "id" : 36950219471978496,
    "created_at" : "2011-02-14 00:49:53 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 36951472264450049,
  "created_at" : "2011-02-14 00:54:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36949354321281024",
  "text" : "Red panda jumps at chance to get inside  http:\/\/yhoo.it\/e7U4uZ",
  "id" : 36949354321281024,
  "created_at" : "2011-02-14 00:46:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 3, 11 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "YapToWin",
      "indices" : [ 106, 115 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36948372979982336",
  "text" : "RT @BookYap: What book will you review to win your very own Kindle? Join our contest! http:\/\/so-kt.tw\/7XO #YapToWin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialkaty.com\" rel=\"nofollow\"\u003Esocialkaty\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "YapToWin",
        "indices" : [ 93, 102 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36947732513951745",
    "text" : "What book will you review to win your very own Kindle? Join our contest! http:\/\/so-kt.tw\/7XO #YapToWin",
    "id" : 36947732513951745,
    "created_at" : "2011-02-14 00:40:00 +0000",
    "user" : {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "protected" : false,
      "id_str" : "123948351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083030490\/Bookyap1_normal.jpg",
      "id" : 123948351,
      "verified" : false
    }
  },
  "id" : 36948372979982336,
  "created_at" : "2011-02-14 00:42:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 30, 44 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36945881651609600",
  "text" : "RT @CaplinROUS: Please follow @GaribaldiRous for all (or almost all) your capybara news. Get the rest from GiantHamster.com.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Garibaldi Rous",
        "screen_name" : "GaribaldiRous",
        "indices" : [ 14, 28 ],
        "id_str" : "244989679",
        "id" : 244989679
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36944736392581120",
    "text" : "Please follow @GaribaldiRous for all (or almost all) your capybara news. Get the rest from GiantHamster.com.",
    "id" : 36944736392581120,
    "created_at" : "2011-02-14 00:28:06 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 36945881651609600,
  "created_at" : "2011-02-14 00:32:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "indices" : [ 3, 17 ],
      "id_str" : "33276161",
      "id" : 33276161
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36910859670265856",
  "text" : "RT @JohnFugelsang: When space aliens land, colonize, move us onto reservations &decimate our culture will they call us 'The Native Marti ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36870131455885313",
    "text" : "When space aliens land, colonize, move us onto reservations &decimate our culture will they call us 'The Native Martians?'",
    "id" : 36870131455885313,
    "created_at" : "2011-02-13 19:31:39 +0000",
    "user" : {
      "name" : "John Fugelsang",
      "screen_name" : "JohnFugelsang",
      "protected" : false,
      "id_str" : "33276161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618501788518342656\/ycqZZrVj_normal.jpg",
      "id" : 33276161,
      "verified" : true
    }
  },
  "id" : 36910859670265856,
  "created_at" : "2011-02-13 22:13:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36888510073929728",
  "text" : "RT @KindleLending: Starting tomorrow, KindleLendingClub.com will be BookLending.com - new name, same great Kindle book lending community!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36886852824735744",
    "text" : "Starting tomorrow, KindleLendingClub.com will be BookLending.com - new name, same great Kindle book lending community!",
    "id" : 36886852824735744,
    "created_at" : "2011-02-13 20:38:05 +0000",
    "user" : {
      "name" : "BookLending.com",
      "screen_name" : "BookLending",
      "protected" : false,
      "id_str" : "233470432",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1209411096\/logo-kindle_normal.gif",
      "id" : 233470432,
      "verified" : false
    }
  },
  "id" : 36888510073929728,
  "created_at" : "2011-02-13 20:44:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36873523188342784",
  "text" : "Sample Sunday - Check out Indie Writers! http:\/\/bit.ly\/hBv990",
  "id" : 36873523188342784,
  "created_at" : "2011-02-13 19:45:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "indices" : [ 3, 19 ],
      "id_str" : "111579405",
      "id" : 111579405
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36868937937465344",
  "text" : "RT @thDigitalReader: Kindle Lending Club to change name http:\/\/bit.ly\/dW8MDz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wordpress.org\/extend\/plugins\/twitter-publisher\/\" rel=\"nofollow\"\u003ETwitPublisher\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36868233139068928",
    "text" : "Kindle Lending Club to change name http:\/\/bit.ly\/dW8MDz",
    "id" : 36868233139068928,
    "created_at" : "2011-02-13 19:24:06 +0000",
    "user" : {
      "name" : "Nate Hoffelder",
      "screen_name" : "thDigitalReader",
      "protected" : false,
      "id_str" : "111579405",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/727151990627684352\/B4HA4WvK_normal.jpg",
      "id" : 111579405,
      "verified" : false
    }
  },
  "id" : 36868937937465344,
  "created_at" : "2011-02-13 19:26:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 36, 44 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AZ",
      "indices" : [ 113, 116 ]
    }, {
      "text" : "rescue",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36867570392895488",
  "text" : "please pass on 2 yr anipal tweeps \u2665 @sangyeh The Dogs At Kayenta - I Think We're On Our Own http:\/\/bit.ly\/h6hgEe #AZ #rescue",
  "id" : 36867570392895488,
  "created_at" : "2011-02-13 19:21:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "AZ",
      "indices" : [ 68, 71 ]
    }, {
      "text" : "rescue",
      "indices" : [ 72, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36865117811376128",
  "text" : "The Dogs At Kayenta - I Think We're On Our Own http:\/\/bit.ly\/h6hgEe #AZ #rescue",
  "id" : 36865117811376128,
  "created_at" : "2011-02-13 19:11:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 23, 37 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36862756816687104",
  "text" : "RT @CaplinROUS: Follow @GaribaldiRous to see cute photos like this one: http:\/\/yfrog.com\/h763dpzj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Garibaldi Rous",
        "screen_name" : "GaribaldiRous",
        "indices" : [ 7, 21 ],
        "id_str" : "244989679",
        "id" : 244989679
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36862578940452864",
    "text" : "Follow @GaribaldiRous to see cute photos like this one: http:\/\/yfrog.com\/h763dpzj",
    "id" : 36862578940452864,
    "created_at" : "2011-02-13 19:01:38 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 36862756816687104,
  "created_at" : "2011-02-13 19:02:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SNOWGA",
      "screen_name" : "SNOWGA",
      "indices" : [ 3, 10 ],
      "id_str" : "71431827",
      "id" : 71431827
    }, {
      "name" : "Arlene",
      "screen_name" : "wisdomalacarte",
      "indices" : [ 84, 99 ],
      "id_str" : "161128169",
      "id" : 161128169
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36862545235017728",
  "text" : "RT @SNOWGA: The kindest word in all the world is the unkind word, unsaid. ~ Unknown @WisdomalaCarte",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Arlene",
        "screen_name" : "wisdomalacarte",
        "indices" : [ 72, 87 ],
        "id_str" : "161128169",
        "id" : 161128169
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36860344030728192",
    "text" : "The kindest word in all the world is the unkind word, unsaid. ~ Unknown @WisdomalaCarte",
    "id" : 36860344030728192,
    "created_at" : "2011-02-13 18:52:45 +0000",
    "user" : {
      "name" : "SNOWGA",
      "screen_name" : "SNOWGA",
      "protected" : false,
      "id_str" : "71431827",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/760257403099021312\/vjUkJ6RO_normal.jpg",
      "id" : 71431827,
      "verified" : false
    }
  },
  "id" : 36862545235017728,
  "created_at" : "2011-02-13 19:01:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36854751635177472",
  "text" : "I still need to come up with good domain for my ebook blog\/site!",
  "id" : 36854751635177472,
  "created_at" : "2011-02-13 18:30:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "OMGFactsSex",
      "screen_name" : "OMGFactsSex",
      "indices" : [ 7, 19 ],
      "id_str" : "105654296",
      "id" : 105654296
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36854156211781632",
  "text" : "O-o RT @OMGFactsSex: A scrotal infusion is when a man inflates his scrotum with air or gas, like a balloon.",
  "id" : 36854156211781632,
  "created_at" : "2011-02-13 18:28:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "indices" : [ 3, 16 ],
      "id_str" : "42974138",
      "id" : 42974138
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36824537303613440",
  "text" : "RT @GraveStomper: What do your tweets\/posts reveal about the kind of future you're likely to have?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36823925824430081",
    "text" : "What do your tweets\/posts reveal about the kind of future you're likely to have?",
    "id" : 36823925824430081,
    "created_at" : "2011-02-13 16:28:02 +0000",
    "user" : {
      "name" : "Corin White",
      "screen_name" : "GraveStomper",
      "protected" : false,
      "id_str" : "42974138",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1238566251\/comingsoonavatar_normal.jpg",
      "id" : 42974138,
      "verified" : false
    }
  },
  "id" : 36824537303613440,
  "created_at" : "2011-02-13 16:30:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 3, 15 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36824220088410113",
  "text" : "RT @DarciaHelle: We are standing in the vegetable section and I am staring at the widest ass I have ever seen. http:\/\/j.mp\/hiqnbJ #Sampl ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "SampleSunday",
        "indices" : [ 113, 126 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36820876028551168",
    "text" : "We are standing in the vegetable section and I am staring at the widest ass I have ever seen. http:\/\/j.mp\/hiqnbJ #SampleSunday",
    "id" : 36820876028551168,
    "created_at" : "2011-02-13 16:15:55 +0000",
    "user" : {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "protected" : false,
      "id_str" : "140067631",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000167675770\/8468388ef75895d5393ad4bede3fcb35_normal.jpeg",
      "id" : 140067631,
      "verified" : false
    }
  },
  "id" : 36824220088410113,
  "created_at" : "2011-02-13 16:29:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "indices" : [ 3, 15 ],
      "id_str" : "890831",
      "id" : 890831
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36824144406380544",
  "text" : "RT @scottsigler: If you give a police dog a Milk Bone to sniff the other way, does that constitute bribery?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36822062463066112",
    "text" : "If you give a police dog a Milk Bone to sniff the other way, does that constitute bribery?",
    "id" : 36822062463066112,
    "created_at" : "2011-02-13 16:20:38 +0000",
    "user" : {
      "name" : "Scott Sigler",
      "screen_name" : "scottsigler",
      "protected" : false,
      "id_str" : "890831",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745022519644557312\/r5WawRHg_normal.jpg",
      "id" : 890831,
      "verified" : true
    }
  },
  "id" : 36824144406380544,
  "created_at" : "2011-02-13 16:28:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36824077033275393",
  "text" : "RT @Reverend_Sue: Atheists calling believers \"losers,\" and believers calling atheists \"losers\" does nothing for the continuity of global ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "love",
        "indices" : [ 119, 124 ]
      }, {
        "text" : "unity",
        "indices" : [ 129, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36823043854565377",
    "text" : "Atheists calling believers \"losers,\" and believers calling atheists \"losers\" does nothing for the continuity of global #love and #unity.",
    "id" : 36823043854565377,
    "created_at" : "2011-02-13 16:24:32 +0000",
    "user" : {
      "name" : "Reverend Sue",
      "screen_name" : "ReverendSue",
      "protected" : false,
      "id_str" : "40585382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000026906686\/7fde104eb413edabacb8eff79d6d67ff_normal.jpeg",
      "id" : 40585382,
      "verified" : false
    }
  },
  "id" : 36824077033275393,
  "created_at" : "2011-02-13 16:28:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36824003951730688",
  "text" : "RT @KreelanWarrior: After extensive consultations with all body components, the consensus is that it's nap time! :^D",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36823309953798145",
    "text" : "After extensive consultations with all body components, the consensus is that it's nap time! :^D",
    "id" : 36823309953798145,
    "created_at" : "2011-02-13 16:25:35 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 36824003951730688,
  "created_at" : "2011-02-13 16:28:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36819162890248192",
  "text" : "RT @TrishScott: Quantum mechanics: The dreams stuff is made of.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36818163798773760",
    "text" : "Quantum mechanics: The dreams stuff is made of.",
    "id" : 36818163798773760,
    "created_at" : "2011-02-13 16:05:08 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 36819162890248192,
  "created_at" : "2011-02-13 16:09:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CJ West",
      "screen_name" : "cjwest",
      "indices" : [ 46, 53 ],
      "id_str" : "14947233",
      "id" : 14947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36803992981872640",
  "text" : "finished reading \"The End of Marking Time\" by @cjwest last night .. Excellent read!",
  "id" : 36803992981872640,
  "created_at" : "2011-02-13 15:08:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36796955824898048",
  "text" : "RT @petsalive: Please help us socially network Moonie & Red: http:\/\/www.petfinder.com\/petdetail\/16216156 - Red is blind. Moonie is her \" ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36774556119076864",
    "text" : "Please help us socially network Moonie & Red: http:\/\/www.petfinder.com\/petdetail\/16216156 - Red is blind. Moonie is her \"seeing eye dog\".",
    "id" : 36774556119076864,
    "created_at" : "2011-02-13 13:11:52 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 36796955824898048,
  "created_at" : "2011-02-13 14:40:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36792387783106560",
  "text" : "Sample Sunday - Check out Indie Writers! http:\/\/bit.ly\/hBv990",
  "id" : 36792387783106560,
  "created_at" : "2011-02-13 14:22:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36602398491279360",
  "text" : "Writing Kindle Books FB group http:\/\/on.fb.me\/fsNoBT",
  "id" : 36602398491279360,
  "created_at" : "2011-02-13 01:47:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Carole ODell",
      "screen_name" : "CaroleODell",
      "indices" : [ 8, 20 ],
      "id_str" : "71118021",
      "id" : 71118021
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36577180938928128",
  "text" : "Wow. RT @CaroleODell: Just got a DM asking my why I follow somebody else?? Why does it matter?",
  "id" : 36577180938928128,
  "created_at" : "2011-02-13 00:07:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Shaka Zulu Consuelez",
      "screen_name" : "mindymayhem",
      "indices" : [ 2, 14 ],
      "id_str" : "24736943",
      "id" : 24736943
    }, {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 18, 28 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36576985182371840",
  "text" : ". @mindymayhem RT @petsalive: And this was the bitee. The PDP (poor defenseless pitbull). Houma is ok. Only... (more) http:\/\/twtm.in\/eMC",
  "id" : 36576985182371840,
  "created_at" : "2011-02-13 00:06:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "indices" : [ 33, 48 ],
      "id_str" : "155212706",
      "id" : 155212706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36576152684335104",
  "text" : "Swallow was exc (as was yours!)  @HeatherWardell",
  "id" : 36576152684335104,
  "created_at" : "2011-02-13 00:03:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 46, 59 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36571428895596544",
  "geo" : { },
  "id_str" : "36571736359051264",
  "in_reply_to_user_id" : 123068593,
  "text" : "You & wife have great dinner! : ) Happy 20th! @GeneDoucette",
  "id" : 36571736359051264,
  "in_reply_to_status_id" : 36571428895596544,
  "created_at" : "2011-02-12 23:45:56 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 40, 55 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36571224591044608",
  "text" : "Maya 2012 http:\/\/bit.ly\/hqEOCz video by @anamericanmonk",
  "id" : 36571224591044608,
  "created_at" : "2011-02-12 23:43:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36565575081656320",
  "text" : "Gabrielle's Reading http:\/\/bit.ly\/f0zleM if you've reviewed any of these, add your link in post comment",
  "id" : 36565575081656320,
  "created_at" : "2011-02-12 23:21:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EgyptiansRock",
      "indices" : [ 104, 118 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36551893203296256",
  "text" : "RT @SangyeH: Anyone ever heard of Americans cleaning up the mess they made after a protest? Me neither. #EgyptiansRock",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EgyptiansRock",
        "indices" : [ 91, 105 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36548202333212672",
    "text" : "Anyone ever heard of Americans cleaning up the mess they made after a protest? Me neither. #EgyptiansRock",
    "id" : 36548202333212672,
    "created_at" : "2011-02-12 22:12:25 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 36551893203296256,
  "created_at" : "2011-02-12 22:27:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "indices" : [ 3, 18 ],
      "id_str" : "31231020",
      "id" : 31231020
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36519392942497792",
  "text" : "RT @AnAmericanMonk: My newest You Tube Video on the Maya date of 2012 see part 1 here. http:\/\/lnk.ms\/KY9lx",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.myspace.com\/sync\" rel=\"nofollow\"\u003EMySpace\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36510841620668416",
    "text" : "My newest You Tube Video on the Maya date of 2012 see part 1 here. http:\/\/lnk.ms\/KY9lx",
    "id" : 36510841620668416,
    "created_at" : "2011-02-12 19:43:57 +0000",
    "user" : {
      "name" : "Steven L Hairfield",
      "screen_name" : "AnAmericanMonk",
      "protected" : false,
      "id_str" : "31231020",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/447391965936500736\/dpCS4ol7_normal.jpeg",
      "id" : 31231020,
      "verified" : false
    }
  },
  "id" : 36519392942497792,
  "created_at" : "2011-02-12 20:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36518907875434497",
  "text" : "RT @GeneDoucette: For under five bucks you can learn how to tell if your neighbor is a serial killer AND how to survive Disney World. ht ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36514942051942400",
    "text" : "For under five bucks you can learn how to tell if your neighbor is a serial killer AND how to survive Disney World. http:\/\/bit.ly\/e2Jrv2",
    "id" : 36514942051942400,
    "created_at" : "2011-02-12 20:00:15 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 36518907875434497,
  "created_at" : "2011-02-12 20:16:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36486844837396480",
  "text" : "RT @GeneDoucette: Need to know how to defend yourself against a squirrel? Of course you do! http:\/\/bit.ly\/e2Jrv2",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36484729934979072",
    "text" : "Need to know how to defend yourself against a squirrel? Of course you do! http:\/\/bit.ly\/e2Jrv2",
    "id" : 36484729934979072,
    "created_at" : "2011-02-12 18:00:12 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 36486844837396480,
  "created_at" : "2011-02-12 18:08:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36474950319611904",
  "text" : "RT @Wylieknowords: Dear Cupid, I still want a Kindle. (Gave up on Santa.)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36473476374073344",
    "text" : "Dear Cupid, I still want a Kindle. (Gave up on Santa.)",
    "id" : 36473476374073344,
    "created_at" : "2011-02-12 17:15:29 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 36474950319611904,
  "created_at" : "2011-02-12 17:21:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36470166799785984",
  "text" : "Did you know you can get Kindle credit (Amazon gift card) via email? Easy-peasy! http:\/\/amzn.to\/g1vZvO",
  "id" : 36470166799785984,
  "created_at" : "2011-02-12 17:02:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "CJ West",
      "screen_name" : "cjwest",
      "indices" : [ 47, 54 ],
      "id_str" : "14947233",
      "id" : 14947233
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36468381112598528",
  "text" : "currently reading \"The End of Marking Time\" by @cjwest .. very interesting! all prisoners released..",
  "id" : 36468381112598528,
  "created_at" : "2011-02-12 16:55:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 15, 28 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36467302392135680",
  "text" : "Bees. Hmm.. RT @GeneDoucette: The strangest dream http:\/\/wp.me\/pXlXL-ch",
  "id" : 36467302392135680,
  "created_at" : "2011-02-12 16:50:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36466888712134657",
  "text" : "RT @GeneDoucette: For $4.99 you can learn how to split the atom, how to find Jesus, and how to rob a bank. And so much more: http:\/\/bit. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36462100586962944",
    "text" : "For $4.99 you can learn how to split the atom, how to find Jesus, and how to rob a bank. And so much more: http:\/\/bit.ly\/e2Jrv2",
    "id" : 36462100586962944,
    "created_at" : "2011-02-12 16:30:16 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 36466888712134657,
  "created_at" : "2011-02-12 16:49:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Betcher",
      "screen_name" : "JohnBetcher",
      "indices" : [ 3, 15 ],
      "id_str" : "53730065",
      "id" : 53730065
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36466830319034368",
  "text" : "RT @JohnBetcher: Do these faces look familiar? They should by now They're the Members of The Independent Author Network http:\/\/j.mp\/f3Za ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amwriting",
        "indices" : [ 122, 132 ]
      }, {
        "text" : "IAN",
        "indices" : [ 133, 137 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36466701990109184",
    "text" : "Do these faces look familiar? They should by now They're the Members of The Independent Author Network http:\/\/j.mp\/f3Zaxj #amwriting #IAN",
    "id" : 36466701990109184,
    "created_at" : "2011-02-12 16:48:33 +0000",
    "user" : {
      "name" : "John Betcher",
      "screen_name" : "JohnBetcher",
      "protected" : false,
      "id_str" : "53730065",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/740262527\/John_Grand_Canyon_normal.jpg",
      "id" : 53730065,
      "verified" : false
    }
  },
  "id" : 36466830319034368,
  "created_at" : "2011-02-12 16:49:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 70, 81 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36460129297637377",
  "geo" : { },
  "id_str" : "36463109312872448",
  "in_reply_to_user_id" : 34258680,
  "text" : "have u seen this one? free: http:\/\/www.independentauthornetwork.com\/  @WestofMars",
  "id" : 36463109312872448,
  "in_reply_to_status_id" : 36460129297637377,
  "created_at" : "2011-02-12 16:34:17 +0000",
  "in_reply_to_screen_name" : "WestofMars",
  "in_reply_to_user_id_str" : "34258680",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "indices" : [ 3, 18 ],
      "id_str" : "23193505",
      "id" : 23193505
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36459902280929280",
  "text" : "RT @stevetheseeker: Dictators on earth will go the way of the dinosaurs when our inner dictators do as well.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36454134072745984",
    "text" : "Dictators on earth will go the way of the dinosaurs when our inner dictators do as well.",
    "id" : 36454134072745984,
    "created_at" : "2011-02-12 15:58:37 +0000",
    "user" : {
      "name" : "Steve Larsen",
      "screen_name" : "stevetheseeker",
      "protected" : false,
      "id_str" : "23193505",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/708652858543964160\/yaJ3K5Nx_normal.jpg",
      "id" : 23193505,
      "verified" : false
    }
  },
  "id" : 36459902280929280,
  "created_at" : "2011-02-12 16:21:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36459430157492224",
  "text" : "hubby has a playdate today!",
  "id" : 36459430157492224,
  "created_at" : "2011-02-12 16:19:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36452302680371200",
  "text" : "RT @fearfuldogs: OMG my husband is out w a helmet & a hoe chopping ice off the roof. I'm either going 2 need a new roof or a new husband.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36425055365906432",
    "text" : "OMG my husband is out w a helmet & a hoe chopping ice off the roof. I'm either going 2 need a new roof or a new husband.",
    "id" : 36425055365906432,
    "created_at" : "2011-02-12 14:03:04 +0000",
    "user" : {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "protected" : false,
      "id_str" : "16691399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/67007991\/DJ3_normal.JPG",
      "id" : 16691399,
      "verified" : false
    }
  },
  "id" : 36452302680371200,
  "created_at" : "2011-02-12 15:51:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 118, 137 ],
      "url" : "http:\/\/t.co\/LJVrgIf",
      "expanded_url" : "http:\/\/wp.me\/PXlXL-c8",
      "display_url" : "wp.me\/PXlXL-c8"
    } ]
  },
  "geo" : { },
  "id_str" : "36451436824895488",
  "text" : "RT @GeneDoucette: How to survive on the moon! How to prepare a human being for emergency consumption! And much more!  http:\/\/t.co\/LJVrgIf",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 100, 119 ],
        "url" : "http:\/\/t.co\/LJVrgIf",
        "expanded_url" : "http:\/\/wp.me\/PXlXL-c8",
        "display_url" : "wp.me\/PXlXL-c8"
      } ]
    },
    "geo" : { },
    "id_str" : "36437337848156160",
    "text" : "How to survive on the moon! How to prepare a human being for emergency consumption! And much more!  http:\/\/t.co\/LJVrgIf",
    "id" : 36437337848156160,
    "created_at" : "2011-02-12 14:51:52 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 36451436824895488,
  "created_at" : "2011-02-12 15:47:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36259926829441024",
  "text" : "http:\/\/amzn.com\/k\/18F5HZM5NYQ0L #Kindle",
  "id" : 36259926829441024,
  "created_at" : "2011-02-12 03:06:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36250738275389441",
  "text" : "Julius Katz Mysteries by Dave Zeltserman \u2014 Gabrielle's Reading http:\/\/bit.ly\/g2cDG8",
  "id" : 36250738275389441,
  "created_at" : "2011-02-12 02:30:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 76, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36154296303099904",
  "text" : "finished Mute by Richard Matheson and gave it 4 stars http:\/\/amzn.to\/e2fpg9 #Kindle",
  "id" : 36154296303099904,
  "created_at" : "2011-02-11 20:07:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041E\u0441\u0438\u043F\u043E\u0432\u0430   \u041A\u043B\u0435\u043C\u0435\u043D\u0442\u0438\u043D\u0430",
      "screen_name" : "shamansun",
      "indices" : [ 3, 13 ],
      "id_str" : "3007135943",
      "id" : 3007135943
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "solidarity",
      "indices" : [ 76, 87 ]
    }, {
      "text" : "global",
      "indices" : [ 88, 95 ]
    }, {
      "text" : "citizen",
      "indices" : [ 96, 104 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36108203297218560",
  "text" : "RT @shamansun: Egypt is not just a regional victory, it is a planetary one. #solidarity #global #citizen",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "solidarity",
        "indices" : [ 61, 72 ]
      }, {
        "text" : "global",
        "indices" : [ 73, 80 ]
      }, {
        "text" : "citizen",
        "indices" : [ 81, 89 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36105752984829953",
    "text" : "Egypt is not just a regional victory, it is a planetary one. #solidarity #global #citizen",
    "id" : 36105752984829953,
    "created_at" : "2011-02-11 16:54:16 +0000",
    "user" : {
      "name" : "Jeremy D. Johnson",
      "screen_name" : "jdj_tweets",
      "protected" : false,
      "id_str" : "16045144",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/769739970919731201\/Iyq7SXjC_normal.jpg",
      "id" : 16045144,
      "verified" : false
    }
  },
  "id" : 36108203297218560,
  "created_at" : "2011-02-11 17:04:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "What duck?",
      "screen_name" : "geeoharee",
      "indices" : [ 16, 26 ],
      "id_str" : "5774442",
      "id" : 5774442
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36105373265952769",
  "text" : "RT @SangyeH: RT @geeoharee: Trending in US: 'Congrats Egypt'. Awww.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "What duck?",
        "screen_name" : "geeoharee",
        "indices" : [ 3, 13 ],
        "id_str" : "5774442",
        "id" : 5774442
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36104465404801024",
    "text" : "RT @geeoharee: Trending in US: 'Congrats Egypt'. Awww.",
    "id" : 36104465404801024,
    "created_at" : "2011-02-11 16:49:09 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 36105373265952769,
  "created_at" : "2011-02-11 16:52:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Juli\u00E1n Rojas Mill\u00E1n",
      "screen_name" : "lobachevscki",
      "indices" : [ 3, 16 ],
      "id_str" : "22858188",
      "id" : 22858188
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "egypt",
      "indices" : [ 89, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36104887200653312",
  "text" : "RT @lobachevscki: Uninstalling dictator ... 100% complete \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588 #egypt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "egypt",
        "indices" : [ 71, 77 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36097188094427136",
    "text" : "Uninstalling dictator ... 100% complete \u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588\u2588 #egypt",
    "id" : 36097188094427136,
    "created_at" : "2011-02-11 16:20:14 +0000",
    "user" : {
      "name" : "Juli\u00E1n Rojas Mill\u00E1n",
      "screen_name" : "lobachevscki",
      "protected" : false,
      "id_str" : "22858188",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/655249278995009536\/lFrPNjCS_normal.jpg",
      "id" : 22858188,
      "verified" : false
    }
  },
  "id" : 36104887200653312,
  "created_at" : "2011-02-11 16:50:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36094726939607040",
  "text" : "RT @Wylieknowords: #Egypt: Nonviolence won. Suicide religious nuts lost. Fox News and Beck lost. Hate lost. Creativity and love won. Fac ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egypt",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36094511213973505",
    "text" : "#Egypt: Nonviolence won. Suicide religious nuts lost. Fox News and Beck lost. Hate lost. Creativity and love won. Facebook and Twitter won.",
    "id" : 36094511213973505,
    "created_at" : "2011-02-11 16:09:36 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 36094726939607040,
  "created_at" : "2011-02-11 16:10:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u0633\u0644\u0637\u0627\u0646 \u0633\u0639\u0648\u062F \u0627\u0644\u0642\u0627\u0633\u0645\u064A",
      "screen_name" : "SultanAlQassemi",
      "indices" : [ 3, 19 ],
      "id_str" : "46744791",
      "id" : 46744791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36094635457650688",
  "text" : "RT @SultanAlQassemi: UNBELIEVABLE. THE EGYPTIANS REALLY DID IT.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36093555378368512",
    "text" : "UNBELIEVABLE. THE EGYPTIANS REALLY DID IT.",
    "id" : 36093555378368512,
    "created_at" : "2011-02-11 16:05:48 +0000",
    "user" : {
      "name" : "\u0633\u0644\u0637\u0627\u0646 \u0633\u0639\u0648\u062F \u0627\u0644\u0642\u0627\u0633\u0645\u064A",
      "screen_name" : "SultanAlQassemi",
      "protected" : false,
      "id_str" : "46744791",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/659211741356650496\/x25TISxZ_normal.jpg",
      "id" : 46744791,
      "verified" : true
    }
  },
  "id" : 36094635457650688,
  "created_at" : "2011-02-11 16:10:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 19, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36092961645142017",
  "text" : "RT @Wylieknowords: #Egypt Tahrir - Mubarak gets to heaven and dead Egyptian leaders ask what killed him: guns,poison,bomb? No, Facebook  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egypt",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36092055700639746",
    "text" : "#Egypt Tahrir - Mubarak gets to heaven and dead Egyptian leaders ask what killed him: guns,poison,bomb? No, Facebook and Twitter. NWJ",
    "id" : 36092055700639746,
    "created_at" : "2011-02-11 15:59:51 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 36092961645142017,
  "created_at" : "2011-02-11 16:03:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 16, 30 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    }, {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 31, 41 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    }, {
      "name" : "BibleAlsoSays",
      "screen_name" : "BibleAlsoSays",
      "indices" : [ 56, 70 ],
      "id_str" : "2511428924",
      "id" : 2511428924
    }, {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 71, 85 ],
      "id_str" : "28863804",
      "id" : 28863804
    }, {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 101, 114 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 133, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36092766899404800",
  "text" : "My twitter bros @HEATHENRABBIT @ID_vs_EGO @tragic_pizza @BibleAlsoSays @Wylieknowords @Skandhasattva @derekrootboy &lt;3 &lt;3 &lt;3 #FF",
  "id" : 36092766899404800,
  "created_at" : "2011-02-11 16:02:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36086418807861248",
  "text" : "I love my ppl.. and you are my ppl. \u2665",
  "id" : 36086418807861248,
  "created_at" : "2011-02-11 15:37:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 18, 33 ],
      "id_str" : "62867227",
      "id" : 62867227
    }, {
      "name" : "ShhDragon",
      "screen_name" : "ShhDragon",
      "indices" : [ 34, 44 ],
      "id_str" : "15572724",
      "id" : 15572724
    }, {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 45, 52 ],
      "id_str" : "122393631",
      "id" : 122393631
    }, {
      "name" : "Tracy Fitzgerald",
      "screen_name" : "TraLeeFitz",
      "indices" : [ 53, 64 ],
      "id_str" : "76225852",
      "id" : 76225852
    }, {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 65, 80 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    }, {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 81, 96 ],
      "id_str" : "30825946",
      "id" : 30825946
    }, {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 97, 111 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 14, 17 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36084433455022080",
  "text" : "Awesomesauce! #FF @thesexyatheist @ShhDragon @SsmDad @TraLeeFitz @ReformedBuddha @JonathanElliot @Dwayne_Reaves &lt;3 ((hugs))",
  "id" : 36084433455022080,
  "created_at" : "2011-02-11 15:29:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Faysal Adam",
      "screen_name" : "BestAt",
      "indices" : [ 3, 10 ],
      "id_str" : "770322629127507968",
      "id" : 770322629127507968
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36078371024670720",
  "text" : "RT @BestAt: RT @PaulyMortadella: Facebook buying Twitter is like your fundamentalist Christian parents coming home during the best party ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitterfeed.com\" rel=\"nofollow\"\u003Etwitterfeed\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36077187740213248",
    "text" : "RT @PaulyMortadella: Facebook buying Twitter is like your fundamentalist Christian parents coming home during the best party ever.",
    "id" : 36077187740213248,
    "created_at" : "2011-02-11 15:00:46 +0000",
    "user" : {
      "name" : "Animals \uD83C\uDF83",
      "screen_name" : "AnimaIpics",
      "protected" : false,
      "id_str" : "17080369",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792637289268649984\/qGEY2R0g_normal.jpg",
      "id" : 17080369,
      "verified" : false
    }
  },
  "id" : 36078371024670720,
  "created_at" : "2011-02-11 15:05:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael_Palmer",
      "screen_name" : "Michael_Palmer",
      "indices" : [ 3, 18 ],
      "id_str" : "17919174",
      "id" : 17919174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 20, 24 ]
    }, {
      "text" : "AHeartbeatAway",
      "indices" : [ 58, 73 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36077931667132416",
  "text" : "RT @Michael_Palmer: #win a kindle\u2026 just share chap 2 from #AHeartbeatAway on FB and Twitter to enter...thanks http:\/\/on.fb.me\/hu4TxJ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 0, 4 ]
      }, {
        "text" : "AHeartbeatAway",
        "indices" : [ 38, 53 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36072715253190656",
    "text" : "#win a kindle\u2026 just share chap 2 from #AHeartbeatAway on FB and Twitter to enter...thanks http:\/\/on.fb.me\/hu4TxJ",
    "id" : 36072715253190656,
    "created_at" : "2011-02-11 14:43:00 +0000",
    "user" : {
      "name" : "Michael_Palmer",
      "screen_name" : "Michael_Palmer",
      "protected" : false,
      "id_str" : "17919174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817290389\/michael_normal.jpg",
      "id" : 17919174,
      "verified" : false
    }
  },
  "id" : 36077931667132416,
  "created_at" : "2011-02-11 15:03:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 3, 14 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36077646941003776",
  "text" : "RT @modernevil: Dropping the prices of my eBooks to the $3-$5 range has apparently killed sales completely. Ridiculously. Tempted to rai ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/itunes.apple.com\/us\/app\/twitter\/id409789998?mt=12\" rel=\"nofollow\"\u003ETwitter for Mac\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36073622061711360",
    "text" : "Dropping the prices of my eBooks to the $3-$5 range has apparently killed sales completely. Ridiculously. Tempted to raise to $10 instead.",
    "id" : 36073622061711360,
    "created_at" : "2011-02-11 14:46:36 +0000",
    "user" : {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "protected" : false,
      "id_str" : "7482152",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/745021544322072576\/MQuQhm3R_normal.jpg",
      "id" : 7482152,
      "verified" : false
    }
  },
  "id" : 36077646941003776,
  "created_at" : "2011-02-11 15:02:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Iconic88",
      "screen_name" : "Iconic88",
      "indices" : [ 3, 12 ],
      "id_str" : "17401289",
      "id" : 17401289
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "iconic",
      "indices" : [ 126, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "36071175587110912",
  "text" : "RT @Iconic88: Twitter is like ISP. Its not how many followers you have but the quality of ur connections that brings results. #iconic",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "iconic",
        "indices" : [ 112, 119 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "36061281639202816",
    "text" : "Twitter is like ISP. Its not how many followers you have but the quality of ur connections that brings results. #iconic",
    "id" : 36061281639202816,
    "created_at" : "2011-02-11 13:57:34 +0000",
    "user" : {
      "name" : "Iconic88",
      "screen_name" : "Iconic88",
      "protected" : false,
      "id_str" : "17401289",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1535200940\/Iconic88_avatar_normal.JPG",
      "id" : 17401289,
      "verified" : false
    }
  },
  "id" : 36071175587110912,
  "created_at" : "2011-02-11 14:36:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 109, 125 ],
      "id_str" : "41377983",
      "id" : 41377983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36001214013374464",
  "geo" : { },
  "id_str" : "36064694808612865",
  "in_reply_to_user_id" : 41377983,
  "text" : "Kindle just updated firmware so last page of book inc \"tweet this\" (finished this title) & rate this (stars) @emperorsclothes",
  "id" : 36064694808612865,
  "in_reply_to_status_id" : 36001214013374464,
  "created_at" : "2011-02-11 14:11:07 +0000",
  "in_reply_to_screen_name" : "emperorsclothes",
  "in_reply_to_user_id_str" : "41377983",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 0, 16 ],
      "id_str" : "41377983",
      "id" : 41377983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "36001214013374464",
  "geo" : { },
  "id_str" : "36064357641093120",
  "in_reply_to_user_id" : 41377983,
  "text" : "@emperorsclothes no review, just rated it (4stars). I was suggstng Amazon shld auto tweet author. They need that feature. : )",
  "id" : 36064357641093120,
  "in_reply_to_status_id" : 36001214013374464,
  "created_at" : "2011-02-11 14:09:47 +0000",
  "in_reply_to_screen_name" : "emperorsclothes",
  "in_reply_to_user_id_str" : "41377983",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35914319958904832",
  "text" : "http:\/\/amzn.com\/k\/ZKYPCT3D3I8U #Kindle",
  "id" : 35914319958904832,
  "created_at" : "2011-02-11 04:13:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35896914197090304",
  "text" : "Three Sisters (The Emily Castles Mysteries) by Helen Smith \u2014 Gabrielle's Reading http:\/\/bit.ly\/fv0tRL",
  "id" : 35896914197090304,
  "created_at" : "2011-02-11 03:04:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35890095521275904",
  "text" : "RT @tonyrobbins: Keep digging deeper.. what you passionately pursue you will find!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35888478810017792",
    "text" : "Keep digging deeper.. what you passionately pursue you will find!",
    "id" : 35888478810017792,
    "created_at" : "2011-02-11 02:30:54 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 35890095521275904,
  "created_at" : "2011-02-11 02:37:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35843571231756289",
  "text" : "RT @SangyeH: So basically Mubarak said \"Over my dead body.\"  Not a smart thing to say in the middle of a revolution.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35836916330926080",
    "text" : "So basically Mubarak said \"Over my dead body.\"  Not a smart thing to say in the middle of a revolution.",
    "id" : 35836916330926080,
    "created_at" : "2011-02-10 23:06:01 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 35843571231756289,
  "created_at" : "2011-02-10 23:32:27 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Alec Sulkin",
      "screen_name" : "thesulk",
      "indices" : [ 16, 24 ],
      "id_str" : "24008967",
      "id" : 24008967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35843505242775553",
  "text" : "RT @SangyeH: RT @thesulk: When dogs sniff pee on a tree, that's like their facebook. \/\/LOL True",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Alec Sulkin",
        "screen_name" : "thesulk",
        "indices" : [ 3, 11 ],
        "id_str" : "24008967",
        "id" : 24008967
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35837336612773888",
    "text" : "RT @thesulk: When dogs sniff pee on a tree, that's like their facebook. \/\/LOL True",
    "id" : 35837336612773888,
    "created_at" : "2011-02-10 23:07:41 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 35843505242775553,
  "created_at" : "2011-02-10 23:32:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Daryl Sedore",
      "screen_name" : "DarylSedore",
      "indices" : [ 3, 15 ],
      "id_str" : "3419972170",
      "id" : 3419972170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35843183451570177",
  "text" : "RT @darylsedore: Life is a tragedy for those who feel and a comedy for those that think.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35839925072961536",
    "text" : "Life is a tragedy for those who feel and a comedy for those that think.",
    "id" : 35839925072961536,
    "created_at" : "2011-02-10 23:17:58 +0000",
    "user" : {
      "name" : "Jonas Saul",
      "screen_name" : "jonassaul",
      "protected" : false,
      "id_str" : "127322699",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1568329636\/Jonas-Saul_normal.jpg",
      "id" : 127322699,
      "verified" : false
    }
  },
  "id" : 35843183451570177,
  "created_at" : "2011-02-10 23:30:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 17, 32 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35824813649956864",
  "text" : "Aww so sweet! RT @thesexyatheist: Have to remember to buy kid valentines B4 all the good ones R sold out (Come... (more) http:\/\/twtm.in\/lwz",
  "id" : 35824813649956864,
  "created_at" : "2011-02-10 22:17:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 4, 20 ],
      "id_str" : "41377983",
      "id" : 41377983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35821970318696448",
  "text" : "hey @emperorsclothes I finished yr book & tweeted from last page! Its in my timeline. Amazon shld add authors twitter name so tweets 2 them!",
  "id" : 35821970318696448,
  "created_at" : "2011-02-10 22:06:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 3, 19 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 112, 131 ],
      "url" : "http:\/\/t.co\/o9EhW7O",
      "expanded_url" : "http:\/\/simonwoodwriter.blogspot.com\/2011\/02\/new-ebook-titles.html?spref=tw",
      "display_url" : "simonwoodwriter.blogspot.com\/2011\/02\/new-eb\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "35820635707936768",
  "text" : "RT @simonwoodwrites: My ex-Dorchester thriller titles are availableas ebooks. Check out the new showcase.  :-)\n http:\/\/t.co\/o9EhW7O",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 91, 110 ],
        "url" : "http:\/\/t.co\/o9EhW7O",
        "expanded_url" : "http:\/\/simonwoodwriter.blogspot.com\/2011\/02\/new-ebook-titles.html?spref=tw",
        "display_url" : "simonwoodwriter.blogspot.com\/2011\/02\/new-eb\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "35816814336278529",
    "text" : "My ex-Dorchester thriller titles are availableas ebooks. Check out the new showcase.  :-)\n http:\/\/t.co\/o9EhW7O",
    "id" : 35816814336278529,
    "created_at" : "2011-02-10 21:46:08 +0000",
    "user" : {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "protected" : false,
      "id_str" : "30077179",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/786815188955570176\/XPC8uW7z_normal.jpg",
      "id" : 30077179,
      "verified" : false
    }
  },
  "id" : 35820635707936768,
  "created_at" : "2011-02-10 22:01:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 110, 117 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35810159481733120",
  "text" : "finished Three Sisters (The Emily Castles Mysteries) by Helen Smith and gave it 4 stars http:\/\/amzn.to\/fWWJMn #Kindle",
  "id" : 35810159481733120,
  "created_at" : "2011-02-10 21:19:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Scott Baio",
      "screen_name" : "ScottBaio",
      "indices" : [ 7, 17 ],
      "id_str" : "82447359",
      "id" : 82447359
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35796901899010048",
  "text" : "Wii RT @ScottBaio: Poll: X Box 360 or Wii for my 3 year old?",
  "id" : 35796901899010048,
  "created_at" : "2011-02-10 20:27:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pulp Life",
      "screen_name" : "Kippoe",
      "indices" : [ 3, 10 ],
      "id_str" : "14609985",
      "id" : 14609985
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 52, 71 ],
      "url" : "http:\/\/t.co\/iyPxKLV",
      "expanded_url" : "http:\/\/kippoe.blogspot.com\/2011\/02\/brian-drake-show-no-mercy-release-party.html?spref=tw",
      "display_url" : "kippoe.blogspot.com\/2011\/02\/brian-\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "35786495923064832",
  "text" : "RT @Kippoe: Brian Drake SHOW NO MERCY release party http:\/\/t.co\/iyPxKLV Stop by to win a copy for your Kindle",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/dev.twitter.com\/docs\/tfw\" rel=\"nofollow\"\u003ETwitter for Websites\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 40, 59 ],
        "url" : "http:\/\/t.co\/iyPxKLV",
        "expanded_url" : "http:\/\/kippoe.blogspot.com\/2011\/02\/brian-drake-show-no-mercy-release-party.html?spref=tw",
        "display_url" : "kippoe.blogspot.com\/2011\/02\/brian-\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "35780801492688896",
    "text" : "Brian Drake SHOW NO MERCY release party http:\/\/t.co\/iyPxKLV Stop by to win a copy for your Kindle",
    "id" : 35780801492688896,
    "created_at" : "2011-02-10 19:23:02 +0000",
    "user" : {
      "name" : "Pulp Life",
      "screen_name" : "Kippoe",
      "protected" : false,
      "id_str" : "14609985",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2672717840\/596d784253ba2a75fab240d0e7388d90_normal.jpeg",
      "id" : 14609985,
      "verified" : false
    }
  },
  "id" : 35786495923064832,
  "created_at" : "2011-02-10 19:45:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35784210480369664",
  "text" : "About IAN  - The Independent Author Network http:\/\/bit.ly\/glS0l8",
  "id" : 35784210480369664,
  "created_at" : "2011-02-10 19:36:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35781214837149696",
  "text" : "my eye keeps watering..",
  "id" : 35781214837149696,
  "created_at" : "2011-02-10 19:24:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 43, 56 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "parody",
      "indices" : [ 78, 85 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35779587673694208",
  "text" : "How to Reach the Summit of Mount Everest \u00AB @GeneDoucette http:\/\/bit.ly\/fyabQF #parody",
  "id" : 35779587673694208,
  "created_at" : "2011-02-10 19:18:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35765982597349376",
  "text" : "RT @wow_trees: According to Mayan archaeologists who translated the calendar, today marks a new consciousness cycle that'll last for 260 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35753658293428224",
    "text" : "According to Mayan archaeologists who translated the calendar, today marks a new consciousness cycle that'll last for 260 days.",
    "id" : 35753658293428224,
    "created_at" : "2011-02-10 17:35:11 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 35765982597349376,
  "created_at" : "2011-02-10 18:24:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35765843686207488",
  "text" : "RT @petsalive: We need canned cat food!  Any brand (Friskies, Fancy Feast - doesn't matter).  If anyone can bring down or donate some ca ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35755072960860160",
    "text" : "We need canned cat food!  Any brand (Friskies, Fancy Feast - doesn't matter).  If anyone can bring down or donate some canned cat food...?",
    "id" : 35755072960860160,
    "created_at" : "2011-02-10 17:40:48 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 35765843686207488,
  "created_at" : "2011-02-10 18:23:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "indices" : [ 110, 123 ],
      "id_str" : "95730042",
      "id" : 95730042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FlyingSquirrels",
      "indices" : [ 124, 140 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35755928657600512",
  "geo" : { },
  "id_str" : "35765542979637248",
  "in_reply_to_user_id" : 95730042,
  "text" : "LOL.. hubby thinks its been living here awhile. went back in the walls - again! just hope cat doesnt get him! @GoblinWriter #FlyingSquirrels",
  "id" : 35765542979637248,
  "in_reply_to_status_id" : 35755928657600512,
  "created_at" : "2011-02-10 18:22:24 +0000",
  "in_reply_to_screen_name" : "GoblinWriter",
  "in_reply_to_user_id_str" : "95730042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "indices" : [ 3, 12 ],
      "id_str" : "19636553",
      "id" : 19636553
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35752955567153152",
  "text" : "RT @LunaJune: Worrying is using your imagination to create something you don't want. \n\n--- Abraham",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35744593421152256",
    "text" : "Worrying is using your imagination to create something you don't want. \n\n--- Abraham",
    "id" : 35744593421152256,
    "created_at" : "2011-02-10 16:59:09 +0000",
    "user" : {
      "name" : "June O'Reilly",
      "screen_name" : "LunaJune",
      "protected" : false,
      "id_str" : "19636553",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/521342919387533313\/KI-XkoTw_normal.jpeg",
      "id" : 19636553,
      "verified" : false
    }
  },
  "id" : 35752955567153152,
  "created_at" : "2011-02-10 17:32:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 3, 13 ],
      "id_str" : "93341555",
      "id" : 93341555
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 15, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35752035047440384",
  "text" : "RT @wow_trees: #Egypt...I'm sending my thoughts and good vibes to you everyday. Today I'm concentrating on you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/seesmic.com\/\" rel=\"nofollow\"\u003ESeesmic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egypt",
        "indices" : [ 0, 6 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35751899529613312",
    "text" : "#Egypt...I'm sending my thoughts and good vibes to you everyday. Today I'm concentrating on you.",
    "id" : 35751899529613312,
    "created_at" : "2011-02-10 17:28:11 +0000",
    "user" : {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "protected" : false,
      "id_str" : "93341555",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/687849984994062337\/rUGzObqQ_normal.jpg",
      "id" : 93341555,
      "verified" : false
    }
  },
  "id" : 35752035047440384,
  "created_at" : "2011-02-10 17:28:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "indices" : [ 7, 22 ],
      "id_str" : "155212706",
      "id" : 155212706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35735693657505792",
  "text" : "Aww RT @HeatherWardell: How am i supposed to work in the presence of such cuteness? http:\/\/ow.ly\/i\/81vs",
  "id" : 35735693657505792,
  "created_at" : "2011-02-10 16:23:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "indices" : [ 3, 15 ],
      "id_str" : "45727491",
      "id" : 45727491
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 36, 43 ]
    }, {
      "text" : "ereader",
      "indices" : [ 128, 136 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35732243762774016",
  "text" : "RT @kindleworld: How \"People in the #Kindle ecosystem are messing with the magic\" - disrupting old ways. http:\/\/bit.ly\/kdisrupt #ereader ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 19, 26 ]
      }, {
        "text" : "ereader",
        "indices" : [ 111, 119 ]
      }, {
        "text" : "ebooks",
        "indices" : [ 120, 127 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35729509684617217",
    "text" : "How \"People in the #Kindle ecosystem are messing with the magic\" - disrupting old ways. http:\/\/bit.ly\/kdisrupt #ereader #ebooks",
    "id" : 35729509684617217,
    "created_at" : "2011-02-10 15:59:13 +0000",
    "user" : {
      "name" : "Andrys Basten",
      "screen_name" : "kindleworld",
      "protected" : false,
      "id_str" : "45727491",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/477176032563167233\/rnTxZldx_normal.jpeg",
      "id" : 45727491,
      "verified" : false
    }
  },
  "id" : 35732243762774016,
  "created_at" : "2011-02-10 16:10:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 3, 15 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35729810995023873",
  "text" : "RT @AlisynGayle: Fear and worry accomplish nothing, like tires spinning on ice. Energy is productively spent on understanding and change.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35727960375828481",
    "text" : "Fear and worry accomplish nothing, like tires spinning on ice. Energy is productively spent on understanding and change.",
    "id" : 35727960375828481,
    "created_at" : "2011-02-10 15:53:04 +0000",
    "user" : {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "protected" : false,
      "id_str" : "90733366",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/462952291612368897\/4AvbF1M-_normal.jpeg",
      "id" : 90733366,
      "verified" : false
    }
  },
  "id" : 35729810995023873,
  "created_at" : "2011-02-10 16:00:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pia tot",
      "screen_name" : "MadMuse",
      "indices" : [ 3, 11 ],
      "id_str" : "14545638",
      "id" : 14545638
    }, {
      "name" : "Bernie Berlin",
      "screen_name" : "aplacetobark",
      "indices" : [ 24, 37 ],
      "id_str" : "14669290",
      "id" : 14669290
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 77, 96 ],
      "url" : "http:\/\/t.co\/kFWaFnz",
      "expanded_url" : "http:\/\/bit.ly\/mQHq1",
      "display_url" : "bit.ly\/mQHq1"
    } ]
  },
  "geo" : { },
  "id_str" : "35723176528842752",
  "text" : "RT @MadMuse: Thank you! @aplacetobark.  A must-see for ALL God & dog lovers. http:\/\/t.co\/kFWaFnz",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Bernie Berlin",
        "screen_name" : "aplacetobark",
        "indices" : [ 11, 24 ],
        "id_str" : "14669290",
        "id" : 14669290
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 64, 83 ],
        "url" : "http:\/\/t.co\/kFWaFnz",
        "expanded_url" : "http:\/\/bit.ly\/mQHq1",
        "display_url" : "bit.ly\/mQHq1"
      } ]
    },
    "geo" : { },
    "id_str" : "35705245883441153",
    "text" : "Thank you! @aplacetobark.  A must-see for ALL God & dog lovers. http:\/\/t.co\/kFWaFnz",
    "id" : 35705245883441153,
    "created_at" : "2011-02-10 14:22:48 +0000",
    "user" : {
      "name" : "Pia tot",
      "screen_name" : "MadMuse",
      "protected" : false,
      "id_str" : "14545638",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/575492156145692672\/5Jh4VSBj_normal.jpeg",
      "id" : 14545638,
      "verified" : false
    }
  },
  "id" : 35723176528842752,
  "created_at" : "2011-02-10 15:34:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/beta.twitlonger.com\" rel=\"nofollow\"\u003ETwitLonger Beta\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35722288519188481",
  "text" : "\"The most important thing I learned,\" said Billy Pilgrim in Kurt Vonnegut's novel \"Slaughterhouse Five,\" \"was (cont) http:\/\/tl.gd\/8o0gn6",
  "id" : 35722288519188481,
  "created_at" : "2011-02-10 15:30:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "indices" : [ 3, 13 ],
      "id_str" : "36647504",
      "id" : 36647504
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35720038107451392",
  "text" : "RT @marseelee: Why Death Is Not The End Of Existence http:\/\/pulsene.ws\/10Wk4",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.pulse.me\" rel=\"nofollow\"\u003EPulse News\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35718927489175552",
    "text" : "Why Death Is Not The End Of Existence http:\/\/pulsene.ws\/10Wk4",
    "id" : 35718927489175552,
    "created_at" : "2011-02-10 15:17:10 +0000",
    "user" : {
      "name" : "Marcelle",
      "screen_name" : "marseelee",
      "protected" : false,
      "id_str" : "36647504",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/626129049828593665\/J1yvMKd__normal.jpg",
      "id" : 36647504,
      "verified" : false
    }
  },
  "id" : 35720038107451392,
  "created_at" : "2011-02-10 15:21:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "indices" : [ 105, 118 ],
      "id_str" : "95730042",
      "id" : 95730042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35554574907473920",
  "geo" : { },
  "id_str" : "35719499848093698",
  "in_reply_to_user_id" : 95730042,
  "text" : "the cat was excited. the dog wanted to herd it but our yelling scared her. she went upstairs to bed..lol @GoblinWriter",
  "id" : 35719499848093698,
  "in_reply_to_status_id" : 35554574907473920,
  "created_at" : "2011-02-10 15:19:27 +0000",
  "in_reply_to_screen_name" : "GoblinWriter",
  "in_reply_to_user_id_str" : "95730042",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35541266250858496",
  "text" : "flying squirrel loose in our house. hub got him out of hot air vent but he got loose and now back in the walls... hes really cute!",
  "id" : 35541266250858496,
  "created_at" : "2011-02-10 03:31:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35540386504118272",
  "text" : "RT @DougDorow: 5 more followers to 700, another hurdle.  Can I add faster than they drop?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35535877421670400",
    "text" : "5 more followers to 700, another hurdle.  Can I add faster than they drop?",
    "id" : 35535877421670400,
    "created_at" : "2011-02-10 03:09:48 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 35540386504118272,
  "created_at" : "2011-02-10 03:27:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 18, 32 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35524226861506560",
  "text" : "Why?? ((hugs)) RT @Dwayne_Reaves: I hate myself really bad!!!!",
  "id" : 35524226861506560,
  "created_at" : "2011-02-10 02:23:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Dwayne Reaves",
      "screen_name" : "dwayne_reaves",
      "indices" : [ 10, 24 ],
      "id_str" : "760205054531874816",
      "id" : 760205054531874816
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35524102290669568",
  "text" : "Um, NO RT @Dwayne_Reaves: Someone called me STUPID! They are probably right!",
  "id" : 35524102290669568,
  "created_at" : "2011-02-10 02:23:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 2, 13 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35460822192885760",
  "geo" : { },
  "id_str" : "35472068061437953",
  "in_reply_to_user_id" : 6994832,
  "text" : "\u2665 @TrishScott",
  "id" : 35472068061437953,
  "in_reply_to_status_id" : 35460822192885760,
  "created_at" : "2011-02-09 22:56:14 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35451830351691776",
  "text" : "oh, and I follow a lot of animals! lol",
  "id" : 35451830351691776,
  "created_at" : "2011-02-09 21:35:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35451190191857664",
  "text" : "interesting.. I follow a lot of: atheists, authors, buddhists",
  "id" : 35451190191857664,
  "created_at" : "2011-02-09 21:33:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 19, 29 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35444764019003392",
  "text" : "but of course! : ) @ID_vs_EGO",
  "id" : 35444764019003392,
  "created_at" : "2011-02-09 21:07:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Alisyn Gayle",
      "screen_name" : "AlisynGayle",
      "indices" : [ 105, 117 ],
      "id_str" : "90733366",
      "id" : 90733366
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35433927384506368",
  "geo" : { },
  "id_str" : "35435807321886720",
  "in_reply_to_user_id" : 90733366,
  "text" : "omg, I \u2665 U!! lol.. hubby decided to clean & expected me to join him. but didnt say what he wanted..sigh. @AlisynGayle",
  "id" : 35435807321886720,
  "in_reply_to_status_id" : 35433927384506368,
  "created_at" : "2011-02-09 20:32:09 +0000",
  "in_reply_to_screen_name" : "AlisynGayle",
  "in_reply_to_user_id_str" : "90733366",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "indices" : [ 3, 11 ],
      "id_str" : "14232408",
      "id" : 14232408
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35435480547983360",
  "text" : "RT @offgrid: Domains from $1.99  -  I just bought a Dot.Info for $1.99\n\nhttp:\/\/x.co\/MvKZ",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.linkedin.com\/\" rel=\"nofollow\"\u003ELinkedIn\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35434208864247808",
    "text" : "Domains from $1.99  -  I just bought a Dot.Info for $1.99\n\nhttp:\/\/x.co\/MvKZ",
    "id" : 35434208864247808,
    "created_at" : "2011-02-09 20:25:48 +0000",
    "user" : {
      "name" : "Offgrid",
      "screen_name" : "offgrid",
      "protected" : false,
      "id_str" : "14232408",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/658770933063151617\/yzshyxdA_normal.jpg",
      "id" : 14232408,
      "verified" : false
    }
  },
  "id" : 35435480547983360,
  "created_at" : "2011-02-09 20:30:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35433731384680448",
  "text" : "just dropped a whole bunch of ppl! it was kinda fun!",
  "id" : 35433731384680448,
  "created_at" : "2011-02-09 20:23:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 21, 36 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35419152319651840",
  "text" : "Yay! I cant wait! RT @thesexyatheist: End of times, this this time http:\/\/bit.ly\/gRfZCE May 21st, 2011.",
  "id" : 35419152319651840,
  "created_at" : "2011-02-09 19:25:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35417470080647168",
  "text" : "im getting yelled at today",
  "id" : 35417470080647168,
  "created_at" : "2011-02-09 19:19:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 56, 66 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35403541384269825",
  "geo" : { },
  "id_str" : "35416201152700416",
  "in_reply_to_user_id" : 56280847,
  "text" : "get hopping with 9th District.. Im want 2 read shortly! @DougDorow",
  "id" : 35416201152700416,
  "in_reply_to_status_id" : 35403541384269825,
  "created_at" : "2011-02-09 19:14:15 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35403268876140544",
  "text" : "RT @petsalive: This quarter from people using the Pets Alive credit card, we reaped $382!!!  WEE!!! FREE $! Get a card today! tinyurl.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35401823997132800",
    "text" : "This quarter from people using the Pets Alive credit card, we reaped $382!!!  WEE!!! FREE $! Get a card today! tinyurl.com\/petsalivecc",
    "id" : 35401823997132800,
    "created_at" : "2011-02-09 18:17:07 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 35403268876140544,
  "created_at" : "2011-02-09 18:22:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35401070729494529",
  "text" : "Pitbull surrounded! http:\/\/on.fb.me\/fKciIM",
  "id" : 35401070729494529,
  "created_at" : "2011-02-09 18:14:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 3, 16 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "hewontlikethat",
      "indices" : [ 125, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35395894371291136",
  "text" : "RT @derekrootboy: if i lose coffee bet because mubarak doesn't resign, i'm getting on plane to cairo to join the revolution. #hewontlikethat",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "hewontlikethat",
        "indices" : [ 107, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35395259919904768",
    "text" : "if i lose coffee bet because mubarak doesn't resign, i'm getting on plane to cairo to join the revolution. #hewontlikethat",
    "id" : 35395259919904768,
    "created_at" : "2011-02-09 17:51:02 +0000",
    "user" : {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "protected" : false,
      "id_str" : "35585695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/799761806365519873\/IUhJ_hcg_normal.jpg",
      "id" : 35585695,
      "verified" : false
    }
  },
  "id" : 35395894371291136,
  "created_at" : "2011-02-09 17:53:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35395772119781376",
  "text" : "sorry to hear this. have some chocolate. @Skandhasattva",
  "id" : 35395772119781376,
  "created_at" : "2011-02-09 17:53:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "indices" : [ 3, 16 ],
      "id_str" : "95730042",
      "id" : 95730042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35394265131655168",
  "text" : "RT @GoblinWriter: Offering a Free Ebook for Marketing \u2014 My Results http:\/\/bit.ly\/fLjnhK",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35390832676704256",
    "text" : "Offering a Free Ebook for Marketing \u2014 My Results http:\/\/bit.ly\/fLjnhK",
    "id" : 35390832676704256,
    "created_at" : "2011-02-09 17:33:26 +0000",
    "user" : {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "protected" : false,
      "id_str" : "95730042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1558192985\/goblin-pic_normal.jpg",
      "id" : 95730042,
      "verified" : false
    }
  },
  "id" : 35394265131655168,
  "created_at" : "2011-02-09 17:47:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35355256523194368",
  "text" : "RT @GeneDoucette: Finding out AOL still exists is like discovering your old preschool is still running.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35348956766666752",
    "text" : "Finding out AOL still exists is like discovering your old preschool is still running.",
    "id" : 35348956766666752,
    "created_at" : "2011-02-09 14:47:02 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 35355256523194368,
  "created_at" : "2011-02-09 15:12:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35348501118324736",
  "text" : "RT @TrishScott: So I've been following the ppl twitter says are \"like\" me. Must say, don't see it. What is the criteria? That we are ONE ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35347211013332992",
    "text" : "So I've been following the ppl twitter says are \"like\" me. Must say, don't see it. What is the criteria? That we are ONE? OK.",
    "id" : 35347211013332992,
    "created_at" : "2011-02-09 14:40:06 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 35348501118324736,
  "created_at" : "2011-02-09 14:45:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Cushing SteveC",
      "screen_name" : "Montberte",
      "indices" : [ 3, 13 ],
      "id_str" : "193318094",
      "id" : 193318094
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35348432868610048",
  "text" : "RT @Montberte: When I was a little boy, they called me a liar, but now that I am grown up, they call me a writer.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34852872139055104",
    "text" : "When I was a little boy, they called me a liar, but now that I am grown up, they call me a writer.",
    "id" : 34852872139055104,
    "created_at" : "2011-02-08 05:55:46 +0000",
    "user" : {
      "name" : "Steve Cushing SteveC",
      "screen_name" : "Montberte",
      "protected" : false,
      "id_str" : "193318094",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/676800864485527553\/9pgD-hX-_normal.jpg",
      "id" : 193318094,
      "verified" : false
    }
  },
  "id" : 35348432868610048,
  "created_at" : "2011-02-09 14:44:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 84, 95 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35344980713148416",
  "geo" : { },
  "id_str" : "35348251641126913",
  "in_reply_to_user_id" : 6994832,
  "text" : "yet ppl assume they can decide how one should act or feel in any situation.. pffft! @TrishScott",
  "id" : 35348251641126913,
  "in_reply_to_status_id" : 35344980713148416,
  "created_at" : "2011-02-09 14:44:14 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JCPhelps",
      "screen_name" : "jeaniep3",
      "indices" : [ 3, 12 ],
      "id_str" : "53925824",
      "id" : 53925824
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 25, 33 ]
    }, {
      "text" : "kindle",
      "indices" : [ 68, 75 ]
    }, {
      "text" : "nook",
      "indices" : [ 102, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35347843493404673",
  "text" : "RT @jeaniep3: Crime Beat\n#mystery Crime Beat by Scott Nicholson for #kindle http:\/\/amzn.to\/e5tGqB and #nook http:\/\/bit.ly\/f3w9Pj 99 cent ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "mystery",
        "indices" : [ 11, 19 ]
      }, {
        "text" : "kindle",
        "indices" : [ 54, 61 ]
      }, {
        "text" : "nook",
        "indices" : [ 88, 93 ]
      }, {
        "text" : "books",
        "indices" : [ 124, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35342737360289792",
    "text" : "Crime Beat\n#mystery Crime Beat by Scott Nicholson for #kindle http:\/\/amzn.to\/e5tGqB and #nook http:\/\/bit.ly\/f3w9Pj 99 cents #books Plz RT",
    "id" : 35342737360289792,
    "created_at" : "2011-02-09 14:22:19 +0000",
    "user" : {
      "name" : "JCPhelps",
      "screen_name" : "jeaniep3",
      "protected" : false,
      "id_str" : "53925824",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3331537070\/59c63636bb567abbd22e47baccfce4b4_normal.jpeg",
      "id" : 53925824,
      "verified" : false
    }
  },
  "id" : 35347843493404673,
  "created_at" : "2011-02-09 14:42:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "David Biello",
      "screen_name" : "dbiello",
      "indices" : [ 17, 25 ],
      "id_str" : "14323791",
      "id" : 14323791
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35344195317145600",
  "geo" : { },
  "id_str" : "35347561380319232",
  "in_reply_to_user_id" : 14323791,
  "text" : "no profit in it? @dbiello",
  "id" : 35347561380319232,
  "in_reply_to_status_id" : 35344195317145600,
  "created_at" : "2011-02-09 14:41:30 +0000",
  "in_reply_to_screen_name" : "dbiello",
  "in_reply_to_user_id_str" : "14323791",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 52, 65 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35347361886642176",
  "text" : "Happy Anniversary! I got u beat by 2.x yrs..HA! : ) @GeneDoucette",
  "id" : 35347361886642176,
  "created_at" : "2011-02-09 14:40:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 58, 69 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35188428714811392",
  "geo" : { },
  "id_str" : "35331641966600192",
  "in_reply_to_user_id" : 7482152,
  "text" : "lucky my DD prefers pbooks cuz I wont share my kindle : ) @modernevil",
  "id" : 35331641966600192,
  "in_reply_to_status_id" : 35188428714811392,
  "created_at" : "2011-02-09 13:38:14 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thriller",
      "indices" : [ 50, 59 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35331007473258496",
  "text" : "RT @ThrillersRockT: I\u2019m looking for some good new #thriller author recommendations. Everyone tweet your top three!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thriller",
        "indices" : [ 30, 39 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35329897513615360",
    "text" : "I\u2019m looking for some good new #thriller author recommendations. Everyone tweet your top three!",
    "id" : 35329897513615360,
    "created_at" : "2011-02-09 13:31:18 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 35331007473258496,
  "created_at" : "2011-02-09 13:35:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Universal Connection",
      "screen_name" : "wow_trees",
      "indices" : [ 53, 63 ],
      "id_str" : "93341555",
      "id" : 93341555
    }, {
      "name" : "*Shadow of Elements*",
      "screen_name" : "SHDW_of_LMNTS",
      "indices" : [ 64, 78 ],
      "id_str" : "122561238",
      "id" : 122561238
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35329904576970752",
  "geo" : { },
  "id_str" : "35330970403999744",
  "in_reply_to_user_id" : 93341555,
  "text" : "I read \"a new earth\" by him. jumpstarted my path : ) @wow_trees @SHDW_of_LMNTS",
  "id" : 35330970403999744,
  "in_reply_to_status_id" : 35329904576970752,
  "created_at" : "2011-02-09 13:35:34 +0000",
  "in_reply_to_screen_name" : "wow_trees",
  "in_reply_to_user_id_str" : "93341555",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Premium-Hosts.com",
      "screen_name" : "premhosts",
      "indices" : [ 3, 13 ],
      "id_str" : "242830330",
      "id" : 242830330
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35329874747072512",
  "text" : "RT @premhosts: We now offer a fantastic unlimited hosting package for as low as $5 a month. Please visit http:\/\/www.premium-hosts.com fo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35327886948966400",
    "text" : "We now offer a fantastic unlimited hosting package for as low as $5 a month. Please visit http:\/\/www.premium-hosts.com for more information",
    "id" : 35327886948966400,
    "created_at" : "2011-02-09 13:23:19 +0000",
    "user" : {
      "name" : "Premium-Hosts.com",
      "screen_name" : "premhosts",
      "protected" : false,
      "id_str" : "242830330",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1232512315\/PH_normal.png",
      "id" : 242830330,
      "verified" : false
    }
  },
  "id" : 35329874747072512,
  "created_at" : "2011-02-09 13:31:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments",
      "indices" : [ 3, 15 ],
      "id_str" : "17486629",
      "id" : 17486629
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35320505334497280",
  "text" : "RT @Zen_Moments: Difficulties strengthen the mind, as well as labor does the body. ~ Seneca",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tweetspinner.com\/\" rel=\"nofollow\"\u003ETweet Spinner\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35298138873016321",
    "text" : "Difficulties strengthen the mind, as well as labor does the body. ~ Seneca",
    "id" : 35298138873016321,
    "created_at" : "2011-02-09 11:25:06 +0000",
    "user" : {
      "name" : "Zen Moments",
      "screen_name" : "Zen_Moments",
      "protected" : false,
      "id_str" : "17486629",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1117626620\/circle-1_normal.PNG",
      "id" : 17486629,
      "verified" : false
    }
  },
  "id" : 35320505334497280,
  "created_at" : "2011-02-09 12:53:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35320341794394112",
  "text" : "RT @screek: Vermont - Pete the Moose\u2019s Life Is on the Line, Again - NYTimes.com http:\/\/nyti.ms\/es9ADm",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35319686312755201",
    "text" : "Vermont - Pete the Moose\u2019s Life Is on the Line, Again - NYTimes.com http:\/\/nyti.ms\/es9ADm",
    "id" : 35319686312755201,
    "created_at" : "2011-02-09 12:50:44 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 35320341794394112,
  "created_at" : "2011-02-09 12:53:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35319011503767552",
  "text" : "RT @screek: Almost 1,700 NY geese killed to protect air travel http:\/\/bit.ly\/fr2U0u",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35316824081956864",
    "text" : "Almost 1,700 NY geese killed to protect air travel http:\/\/bit.ly\/fr2U0u",
    "id" : 35316824081956864,
    "created_at" : "2011-02-09 12:39:21 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 35319011503767552,
  "created_at" : "2011-02-09 12:48:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35314743032020992",
  "text" : "((hugs)) to @InfantileAdult for your Nana passing on",
  "id" : 35314743032020992,
  "created_at" : "2011-02-09 12:31:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "indices" : [ 3, 13 ],
      "id_str" : "14959952",
      "id" : 14959952
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35313351055638528",
  "text" : "RT @parkstepp: \"Since her death in 1979, the woman who discovered what the universe is made of has not so much as...\" http:\/\/tumblr.com\/ ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tumblr.com\/\" rel=\"nofollow\"\u003ETumblr\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35276530288431104",
    "text" : "\"Since her death in 1979, the woman who discovered what the universe is made of has not so much as...\" http:\/\/tumblr.com\/xjw1gv9tfj",
    "id" : 35276530288431104,
    "created_at" : "2011-02-09 09:59:14 +0000",
    "user" : {
      "name" : "Stephen Parker",
      "screen_name" : "parkstepp",
      "protected" : false,
      "id_str" : "14959952",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2956627407\/f64334d82ce31cd30da16f08338ca35d_normal.jpeg",
      "id" : 14959952,
      "verified" : false
    }
  },
  "id" : 35313351055638528,
  "created_at" : "2011-02-09 12:25:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35310332247281664",
  "text" : "RT @neardeathdoc: I learned from children who have nearly died that each of us has a personal connection with the divine. A god spot!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35303879751122944",
    "text" : "I learned from children who have nearly died that each of us has a personal connection with the divine. A god spot!",
    "id" : 35303879751122944,
    "created_at" : "2011-02-09 11:47:55 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 35310332247281664,
  "created_at" : "2011-02-09 12:13:33 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vanilla Ice",
      "screen_name" : "brandonrofl",
      "indices" : [ 3, 15 ],
      "id_str" : "1934461332",
      "id" : 1934461332
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35176488093351936",
  "text" : "RT @brandonrofl: Look, if you have a Facebook and haven't added your parents\/relatives yet, for the love of God do not do it. Just trust me.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35176013428305920",
    "text" : "Look, if you have a Facebook and haven't added your parents\/relatives yet, for the love of God do not do it. Just trust me.",
    "id" : 35176013428305920,
    "created_at" : "2011-02-09 03:19:49 +0000",
    "user" : {
      "name" : "Spaced Out Brandon",
      "screen_name" : "4ores7",
      "protected" : false,
      "id_str" : "18694547",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765973859984142337\/tinvURiM_normal.jpg",
      "id" : 18694547,
      "verified" : false
    }
  },
  "id" : 35176488093351936,
  "created_at" : "2011-02-09 03:21:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ryne Douglas Pearson",
      "screen_name" : "rynedp",
      "indices" : [ 3, 10 ],
      "id_str" : "18089695",
      "id" : 18089695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "writers",
      "indices" : [ 91, 99 ]
    }, {
      "text" : "writing",
      "indices" : [ 100, 108 ]
    }, {
      "text" : "amwriting",
      "indices" : [ 109, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35176219414630400",
  "text" : "RT @rynedp: A post today on things you can do to help authors you like: http:\/\/j.mp\/i2pYtf #writers #writing #amwriting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "writers",
        "indices" : [ 79, 87 ]
      }, {
        "text" : "writing",
        "indices" : [ 88, 96 ]
      }, {
        "text" : "amwriting",
        "indices" : [ 97, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35175029649965056",
    "text" : "A post today on things you can do to help authors you like: http:\/\/j.mp\/i2pYtf #writers #writing #amwriting",
    "id" : 35175029649965056,
    "created_at" : "2011-02-09 03:15:55 +0000",
    "user" : {
      "name" : "Ryne Douglas Pearson",
      "screen_name" : "rynedp",
      "protected" : false,
      "id_str" : "18089695",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458711316874555392\/8GSsda5g_normal.jpeg",
      "id" : 18089695,
      "verified" : false
    }
  },
  "id" : 35176219414630400,
  "created_at" : "2011-02-09 03:20:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35174383957839872",
  "text" : "None of us really truly knows what its like to be someone else.",
  "id" : 35174383957839872,
  "created_at" : "2011-02-09 03:13:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35173972505010176",
  "text" : "I hear ppl say \"Im so tired of ppl getting away with blahblah\" well, Im so tired of ppl judging each other, condemning each other!",
  "id" : 35173972505010176,
  "created_at" : "2011-02-09 03:11:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 7, 16 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35170378217308160",
  "text" : "LOL RT @Fernwise: Monetized my blog.  I feel like a whore.",
  "id" : 35170378217308160,
  "created_at" : "2011-02-09 02:57:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 3, 11 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "reading",
      "indices" : [ 114, 122 ]
    }, {
      "text" : "suggestions",
      "indices" : [ 123, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35155337136979968",
  "text" : "RT @BookYap: We're here to help you find a new book. Still don't get it? Here's how we do it: http:\/\/so-kt.tw\/7Nd #reading #suggestions",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialkaty.com\" rel=\"nofollow\"\u003Esocialkaty\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "reading",
        "indices" : [ 101, 109 ]
      }, {
        "text" : "suggestions",
        "indices" : [ 110, 122 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35153413155065856",
    "text" : "We're here to help you find a new book. Still don't get it? Here's how we do it: http:\/\/so-kt.tw\/7Nd #reading #suggestions",
    "id" : 35153413155065856,
    "created_at" : "2011-02-09 01:50:01 +0000",
    "user" : {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "protected" : false,
      "id_str" : "123948351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083030490\/Bookyap1_normal.jpg",
      "id" : 123948351,
      "verified" : false
    }
  },
  "id" : 35155337136979968,
  "created_at" : "2011-02-09 01:57:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 0, 11 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35113276979290112",
  "geo" : { },
  "id_str" : "35120746258763776",
  "in_reply_to_user_id" : 7482152,
  "text" : "@modernevil never heard of them either. Is your lady excited about the kindle?",
  "id" : 35120746258763776,
  "in_reply_to_status_id" : 35113276979290112,
  "created_at" : "2011-02-08 23:40:13 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ade Lack",
      "screen_name" : "bookborrowr",
      "indices" : [ 3, 15 ],
      "id_str" : "209836347",
      "id" : 209836347
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 82, 93 ],
      "id_str" : "93747129",
      "id" : 93747129
    }, {
      "name" : "Jonathan Cyfer",
      "screen_name" : "jonathancyfer",
      "indices" : [ 94, 108 ],
      "id_str" : "138559627",
      "id" : 138559627
    }, {
      "name" : "Barbara E Brink",
      "screen_name" : "BarbaraEBrink",
      "indices" : [ 109, 123 ],
      "id_str" : "109654184",
      "id" : 109654184
    }, {
      "name" : "Juraj Chlebec",
      "screen_name" : "havran",
      "indices" : [ 124, 131 ],
      "id_str" : "16664876",
      "id" : 16664876
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35102037720956929",
  "text" : "RT @bookborrowr: Kindle News is out! http:\/\/bit.ly\/dHtGbI \u25B8 Top stories today via @moosebegab @jonathancyfer @barbaraebrink @havran @joe ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/paper.li\" rel=\"nofollow\"\u003EPaper.li\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 65, 76 ],
        "id_str" : "93747129",
        "id" : 93747129
      }, {
        "name" : "Jonathan Cyfer",
        "screen_name" : "jonathancyfer",
        "indices" : [ 77, 91 ],
        "id_str" : "138559627",
        "id" : 138559627
      }, {
        "name" : "Barbara E Brink",
        "screen_name" : "BarbaraEBrink",
        "indices" : [ 92, 106 ],
        "id_str" : "109654184",
        "id" : 109654184
      }, {
        "name" : "Juraj Chlebec",
        "screen_name" : "havran",
        "indices" : [ 107, 114 ],
        "id_str" : "16664876",
        "id" : 16664876
      }, {
        "name" : "Joey Mavity",
        "screen_name" : "joeymavity",
        "indices" : [ 115, 126 ],
        "id_str" : "138525825",
        "id" : 138525825
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35101146058207232",
    "text" : "Kindle News is out! http:\/\/bit.ly\/dHtGbI \u25B8 Top stories today via @moosebegab @jonathancyfer @barbaraebrink @havran @joeymavity",
    "id" : 35101146058207232,
    "created_at" : "2011-02-08 22:22:20 +0000",
    "user" : {
      "name" : "Ade Lack",
      "screen_name" : "bookborrowr",
      "protected" : false,
      "id_str" : "209836347",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1202830487\/bbprofile_normal.jpg",
      "id" : 209836347,
      "verified" : false
    }
  },
  "id" : 35102037720956929,
  "created_at" : "2011-02-08 22:25:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35090934270005248",
  "text" : "I need 2 go get my chapstick..but lazy..lol. Ever since got real sore lips as a kid, I keep several chapsticks. Use it several times daily",
  "id" : 35090934270005248,
  "created_at" : "2011-02-08 21:41:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35086045238267904",
  "text" : "We love having our dog sleep with us. She no longer sleeps on bed tho cuz Daddy moves too much..lol",
  "id" : 35086045238267904,
  "created_at" : "2011-02-08 21:22:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Heather Wardell",
      "screen_name" : "HeatherWardell",
      "indices" : [ 0, 15 ],
      "id_str" : "155212706",
      "id" : 155212706
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35085809187028992",
  "text" : "@HeatherWardell heehee. we had a cat we'd have to keep out cuz he wouldnt settle down after lights out.",
  "id" : 35085809187028992,
  "created_at" : "2011-02-08 21:21:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "35075881495957504",
  "geo" : { },
  "id_str" : "35085464926953472",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott the way they were slanting the preview was negative (like everything else in the news..sigh)",
  "id" : 35085464926953472,
  "in_reply_to_status_id" : 35075881495957504,
  "created_at" : "2011-02-08 21:20:01 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 3, 15 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35085203999436800",
  "text" : "RT @PuaTamandua: Baby on Aurora's butt http:\/\/www.flickr.com\/photos\/tamanduagirl\/5429142660\/ http:\/\/fb.me\/vcQL0iO0",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35084707058155520",
    "text" : "Baby on Aurora's butt http:\/\/www.flickr.com\/photos\/tamanduagirl\/5429142660\/ http:\/\/fb.me\/vcQL0iO0",
    "id" : 35084707058155520,
    "created_at" : "2011-02-08 21:17:00 +0000",
    "user" : {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "protected" : false,
      "id_str" : "17218256",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63782435\/shirt_normal.jpg",
      "id" : 17218256,
      "verified" : false
    }
  },
  "id" : 35085203999436800,
  "created_at" : "2011-02-08 21:18:59 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35084914642657280",
  "text" : "I try not to watch the news. It's all propaganda and just plain stupid. Unfortunately, its on channel hubby watches :\/",
  "id" : 35084914642657280,
  "created_at" : "2011-02-08 21:17:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35071062395846656",
  "text" : "so apparently sleeping w pets is frowned upon? on news last night. didnt watch but saw previews. stupid!",
  "id" : 35071062395846656,
  "created_at" : "2011-02-08 20:22:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael_Palmer",
      "screen_name" : "Michael_Palmer",
      "indices" : [ 3, 18 ],
      "id_str" : "17919174",
      "id" : 17919174
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "win",
      "indices" : [ 28, 32 ]
    }, {
      "text" : "AHeartbeatAway",
      "indices" : [ 59, 74 ]
    }, {
      "text" : "thriller",
      "indices" : [ 126, 135 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35067894861664256",
  "text" : "RT @Michael_Palmer: Want to #win a kindle? Share chap 1 of #AHeartbeatAway on Twitter or FB\u2026 thanks :) http:\/\/on.fb.me\/gaE8dO #thriller",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.exacttarget.com\/social\" rel=\"nofollow\"\u003ESocialEngage\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "win",
        "indices" : [ 8, 12 ]
      }, {
        "text" : "AHeartbeatAway",
        "indices" : [ 39, 54 ]
      }, {
        "text" : "thriller",
        "indices" : [ 106, 115 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35067154508288001",
    "text" : "Want to #win a kindle? Share chap 1 of #AHeartbeatAway on Twitter or FB\u2026 thanks :) http:\/\/on.fb.me\/gaE8dO #thriller",
    "id" : 35067154508288001,
    "created_at" : "2011-02-08 20:07:15 +0000",
    "user" : {
      "name" : "Michael_Palmer",
      "screen_name" : "Michael_Palmer",
      "protected" : false,
      "id_str" : "17919174",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/817290389\/michael_normal.jpg",
      "id" : 17919174,
      "verified" : false
    }
  },
  "id" : 35067894861664256,
  "created_at" : "2011-02-08 20:10:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "indices" : [ 3, 16 ],
      "id_str" : "135615040",
      "id" : 135615040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "justsayin",
      "indices" : [ 122, 132 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35063674758643712",
  "text" : "RT @CrystalLewis: I don't think twitter should count the names of those we \"@-reply\" against our 140 character allowance. #justsayin",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "justsayin",
        "indices" : [ 104, 114 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35059956046757888",
    "text" : "I don't think twitter should count the names of those we \"@-reply\" against our 140 character allowance. #justsayin",
    "id" : 35059956046757888,
    "created_at" : "2011-02-08 19:38:39 +0000",
    "user" : {
      "name" : "the woman @ the welp",
      "screen_name" : "CrystalLewis",
      "protected" : true,
      "id_str" : "135615040",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/765015541664940032\/2VlsuWyj_normal.jpg",
      "id" : 135615040,
      "verified" : false
    }
  },
  "id" : 35063674758643712,
  "created_at" : "2011-02-08 19:53:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35052552298958848",
  "text" : "Love this - Get Your Validation! : ) http:\/\/bit.ly\/ifVIIF",
  "id" : 35052552298958848,
  "created_at" : "2011-02-08 19:09:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35052193077796864",
  "text" : "Giveaway of Falling Star (10 ebooks) - exp 2\/15 http:\/\/bit.ly\/fiJ7Z6",
  "id" : 35052193077796864,
  "created_at" : "2011-02-08 19:07:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35051512774270977",
  "text" : "oops.. made a mess on my website...",
  "id" : 35051512774270977,
  "created_at" : "2011-02-08 19:05:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35043802120986624",
  "text" : "RT @KreelanWarrior: Sweet! SEASON OF THE HARVEST now at 4,064 in the Kindle Store - just a bit more to get into the 3K's! http:\/\/ow.ly\/3 ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35042607105052672",
    "text" : "Sweet! SEASON OF THE HARVEST now at 4,064 in the Kindle Store - just a bit more to get into the 3K's! http:\/\/ow.ly\/3S0oQ  :-)",
    "id" : 35042607105052672,
    "created_at" : "2011-02-08 18:29:43 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 35043802120986624,
  "created_at" : "2011-02-08 18:34:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 3, 11 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "bookyap",
      "indices" : [ 125, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35036544096141312",
  "text" : "RT @BookYap: BIG contest starting tomorrow! What will it be? Finish up those books and peep our tweets tomorrow to find out! #bookyap #c ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialkaty.com\" rel=\"nofollow\"\u003Esocialkaty\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "bookyap",
        "indices" : [ 112, 120 ]
      }, {
        "text" : "contests",
        "indices" : [ 121, 130 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35035135271239681",
    "text" : "BIG contest starting tomorrow! What will it be? Finish up those books and peep our tweets tomorrow to find out! #bookyap #contests",
    "id" : 35035135271239681,
    "created_at" : "2011-02-08 18:00:01 +0000",
    "user" : {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "protected" : false,
      "id_str" : "123948351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083030490\/Bookyap1_normal.jpg",
      "id" : 123948351,
      "verified" : false
    }
  },
  "id" : 35036544096141312,
  "created_at" : "2011-02-08 18:05:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 24, 37 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 55, 74 ],
      "url" : "http:\/\/t.co\/i1AZcwx",
      "expanded_url" : "http:\/\/wp.me\/pXlXL-b4",
      "display_url" : "wp.me\/pXlXL-b4"
    } ]
  },
  "geo" : { },
  "id_str" : "35036325363187712",
  "text" : "What about the cat?? RT @GeneDoucette: Working it out: http:\/\/t.co\/i1AZcwx",
  "id" : 35036325363187712,
  "created_at" : "2011-02-08 18:04:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "indices" : [ 3, 16 ],
      "id_str" : "84714448",
      "id" : 84714448
    }, {
      "name" : "Chloe Angyal",
      "screen_name" : "ChloeAngyal",
      "indices" : [ 21, 33 ],
      "id_str" : "51426896",
      "id" : 51426896
    }, {
      "name" : "John Henry Pepper",
      "screen_name" : "JHPepper",
      "indices" : [ 35, 44 ],
      "id_str" : "96180203",
      "id" : 96180203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35031043169849344",
  "text" : "RT @Thinking_mom: RT @ChloeAngyal: @JHPepper: we use brain activity to mark when life ends. Why use heartbeat to determine when it begin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Chloe Angyal",
        "screen_name" : "ChloeAngyal",
        "indices" : [ 3, 15 ],
        "id_str" : "51426896",
        "id" : 51426896
      }, {
        "name" : "John Henry Pepper",
        "screen_name" : "JHPepper",
        "indices" : [ 17, 26 ],
        "id_str" : "96180203",
        "id" : 96180203
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35028625912758272",
    "text" : "RT @ChloeAngyal: @JHPepper: we use brain activity to mark when life ends. Why use heartbeat to determine when it begins? http:\/\/is.gd\/ZSYwFI",
    "id" : 35028625912758272,
    "created_at" : "2011-02-08 17:34:09 +0000",
    "user" : {
      "name" : "Thinking Mom",
      "screen_name" : "Thinking_mom",
      "protected" : false,
      "id_str" : "84714448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792761883749154816\/N4CNeldE_normal.jpg",
      "id" : 84714448,
      "verified" : false
    }
  },
  "id" : 35031043169849344,
  "created_at" : "2011-02-08 17:43:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35022192802529281",
  "text" : "RT @GeneDoucette: Vincent Zandri: \"Imagine if you will two editors sitting at a bar in New York, trying to think up the next hug\u2026 (cont) ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35018314262511617",
    "text" : "Vincent Zandri: \"Imagine if you will two editors sitting at a bar in New York, trying to think up the next hug\u2026 (cont) http:\/\/deck.ly\/~3Vr7H",
    "id" : 35018314262511617,
    "created_at" : "2011-02-08 16:53:11 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 35022192802529281,
  "created_at" : "2011-02-08 17:08:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35021038609760257",
  "text" : "RT @Wylieknowords: \"You must be more than 'on Twitter'--young grasshopper.\" N. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35018834716917760",
    "text" : "\"You must be more than 'on Twitter'--young grasshopper.\" N. Wylie Jones www.knowords.com",
    "id" : 35018834716917760,
    "created_at" : "2011-02-08 16:55:15 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 35021038609760257,
  "created_at" : "2011-02-08 17:04:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35020754458247168",
  "text" : "What if Heaven is what each of us makes it to be? http:\/\/bit.ly\/gCAi2w",
  "id" : 35020754458247168,
  "created_at" : "2011-02-08 17:02:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 39, 55 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34758223311409152",
  "geo" : { },
  "id_str" : "35011485990129664",
  "in_reply_to_user_id" : 30077179,
  "text" : "hope today is a better day for you : ) @simonwoodwrites",
  "id" : 35011485990129664,
  "in_reply_to_status_id" : 34758223311409152,
  "created_at" : "2011-02-08 16:26:03 +0000",
  "in_reply_to_screen_name" : "simonwoodwrites",
  "in_reply_to_user_id_str" : "30077179",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 3, 18 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35008176407449600",
  "text" : "RT @KreelanWarrior: BTW, dear readers, *please* consider doing a review of the books you read where you purchased them. You don't have.. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "35002887025201152",
    "text" : "BTW, dear readers, *please* consider doing a review of the books you read where you purchased them. You don't have... http:\/\/fb.me\/SAEZf2qB",
    "id" : 35002887025201152,
    "created_at" : "2011-02-08 15:51:53 +0000",
    "user" : {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "protected" : false,
      "id_str" : "16114141",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/666104892\/P1080501-a_normal.jpg",
      "id" : 16114141,
      "verified" : false
    }
  },
  "id" : 35008176407449600,
  "created_at" : "2011-02-08 16:12:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 121, 137 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "kindle",
      "indices" : [ 47, 54 ]
    }, {
      "text" : "nook",
      "indices" : [ 81, 86 ]
    }, {
      "text" : "books",
      "indices" : [ 114, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "35001034883469312",
  "text" : "#mystery The Skull Ring by Scott Nicholson for #kindle http:\/\/amzn.to\/9Ii8kC and #nook http:\/\/bit.ly\/hzGa5Y $2.99 #books @hauntedcomputer",
  "id" : 35001034883469312,
  "created_at" : "2011-02-08 15:44:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34993314663108608",
  "text" : "RT @GeneDoucette: Immortal, in nearly all formats. the \"carved on the side of a pig\" version is pending. http:\/\/bit.ly\/90yYxc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34992422245109760",
    "text" : "Immortal, in nearly all formats. the \"carved on the side of a pig\" version is pending. http:\/\/bit.ly\/90yYxc",
    "id" : 34992422245109760,
    "created_at" : "2011-02-08 15:10:18 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 34993314663108608,
  "created_at" : "2011-02-08 15:13:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34967697573806080",
  "text" : "so lovely to see crows, squirrels, lil birds enjoy our backyard bounty",
  "id" : 34967697573806080,
  "created_at" : "2011-02-08 13:32:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    }, {
      "name" : "Paul V Harris",
      "screen_name" : "paulvharris",
      "indices" : [ 21, 33 ],
      "id_str" : "17008328",
      "id" : 17008328
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34967138691194880",
  "text" : "RT @neardeathdoc: RT @paulvharris: Everyone dies, yet only a few have the courage to live. ~Paul V Harris (this is the No 1 message of n ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Paul V Harris",
        "screen_name" : "paulvharris",
        "indices" : [ 3, 15 ],
        "id_str" : "17008328",
        "id" : 17008328
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34956822943109120",
    "text" : "RT @paulvharris: Everyone dies, yet only a few have the courage to live. ~Paul V Harris (this is the No 1 message of near death experience)",
    "id" : 34956822943109120,
    "created_at" : "2011-02-08 12:48:50 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 34967138691194880,
  "created_at" : "2011-02-08 13:29:50 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "indices" : [ 3, 18 ],
      "id_str" : "143989898",
      "id" : 143989898
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "thrillers",
      "indices" : [ 28, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34964864208207872",
  "text" : "RT @ThrillersRockT: So many #thrillers. So little time.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "thrillers",
        "indices" : [ 8, 18 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34962987966005248",
    "text" : "So many #thrillers. So little time.",
    "id" : 34962987966005248,
    "created_at" : "2011-02-08 13:13:20 +0000",
    "user" : {
      "name" : "#1 Fan of Thrillers",
      "screen_name" : "ThrillersRockT",
      "protected" : false,
      "id_str" : "143989898",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1007990288\/RollinsRock_collage_small_normal.jpg",
      "id" : 143989898,
      "verified" : false
    }
  },
  "id" : 34964864208207872,
  "created_at" : "2011-02-08 13:20:47 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USE",
      "indices" : [ 75, 79 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34804539949318144",
  "text" : "RT @UnseeingEyes: \"Is all that we see or seem but a dream within a dream?\" #USE -Edgar Allan Poe",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USE",
        "indices" : [ 57, 61 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34804038990045184",
    "text" : "\"Is all that we see or seem but a dream within a dream?\" #USE -Edgar Allan Poe",
    "id" : 34804038990045184,
    "created_at" : "2011-02-08 02:41:44 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 34804539949318144,
  "created_at" : "2011-02-08 02:43:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "indices" : [ 3, 16 ],
      "id_str" : "44101564",
      "id" : 44101564
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34788081949212672",
  "text" : "RT @Joeandrasi93: Do you think consciousness can exist at the subatomic level?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34785059118522368",
    "text" : "Do you think consciousness can exist at the subatomic level?",
    "id" : 34785059118522368,
    "created_at" : "2011-02-08 01:26:19 +0000",
    "user" : {
      "name" : "Joseph J. Andrasi",
      "screen_name" : "Joeandrasi93",
      "protected" : false,
      "id_str" : "44101564",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/639542529864548352\/dgfDJkY8_normal.jpg",
      "id" : 44101564,
      "verified" : false
    }
  },
  "id" : 34788081949212672,
  "created_at" : "2011-02-08 01:38:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 3, 11 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "BookYap",
      "indices" : [ 75, 83 ]
    }, {
      "text" : "reads",
      "indices" : [ 110, 116 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34748969250717696",
  "text" : "RT @BookYap: See what our Kindle book winners selected to read next on the #BookYap blog. http:\/\/so-kt.tw\/7Kj #reads",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialkaty.com\" rel=\"nofollow\"\u003Esocialkaty\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "BookYap",
        "indices" : [ 62, 70 ]
      }, {
        "text" : "reads",
        "indices" : [ 97, 103 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34745738034421760",
    "text" : "See what our Kindle book winners selected to read next on the #BookYap blog. http:\/\/so-kt.tw\/7Kj #reads",
    "id" : 34745738034421760,
    "created_at" : "2011-02-07 22:50:04 +0000",
    "user" : {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "protected" : false,
      "id_str" : "123948351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083030490\/Bookyap1_normal.jpg",
      "id" : 123948351,
      "verified" : false
    }
  },
  "id" : 34748969250717696,
  "created_at" : "2011-02-07 23:02:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Michael R. Hicks",
      "screen_name" : "KreelanWarrior",
      "indices" : [ 0, 15 ],
      "id_str" : "16114141",
      "id" : 16114141
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34722683413331969",
  "geo" : { },
  "id_str" : "34723975623999488",
  "in_reply_to_user_id" : 16114141,
  "text" : "@KreelanWarrior been watching the thread on kindleboards..lol. waiting 4 it 2 come out on amazon ((nailsdrumming)) lol",
  "id" : 34723975623999488,
  "in_reply_to_status_id" : 34722683413331969,
  "created_at" : "2011-02-07 21:23:35 +0000",
  "in_reply_to_screen_name" : "KreelanWarrior",
  "in_reply_to_user_id_str" : "16114141",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary Beth Nelson",
      "screen_name" : "northernmagic",
      "indices" : [ 3, 17 ],
      "id_str" : "2556861443",
      "id" : 2556861443
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34715138506362880",
  "text" : "RT @NorthernMagic: My mood ring is totally unique. If the big red demon eye shows up, it indicates my mood is... (more) http:\/\/twtm.in\/lUn",
  "id" : 34715138506362880,
  "created_at" : "2011-02-07 20:48:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "indices" : [ 3, 17 ],
      "id_str" : "236401429",
      "id" : 236401429
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindleapp",
      "indices" : [ 67, 77 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34714340426776576",
  "text" : "RT @ebookfriendly: Pentecost, a thriller by Joanna Penn \u00BB Buy with #kindleapp now and U can win a Kindle http:\/\/amzn.to\/eOOHUt Details:  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindleapp",
        "indices" : [ 48, 58 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34713026854653952",
    "text" : "Pentecost, a thriller by Joanna Penn \u00BB Buy with #kindleapp now and U can win a Kindle http:\/\/amzn.to\/eOOHUt Details: http:\/\/ow.ly\/3RrVR",
    "id" : 34713026854653952,
    "created_at" : "2011-02-07 20:40:05 +0000",
    "user" : {
      "name" : "Ebook Friendly",
      "screen_name" : "ebookfriendly",
      "protected" : false,
      "id_str" : "236401429",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/421202750320283648\/Dn314NRu_normal.jpeg",
      "id" : 236401429,
      "verified" : false
    }
  },
  "id" : 34714340426776576,
  "created_at" : "2011-02-07 20:45:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34707437143597056",
  "text" : "like the background on blog! nice post.. \"let them go\" @Skandhasattva",
  "id" : 34707437143597056,
  "created_at" : "2011-02-07 20:17:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Digital Bookmobile",
      "screen_name" : "DigiBookmobile",
      "indices" : [ 3, 18 ],
      "id_str" : "15476940",
      "id" : 15476940
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34692594004922368",
  "text" : "RT @DigiBookmobile: Now you can check The New York Times for your next good read: the paper will launch its eBook best sellers list onli ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ebooks",
        "indices" : [ 132, 139 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34691392949194753",
    "text" : "Now you can check The New York Times for your next good read: the paper will launch its eBook best sellers list online this Friday. #ebooks",
    "id" : 34691392949194753,
    "created_at" : "2011-02-07 19:14:07 +0000",
    "user" : {
      "name" : "Digital Bookmobile",
      "screen_name" : "DigiBookmobile",
      "protected" : false,
      "id_str" : "15476940",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/615892646628868100\/P7e8slku_normal.jpg",
      "id" : 15476940,
      "verified" : false
    }
  },
  "id" : 34692594004922368,
  "created_at" : "2011-02-07 19:18:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "People Pets",
      "screen_name" : "PEOPLEPets",
      "indices" : [ 3, 14 ],
      "id_str" : "22565066",
      "id" : 22565066
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34686757492498432",
  "text" : "RT @PEOPLEPets: Anybody got a cute pet photo they want to share? We're dying to see! Show us and make your pet a star. Tweet by 5ET and  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "cutepic",
        "indices" : [ 128, 136 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34682547006996480",
    "text" : "Anybody got a cute pet photo they want to share? We're dying to see! Show us and make your pet a star. Tweet by 5ET and mark it #cutepic",
    "id" : 34682547006996480,
    "created_at" : "2011-02-07 18:38:58 +0000",
    "user" : {
      "name" : "People Pets",
      "screen_name" : "PEOPLEPets",
      "protected" : false,
      "id_str" : "22565066",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/713022349474332672\/QwvQOaWJ_normal.jpg",
      "id" : 22565066,
      "verified" : true
    }
  },
  "id" : 34686757492498432,
  "created_at" : "2011-02-07 18:55:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Simon Wood",
      "screen_name" : "simonwoodwrites",
      "indices" : [ 26, 42 ],
      "id_str" : "30077179",
      "id" : 30077179
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34684152666128384",
  "geo" : { },
  "id_str" : "34684706498813952",
  "in_reply_to_user_id" : 30077179,
  "text" : "aww do you need a ((hug)) @simonwoodwrites",
  "id" : 34684706498813952,
  "in_reply_to_status_id" : 34684152666128384,
  "created_at" : "2011-02-07 18:47:33 +0000",
  "in_reply_to_screen_name" : "simonwoodwrites",
  "in_reply_to_user_id_str" : "30077179",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34684440034680832",
  "text" : "maybe by Spring my tummy will feel somewhat normal again? ugh",
  "id" : 34684440034680832,
  "created_at" : "2011-02-07 18:46:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "indices" : [ 3, 11 ],
      "id_str" : "15510821",
      "id" : 15510821
    }, {
      "name" : "McKenzies Trailswest",
      "screen_name" : "Mountain_Trails",
      "indices" : [ 72, 88 ],
      "id_str" : "81906665",
      "id" : 81906665
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "EOTD",
      "indices" : [ 89, 94 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 95, 104 ]
    }, {
      "text" : "Cline_River_AB",
      "indices" : [ 105, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34675509241585666",
  "text" : "RT @wildobs: In case you missed it: Moose http:\/\/wildobs.com\/wo\/8418 by @mountain_trails #EOTD #wildlife #Cline_River_AB 2 for breakfast.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/wildobs.com\" rel=\"nofollow\"\u003EWildObs\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "McKenzies Trailswest",
        "screen_name" : "Mountain_Trails",
        "indices" : [ 59, 75 ],
        "id_str" : "81906665",
        "id" : 81906665
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "EOTD",
        "indices" : [ 76, 81 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 82, 91 ]
      }, {
        "text" : "Cline_River_AB",
        "indices" : [ 92, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34674081710211073",
    "text" : "In case you missed it: Moose http:\/\/wildobs.com\/wo\/8418 by @mountain_trails #EOTD #wildlife #Cline_River_AB 2 for breakfast.",
    "id" : 34674081710211073,
    "created_at" : "2011-02-07 18:05:19 +0000",
    "user" : {
      "name" : "Adam Jack",
      "screen_name" : "wildobs",
      "protected" : false,
      "id_str" : "15510821",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1023771269\/2068d3cd-bdbd-44af-8287-93e4e3c76267_normal.png",
      "id" : 15510821,
      "verified" : false
    }
  },
  "id" : 34675509241585666,
  "created_at" : "2011-02-07 18:11:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 0, 16 ],
      "id_str" : "26547903",
      "id" : 26547903
    }, {
      "name" : "ReaganStar",
      "screen_name" : "StarShadowCo",
      "indices" : [ 17, 30 ],
      "id_str" : "111106130",
      "id" : 111106130
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34668776448331776",
  "geo" : { },
  "id_str" : "34674578848481280",
  "in_reply_to_user_id" : 26547903,
  "text" : "@SparklingReview @StarShadowCo had to look that up..and it looks good..added to my wishlist..lol",
  "id" : 34674578848481280,
  "in_reply_to_status_id" : 34668776448331776,
  "created_at" : "2011-02-07 18:07:18 +0000",
  "in_reply_to_screen_name" : "SparklingReview",
  "in_reply_to_user_id_str" : "26547903",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "indices" : [ 3, 16 ],
      "id_str" : "95730042",
      "id" : 95730042
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34671557552898049",
  "text" : "RT @GoblinWriter: 3 Amazon Marketing Tactics to Increase Book Visibility: http:\/\/bit.ly\/hm8n9I",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34671135719170048",
    "text" : "3 Amazon Marketing Tactics to Increase Book Visibility: http:\/\/bit.ly\/hm8n9I",
    "id" : 34671135719170048,
    "created_at" : "2011-02-07 17:53:37 +0000",
    "user" : {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "protected" : false,
      "id_str" : "95730042",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1558192985\/goblin-pic_normal.jpg",
      "id" : 95730042,
      "verified" : false
    }
  },
  "id" : 34671557552898049,
  "created_at" : "2011-02-07 17:55:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 7, 15 ],
      "id_str" : "123948351",
      "id" : 123948351
    }, {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 43, 56 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34670094726467585",
  "text" : "Thanks @BookYap for sending me Immortal by @GeneDoucette - I appreciate the gift & will give review when done!",
  "id" : 34670094726467585,
  "created_at" : "2011-02-07 17:49:29 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34665680615776256",
  "geo" : { },
  "id_str" : "34666817926594560",
  "in_reply_to_user_id" : 75708394,
  "text" : "@JulzMayBe im only familiar with touch. I wld think music ipods shldnt drain so fast... but I know touch & iphones notorious for short span",
  "id" : 34666817926594560,
  "in_reply_to_status_id" : 34665680615776256,
  "created_at" : "2011-02-07 17:36:28 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 3, 19 ],
      "id_str" : "26547903",
      "id" : 26547903
    }, {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 24, 40 ],
      "id_str" : "26547903",
      "id" : 26547903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34665926746054656",
  "text" : "RT @SparklingReview: RT @SparklingReview: Win a copy of All Just Glass ... ReTweet this Tweet! I will choose 3 winners in 10 minutes ... ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary",
        "screen_name" : "SparklingReview",
        "indices" : [ 3, 19 ],
        "id_str" : "26547903",
        "id" : 26547903
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34665124266512384",
    "text" : "RT @SparklingReview: Win a copy of All Just Glass ... ReTweet this Tweet! I will choose 3 winners in 10 minutes .... an E-book copy!",
    "id" : 34665124266512384,
    "created_at" : "2011-02-07 17:29:44 +0000",
    "user" : {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "protected" : false,
      "id_str" : "26547903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535442186964176897\/q9jfS0U4_normal.png",
      "id" : 26547903,
      "verified" : false
    }
  },
  "id" : 34665926746054656,
  "created_at" : "2011-02-07 17:32:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 34, 50 ],
      "id_str" : "26547903",
      "id" : 26547903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34662153587793920",
  "text" : "The Toy Cop by Robert Crawford RT @SparklingReview let me know what book you want to read next on your e-reader..",
  "id" : 34662153587793920,
  "created_at" : "2011-02-07 17:17:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34658212888186880",
  "geo" : { },
  "id_str" : "34659050578776064",
  "in_reply_to_user_id" : 75708394,
  "text" : "not sure if all ipods but ipod touch seems to drain quickly. using apps, games, vids takes more pwr than music @JulzMayBe",
  "id" : 34659050578776064,
  "in_reply_to_status_id" : 34658212888186880,
  "created_at" : "2011-02-07 17:05:36 +0000",
  "in_reply_to_screen_name" : "JulianneGarska",
  "in_reply_to_user_id_str" : "75708394",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 3, 19 ],
      "id_str" : "26547903",
      "id" : 26547903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34655668724178944",
  "text" : "RT @SparklingReview: Tell me what books you would like to read next on your Kindle or Nook and you just might win! I will pick 3 winners ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34619476360044544",
    "text" : "Tell me what books you would like to read next on your Kindle or Nook and you just might win! I will pick 3 winners this afternoon ...",
    "id" : 34619476360044544,
    "created_at" : "2011-02-07 14:28:21 +0000",
    "user" : {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "protected" : false,
      "id_str" : "26547903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535442186964176897\/q9jfS0U4_normal.png",
      "id" : 26547903,
      "verified" : false
    }
  },
  "id" : 34655668724178944,
  "created_at" : "2011-02-07 16:52:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 3, 19 ],
      "id_str" : "26547903",
      "id" : 26547903
    }, {
      "name" : "Kate",
      "screen_name" : "sithereandread",
      "indices" : [ 84, 99 ],
      "id_str" : "109130246",
      "id" : 109130246
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34655612616966144",
  "text" : "RT @SparklingReview: Hey guys... I am going to giveaway an E-book of Unearthly when @sithereandread reaches 800 followers! So go follow  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Kate",
        "screen_name" : "sithereandread",
        "indices" : [ 63, 78 ],
        "id_str" : "109130246",
        "id" : 109130246
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34606667182120960",
    "text" : "Hey guys... I am going to giveaway an E-book of Unearthly when @sithereandread reaches 800 followers! So go follow her! http:\/\/bit.ly\/eRgaMZ",
    "id" : 34606667182120960,
    "created_at" : "2011-02-07 13:37:27 +0000",
    "user" : {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "protected" : false,
      "id_str" : "26547903",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/535442186964176897\/q9jfS0U4_normal.png",
      "id" : 26547903,
      "verified" : false
    }
  },
  "id" : 34655612616966144,
  "created_at" : "2011-02-07 16:51:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34638776231796737",
  "text" : "Free Kindle book (limited time offer) - Three Sisters - New Cozy Mystery http:\/\/bit.ly\/ffgmSr",
  "id" : 34638776231796737,
  "created_at" : "2011-02-07 15:45:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 3, 16 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34628197924478976",
  "text" : "RT @golden_books: Got some new books on the kindle.  It's official, I'm addicted.  Now, I just need to find time to read them all!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34627746764161024",
    "text" : "Got some new books on the kindle.  It's official, I'm addicted.  Now, I just need to find time to read them all!",
    "id" : 34627746764161024,
    "created_at" : "2011-02-07 15:01:12 +0000",
    "user" : {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "protected" : false,
      "id_str" : "124594428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707724561714905089\/xr54lDFv_normal.jpg",
      "id" : 124594428,
      "verified" : false
    }
  },
  "id" : 34628197924478976,
  "created_at" : "2011-02-07 15:03:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34622777495519232",
  "text" : "one path or none? but why? why not individual paths? use bible as tool but see big picture.",
  "id" : 34622777495519232,
  "created_at" : "2011-02-07 14:41:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34622262694907904",
  "text" : "RT @ZachsMind: Each individual @jnathanmuller has their own religion, culled from whatever works for them personally, as if theology wer ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34620861893836801",
    "text" : "Each individual @jnathanmuller has their own religion, culled from whatever works for them personally, as if theology were a salad bar.",
    "id" : 34620861893836801,
    "created_at" : "2011-02-07 14:33:51 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 34622262694907904,
  "created_at" : "2011-02-07 14:39:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34622222089854976",
  "text" : "RT @ZachsMind: There's either only one path or there's none, so if Believers are all almost right, heaven will have only one person in i ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34621169432793088",
    "text" : "There's either only one path or there's none, so if Believers are all almost right, heaven will have only one person in it. Like a lottery.",
    "id" : 34621169432793088,
    "created_at" : "2011-02-07 14:35:04 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 34622222089854976,
  "created_at" : "2011-02-07 14:39:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34621689341939712",
  "text" : "@Skandhasattva ah but grasshopper UR wise. to admit mistakes & try again. all mistakes R lessons.",
  "id" : 34621689341939712,
  "created_at" : "2011-02-07 14:37:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34620577901711360",
  "text" : "@Skandhasattva maybe they r just not ready 4 yr wisdom..lol",
  "id" : 34620577901711360,
  "created_at" : "2011-02-07 14:32:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 0, 16 ],
      "id_str" : "26547903",
      "id" : 26547903
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34606306165792768",
  "geo" : { },
  "id_str" : "34610836680998912",
  "in_reply_to_user_id" : 26547903,
  "text" : "@SparklingReview maybe they are sending books out all at once after contest? hmm..",
  "id" : 34610836680998912,
  "in_reply_to_status_id" : 34606306165792768,
  "created_at" : "2011-02-07 13:54:01 +0000",
  "in_reply_to_screen_name" : "SparklingReview",
  "in_reply_to_user_id_str" : "26547903",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "mystery",
      "indices" : [ 0, 8 ]
    }, {
      "text" : "kindle",
      "indices" : [ 58, 65 ]
    }, {
      "text" : "nook",
      "indices" : [ 92, 97 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34605360694169600",
  "text" : "#mystery bestseller Disintegration by Scott Nicholson for #kindle http:\/\/amzn.to\/dBEesM and #nook http:\/\/bit.ly\/huQGD0 99 cents",
  "id" : 34605360694169600,
  "created_at" : "2011-02-07 13:32:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "indices" : [ 3, 15 ],
      "id_str" : "17266725",
      "id" : 17266725
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34604809537589248",
  "text" : "RT @tonyrobbins: Amazing how the mind works. 3,000 cows for footballs seems appalling because I picture the animals but I don'\u2026 (cont) h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34604469844967425",
    "text" : "Amazing how the mind works. 3,000 cows for footballs seems appalling because I picture the animals but I don'\u2026 (cont) http:\/\/deck.ly\/~3maEM",
    "id" : 34604469844967425,
    "created_at" : "2011-02-07 13:28:43 +0000",
    "user" : {
      "name" : "Tony Robbins",
      "screen_name" : "TonyRobbins",
      "protected" : false,
      "id_str" : "17266725",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/540248015571660800\/9qXSC-X9_normal.png",
      "id" : 17266725,
      "verified" : true
    }
  },
  "id" : 34604809537589248,
  "created_at" : "2011-02-07 13:30:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amwriting",
      "indices" : [ 73, 83 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34604131830202368",
  "text" : "RT @byoung210: A new week brings new challenges. Let's see what unfolds. #amwriting",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amwriting",
        "indices" : [ 58, 68 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34603816720539648",
    "text" : "A new week brings new challenges. Let's see what unfolds. #amwriting",
    "id" : 34603816720539648,
    "created_at" : "2011-02-07 13:26:07 +0000",
    "user" : {
      "name" : "Desmond Shepherd",
      "screen_name" : "DesShep",
      "protected" : false,
      "id_str" : "18219084",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783720692827164672\/aE_mtycf_normal.jpg",
      "id" : 18219084,
      "verified" : false
    }
  },
  "id" : 34604131830202368,
  "created_at" : "2011-02-07 13:27:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 5, 21 ],
      "id_str" : "26547903",
      "id" : 26547903
    }, {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 49, 57 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34063745881866240",
  "geo" : { },
  "id_str" : "34601100640260096",
  "in_reply_to_user_id" : 26547903,
  "text" : "Mary @SparklingReview Did you get your book from @BookYap yet? (Im afraid of missing email..lol)",
  "id" : 34601100640260096,
  "in_reply_to_status_id" : 34063745881866240,
  "created_at" : "2011-02-07 13:15:19 +0000",
  "in_reply_to_screen_name" : "SparklingReview",
  "in_reply_to_user_id_str" : "26547903",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "indices" : [ 3, 10 ],
      "id_str" : "12023102",
      "id" : 12023102
    }, {
      "name" : "Pat English",
      "screen_name" : "Squirrelbasket",
      "indices" : [ 30, 45 ],
      "id_str" : "40189152",
      "id" : 40189152
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "nature",
      "indices" : [ 112, 119 ]
    }, {
      "text" : "wildlife",
      "indices" : [ 120, 129 ]
    }, {
      "text" : "squirrels",
      "indices" : [ 130, 140 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34587221885456385",
  "text" : "RT @screek: This is great! RT @Squirrelbasket: Red squirrel's obsession with dog statue... http:\/\/bit.ly\/i68Vir #nature #wildlife #squirrels",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Pat English",
        "screen_name" : "Squirrelbasket",
        "indices" : [ 18, 33 ],
        "id_str" : "40189152",
        "id" : 40189152
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "nature",
        "indices" : [ 100, 107 ]
      }, {
        "text" : "wildlife",
        "indices" : [ 108, 117 ]
      }, {
        "text" : "squirrels",
        "indices" : [ 118, 128 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34582197910376448",
    "text" : "This is great! RT @Squirrelbasket: Red squirrel's obsession with dog statue... http:\/\/bit.ly\/i68Vir #nature #wildlife #squirrels",
    "id" : 34582197910376448,
    "created_at" : "2011-02-07 12:00:13 +0000",
    "user" : {
      "name" : "Steve Creek",
      "screen_name" : "screek",
      "protected" : false,
      "id_str" : "12023102",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/458928493888151552\/gIbKRJ1Y_normal.jpeg",
      "id" : 12023102,
      "verified" : false
    }
  },
  "id" : 34587221885456385,
  "created_at" : "2011-02-07 12:20:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34433437284700160",
  "text" : "See yourself as an actor playing a character. Describe that character to yourself.",
  "id" : 34433437284700160,
  "created_at" : "2011-02-07 02:09:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34433137635237888",
  "text" : "RT @ChrisGroove1: I can't help it. Imma rebel.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34431448190550016",
    "text" : "I can't help it. Imma rebel.",
    "id" : 34431448190550016,
    "created_at" : "2011-02-07 02:01:11 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 34433137635237888,
  "created_at" : "2011-02-07 02:07:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kick out",
      "screen_name" : "kickoutblog",
      "indices" : [ 3, 15 ],
      "id_str" : "3006879233",
      "id" : 3006879233
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "sb45",
      "indices" : [ 83, 88 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34430042050134016",
  "text" : "RT @kickoutblog: Fergie singing Sweet Child O' Mine... RIP Music: 40,000 BC - 2011 #sb45",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "sb45",
        "indices" : [ 66, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34419928161320960",
    "text" : "Fergie singing Sweet Child O' Mine... RIP Music: 40,000 BC - 2011 #sb45",
    "id" : 34419928161320960,
    "created_at" : "2011-02-07 01:15:25 +0000",
    "user" : {
      "name" : "Razor",
      "screen_name" : "SugaRazor",
      "protected" : false,
      "id_str" : "28519022",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/797135022616674304\/KxUaSRF-_normal.jpg",
      "id" : 28519022,
      "verified" : false
    }
  },
  "id" : 34430042050134016,
  "created_at" : "2011-02-07 01:55:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Eugene Mirman",
      "screen_name" : "EugeneMirman",
      "indices" : [ 3, 16 ],
      "id_str" : "16302651",
      "id" : 16302651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34421808446832640",
  "text" : "RT @EugeneMirman: I'm afraid if the Superbowl is being broadcast into space, aliens will interpret this Black Eyed Peas performance as a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34420085644861440",
    "text" : "I'm afraid if the Superbowl is being broadcast into space, aliens will interpret this Black Eyed Peas performance as an act of war.",
    "id" : 34420085644861440,
    "created_at" : "2011-02-07 01:16:02 +0000",
    "user" : {
      "name" : "Eugene Mirman",
      "screen_name" : "EugeneMirman",
      "protected" : false,
      "id_str" : "16302651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2845649245\/97c8846f6890bd3846d7e9294ba6476f_normal.png",
      "id" : 16302651,
      "verified" : true
    }
  },
  "id" : 34421808446832640,
  "created_at" : "2011-02-07 01:22:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Crissie Chambers",
      "screen_name" : "caninecultureuk",
      "indices" : [ 3, 19 ],
      "id_str" : "148382888",
      "id" : 148382888
    }, {
      "name" : "Petfinder",
      "screen_name" : "petfinder",
      "indices" : [ 59, 69 ],
      "id_str" : "14534060",
      "id" : 14534060
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Hedoesn",
      "indices" : [ 106, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34420356261351424",
  "text" : "RT @caninecultureuk: Adopt Phillip: Australian Shepherd on @Petfinder http:\/\/shar.es\/3rwO7#24Hours URGENT #Hedoesn'tDeserve to Die!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Petfinder",
        "screen_name" : "petfinder",
        "indices" : [ 38, 48 ],
        "id_str" : "14534060",
        "id" : 14534060
      } ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Hedoesn",
        "indices" : [ 85, 93 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34403819798396928",
    "text" : "Adopt Phillip: Australian Shepherd on @Petfinder http:\/\/shar.es\/3rwO7#24Hours URGENT #Hedoesn'tDeserve to Die!",
    "id" : 34403819798396928,
    "created_at" : "2011-02-07 00:11:24 +0000",
    "user" : {
      "name" : "Crissie Chambers",
      "screen_name" : "caninecultureuk",
      "protected" : false,
      "id_str" : "148382888",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737652227821711360\/lTLApxT0_normal.jpg",
      "id" : 148382888,
      "verified" : false
    }
  },
  "id" : 34420356261351424,
  "created_at" : "2011-02-07 01:17:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Mark Adair",
      "screen_name" : "markadairauthor",
      "indices" : [ 13, 29 ],
      "id_str" : "178469665",
      "id" : 178469665
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34302211261464576",
  "geo" : { },
  "id_str" : "34399144428699649",
  "in_reply_to_user_id" : 178469665,
  "text" : "Thx 4 RT : ) @markadairauthor",
  "id" : 34399144428699649,
  "in_reply_to_status_id" : 34302211261464576,
  "created_at" : "2011-02-06 23:52:49 +0000",
  "in_reply_to_screen_name" : "markadairauthor",
  "in_reply_to_user_id_str" : "178469665",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 0, 10 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34390836401815552",
  "geo" : { },
  "id_str" : "34398943194390528",
  "in_reply_to_user_id" : 56280847,
  "text" : "@DougDorow my MIL likes her pudding pies..lol.. and this one was particularly good. not too firm but not too mushy..and grahamcrackercrust",
  "id" : 34398943194390528,
  "in_reply_to_status_id" : 34390836401815552,
  "created_at" : "2011-02-06 23:52:01 +0000",
  "in_reply_to_screen_name" : "DougDorow",
  "in_reply_to_user_id_str" : "56280847",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34390374453608448",
  "text" : "so I was able to eat lasagna today along w butterscotch pie.. oh my belly.. still full.",
  "id" : 34390374453608448,
  "created_at" : "2011-02-06 23:17:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 3, 17 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34302658122612736",
  "text" : "RT @GaribaldiRous: People tried to wake me up but it is my nap time and I refuse.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34302281167929344",
    "text" : "People tried to wake me up but it is my nap time and I refuse.",
    "id" : 34302281167929344,
    "created_at" : "2011-02-06 17:27:55 +0000",
    "user" : {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "protected" : false,
      "id_str" : "244989679",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2506028052\/ysh8tqfrzpqosw1cbpw6_normal.jpeg",
      "id" : 244989679,
      "verified" : false
    }
  },
  "id" : 34302658122612736,
  "created_at" : "2011-02-06 17:29:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "samplesunday",
      "indices" : [ 33, 46 ]
    }, {
      "text" : "ss",
      "indices" : [ 47, 50 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34301835061755904",
  "text" : "http:\/\/ebooktweets.abfabgab.com\/ #samplesunday #ss",
  "id" : 34301835061755904,
  "created_at" : "2011-02-06 17:26:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "UK",
      "indices" : [ 78, 81 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34300962562768896",
  "text" : "RT @gemswinc: FREE PUPPIES.\n1\/2 Cocker Spaniel, 1\/2 sneaky neighbour's dog. ~ #UK classified ad",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "UK",
        "indices" : [ 64, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34299017223471104",
    "text" : "FREE PUPPIES.\n1\/2 Cocker Spaniel, 1\/2 sneaky neighbour's dog. ~ #UK classified ad",
    "id" : 34299017223471104,
    "created_at" : "2011-02-06 17:14:57 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 34300962562768896,
  "created_at" : "2011-02-06 17:22:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "supernatural",
      "indices" : [ 25, 38 ]
    }, {
      "text" : "ghost",
      "indices" : [ 43, 49 ]
    }, {
      "text" : "kindle",
      "indices" : [ 58, 65 ]
    }, {
      "text" : "nook",
      "indices" : [ 89, 94 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34294973448990720",
  "text" : "Ashes by Scott Nicholson:#supernatural and #ghost stories #kindle: http:\/\/amzn.to\/fSIEfS #nook: http:\/\/bit.ly\/htFLtx 99 cents",
  "id" : 34294973448990720,
  "created_at" : "2011-02-06 16:58:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34272149833252864",
  "text" : "hope stomach cooperates today. going 4 lasagna at MIL. then home so hubby can watch football.",
  "id" : 34272149833252864,
  "created_at" : "2011-02-06 15:28:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34271619694198784",
  "text" : "this cup o' coffee sucks...",
  "id" : 34271619694198784,
  "created_at" : "2011-02-06 15:26:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "mimi madeira",
      "screen_name" : "mimismutts",
      "indices" : [ 0, 11 ],
      "id_str" : "176864114",
      "id" : 176864114
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34091542889103360",
  "geo" : { },
  "id_str" : "34092116460314624",
  "in_reply_to_user_id" : 176864114,
  "text" : "@mimismutts yes. Ive only tweeted notes from books but I can access twitter and tweet.",
  "id" : 34092116460314624,
  "in_reply_to_status_id" : 34091542889103360,
  "created_at" : "2011-02-06 03:32:48 +0000",
  "in_reply_to_screen_name" : "mimismutts",
  "in_reply_to_user_id_str" : "176864114",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "indices" : [ 3, 16 ],
      "id_str" : "15120037",
      "id" : 15120037
    }, {
      "name" : "Catherine Connors",
      "screen_name" : "herbadmother",
      "indices" : [ 31, 44 ],
      "id_str" : "2643941",
      "id" : 2643941
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34090826233552896",
  "text" : "RT @AnissaMayhew: This post by @herbadmother is about prayers that dont \"work\" and petitionary prayers are a myth.  http:\/\/bit.ly\/hIyfys",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Catherine Connors",
        "screen_name" : "herbadmother",
        "indices" : [ 13, 26 ],
        "id_str" : "2643941",
        "id" : 2643941
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34089562347143168",
    "text" : "This post by @herbadmother is about prayers that dont \"work\" and petitionary prayers are a myth.  http:\/\/bit.ly\/hIyfys",
    "id" : 34089562347143168,
    "created_at" : "2011-02-06 03:22:39 +0000",
    "user" : {
      "name" : "Anissa Mayhew",
      "screen_name" : "AnissaMayhew",
      "protected" : false,
      "id_str" : "15120037",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3062161006\/ad2239750e205707bab7b90d1b5e5373_normal.jpeg",
      "id" : 15120037,
      "verified" : false
    }
  },
  "id" : 34090826233552896,
  "created_at" : "2011-02-06 03:27:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Counting Bankroll",
      "screen_name" : "hauntedcomputer",
      "indices" : [ 3, 19 ],
      "id_str" : "2553401966",
      "id" : 2553401966
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "books",
      "indices" : [ 116, 122 ]
    }, {
      "text" : "contest",
      "indices" : [ 123, 131 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34087924937003008",
  "text" : "RT @hauntedcomputer: Join Scott's Tweet Team and win Amazon or BN gift certificates this month http:\/\/bit.ly\/fB34KV #books #contest #kin ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "books",
        "indices" : [ 95, 101 ]
      }, {
        "text" : "contest",
        "indices" : [ 102, 110 ]
      }, {
        "text" : "kindle",
        "indices" : [ 111, 118 ]
      }, {
        "text" : "nook",
        "indices" : [ 119, 124 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33986761239568384",
    "text" : "Join Scott's Tweet Team and win Amazon or BN gift certificates this month http:\/\/bit.ly\/fB34KV #books #contest #kindle #nook",
    "id" : 33986761239568384,
    "created_at" : "2011-02-05 20:34:09 +0000",
    "user" : {
      "name" : "Scott Nicholson",
      "screen_name" : "eScottNicholson",
      "protected" : false,
      "id_str" : "20245651",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1135984922\/flyboymug_normal.JPG",
      "id" : 20245651,
      "verified" : false
    }
  },
  "id" : 34087924937003008,
  "created_at" : "2011-02-06 03:16:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "indices" : [ 3, 14 ],
      "id_str" : "18840386",
      "id" : 18840386
    }, {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 54, 68 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34083409865216001",
  "text" : "RT @CaplinROUS: Caplin has almost 4,000 followers and @GaribaldiRous has only 250. Are you not going to follow him?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Garibaldi Rous",
        "screen_name" : "GaribaldiRous",
        "indices" : [ 38, 52 ],
        "id_str" : "244989679",
        "id" : 244989679
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34082746208882688",
    "text" : "Caplin has almost 4,000 followers and @GaribaldiRous has only 250. Are you not going to follow him?",
    "id" : 34082746208882688,
    "created_at" : "2011-02-06 02:55:34 +0000",
    "user" : {
      "name" : "Caplin Rous",
      "screen_name" : "CaplinROUS",
      "protected" : false,
      "id_str" : "18840386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1220473492\/CaplinInHeavenByJimPerry_twitter_normal.png",
      "id" : 18840386,
      "verified" : false
    }
  },
  "id" : 34083409865216001,
  "created_at" : "2011-02-06 02:58:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Noor Al Hussein",
      "screen_name" : "QueenNoor",
      "indices" : [ 3, 13 ],
      "id_str" : "121887978",
      "id" : 121887978
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34077536849756160",
  "text" : "RT @QueenNoor: Just sent this beautiful image of young Christians  joining hands to protect Muslims at prayer in Cairo.  http:\/\/yfrog.co ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/#!\/download\/ipad\" rel=\"nofollow\"\u003ETwitter for iPad\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34076399253987328",
    "text" : "Just sent this beautiful image of young Christians  joining hands to protect Muslims at prayer in Cairo.  http:\/\/yfrog.com\/gy39692910j",
    "id" : 34076399253987328,
    "created_at" : "2011-02-06 02:30:21 +0000",
    "user" : {
      "name" : "Noor Al Hussein",
      "screen_name" : "QueenNoor",
      "protected" : false,
      "id_str" : "121887978",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1325463564\/image_normal.jpg",
      "id" : 121887978,
      "verified" : true
    }
  },
  "id" : 34077536849756160,
  "created_at" : "2011-02-06 02:34:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34076660945006592",
  "text" : "RT @SangyeH: @kpcmonk It's hard to keep a good tweeter down.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34065947274780673",
    "text" : "@kpcmonk It's hard to keep a good tweeter down.",
    "id" : 34065947274780673,
    "created_at" : "2011-02-06 01:48:49 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 34076660945006592,
  "created_at" : "2011-02-06 02:31:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Id vs Ego",
      "screen_name" : "Id_vs_Ego",
      "indices" : [ 0, 10 ],
      "id_str" : "3305720945",
      "id" : 3305720945
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34076322867183616",
  "text" : "@ID_vs_EGO jeepers that would take the fun out of life! : )",
  "id" : 34076322867183616,
  "created_at" : "2011-02-06 02:30:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fern Miller",
      "screen_name" : "Fernwise",
      "indices" : [ 0, 9 ],
      "id_str" : "23538653",
      "id" : 23538653
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "34071698319872000",
  "geo" : { },
  "id_str" : "34075893743751168",
  "in_reply_to_user_id" : 23538653,
  "text" : "@Fernwise heehee ; )",
  "id" : 34075893743751168,
  "in_reply_to_status_id" : 34071698319872000,
  "created_at" : "2011-02-06 02:28:20 +0000",
  "in_reply_to_screen_name" : "Fernwise",
  "in_reply_to_user_id_str" : "23538653",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34060443286769665",
  "text" : "@Tideliar your gal? aww ((hugs))",
  "id" : 34060443286769665,
  "created_at" : "2011-02-06 01:26:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 0, 8 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33722735825784832",
  "geo" : { },
  "id_str" : "34057131242037249",
  "in_reply_to_user_id" : 123948351,
  "text" : "@BookYap are u sending books out daily or at end of contest week?",
  "id" : 34057131242037249,
  "in_reply_to_status_id" : 33722735825784832,
  "created_at" : "2011-02-06 01:13:47 +0000",
  "in_reply_to_screen_name" : "BookYap",
  "in_reply_to_user_id_str" : "123948351",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Penny Sansevieri",
      "screen_name" : "Bookgal",
      "indices" : [ 3, 11 ],
      "id_str" : "2318161",
      "id" : 2318161
    }, {
      "name" : "Rajesh Settu",
      "screen_name" : "BookBuzzr",
      "indices" : [ 16, 26 ],
      "id_str" : "20586227",
      "id" : 20586227
    }, {
      "name" : "Phyllis Z. Miller",
      "screen_name" : "ZimblerMiller",
      "indices" : [ 43, 57 ],
      "id_str" : "14594968",
      "id" : 14594968
    }, {
      "name" : "Penny Sansevieri",
      "screen_name" : "Bookgal",
      "indices" : [ 58, 66 ],
      "id_str" : "2318161",
      "id" : 2318161
    }, {
      "name" : "Joel Friedlander",
      "screen_name" : "JFbookman",
      "indices" : [ 67, 77 ],
      "id_str" : "22296472",
      "id" : 22296472
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34050836346699778",
  "text" : "RT @Bookgal: RT @BookBuzzr: Join our panel @ZimblerMiller @BookGal @Jfbookman as they discuss Twitter Marketing for Authors 16th Feb htt ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Rajesh Settu",
        "screen_name" : "BookBuzzr",
        "indices" : [ 3, 13 ],
        "id_str" : "20586227",
        "id" : 20586227
      }, {
        "name" : "Phyllis Z. Miller",
        "screen_name" : "ZimblerMiller",
        "indices" : [ 30, 44 ],
        "id_str" : "14594968",
        "id" : 14594968
      }, {
        "name" : "Penny Sansevieri",
        "screen_name" : "Bookgal",
        "indices" : [ 45, 53 ],
        "id_str" : "2318161",
        "id" : 2318161
      }, {
        "name" : "Joel Friedlander",
        "screen_name" : "JFbookman",
        "indices" : [ 54, 64 ],
        "id_str" : "22296472",
        "id" : 22296472
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33521293491970048",
    "text" : "RT @BookBuzzr: Join our panel @ZimblerMiller @BookGal @Jfbookman as they discuss Twitter Marketing for Authors 16th Feb http:\/\/bit.ly\/f6jwx1",
    "id" : 33521293491970048,
    "created_at" : "2011-02-04 13:44:33 +0000",
    "user" : {
      "name" : "Penny Sansevieri",
      "screen_name" : "Bookgal",
      "protected" : false,
      "id_str" : "2318161",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000735778899\/2602ed67fb8d45db970aa8ffdcf7f0f8_normal.jpeg",
      "id" : 2318161,
      "verified" : false
    }
  },
  "id" : 34050836346699778,
  "created_at" : "2011-02-06 00:48:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34047093723107328",
  "text" : "@Skandhasattva no. if UR looking at ereaders check out: http:\/\/www.mobileread.com\/forums\/ but feel free to ask me questions : )",
  "id" : 34047093723107328,
  "created_at" : "2011-02-06 00:33:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34045783049371648",
  "text" : "RT @Wylieknowords: \"What was I thinking?\" usually ends up on Twitter.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "34045138976116737",
    "text" : "\"What was I thinking?\" usually ends up on Twitter.",
    "id" : 34045138976116737,
    "created_at" : "2011-02-06 00:26:08 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 34045783049371648,
  "created_at" : "2011-02-06 00:28:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "34045230323990528",
  "text" : "@Skandhasattva no, its not backlit. thats why battery lasts so long.",
  "id" : 34045230323990528,
  "created_at" : "2011-02-06 00:26:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Changes Subtly",
      "screen_name" : "JustLikeMercury",
      "indices" : [ 3, 19 ],
      "id_str" : "18774314",
      "id" : 18774314
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33974273894785025",
  "text" : "RT @JustlikeMercury: @theresaseeber no person needs to be \"broken\". They need to love you for all that you ARE, and all that you AREN'T.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33971405284446208",
    "text" : "@theresaseeber no person needs to be \"broken\". They need to love you for all that you ARE, and all that you AREN'T.",
    "id" : 33971405284446208,
    "created_at" : "2011-02-05 19:33:08 +0000",
    "user" : {
      "name" : "Changes Subtly",
      "screen_name" : "JustLikeMercury",
      "protected" : false,
      "id_str" : "18774314",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/546301137985736705\/sEscLlW5_normal.jpeg",
      "id" : 18774314,
      "verified" : false
    }
  },
  "id" : 33974273894785025,
  "created_at" : "2011-02-05 19:44:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 3, 13 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "StrangerGirl2",
      "screen_name" : "StrangerGirl2",
      "indices" : [ 39, 53 ],
      "id_str" : "24798779",
      "id" : 24798779
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33974076586336256",
  "text" : "RT @ZachsMind: However do keep in mind @StrangerGirl2 since you & I are NOT congenitally deaf, we can never truly grok where they're com ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "StrangerGirl2",
        "screen_name" : "StrangerGirl2",
        "indices" : [ 24, 38 ],
        "id_str" : "24798779",
        "id" : 24798779
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33973230335164416",
    "text" : "However do keep in mind @StrangerGirl2 since you & I are NOT congenitally deaf, we can never truly grok where they're coming from.",
    "id" : 33973230335164416,
    "created_at" : "2011-02-05 19:40:23 +0000",
    "user" : {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "protected" : false,
      "id_str" : "16181537",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/758474083465961472\/Btep-qKV_normal.jpg",
      "id" : 16181537,
      "verified" : false
    }
  },
  "id" : 33974076586336256,
  "created_at" : "2011-02-05 19:43:45 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 31, 38 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33968018266529792",
  "text" : "http:\/\/amzn.com\/k\/YUHUGRL2BXD1 #Kindle",
  "id" : 33968018266529792,
  "created_at" : "2011-02-05 19:19:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"https:\/\/kindle.amazon.com\" rel=\"nofollow\"\u003EKindle\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 32, 39 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33957846852837376",
  "text" : "http:\/\/amzn.com\/k\/22VM2HNFRCGBL #Kindle",
  "id" : 33957846852837376,
  "created_at" : "2011-02-05 18:39:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Receiving Prosperity",
      "screen_name" : "reformedbuddha",
      "indices" : [ 28, 43 ],
      "id_str" : "2169069864",
      "id" : 2169069864
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33946469434277888",
  "text" : "LOLOL RT @Skandhasattva: RT @ReformedBuddha: The internet has a place for everyone http:\/\/bit.ly\/hwNjeu \/ lol thats so true lol",
  "id" : 33946469434277888,
  "created_at" : "2011-02-05 17:54:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 3, 13 ],
      "id_str" : "56280847",
      "id" : 56280847
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "amediting",
      "indices" : [ 15, 25 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33945856474353664",
  "text" : "RT @DougDorow: #amediting to Def Leppard and drinking coffee. Can't stop my legs from shaking. Will I make 700 followers in Feb? Now at  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amediting",
        "indices" : [ 0, 10 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33944073421201408",
    "text" : "#amediting to Def Leppard and drinking coffee. Can't stop my legs from shaking. Will I make 700 followers in Feb? Now at 676.Help plz RT",
    "id" : 33944073421201408,
    "created_at" : "2011-02-05 17:44:32 +0000",
    "user" : {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "protected" : false,
      "id_str" : "56280847",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1740702673\/doug_dorow_profile_photo_normal.JPG",
      "id" : 56280847,
      "verified" : false
    }
  },
  "id" : 33945856474353664,
  "created_at" : "2011-02-05 17:51:37 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33937241197776896",
  "text" : "hubby has NO sense of time when it comes to females.. sigh.",
  "id" : 33937241197776896,
  "created_at" : "2011-02-05 17:17:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "indices" : [ 3, 12 ],
      "id_str" : "27094110",
      "id" : 27094110
    }, {
      "name" : "Byron Katie",
      "screen_name" : "ByronKatie",
      "indices" : [ 17, 28 ],
      "id_str" : "22733967",
      "id" : 22733967
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33936370078584832",
  "text" : "RT @JohnCali: RT @ByronKatie: Everyone in your life is a figment of your imagination--even you.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Byron Katie",
        "screen_name" : "ByronKatie",
        "indices" : [ 3, 14 ],
        "id_str" : "22733967",
        "id" : 22733967
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33936098174443521",
    "text" : "RT @ByronKatie: Everyone in your life is a figment of your imagination--even you.",
    "id" : 33936098174443521,
    "created_at" : "2011-02-05 17:12:50 +0000",
    "user" : {
      "name" : "John Cali",
      "screen_name" : "JohnCali",
      "protected" : false,
      "id_str" : "27094110",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/629479696\/JC_normal.JPG",
      "id" : 27094110,
      "verified" : false
    }
  },
  "id" : 33936370078584832,
  "created_at" : "2011-02-05 17:13:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33935140296069120",
  "text" : "RT @SangyeH: I'm sure I'm not the only one who doesn't understand how Mubarak can resign but still be president.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33934902500003841",
    "text" : "I'm sure I'm not the only one who doesn't understand how Mubarak can resign but still be president.",
    "id" : 33934902500003841,
    "created_at" : "2011-02-05 17:08:05 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 33935140296069120,
  "created_at" : "2011-02-05 17:09:02 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 15, 23 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadersWin",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33929408658145280",
  "text" : "#ReadersWin RT @BookYap: We're starting our Kindle book giveaway early today! Picking 3 winners- retweet and... (more) http:\/\/twtm.in\/lS9",
  "id" : 33929408658145280,
  "created_at" : "2011-02-05 16:46:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33924678103867392",
  "geo" : { },
  "id_str" : "33926221758730240",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 we moved around a bit. NJ,NY,CT,MA,ME,NY.",
  "id" : 33926221758730240,
  "in_reply_to_status_id" : 33924678103867392,
  "created_at" : "2011-02-05 16:33:36 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33924678103867392",
  "geo" : { },
  "id_str" : "33925851401682944",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 hehe..yes & no. we lived w drill in bckyrd 4 long time finding water. was english tudor house. was my least happiest time.",
  "id" : 33925851401682944,
  "in_reply_to_status_id" : 33924678103867392,
  "created_at" : "2011-02-05 16:32:07 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Garibaldi Rous",
      "screen_name" : "GaribaldiRous",
      "indices" : [ 12, 26 ],
      "id_str" : "244989679",
      "id" : 244989679
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33923951272923136",
  "text" : "@statue_dog @GaribaldiRous Absolutely agree! Just be you! \u2665",
  "id" : 33923951272923136,
  "created_at" : "2011-02-05 16:24:34 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Robin Walls",
      "screen_name" : "5x5",
      "indices" : [ 0, 4 ],
      "id_str" : "4752781",
      "id" : 4752781
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33922565541994496",
  "geo" : { },
  "id_str" : "33923398211993600",
  "in_reply_to_user_id" : 4752781,
  "text" : "@5x5 there used 2B a giant hill there.. there's no hill. we had long drive up 2 house. grasshpprs used 2 scare me walkng 2 house..lol",
  "id" : 33923398211993600,
  "in_reply_to_status_id" : 33922565541994496,
  "created_at" : "2011-02-05 16:22:23 +0000",
  "in_reply_to_screen_name" : "5x5",
  "in_reply_to_user_id_str" : "4752781",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "indices" : [ 3, 15 ],
      "id_str" : "17210956",
      "id" : 17210956
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33919317154201600",
  "text" : "RT @kempruffner: Wisdom?: You cannot tell which way the train went by looking at the track.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/tweetspinner.com\/\" rel=\"nofollow\"\u003ETweet Spinner\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33919042167250944",
    "text" : "Wisdom?: You cannot tell which way the train went by looking at the track.",
    "id" : 33919042167250944,
    "created_at" : "2011-02-05 16:05:04 +0000",
    "user" : {
      "name" : "kempruffner",
      "screen_name" : "kempruffner",
      "protected" : false,
      "id_str" : "17210956",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/63757772\/china_bike_normal.jpg",
      "id" : 17210956,
      "verified" : false
    }
  },
  "id" : 33919317154201600,
  "created_at" : "2011-02-05 16:06:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 3, 11 ],
      "id_str" : "123948351",
      "id" : 123948351
    }, {
      "name" : "Mary",
      "screen_name" : "SparklingReview",
      "indices" : [ 54, 70 ],
      "id_str" : "26547903",
      "id" : 26547903
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 71, 82 ],
      "id_str" : "93747129",
      "id" : 93747129
    }, {
      "name" : "Ap",
      "screen_name" : "cantonboyi",
      "indices" : [ 83, 94 ],
      "id_str" : "238754884",
      "id" : 238754884
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33918387218292737",
  "text" : "RT @BookYap: Congrats to today's Kindle book winners: @SparklingReview @moosebegab @cantonboyi (Check your DMs.) Tell your friends to jo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialkaty.com\" rel=\"nofollow\"\u003Esocialkaty\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Mary",
        "screen_name" : "SparklingReview",
        "indices" : [ 41, 57 ],
        "id_str" : "26547903",
        "id" : 26547903
      }, {
        "name" : "Gabrielle P Campbell",
        "screen_name" : "moosebegab",
        "indices" : [ 58, 69 ],
        "id_str" : "93747129",
        "id" : 93747129
      }, {
        "name" : "Ap",
        "screen_name" : "cantonboyi",
        "indices" : [ 70, 81 ],
        "id_str" : "238754884",
        "id" : 238754884
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33722735825784832",
    "text" : "Congrats to today's Kindle book winners: @SparklingReview @moosebegab @cantonboyi (Check your DMs.) Tell your friends to join in tomorrow!",
    "id" : 33722735825784832,
    "created_at" : "2011-02-05 03:05:01 +0000",
    "user" : {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "protected" : false,
      "id_str" : "123948351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083030490\/Bookyap1_normal.jpg",
      "id" : 123948351,
      "verified" : false
    }
  },
  "id" : 33918387218292737,
  "created_at" : "2011-02-05 16:02:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33917790389796865",
  "text" : "ok..looked up childhood home on google maps. think its gone. all houses gone. replaced w subdivision. weird...",
  "id" : 33917790389796865,
  "created_at" : "2011-02-05 16:00:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 4, 17 ],
      "id_str" : "123068593",
      "id" : 123068593
    }, {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 58, 66 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33917398696333312",
  "text" : "hey @GeneDoucette did u hear? I won yr book Immortal from @BookYap - yay! : )",
  "id" : 33917398696333312,
  "created_at" : "2011-02-05 15:58:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "egypt",
      "indices" : [ 4, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33913356670734336",
  "text" : "for #egypt My Chemical Romance - S.I.N.G http:\/\/bit.ly\/hdPrdI",
  "id" : 33913356670734336,
  "created_at" : "2011-02-05 15:42:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    }, {
      "name" : "Gabrielle P Campbell",
      "screen_name" : "moosebegab",
      "indices" : [ 59, 70 ],
      "id_str" : "93747129",
      "id" : 93747129
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33720468884168704",
  "text" : "RT @TrishScott: They really need a better comic routine RT @moosebegab: Catholic Church Issues Guide on How to... (more) http:\/\/twtm.in\/lSl",
  "id" : 33720468884168704,
  "created_at" : "2011-02-05 02:56:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33719623375396865",
  "text" : "RT @PortalChronicle: FAUSTINE bookmarks are here! If you would like one, please email your address to PortalChronicles@hotmail.com and I ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33706078969528320",
    "text" : "FAUSTINE bookmarks are here! If you would like one, please email your address to PortalChronicles@hotmail.com and I'll send a signed one out",
    "id" : 33706078969528320,
    "created_at" : "2011-02-05 01:58:50 +0000",
    "user" : {
      "name" : "IMOGEN ROSE",
      "screen_name" : "ImogenRoseTweet",
      "protected" : false,
      "id_str" : "102568232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1265710799\/profile1_normal.jpg",
      "id" : 102568232,
      "verified" : false
    }
  },
  "id" : 33719623375396865,
  "created_at" : "2011-02-05 02:52:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "indices" : [ 3, 10 ],
      "id_str" : "99531497",
      "id" : 99531497
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33718710925529089",
  "text" : "RT @hvspca: Nobody has stepped up to foster Coco our senior dog. pls cross post her plight http:\/\/wp.me\/pLcDB-c6",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/publicize.wp.com\/\" rel=\"nofollow\"\u003EWordPress.com\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33711199392632832",
    "text" : "Nobody has stepped up to foster Coco our senior dog. pls cross post her plight http:\/\/wp.me\/pLcDB-c6",
    "id" : 33711199392632832,
    "created_at" : "2011-02-05 02:19:10 +0000",
    "user" : {
      "name" : "Hudson Valley SPCA",
      "screen_name" : "hvspca",
      "protected" : false,
      "id_str" : "99531497",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/638069419164454913\/KeccRrpI_normal.jpg",
      "id" : 99531497,
      "verified" : false
    }
  },
  "id" : 33718710925529089,
  "created_at" : "2011-02-05 02:49:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33705514739179520",
  "text" : "Catholic Church Issues Guide on How to Convert Witches http:\/\/aol.it\/hywApC",
  "id" : 33705514739179520,
  "created_at" : "2011-02-05 01:56:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "indices" : [ 3, 11 ],
      "id_str" : "15628274",
      "id" : 15628274
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "health",
      "indices" : [ 131, 138 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33696275534852096",
  "text" : "RT @drbloem: Exclusive Interview with Billy Best, Who Fled Chemotherapy at Age 16 and Beat Hodgkin's Lymphoma http:\/\/bit.ly\/4o01h3 #health",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ajaymatharu.com\/\" rel=\"nofollow\"\u003ETweet Old Post\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "health",
        "indices" : [ 118, 125 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33694803963158528",
    "text" : "Exclusive Interview with Billy Best, Who Fled Chemotherapy at Age 16 and Beat Hodgkin's Lymphoma http:\/\/bit.ly\/4o01h3 #health",
    "id" : 33694803963158528,
    "created_at" : "2011-02-05 01:14:01 +0000",
    "user" : {
      "name" : "Fred Bloem MD",
      "screen_name" : "drbloem",
      "protected" : false,
      "id_str" : "15628274",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/3447424965\/e1c44518208af09e5bc9b1caf0340be9_normal.jpeg",
      "id" : 15628274,
      "verified" : false
    }
  },
  "id" : 33696275534852096,
  "created_at" : "2011-02-05 01:19:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33695657566932994",
  "text" : "YouTube - Sydney the Smiling Australian Shepherd http:\/\/bit.ly\/id1l8s",
  "id" : 33695657566932994,
  "created_at" : "2011-02-05 01:17:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33632873156190208",
  "text" : "RT @PortalChronicle: The delivery man who just dropped of a bookcase for me, asked me for a signed copy of PORTAL :)",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33632094198431744",
    "text" : "The delivery man who just dropped of a bookcase for me, asked me for a signed copy of PORTAL :)",
    "id" : 33632094198431744,
    "created_at" : "2011-02-04 21:04:50 +0000",
    "user" : {
      "name" : "IMOGEN ROSE",
      "screen_name" : "ImogenRoseTweet",
      "protected" : false,
      "id_str" : "102568232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1265710799\/profile1_normal.jpg",
      "id" : 102568232,
      "verified" : false
    }
  },
  "id" : 33632873156190208,
  "created_at" : "2011-02-04 21:07:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 24, 37 ],
      "id_str" : "123068593",
      "id" : 123068593
    }, {
      "name" : "Douglas Dorow",
      "screen_name" : "DougDorow",
      "indices" : [ 51, 61 ],
      "id_str" : "56280847",
      "id" : 56280847
    }, {
      "name" : "Untreed Reads",
      "screen_name" : "UntreedReads",
      "indices" : [ 62, 75 ],
      "id_str" : "14222033",
      "id" : 14222033
    }, {
      "name" : "Susan Bischoff",
      "screen_name" : "susan_bischoff",
      "indices" : [ 76, 91 ],
      "id_str" : "19793768",
      "id" : 19793768
    }, {
      "name" : "Simon Royle",
      "screen_name" : "sgroyle",
      "indices" : [ 92, 100 ],
      "id_str" : "181103297",
      "id" : 181103297
    }, {
      "name" : "Books OnTheKnob",
      "screen_name" : "BooksOnTheKnob",
      "indices" : [ 101, 116 ],
      "id_str" : "29451040",
      "id" : 29451040
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    }, {
      "text" : "ebooks",
      "indices" : [ 4, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33630757851234304",
  "text" : "#FF #ebooks @ReadersWin @GeneDoucette @bookhound78 @DougDorow @UntreedReads @susan_bischoff @sgroyle @BooksOnTheKnob @byoung210",
  "id" : 33630757851234304,
  "created_at" : "2011-02-04 20:59:32 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 26, 34 ],
      "id_str" : "54744689",
      "id" : 54744689
    }, {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 35, 42 ],
      "id_str" : "122393631",
      "id" : 122393631
    }, {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 59, 73 ],
      "id_str" : "28863804",
      "id" : 28863804
    }, {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 74, 89 ],
      "id_str" : "62867227",
      "id" : 62867227
    }, {
      "name" : "Jonathan Elliot",
      "screen_name" : "JonathanElliot",
      "indices" : [ 105, 120 ],
      "id_str" : "30825946",
      "id" : 30825946
    }, {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 121, 134 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "FF",
      "indices" : [ 0, 3 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33629549895880704",
  "text" : "#FF Ppl who think & care  @SangyeH @SsmDad @InfantileAdult @Wylieknowords @thesexyatheist @Skandhasattva @JonathanElliot @derekrootboy",
  "id" : 33629549895880704,
  "created_at" : "2011-02-04 20:54:44 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jon gery",
      "screen_name" : "jongery",
      "indices" : [ 0, 8 ],
      "id_str" : "41209211",
      "id" : 41209211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33624024546283520",
  "geo" : { },
  "id_str" : "33627260380512256",
  "in_reply_to_user_id" : 41209211,
  "text" : "@jongery yes, I was confuzzled by yr reply but its ok : )",
  "id" : 33627260380512256,
  "in_reply_to_status_id" : 33624024546283520,
  "created_at" : "2011-02-04 20:45:38 +0000",
  "in_reply_to_screen_name" : "jongery",
  "in_reply_to_user_id_str" : "41209211",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jean Koch",
      "screen_name" : "whatskochin",
      "indices" : [ 3, 15 ],
      "id_str" : "39165806",
      "id" : 39165806
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33626395527757824",
  "text" : "RT @whatskochin: We Are All Egyptians - http:\/\/nyti.ms\/h69lUA",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/timespeople.nytimes.com\" rel=\"nofollow\"\u003ETimesPeople\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33589131338588160",
    "text" : "We Are All Egyptians - http:\/\/nyti.ms\/h69lUA",
    "id" : 33589131338588160,
    "created_at" : "2011-02-04 18:14:07 +0000",
    "user" : {
      "name" : "Jean Koch",
      "screen_name" : "whatskochin",
      "protected" : false,
      "id_str" : "39165806",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2732126209\/64e306a77c4dc71c2285dcd49904defc_normal.jpeg",
      "id" : 39165806,
      "verified" : false
    }
  },
  "id" : 33626395527757824,
  "created_at" : "2011-02-04 20:42:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33619864702689280",
  "text" : "ok virus, you've had a week. time to go now!",
  "id" : 33619864702689280,
  "created_at" : "2011-02-04 20:16:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 3, 11 ],
      "id_str" : "123948351",
      "id" : 123948351
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 13, 20 ]
    }, {
      "text" : "bookyap",
      "indices" : [ 111, 119 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33618032966242304",
  "text" : "RT @BookYap: #Kindle book giveaway starting NOW! What do you want to read next? Retweet this and win it TODAY! #bookyap",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.socialkaty.com\" rel=\"nofollow\"\u003Esocialkaty\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Kindle",
        "indices" : [ 0, 7 ]
      }, {
        "text" : "bookyap",
        "indices" : [ 98, 106 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33617013762957313",
    "text" : "#Kindle book giveaway starting NOW! What do you want to read next? Retweet this and win it TODAY! #bookyap",
    "id" : 33617013762957313,
    "created_at" : "2011-02-04 20:04:55 +0000",
    "user" : {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "protected" : false,
      "id_str" : "123948351",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1083030490\/Bookyap1_normal.jpg",
      "id" : 123948351,
      "verified" : false
    }
  },
  "id" : 33618032966242304,
  "created_at" : "2011-02-04 20:08:58 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "jon gery",
      "screen_name" : "jongery",
      "indices" : [ 0, 8 ],
      "id_str" : "41209211",
      "id" : 41209211
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33601152746520577",
  "geo" : { },
  "id_str" : "33609737689894912",
  "in_reply_to_user_id" : 41209211,
  "text" : "@jongery I overheard ppl discussing it saying \"why R the Egypt ppl upset now after he's been ruling 30 yrs\"",
  "id" : 33609737689894912,
  "in_reply_to_status_id" : 33601152746520577,
  "created_at" : "2011-02-04 19:36:00 +0000",
  "in_reply_to_screen_name" : "jongery",
  "in_reply_to_user_id_str" : "41209211",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 29, 37 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33601059490365440",
  "geo" : { },
  "id_str" : "33609449809645568",
  "in_reply_to_user_id" : 54744689,
  "text" : "thats what Im wondering..lol @SangyeH",
  "id" : 33609449809645568,
  "in_reply_to_status_id" : 33601059490365440,
  "created_at" : "2011-02-04 19:34:51 +0000",
  "in_reply_to_screen_name" : "SangyeH",
  "in_reply_to_user_id_str" : "54744689",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 6, 14 ],
      "id_str" : "123948351",
      "id" : 123948351
    }, {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 106, 119 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33609097861537792",
  "text" : "\u201CTell @BookYap the next Kindle book you want to read for a chance to win that book for free!\" Immortal by @GeneDoucette",
  "id" : 33609097861537792,
  "created_at" : "2011-02-04 19:33:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 31, 44 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33604697092788224",
  "geo" : { },
  "id_str" : "33607987952222208",
  "in_reply_to_user_id" : 123068593,
  "text" : "liar, liar..hehe (1 or 2X) ; ) @GeneDoucette",
  "id" : 33607987952222208,
  "in_reply_to_status_id" : 33604697092788224,
  "created_at" : "2011-02-04 19:29:03 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "indices" : [ 3, 16 ],
      "id_str" : "84249568",
      "id" : 84249568
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33600717767966720",
  "text" : "RT @AmazonKindle: Share and discuss the books you love: Now you can easily add Amazon purchases to your Shelfari bookshelf. http:\/\/bit.l ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33598460200488960",
    "text" : "Share and discuss the books you love: Now you can easily add Amazon purchases to your Shelfari bookshelf. http:\/\/bit.ly\/eQalSt",
    "id" : 33598460200488960,
    "created_at" : "2011-02-04 18:51:11 +0000",
    "user" : {
      "name" : "Kindle",
      "screen_name" : "AmazonKindle",
      "protected" : false,
      "id_str" : "84249568",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/512411639908298752\/z8wZ_AlQ_normal.jpeg",
      "id" : 84249568,
      "verified" : true
    }
  },
  "id" : 33600717767966720,
  "created_at" : "2011-02-04 19:00:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33600447663181824",
  "text" : "went past a \"forensic psychiatric center\" today.. hmm..",
  "id" : 33600447663181824,
  "created_at" : "2011-02-04 18:59:05 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33599243209936896",
  "text" : "NoTreesHarmed.com  http:\/\/on.fb.me\/haqIbP looking 4 some great ebooks 2 post 4 remaining weeks of Feb. All fees waived until 2\/28!",
  "id" : 33599243209936896,
  "created_at" : "2011-02-04 18:54:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 36, 42 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33598161285021696",
  "text" : "Ppl not on twitter don't understand #Egypt situation",
  "id" : 33598161285021696,
  "created_at" : "2011-02-04 18:50:00 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Teel McClanahan III",
      "screen_name" : "modernevil",
      "indices" : [ 57, 68 ],
      "id_str" : "7482152",
      "id" : 7482152
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33525461275385857",
  "geo" : { },
  "id_str" : "33526465484029953",
  "in_reply_to_user_id" : 7482152,
  "text" : "UR such a good hubby .. except 4 the shipping part..hehe @modernevil",
  "id" : 33526465484029953,
  "in_reply_to_status_id" : 33525461275385857,
  "created_at" : "2011-02-04 14:05:06 +0000",
  "in_reply_to_screen_name" : "modernevil",
  "in_reply_to_user_id_str" : "7482152",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33364247106813952",
  "text" : "RT @Wylieknowords: \"Poetry is making love with a dictionary.\"  N. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33353640794132480",
    "text" : "\"Poetry is making love with a dictionary.\"  N. Wylie Jones www.knowords.com",
    "id" : 33353640794132480,
    "created_at" : "2011-02-04 02:38:22 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 33364247106813952,
  "created_at" : "2011-02-04 03:20:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "indices" : [ 3, 16 ],
      "id_str" : "7350962",
      "id" : 7350962
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33363080385662976",
  "text" : "RT @earthXplorer: Teachers are so unappreciated... RT to spread the love to all the great teachers out there!!! Thank You!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33361114590875648",
    "text" : "Teachers are so unappreciated... RT to spread the love to all the great teachers out there!!! Thank You!!",
    "id" : 33361114590875648,
    "created_at" : "2011-02-04 03:08:04 +0000",
    "user" : {
      "name" : "JD ANDREWS",
      "screen_name" : "earthXplorer",
      "protected" : false,
      "id_str" : "7350962",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/723866940192657408\/PPgb3V3O_normal.jpg",
      "id" : 7350962,
      "verified" : true
    }
  },
  "id" : 33363080385662976,
  "created_at" : "2011-02-04 03:15:52 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Mansfield Keefe",
      "screen_name" : "thrillerXpert",
      "indices" : [ 3, 17 ],
      "id_str" : "203583284",
      "id" : 203583284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33310577904328705",
  "text" : "RT @thrillerXpert: @BestsellerBound, for the Indie book lover http:\/\/wmqdg.th8.us #indie #writer #book #novel #bookclub",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indie",
        "indices" : [ 63, 69 ]
      }, {
        "text" : "writer",
        "indices" : [ 70, 77 ]
      }, {
        "text" : "book",
        "indices" : [ 78, 83 ]
      }, {
        "text" : "novel",
        "indices" : [ 84, 90 ]
      }, {
        "text" : "bookclub",
        "indices" : [ 91, 100 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33308149800898560",
    "text" : "@BestsellerBound, for the Indie book lover http:\/\/wmqdg.th8.us #indie #writer #book #novel #bookclub",
    "id" : 33308149800898560,
    "created_at" : "2011-02-03 23:37:36 +0000",
    "user" : {
      "name" : "Paul Mansfield Keefe",
      "screen_name" : "thrillerXpert",
      "protected" : false,
      "id_str" : "203583284",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1194498590\/paul_m_keefe_normal.jpg",
      "id" : 203583284,
      "verified" : false
    }
  },
  "id" : 33310577904328705,
  "created_at" : "2011-02-03 23:47:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Moonrust\u2122 \uE443",
      "screen_name" : "Moonrust",
      "indices" : [ 0, 9 ],
      "id_str" : "15396585",
      "id" : 15396585
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33302296737611776",
  "geo" : { },
  "id_str" : "33303225377497088",
  "in_reply_to_user_id" : 15396585,
  "text" : "@Moonrust sending ((hugs)) your way",
  "id" : 33303225377497088,
  "in_reply_to_status_id" : 33302296737611776,
  "created_at" : "2011-02-03 23:18:02 +0000",
  "in_reply_to_screen_name" : "Moonrust",
  "in_reply_to_user_id_str" : "15396585",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "BookYap",
      "screen_name" : "BookYap",
      "indices" : [ 6, 14 ],
      "id_str" : "123948351",
      "id" : 123948351
    }, {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 106, 119 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33295589315837952",
  "text" : "\u201CTell @BookYap the next Kindle book you want to read for a chance to win that book for free!\" Immortal by @GeneDoucette",
  "id" : 33295589315837952,
  "created_at" : "2011-02-03 22:47:41 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33294838313000961",
  "text" : "@Skandhasattva not again.. you just got better! : ( How's Jen feeling?",
  "id" : 33294838313000961,
  "created_at" : "2011-02-03 22:44:42 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33268626236637184",
  "geo" : { },
  "id_str" : "33273954898542593",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott hubby sends me these things.. he likes funny stuff. usually I dont watch & he gets mad..lol",
  "id" : 33273954898542593,
  "in_reply_to_status_id" : 33268626236637184,
  "created_at" : "2011-02-03 21:21:43 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordpress",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33272708913434625",
  "text" : "#wordpress peeps.. is there a way 2 list archive year\/month\/post in sidebar under archives? like blogspot does?",
  "id" : 33272708913434625,
  "created_at" : "2011-02-03 21:16:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Karma Tashi",
      "screen_name" : "KTynot",
      "indices" : [ 38, 45 ],
      "id_str" : "79498350",
      "id" : 79498350
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33222412208185344",
  "geo" : { },
  "id_str" : "33241665707708416",
  "in_reply_to_user_id" : 79498350,
  "text" : "TY. I appreciate prayers : ) ((hugs)) @KTynot",
  "id" : 33241665707708416,
  "in_reply_to_status_id" : 33222412208185344,
  "created_at" : "2011-02-03 19:13:25 +0000",
  "in_reply_to_screen_name" : "KTynot",
  "in_reply_to_user_id_str" : "79498350",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy Brooks",
      "screen_name" : "dontlikeclowns",
      "indices" : [ 3, 18 ],
      "id_str" : "48594965",
      "id" : 48594965
    }, {
      "name" : "\uD83D\uDD25apocalypse heart\uD83D\uDD25",
      "screen_name" : "pauljessup",
      "indices" : [ 50, 61 ],
      "id_str" : "14079203",
      "id" : 14079203
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33240964105646080",
  "text" : "RT @dontlikeclowns: Uses rare, imported bytes. RT @pauljessup: WTF???? Why is Angela Carter's Night at the Circus almost $40 for an eboo ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\uD83D\uDD25apocalypse heart\uD83D\uDD25",
        "screen_name" : "pauljessup",
        "indices" : [ 30, 41 ],
        "id_str" : "14079203",
        "id" : 14079203
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33240365532327936",
    "text" : "Uses rare, imported bytes. RT @pauljessup: WTF???? Why is Angela Carter's Night at the Circus almost $40 for an ebook? http:\/\/trunc.it\/e9put",
    "id" : 33240365532327936,
    "created_at" : "2011-02-03 19:08:15 +0000",
    "user" : {
      "name" : "Jeremy Brooks",
      "screen_name" : "dontlikeclowns",
      "protected" : false,
      "id_str" : "48594965",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1335825516\/outside_henderson_normal.jpg",
      "id" : 48594965,
      "verified" : false
    }
  },
  "id" : 33240964105646080,
  "created_at" : "2011-02-03 19:10:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33235920324919296",
  "text" : "RT @Wylieknowords: HUG A REPORTER TODAY: How would you like to be in that square in Egypt with your only weapon a camera? A soldier for  ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33234065083596800",
    "text" : "HUG A REPORTER TODAY: How would you like to be in that square in Egypt with your only weapon a camera? A soldier for us with no gun.",
    "id" : 33234065083596800,
    "created_at" : "2011-02-03 18:43:13 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 33235920324919296,
  "created_at" : "2011-02-03 18:50:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "indices" : [ 3, 18 ],
      "id_str" : "62867227",
      "id" : 62867227
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33235057988599808",
  "text" : "RT @thesexyatheist: Nothing says 12 year old valentines day innocence like candy that says http:\/\/gaw.kr\/h0JOqu nice t*ts, right?",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33229925662064640",
    "text" : "Nothing says 12 year old valentines day innocence like candy that says http:\/\/gaw.kr\/h0JOqu nice t*ts, right?",
    "id" : 33229925662064640,
    "created_at" : "2011-02-03 18:26:46 +0000",
    "user" : {
      "name" : "krissthesexyatheist",
      "screen_name" : "thesexyatheist",
      "protected" : false,
      "id_str" : "62867227",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/513796319840718848\/8S85UpD1_normal.jpeg",
      "id" : 62867227,
      "verified" : false
    }
  },
  "id" : 33235057988599808,
  "created_at" : "2011-02-03 18:47:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "indices" : [ 3, 19 ],
      "id_str" : "41377983",
      "id" : 41377983
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33225060592521216",
  "text" : "RT @emperorsclothes: Farmer with axe chases ketchup-smeared financee to scare littering teenagers http:\/\/bit.ly\/hbyTOd via Daily Mail",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33224656374730752",
    "text" : "Farmer with axe chases ketchup-smeared financee to scare littering teenagers http:\/\/bit.ly\/hbyTOd via Daily Mail",
    "id" : 33224656374730752,
    "created_at" : "2011-02-03 18:05:50 +0000",
    "user" : {
      "name" : "Helen Smith",
      "screen_name" : "emperorsclothes",
      "protected" : false,
      "id_str" : "41377983",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/451424284636745728\/EOavGMYP_normal.jpeg",
      "id" : 41377983,
      "verified" : true
    }
  },
  "id" : 33225060592521216,
  "created_at" : "2011-02-03 18:07:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 3, 16 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33223657916465152",
  "text" : "RT @ChrisGroove1: The carwash got too cold an broke today. http:\/\/twitpic.com\/3w5iiw",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33223202553470976",
    "text" : "The carwash got too cold an broke today. http:\/\/twitpic.com\/3w5iiw",
    "id" : 33223202553470976,
    "created_at" : "2011-02-03 18:00:03 +0000",
    "user" : {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "protected" : false,
      "id_str" : "68905287",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/737261437182038016\/wJaRybb0_normal.jpg",
      "id" : 68905287,
      "verified" : false
    }
  },
  "id" : 33223657916465152,
  "created_at" : "2011-02-03 18:01:51 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33222811631751168",
  "geo" : { },
  "id_str" : "33223401334112257",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad how's yr pneumonia doing? (from last week, I believe?)",
  "id" : 33223401334112257,
  "in_reply_to_status_id" : 33222811631751168,
  "created_at" : "2011-02-03 18:00:50 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 100, 107 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33221455076392960",
  "geo" : { },
  "id_str" : "33222871119568896",
  "in_reply_to_user_id" : 122393631,
  "text" : "I'm keeping a sick diary now 2 document my illnesses. Seems like I get virus every 6-8 wks or so... @SsmDad",
  "id" : 33222871119568896,
  "in_reply_to_status_id" : 33221455076392960,
  "created_at" : "2011-02-03 17:58:44 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Chris",
      "screen_name" : "SsmDad",
      "indices" : [ 0, 7 ],
      "id_str" : "122393631",
      "id" : 122393631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33221455076392960",
  "geo" : { },
  "id_str" : "33222443753541632",
  "in_reply_to_user_id" : 122393631,
  "text" : "@SsmDad yeah, was sick 2 wks ago & hit me again on Mon. This time little\/no nausea thankfully!",
  "id" : 33222443753541632,
  "in_reply_to_status_id" : 33221455076392960,
  "created_at" : "2011-02-03 17:57:02 +0000",
  "in_reply_to_screen_name" : "SsmDad",
  "in_reply_to_user_id_str" : "122393631",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "ZachsMind",
      "screen_name" : "ZachsMind",
      "indices" : [ 9, 19 ],
      "id_str" : "16181537",
      "id" : 16181537
    }, {
      "name" : "Cynthia Kelly",
      "screen_name" : "CynthiaY29",
      "indices" : [ 39, 50 ],
      "id_str" : "18536530",
      "id" : 18536530
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33221944430174208",
  "text" : "Cute! RT @ZachsMind: THIS IS SO ME! RT @CynthiaY29: I have come from the INTERNET http:\/\/i.imgur.com\/qePef.jpg",
  "id" : 33221944430174208,
  "created_at" : "2011-02-03 17:55:03 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 3, 16 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33220741109387264",
  "text" : "RT @golden_books: \"Ask yourself this question:\n\"Will this matter a year from now?\"\nRichard Carlson",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33218780293234688",
    "text" : "\"Ask yourself this question:\n\"Will this matter a year from now?\"\nRichard Carlson",
    "id" : 33218780293234688,
    "created_at" : "2011-02-03 17:42:29 +0000",
    "user" : {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "protected" : false,
      "id_str" : "124594428",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/707724561714905089\/xr54lDFv_normal.jpg",
      "id" : 124594428,
      "verified" : false
    }
  },
  "id" : 33220741109387264,
  "created_at" : "2011-02-03 17:50:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33220494819856384",
  "text" : "Next Testing I'll be doing my Brown form plus one other. So much to remember! Will I be able to do it?? Stay tuned! lol",
  "id" : 33220494819856384,
  "created_at" : "2011-02-03 17:49:17 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33220464310493184",
  "text" : "still got virus hanging in there.. hopefully, wont interfere with TKD tonight.",
  "id" : 33220464310493184,
  "created_at" : "2011-02-03 17:49:10 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 0, 11 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33209434029162496",
  "geo" : { },
  "id_str" : "33213680770359296",
  "in_reply_to_user_id" : 34258680,
  "text" : "@WestofMars i like: enter sandman, the unforgiven, sad but true, nothing else matters",
  "id" : 33213680770359296,
  "in_reply_to_status_id" : 33209434029162496,
  "created_at" : "2011-02-03 17:22:13 +0000",
  "in_reply_to_screen_name" : "WestofMars",
  "in_reply_to_user_id_str" : "34258680",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 0, 11 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33209434029162496",
  "geo" : { },
  "id_str" : "33212845743149056",
  "in_reply_to_user_id" : 34258680,
  "text" : "@WestofMars apprntly I lied..hmm..must have been thinking of old mp3 player.. I swear I had songs on there..",
  "id" : 33212845743149056,
  "in_reply_to_status_id" : 33209434029162496,
  "created_at" : "2011-02-03 17:18:54 +0000",
  "in_reply_to_screen_name" : "WestofMars",
  "in_reply_to_user_id_str" : "34258680",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadersWin",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33209938276777985",
  "text" : "#ReadersWin RT @thecrowscaw: 38 more followers to go and 3 peeps get an ebook form 1 of the following:... (more) http:\/\/twtm.in\/lcx",
  "id" : 33209938276777985,
  "created_at" : "2011-02-03 17:07:20 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 3, 14 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "smashwords",
      "indices" : [ 51, 62 ]
    }, {
      "text" : "ReadersWin",
      "indices" : [ 84, 95 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33209583535128576",
  "text" : "RT @WestofMars: Want an e-copy of Trevor's Song??? #smashwords http:\/\/bit.ly\/g70VCO #ReadersWin",
  "id" : 33209583535128576,
  "created_at" : "2011-02-03 17:05:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 0, 11 ],
      "id_str" : "34258680",
      "id" : 34258680
    }, {
      "name" : "Darcia Helle",
      "screen_name" : "DarciaHelle",
      "indices" : [ 12, 24 ],
      "id_str" : "140067631",
      "id" : 140067631
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33207769590931456",
  "geo" : { },
  "id_str" : "33209192865071104",
  "in_reply_to_user_id" : 34258680,
  "text" : "@WestofMars @DarciaHelle \"One\" is one of my faves. I think I have about 5 Metallica on my ipod.",
  "id" : 33209192865071104,
  "in_reply_to_status_id" : 33207769590931456,
  "created_at" : "2011-02-03 17:04:23 +0000",
  "in_reply_to_screen_name" : "WestofMars",
  "in_reply_to_user_id_str" : "34258680",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33207036846022657",
  "text" : "Hilarious British animal voiceovers. [VIDEO] http:\/\/bit.ly\/h1g05s",
  "id" : 33207036846022657,
  "created_at" : "2011-02-03 16:55:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 0, 11 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "33201700474978305",
  "geo" : { },
  "id_str" : "33202607795208192",
  "in_reply_to_user_id" : 34258680,
  "text" : "@WestofMars I know what u mean! So many on my kindle, archives, wishlist. BUT I keep looking 4 more ((smackshead)) .. Sigh",
  "id" : 33202607795208192,
  "in_reply_to_status_id" : 33201700474978305,
  "created_at" : "2011-02-03 16:38:13 +0000",
  "in_reply_to_screen_name" : "WestofMars",
  "in_reply_to_user_id_str" : "34258680",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TIME",
      "screen_name" : "TIME",
      "indices" : [ 3, 8 ],
      "id_str" : "14293310",
      "id" : 14293310
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33201585551052800",
  "text" : "RT @TIME: NASA discovers more than 1,200 planets roughly the size of Earth | http:\/\/ti.me\/eHyZtC",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33198039275405314",
    "text" : "NASA discovers more than 1,200 planets roughly the size of Earth | http:\/\/ti.me\/eHyZtC",
    "id" : 33198039275405314,
    "created_at" : "2011-02-03 16:20:04 +0000",
    "user" : {
      "name" : "TIME",
      "screen_name" : "TIME",
      "protected" : false,
      "id_str" : "14293310",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1700796190\/Picture_24_normal.png",
      "id" : 14293310,
      "verified" : true
    }
  },
  "id" : 33201585551052800,
  "created_at" : "2011-02-03 16:34:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 16, 27 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33201120658591744",
  "text" : "Awesome! Lol RT @WestofMars: Someone sent me FOUR YA books... and I have no idea why.",
  "id" : 33201120658591744,
  "created_at" : "2011-02-03 16:32:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ebooks",
      "indices" : [ 49, 56 ]
    }, {
      "text" : "kindle",
      "indices" : [ 57, 64 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33198672682426368",
  "text" : "Gabrielle's Reading http:\/\/myreads.abfabgab.com\/ #ebooks #kindle I love having paid hosting..lol..I can have so much fun playing w sites!",
  "id" : 33198672682426368,
  "created_at" : "2011-02-03 16:22:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Debra  L. Martin",
      "screen_name" : "dlmartin6",
      "indices" : [ 3, 13 ],
      "id_str" : "22961399",
      "id" : 22961399
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33197571098947584",
  "text" : "RT @dlmartin6: Only need 18 more followers to reach 500!  Do you like to read about authors, find new books, read reviews. Click follow. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "amwriting",
        "indices" : [ 122, 132 ]
      }, {
        "text" : "Kindle",
        "indices" : [ 133, 140 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33183686295814144",
    "text" : "Only need 18 more followers to reach 500!  Do you like to read about authors, find new books, read reviews. Click follow. #amwriting #Kindle",
    "id" : 33183686295814144,
    "created_at" : "2011-02-03 15:23:01 +0000",
    "user" : {
      "name" : "Debra  L. Martin",
      "screen_name" : "dlmartin6",
      "protected" : false,
      "id_str" : "22961399",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1419477518\/Deb9_normal.jpg",
      "id" : 22961399,
      "verified" : false
    }
  },
  "id" : 33197571098947584,
  "created_at" : "2011-02-03 16:18:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "indices" : [ 3, 18 ],
      "id_str" : "31986700",
      "id" : 31986700
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "33171938176147456",
  "text" : "RT @VeryShortStory: Disatisfied with the automatic submission system, I manually submitted you to the afterlife, ending your suffering a ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/ping.fm\/\" rel=\"nofollow\"\u003EPing.fm\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "33170725678354432",
    "text" : "Disatisfied with the automatic submission system, I manually submitted you to the afterlife, ending your suffering and mine.",
    "id" : 33170725678354432,
    "created_at" : "2011-02-03 14:31:31 +0000",
    "user" : {
      "name" : "Very Short Story",
      "screen_name" : "VeryShortStory",
      "protected" : false,
      "id_str" : "31986700",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/141070636\/42291_normal.jpg",
      "id" : 31986700,
      "verified" : false
    }
  },
  "id" : 33171938176147456,
  "created_at" : "2011-02-03 14:36:21 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 3, 17 ],
      "id_str" : "145083191",
      "id" : 145083191
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "fb",
      "indices" : [ 81, 84 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32990250246606848",
  "text" : "RT @JimBrownBooks: My mind is so sharp that it shreds anything I try to remember #fb",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/www.socialoomph.com\" rel=\"nofollow\"\u003ESocialOomph\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "fb",
        "indices" : [ 62, 65 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32989298928128000",
    "text" : "My mind is so sharp that it shreds anything I try to remember #fb",
    "id" : 32989298928128000,
    "created_at" : "2011-02-03 02:30:36 +0000",
    "user" : {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "protected" : false,
      "id_str" : "145083191",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1866434772\/JIM_WITHOUT_BOOKS_normal.jpg",
      "id" : 145083191,
      "verified" : false
    }
  },
  "id" : 32990250246606848,
  "created_at" : "2011-02-03 02:34:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "indices" : [ 3, 16 ],
      "id_str" : "113458113",
      "id" : 113458113
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32987197170778112",
  "text" : "RT @neardeathdoc: Effective therapies are goal directed, have a beginning and an end, specific plan of action & typically last 2-4 months",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.osfoora.com\" rel=\"nofollow\"\u003EOsfoora for iOS\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32984523541057538",
    "text" : "Effective therapies are goal directed, have a beginning and an end, specific plan of action & typically last 2-4 months",
    "id" : 32984523541057538,
    "created_at" : "2011-02-03 02:11:37 +0000",
    "user" : {
      "name" : "Melvin Morse",
      "screen_name" : "neardeathdoc",
      "protected" : false,
      "id_str" : "113458113",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1234387503\/ProfilePhoto_normal.png",
      "id" : 113458113,
      "verified" : false
    }
  },
  "id" : 32987197170778112,
  "created_at" : "2011-02-03 02:22:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "indices" : [ 3, 11 ],
      "id_str" : "54744689",
      "id" : 54744689
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ANIPALS",
      "indices" : [ 13, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32959295481974784",
  "text" : "RT @SangyeH: #ANIPALS IN CALIFORNIA: Can anyone help us resQ an abused pitbull in Baldwin Pk? We can take her, just need help getting he ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "ANIPALS",
        "indices" : [ 0, 8 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32957260338561024",
    "text" : "#ANIPALS IN CALIFORNIA: Can anyone help us resQ an abused pitbull in Baldwin Pk? We can take her, just need help getting her.  We're in AZ.",
    "id" : 32957260338561024,
    "created_at" : "2011-02-03 00:23:17 +0000",
    "user" : {
      "name" : "Ani Sangye",
      "screen_name" : "SangyeH",
      "protected" : false,
      "id_str" : "54744689",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/618129699315683328\/3AQ8aex8_normal.jpg",
      "id" : 54744689,
      "verified" : false
    }
  },
  "id" : 32959295481974784,
  "created_at" : "2011-02-03 00:31:23 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 0, 11 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32936101802934273",
  "geo" : { },
  "id_str" : "32944531791945728",
  "in_reply_to_user_id" : 6994832,
  "text" : "@TrishScott LOL, oh me, too. Does NOT sound like my kind of fun. was using as example of my physical endurance.",
  "id" : 32944531791945728,
  "in_reply_to_status_id" : 32936101802934273,
  "created_at" : "2011-02-02 23:32:43 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Andrew",
      "screen_name" : "ads60nyc",
      "indices" : [ 3, 12 ],
      "id_str" : "53427397",
      "id" : 53427397
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32931932438265856",
  "text" : "RT @ads60nyc: Mason is a 5-yr-old Russian Blue mix who is the 2\/3 PTS list at NYC ACC. Pls post to Pets on Death Row to adopt her  http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32928814258458624",
    "text" : "Mason is a 5-yr-old Russian Blue mix who is the 2\/3 PTS list at NYC ACC. Pls post to Pets on Death Row to adopt her  http:\/\/on.fb.me\/i6ch4Q",
    "id" : 32928814258458624,
    "created_at" : "2011-02-02 22:30:15 +0000",
    "user" : {
      "name" : "Andrew",
      "screen_name" : "ads60nyc",
      "protected" : false,
      "id_str" : "53427397",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/573266687002222593\/VHHuAD_p_normal.jpeg",
      "id" : 53427397,
      "verified" : false
    }
  },
  "id" : 32931932438265856,
  "created_at" : "2011-02-02 22:42:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lindsay Buroker",
      "screen_name" : "GoblinWriter",
      "indices" : [ 3, 16 ],
      "id_str" : "95730042",
      "id" : 95730042
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadersWin",
      "indices" : [ 109, 120 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32927303696646144",
  "text" : "RT @GoblinWriter: Like to try new authors? Chance to win a $40 Amazon gift certificate: http:\/\/bit.ly\/g2buJg #ReadersWin",
  "id" : 32927303696646144,
  "created_at" : "2011-02-02 22:24:15 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadersWin",
      "indices" : [ 96, 107 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32925388665520128",
  "text" : "RT @thecrowscaw: 41 followers left and the ebook gifting will be let loose! Let's get'er done!! #ReadersWin",
  "id" : 32925388665520128,
  "created_at" : "2011-02-02 22:16:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Tom Delargy",
      "screen_name" : "derekrootboy",
      "indices" : [ 0, 13 ],
      "id_str" : "35585695",
      "id" : 35585695
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32917116575289344",
  "geo" : { },
  "id_str" : "32917807821758466",
  "in_reply_to_user_id" : 35585695,
  "text" : "@derekrootboy I have heard something about the ratio of Following & Followers.. don't know if that's why. (and stupid 4 twitter)",
  "id" : 32917807821758466,
  "in_reply_to_status_id" : 32917116575289344,
  "created_at" : "2011-02-02 21:46:31 +0000",
  "in_reply_to_screen_name" : "derekrootboy",
  "in_reply_to_user_id_str" : "35585695",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32915829494386688",
  "text" : "RT @Buddhaworld: all is temporary, temporary beeings fight temporary situations, that is called life. Nothing else to it. -love buddha v ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32914970807107585",
    "text" : "all is temporary, temporary beeings fight temporary situations, that is called life. Nothing else to it. -love buddha volko.",
    "id" : 32914970807107585,
    "created_at" : "2011-02-02 21:35:15 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 32915829494386688,
  "created_at" : "2011-02-02 21:38:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "indices" : [ 3, 15 ],
      "id_str" : "40560386",
      "id" : 40560386
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32915737970483200",
  "text" : "RT @Buddhaworld: if you have seen one day, you have seen all days. Its what you put into it that makes the difference.-love buddha volko.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/mobile.twitter.com\" rel=\"nofollow\"\u003EMobile Web\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32915322721796096",
    "text" : "if you have seen one day, you have seen all days. Its what you put into it that makes the difference.-love buddha volko.",
    "id" : 32915322721796096,
    "created_at" : "2011-02-02 21:36:39 +0000",
    "user" : {
      "name" : "living buddha volko",
      "screen_name" : "Buddhaworld",
      "protected" : false,
      "id_str" : "40560386",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/625645927651516416\/4AjYGuBo_normal.jpg",
      "id" : 40560386,
      "verified" : false
    }
  },
  "id" : 32915737970483200,
  "created_at" : "2011-02-02 21:38:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32910433740398593",
  "text" : "@Skandhasattva was there supposed 2B a link w that? lol",
  "id" : 32910433740398593,
  "created_at" : "2011-02-02 21:17:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 58, 65 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32906964124049408",
  "text" : "RT @MaryMcDonald64: March Into Hell http:\/\/amzn.to\/eBX09S #kindle Mark Taylor's life takes a dark turn when a cult leader targets him. S ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "kindle",
        "indices" : [ 38, 45 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32906513773232129",
    "text" : "March Into Hell http:\/\/amzn.to\/eBX09S #kindle Mark Taylor's life takes a dark turn when a cult leader targets him. Sequel to No Good Deed",
    "id" : 32906513773232129,
    "created_at" : "2011-02-02 21:01:38 +0000",
    "user" : {
      "name" : "M.P. McDonald",
      "screen_name" : "MarkTaylorBooks",
      "protected" : false,
      "id_str" : "31386920",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/445911314838204416\/vaTQASPe_normal.jpeg",
      "id" : 31386920,
      "verified" : false
    }
  },
  "id" : 32906964124049408,
  "created_at" : "2011-02-02 21:03:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32906858507276290",
  "text" : "on those survivor shows, I'd def B 1st one gone. It doesn't take much 2 sap my energy.",
  "id" : 32906858507276290,
  "created_at" : "2011-02-02 21:03:01 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32906427261521920",
  "text" : "I am not what you call.. sturdy .. as in sturdy stock?",
  "id" : 32906427261521920,
  "created_at" : "2011-02-02 21:01:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wrongkindoflist",
      "indices" : [ 84, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32905422956404736",
  "text" : "RT @GeneDoucette: Daughter: \"I made the Dean's List!\" Me: \"Oh no! What did you do?\" #wrongkindoflist",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "wrongkindoflist",
        "indices" : [ 66, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32903293818634240",
    "text" : "Daughter: \"I made the Dean's List!\" Me: \"Oh no! What did you do?\" #wrongkindoflist",
    "id" : 32903293818634240,
    "created_at" : "2011-02-02 20:48:51 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 32905422956404736,
  "created_at" : "2011-02-02 20:57:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "indices" : [ 3, 14 ],
      "id_str" : "34258680",
      "id" : 34258680
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32898347794694146",
  "text" : "RT @WestofMars: Giving away an e-book copy of Trevor's Song over at Quackers and Tease today. Stop in -- or just share the link.... http ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32895328571105280",
    "text" : "Giving away an e-book copy of Trevor's Song over at Quackers and Tease today. Stop in -- or just share the link.... http:\/\/fb.me\/K18rHvfK",
    "id" : 32895328571105280,
    "created_at" : "2011-02-02 20:17:12 +0000",
    "user" : {
      "name" : "SusanHeleneGottfried",
      "screen_name" : "WestofMars",
      "protected" : false,
      "id_str" : "34258680",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/454321783588413442\/gndVsGba_normal.png",
      "id" : 34258680,
      "verified" : false
    }
  },
  "id" : 32898347794694146,
  "created_at" : "2011-02-02 20:29:11 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "indices" : [ 3, 17 ],
      "id_str" : "28863804",
      "id" : 28863804
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32871173222039552",
  "text" : "RT @Wylieknowords: \"Twitter--Where you meet people you'll never meet.\"  N. Wylie Jones www.knowords.com",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32870041649160192",
    "text" : "\"Twitter--Where you meet people you'll never meet.\"  N. Wylie Jones www.knowords.com",
    "id" : 32870041649160192,
    "created_at" : "2011-02-02 18:36:43 +0000",
    "user" : {
      "name" : "Wylie Jones",
      "screen_name" : "Wylieknowords",
      "protected" : false,
      "id_str" : "28863804",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1339770915\/Wylie_normal.jpg",
      "id" : 28863804,
      "verified" : false
    }
  },
  "id" : 32871173222039552,
  "created_at" : "2011-02-02 18:41:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Editor @ bookPumper",
      "screen_name" : "bookPumper",
      "indices" : [ 3, 14 ],
      "id_str" : "18670221",
      "id" : 18670221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32859208357519360",
  "text" : "RT @bookPumper: Don't have Dad edit your sex scenes: http:\/\/bit.ly\/i4G5ZP",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32854166732800000",
    "text" : "Don't have Dad edit your sex scenes: http:\/\/bit.ly\/i4G5ZP",
    "id" : 32854166732800000,
    "created_at" : "2011-02-02 17:33:38 +0000",
    "user" : {
      "name" : "Editor @ bookPumper",
      "screen_name" : "bookPumper",
      "protected" : false,
      "id_str" : "18670221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/795161232110063616\/yP2VkigI_normal.jpg",
      "id" : 18670221,
      "verified" : false
    }
  },
  "id" : 32859208357519360,
  "created_at" : "2011-02-02 17:53:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 15, 28 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "ReadersWin",
      "indices" : [ 0, 11 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32854542550835200",
  "text" : "#ReadersWin RT @golden_books: Contest time! Email liz@elizabethparkerbooks & put feb11 in subject line 4... (more) http:\/\/twtm.in\/ly0",
  "id" : 32854542550835200,
  "created_at" : "2011-02-02 17:35:08 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Adam Immortal",
      "screen_name" : "AdamtheImmortal",
      "indices" : [ 3, 19 ],
      "id_str" : "123093858",
      "id" : 123093858
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32831288196997120",
  "text" : "RT @AdamtheImmortal: About Immortal, which I can't believe you haven't bought yet: http:\/\/bit.ly\/90yYxc",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32829605576441856",
    "text" : "About Immortal, which I can't believe you haven't bought yet: http:\/\/bit.ly\/90yYxc",
    "id" : 32829605576441856,
    "created_at" : "2011-02-02 15:56:02 +0000",
    "user" : {
      "name" : "Adam Immortal",
      "screen_name" : "AdamtheImmortal",
      "protected" : false,
      "id_str" : "123093858",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/822528305\/01.early.history_normal.jpeg",
      "id" : 123093858,
      "verified" : false
    }
  },
  "id" : 32831288196997120,
  "created_at" : "2011-02-02 16:02:43 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Lex Sisney",
      "screen_name" : "lexsisney",
      "indices" : [ 0, 10 ],
      "id_str" : "14343511",
      "id" : 14343511
    }, {
      "name" : "TrafficWave",
      "screen_name" : "trafficwave",
      "indices" : [ 98, 110 ],
      "id_str" : "19056688",
      "id" : 19056688
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32828995120664576",
  "geo" : { },
  "id_str" : "32830969476022273",
  "in_reply_to_user_id" : 14343511,
  "text" : "@lexsisney try trafficwave.net 30 day free trial (I'm not current affiliate but still love them)  @trafficwave",
  "id" : 32830969476022273,
  "in_reply_to_status_id" : 32828995120664576,
  "created_at" : "2011-02-02 16:01:27 +0000",
  "in_reply_to_screen_name" : "lexsisney",
  "in_reply_to_user_id_str" : "14343511",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 0, 11 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32828273868148736",
  "geo" : { },
  "id_str" : "32829893725130753",
  "in_reply_to_user_id" : 8449382,
  "text" : "@quantafire I use premium-hosts.com .. No, I don't get paid (or free hosting) 2 say so..lol",
  "id" : 32829893725130753,
  "in_reply_to_status_id" : 32828273868148736,
  "created_at" : "2011-02-02 15:57:11 +0000",
  "in_reply_to_screen_name" : "quantafire",
  "in_reply_to_user_id_str" : "8449382",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "NoNicknamesLeft",
      "screen_name" : "heathenrabbit",
      "indices" : [ 19, 33 ],
      "id_str" : "755656347908206592",
      "id" : 755656347908206592
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "groundhogday",
      "indices" : [ 101, 114 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32829372914204674",
  "text" : "Naughty but LOL RT @HEATHENRABBIT: I saw the beavers shadow so that means 6 more inches for my wife. #groundhogday",
  "id" : 32829372914204674,
  "created_at" : "2011-02-02 15:55:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 64, 77 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32811624121245696",
  "geo" : { },
  "id_str" : "32813115921928192",
  "in_reply_to_user_id" : 123068593,
  "text" : "http:\/\/zackhamric.blogspot.com\/ has been doing Kindle giveaways @GeneDoucette",
  "id" : 32813115921928192,
  "in_reply_to_status_id" : 32811624121245696,
  "created_at" : "2011-02-02 14:50:31 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 72, 85 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32811624121245696",
  "geo" : { },
  "id_str" : "32812416056172544",
  "in_reply_to_user_id" : 123068593,
  "text" : "just throwing ideas out there.. stuff Ive seen other writers do..   : ) @GeneDoucette",
  "id" : 32812416056172544,
  "in_reply_to_status_id" : 32811624121245696,
  "created_at" : "2011-02-02 14:47:44 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 34, 47 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32811624121245696",
  "geo" : { },
  "id_str" : "32812223495675905",
  "in_reply_to_user_id" : 123068593,
  "text" : "no?? u crazy cat, u need one! lol @GeneDoucette",
  "id" : 32812223495675905,
  "in_reply_to_status_id" : 32811624121245696,
  "created_at" : "2011-02-02 14:46:58 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32811784553369600",
  "text" : "Jack seems 2B a popular name in book series .. u know, like the lead character..",
  "id" : 32811784553369600,
  "created_at" : "2011-02-02 14:45:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "John Peter  Thompson",
      "screen_name" : "InvasiveNotes",
      "indices" : [ 3, 17 ],
      "id_str" : "41100077",
      "id" : 41100077
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32811304263622656",
  "text" : "RT @InvasiveNotes: Next time my Russian wife gets mad at le for losing my sock in the dryer, I will point out that I never lost a satellite",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32809582896091136",
    "text" : "Next time my Russian wife gets mad at le for losing my sock in the dryer, I will point out that I never lost a satellite",
    "id" : 32809582896091136,
    "created_at" : "2011-02-02 14:36:28 +0000",
    "user" : {
      "name" : "John Peter  Thompson",
      "screen_name" : "InvasiveNotes",
      "protected" : false,
      "id_str" : "41100077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/792827641\/JPT_IMG_9790_normal.JPG",
      "id" : 41100077,
      "verified" : false
    }
  },
  "id" : 32811304263622656,
  "created_at" : "2011-02-02 14:43:19 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 0, 13 ],
      "id_str" : "123068593",
      "id" : 123068593
    }, {
      "name" : "BAB",
      "screen_name" : "msquick1",
      "indices" : [ 14, 23 ],
      "id_str" : "57707041",
      "id" : 57707041
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32806798150864896",
  "geo" : { },
  "id_str" : "32811157949513729",
  "in_reply_to_user_id" : 123068593,
  "text" : "@GeneDoucette @msquick1 run a contest giving away a Kindle when it comes out?",
  "id" : 32811157949513729,
  "in_reply_to_status_id" : 32806798150864896,
  "created_at" : "2011-02-02 14:42:44 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "indie",
      "indices" : [ 114, 120 ]
    }, {
      "text" : "books",
      "indices" : [ 121, 127 ]
    }, {
      "text" : "nook",
      "indices" : [ 128, 133 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32806133232050176",
  "text" : "RT @indiebooksblog: Heather Wardell's novel PLANNING TO LIVE featured today at http:\/\/indiebooksblog.blogspot.com #indie #books #nook",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "indie",
        "indices" : [ 94, 100 ]
      }, {
        "text" : "books",
        "indices" : [ 101, 107 ]
      }, {
        "text" : "nook",
        "indices" : [ 108, 113 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32794759298813953",
    "text" : "Heather Wardell's novel PLANNING TO LIVE featured today at http:\/\/indiebooksblog.blogspot.com #indie #books #nook",
    "id" : 32794759298813953,
    "created_at" : "2011-02-02 13:37:34 +0000",
    "user" : {
      "name" : "eBooks Blog",
      "screen_name" : "ebooksblog",
      "protected" : false,
      "id_str" : "152238836",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1020901565\/HC_logo_normal.jpg",
      "id" : 152238836,
      "verified" : false
    }
  },
  "id" : 32806133232050176,
  "created_at" : "2011-02-02 14:22:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jim Brown",
      "screen_name" : "JimBrownBooks",
      "indices" : [ 32, 46 ],
      "id_str" : "145083191",
      "id" : 145083191
    }, {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 71, 84 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32803732567629824",
  "geo" : { },
  "id_str" : "32805630553104384",
  "in_reply_to_user_id" : 123068593,
  "text" : "u could do videos, u & the cat? @JimBrownBooks does video on his site. @GeneDoucette",
  "id" : 32805630553104384,
  "in_reply_to_status_id" : 32803732567629824,
  "created_at" : "2011-02-02 14:20:46 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 0, 13 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32803732567629824",
  "geo" : { },
  "id_str" : "32805057321771008",
  "in_reply_to_user_id" : 123068593,
  "text" : "@GeneDoucette i've seen countdowns on various sites.. use a good graphic.",
  "id" : 32805057321771008,
  "in_reply_to_status_id" : 32803732567629824,
  "created_at" : "2011-02-02 14:18:29 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32801736255082496",
  "text" : "The Quackery of Chemotherapy, Gunpoint Medicine and the Disturbing Fate of 13-Year-Old Daniel Hauser http:\/\/bit.ly\/gMYsVM",
  "id" : 32801736255082496,
  "created_at" : "2011-02-02 14:05:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32799213691609088",
  "text" : "@Skandhasattva my ebook site http:\/\/abfabgab.com\/ebooks .. need 2 get a domain 4 it at some point..lol",
  "id" : 32799213691609088,
  "created_at" : "2011-02-02 13:55:16 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32795673296379904",
  "text" : "having my coffee, trying 2 remember my ideas 4 my website last night.. hmm..",
  "id" : 32795673296379904,
  "created_at" : "2011-02-02 13:41:12 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32629232802734080",
  "text" : "RT @UnseeingEyes: The truth is...there is no normal. What does exist is what is healthy & good for you & others...& that's \"nice.\"",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32628708665729024",
    "text" : "The truth is...there is no normal. What does exist is what is healthy & good for you & others...& that's \"nice.\"",
    "id" : 32628708665729024,
    "created_at" : "2011-02-02 02:37:45 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 32629232802734080,
  "created_at" : "2011-02-02 02:39:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "USE",
      "indices" : [ 85, 89 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32618479047675904",
  "text" : "RT @UnseeingEyes: The most profound & brilliant thing I ever tweeted went unnoticed. #USE -V-",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "USE",
        "indices" : [ 67, 71 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32618093628882944",
    "text" : "The most profound & brilliant thing I ever tweeted went unnoticed. #USE -V-",
    "id" : 32618093628882944,
    "created_at" : "2011-02-02 01:55:34 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 32618479047675904,
  "created_at" : "2011-02-02 01:57:06 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "indices" : [ 3, 16 ],
      "id_str" : "36008885",
      "id" : 36008885
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Twisted",
      "indices" : [ 85, 93 ]
    }, {
      "text" : "Humor",
      "indices" : [ 94, 100 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32614402343567361",
  "text" : "RT @UnseeingEyes: Another 12 Hilariously Inappropriate T-Shirts http:\/\/bit.ly\/fOp49C #Twisted #Humor (Published yesterday on \"Raw Meat\")",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Twisted",
        "indices" : [ 67, 75 ]
      }, {
        "text" : "Humor",
        "indices" : [ 76, 82 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32611685390876672",
    "text" : "Another 12 Hilariously Inappropriate T-Shirts http:\/\/bit.ly\/fOp49C #Twisted #Humor (Published yesterday on \"Raw Meat\")",
    "id" : 32611685390876672,
    "created_at" : "2011-02-02 01:30:06 +0000",
    "user" : {
      "name" : "Vincenzo Scipioni",
      "screen_name" : "UnseeingEyes",
      "protected" : false,
      "id_str" : "36008885",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1292799471\/USEempireImage_normal.jpg",
      "id" : 36008885,
      "verified" : false
    }
  },
  "id" : 32614402343567361,
  "created_at" : "2011-02-02 01:40:54 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    }, {
      "name" : "Holly McRae",
      "screen_name" : "hollymcrae",
      "indices" : [ 20, 31 ],
      "id_str" : "88476620",
      "id" : 88476620
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32607297641381888",
  "text" : "RT @SheilaWalsh: RT @hollymcrae: prayers for Kate more than ever.  http:\/\/bit.ly\/bRqgfz I have no words Holly, just tears, cry 4 mercy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Holly McRae",
        "screen_name" : "hollymcrae",
        "indices" : [ 3, 14 ],
        "id_str" : "88476620",
        "id" : 88476620
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32602658548228096",
    "text" : "RT @hollymcrae: prayers for Kate more than ever.  http:\/\/bit.ly\/bRqgfz I have no words Holly, just tears, cry 4 mercy",
    "id" : 32602658548228096,
    "created_at" : "2011-02-02 00:54:14 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 32607297641381888,
  "created_at" : "2011-02-02 01:12:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "indices" : [ 3, 15 ],
      "id_str" : "15179770",
      "id" : 15179770
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32607108344057856",
  "text" : "RT @SheilaWalsh: How is any mom or dad supposed to answer such a brave child who has suffered so much and asks, \"Why hasn't Jesus healed ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "katemcrae",
        "indices" : [ 125, 135 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32605261692669952",
    "text" : "How is any mom or dad supposed to answer such a brave child who has suffered so much and asks, \"Why hasn't Jesus healed me?\" #katemcrae",
    "id" : 32605261692669952,
    "created_at" : "2011-02-02 01:04:34 +0000",
    "user" : {
      "name" : "SheilaWalsh",
      "screen_name" : "SheilaWalsh",
      "protected" : false,
      "id_str" : "15179770",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/704108344550694916\/3kqIBvEu_normal.jpg",
      "id" : 15179770,
      "verified" : false
    }
  },
  "id" : 32607108344057856,
  "created_at" : "2011-02-02 01:11:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32583438217248769",
  "geo" : { },
  "id_str" : "32584638652223488",
  "in_reply_to_user_id" : 159213309,
  "text" : "@InfantileAdult ((hugs))",
  "id" : 32584638652223488,
  "in_reply_to_status_id" : 32583438217248769,
  "created_at" : "2011-02-01 23:42:37 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "indices" : [ 3, 16 ],
      "id_str" : "18306792",
      "id" : 18306792
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32574616639639552",
  "text" : "RT @morsemusings: When you know all, you would judge none. -Mikhail Naimy",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32573015736713216",
    "text" : "When you know all, you would judge none. -Mikhail Naimy",
    "id" : 32573015736713216,
    "created_at" : "2011-02-01 22:56:26 +0000",
    "user" : {
      "name" : "morsemusings",
      "screen_name" : "morsemusings",
      "protected" : true,
      "id_str" : "18306792",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1642775845\/RisingSun_normal.jpg",
      "id" : 18306792,
      "verified" : false
    }
  },
  "id" : 32574616639639552,
  "created_at" : "2011-02-01 23:02:48 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32574579331301376",
  "text" : "RT @InfantileAdult: I miss you Dad, trust me, I miss you. So much.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32573297698807810",
    "text" : "I miss you Dad, trust me, I miss you. So much.",
    "id" : 32573297698807810,
    "created_at" : "2011-02-01 22:57:34 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 32574579331301376,
  "created_at" : "2011-02-01 23:02:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32573519820754944",
  "geo" : { },
  "id_str" : "32574374380834816",
  "in_reply_to_user_id" : 159213309,
  "text" : "@InfantileAdult not the same but you can start anew. might help to write letters to your Dad -but not send. write everything, good or bad.",
  "id" : 32574374380834816,
  "in_reply_to_status_id" : 32573519820754944,
  "created_at" : "2011-02-01 23:01:50 +0000",
  "in_reply_to_screen_name" : "StandForAnimals",
  "in_reply_to_user_id_str" : "159213309",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "debbie jacobs",
      "screen_name" : "fearfuldogs",
      "indices" : [ 3, 15 ],
      "id_str" : "16691399",
      "id" : 16691399
    }, {
      "name" : "Liz Parker-Author",
      "screen_name" : "golden_books",
      "indices" : [ 19, 32 ],
      "id_str" : "124594428",
      "id" : 124594428
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32571876148510720",
  "text" : "?4 @fearfuldogs RT @golden_books: Anyone know how to help a dog to NOT be afraid of a camera (or even a cell... (more) http:\/\/twtm.in\/lXq",
  "id" : 32571876148510720,
  "created_at" : "2011-02-01 22:51:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "indices" : [ 3, 16 ],
      "id_str" : "17374293",
      "id" : 17374293
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32564039317987328",
  "text" : "RT @JeremyCShipp: Could you please help me spread the word about this free PDF copy of my horror story \"Camp\"? http:\/\/tinyurl.com\/ylcm4tj",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "31867580377473024",
    "text" : "Could you please help me spread the word about this free PDF copy of my horror story \"Camp\"? http:\/\/tinyurl.com\/ylcm4tj",
    "id" : 31867580377473024,
    "created_at" : "2011-01-31 00:13:17 +0000",
    "user" : {
      "name" : "Jeremy C. Shipp",
      "screen_name" : "JeremyCShipp",
      "protected" : false,
      "id_str" : "17374293",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/783400288744976384\/0mqEAkRW_normal.jpg",
      "id" : 17374293,
      "verified" : false
    }
  },
  "id" : 32564039317987328,
  "created_at" : "2011-02-01 22:20:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Rachael Rossman Art",
      "screen_name" : "RachaelRossman",
      "indices" : [ 3, 18 ],
      "id_str" : "15991826",
      "id" : 15991826
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32560398477557760",
  "text" : "RT @RachaelRossman: Snow storm from space. Creepy! http:\/\/www.huffingtonpost.com\/2011\/02\/01\/midwest-snowstorm-weather-_n_817070.html",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32549281139261440",
    "text" : "Snow storm from space. Creepy! http:\/\/www.huffingtonpost.com\/2011\/02\/01\/midwest-snowstorm-weather-_n_817070.html",
    "id" : 32549281139261440,
    "created_at" : "2011-02-01 21:22:08 +0000",
    "user" : {
      "name" : "Rachael Rossman Art",
      "screen_name" : "RachaelRossman",
      "protected" : false,
      "id_str" : "15991826",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2888404500\/7de4999a601b084c8422c02a59fcaa52_normal.jpeg",
      "id" : 15991826,
      "verified" : false
    }
  },
  "id" : 32560398477557760,
  "created_at" : "2011-02-01 22:06:18 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Premium-Hosts.com",
      "screen_name" : "premhosts",
      "indices" : [ 97, 107 ],
      "id_str" : "242830330",
      "id" : 242830330
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "wordpress",
      "indices" : [ 27, 37 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32531500071133185",
  "text" : "If u need web hosting 4 yr #wordpress see http:\/\/premium-hosts.com .. I use them 4 abfabgab.com  @premhosts",
  "id" : 32531500071133185,
  "created_at" : "2011-02-01 20:11:28 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Premium-Hosts.com",
      "screen_name" : "premhosts",
      "indices" : [ 6, 16 ],
      "id_str" : "242830330",
      "id" : 242830330
    }, {
      "name" : "SharedMinds",
      "screen_name" : "SharedMinds",
      "indices" : [ 33, 45 ],
      "id_str" : "20355125",
      "id" : 20355125
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32530579115216898",
  "text" : "I use @premhosts 4 my hosting RT @SharedMinds: How To Setup a Self-Hosted WordPress Blog: http:\/\/is.gd\/kV8FNE  ... (more) http:\/\/twtm.in\/lXK",
  "id" : 32530579115216898,
  "created_at" : "2011-02-01 20:07:49 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 10, 22 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32528630319947776",
  "text" : "@Tideliar @neilhimself hehe..yeah, DD still loves her pbooks, too..  : )",
  "id" : 32528630319947776,
  "created_at" : "2011-02-01 20:00:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u041B\u0435\u0440\u043E\u0447\u043A\u0430 \u043A\u0440\u0430\u0441\u043E\u0442\u043E\u0447\u043A\u0430",
      "screen_name" : "Tideliar",
      "indices" : [ 0, 9 ],
      "id_str" : "137866651",
      "id" : 137866651
    }, {
      "name" : "Neil Gaiman",
      "screen_name" : "neilhimself",
      "indices" : [ 10, 22 ],
      "id_str" : "18393773",
      "id" : 18393773
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Kindle",
      "indices" : [ 34, 41 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32527575658008576",
  "text" : "@Tideliar @neilhimself You need a #Kindle..LOL",
  "id" : 32527575658008576,
  "created_at" : "2011-02-01 19:55:53 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32526833501085696",
  "text" : "RT @InfantileAdult: They're controlling him with their Jedi hands :)\n\nCarmVisuals Photography http:\/\/twitpic.com\/3vjjnt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32524678820003840",
    "text" : "They're controlling him with their Jedi hands :)\n\nCarmVisuals Photography http:\/\/twitpic.com\/3vjjnt",
    "id" : 32524678820003840,
    "created_at" : "2011-02-01 19:44:22 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 32526833501085696,
  "created_at" : "2011-02-01 19:52:56 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32526329828081666",
  "text" : "RT @InfantileAdult: FIRST NIGHT SKY SHOT. Was so happy when I got this. Long shutter speed and tripod ;)\n\nCarmVisuals photography. http: ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32525963040391168",
    "text" : "FIRST NIGHT SKY SHOT. Was so happy when I got this. Long shutter speed and tripod ;)\n\nCarmVisuals photography. http:\/\/twitpic.com\/3vjl3f",
    "id" : 32525963040391168,
    "created_at" : "2011-02-01 19:49:28 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 32526329828081666,
  "created_at" : "2011-02-01 19:50:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/bitly.com\" rel=\"nofollow\"\u003Ebitly bitlink\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32525489650278401",
  "text" : "LOL&gt;&gt;\"unlike deer, moose don\u2019t crawl under or jump over fences \u2014 they just walk through them\" http:\/\/bit.ly\/dJcKbI",
  "id" : 32525489650278401,
  "created_at" : "2011-02-01 19:47:35 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "burdr",
      "screen_name" : "burdr",
      "indices" : [ 3, 9 ],
      "id_str" : "18826472",
      "id" : 18826472
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "birds",
      "indices" : [ 50, 56 ]
    }, {
      "text" : "birding",
      "indices" : [ 57, 65 ]
    }, {
      "text" : "photography",
      "indices" : [ 66, 78 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32516804190408704",
  "text" : "RT @burdr: Wall of Snow Geese! http:\/\/ow.ly\/3O9jq #birds #birding #photography",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.hootsuite.com\" rel=\"nofollow\"\u003EHootsuite\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "birds",
        "indices" : [ 39, 45 ]
      }, {
        "text" : "birding",
        "indices" : [ 46, 54 ]
      }, {
        "text" : "photography",
        "indices" : [ 55, 67 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32516049421209600",
    "text" : "Wall of Snow Geese! http:\/\/ow.ly\/3O9jq #birds #birding #photography",
    "id" : 32516049421209600,
    "created_at" : "2011-02-01 19:10:04 +0000",
    "user" : {
      "name" : "burdr",
      "screen_name" : "burdr",
      "protected" : false,
      "id_str" : "18826472",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1349213818\/IMG_0448_normal.jpg",
      "id" : 18826472,
      "verified" : false
    }
  },
  "id" : 32516804190408704,
  "created_at" : "2011-02-01 19:13:04 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32515406069501952",
  "text" : "RT @InfantileAdult: First attempt at adding a logo to my photography. Oh, and one of my first successful night shots :)  http:\/\/twitpic. ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitpic.com\" rel=\"nofollow\"\u003ETwitpic\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32511962747240448",
    "text" : "First attempt at adding a logo to my photography. Oh, and one of my first successful night shots :)  http:\/\/twitpic.com\/3vj550",
    "id" : 32511962747240448,
    "created_at" : "2011-02-01 18:53:50 +0000",
    "user" : {
      "name" : "Rumplestiltskin",
      "screen_name" : "StandForAnimals",
      "protected" : false,
      "id_str" : "159213309",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1320616002\/189621_10150106209234023_628349022_6439929_4024672_n__1__normal.jpg",
      "id" : 159213309,
      "verified" : false
    }
  },
  "id" : 32515406069501952,
  "created_at" : "2011-02-01 19:07:31 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "PuaTamandua",
      "screen_name" : "PuaTamandua",
      "indices" : [ 15, 27 ],
      "id_str" : "17218256",
      "id" : 17218256
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32512213549846529",
  "geo" : { },
  "id_str" : "32514966363832320",
  "in_reply_to_user_id" : 17218256,
  "text" : "aww, poor Pua! @PuaTamandua",
  "id" : 32514966363832320,
  "in_reply_to_status_id" : 32512213549846529,
  "created_at" : "2011-02-01 19:05:46 +0000",
  "in_reply_to_screen_name" : "PuaTamandua",
  "in_reply_to_user_id_str" : "17218256",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Diamond Dd",
      "screen_name" : "ntnslykrazy",
      "indices" : [ 3, 15 ],
      "id_str" : "30335077",
      "id" : 30335077
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "OK",
      "indices" : [ 40, 43 ]
    }, {
      "text" : "KS",
      "indices" : [ 44, 47 ]
    }, {
      "text" : "WildHorses",
      "indices" : [ 102, 113 ]
    }, {
      "text" : "Burros",
      "indices" : [ 117, 124 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32512129240137728",
  "text" : "RT @ntnslykrazy: http:\/\/bit.ly\/hWFIim \" #OK #KS Under Extreme Blizzard Warnings\" No shelter 4 these   #WildHorses &  #Burros N long term ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "OK",
        "indices" : [ 23, 26 ]
      }, {
        "text" : "KS",
        "indices" : [ 27, 30 ]
      }, {
        "text" : "WildHorses",
        "indices" : [ 85, 96 ]
      }, {
        "text" : "Burros",
        "indices" : [ 100, 107 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32508441469652992",
    "text" : "http:\/\/bit.ly\/hWFIim \" #OK #KS Under Extreme Blizzard Warnings\" No shelter 4 these   #WildHorses &  #Burros N long term holdN pens!!",
    "id" : 32508441469652992,
    "created_at" : "2011-02-01 18:39:51 +0000",
    "user" : {
      "name" : "Diamond Dd",
      "screen_name" : "ntnslykrazy",
      "protected" : false,
      "id_str" : "30335077",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1648817390\/My-4-Pommy_s_normal.jpg",
      "id" : 30335077,
      "verified" : false
    }
  },
  "id" : 32512129240137728,
  "created_at" : "2011-02-01 18:54:30 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32505320542576640",
  "text" : "RT @PortalChronicle: Kindle Kisses from Donna Clayton! I have three copies of her book Mountain Laurel to giveaway. Click \"like\" or... h ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.facebook.com\/twitter\" rel=\"nofollow\"\u003EFacebook\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32504344129576960",
    "text" : "Kindle Kisses from Donna Clayton! I have three copies of her book Mountain Laurel to giveaway. Click \"like\" or... http:\/\/fb.me\/Nx511syS",
    "id" : 32504344129576960,
    "created_at" : "2011-02-01 18:23:34 +0000",
    "user" : {
      "name" : "IMOGEN ROSE",
      "screen_name" : "ImogenRoseTweet",
      "protected" : false,
      "id_str" : "102568232",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1265710799\/profile1_normal.jpg",
      "id" : 102568232,
      "verified" : false
    }
  },
  "id" : 32505320542576640,
  "created_at" : "2011-02-01 18:27:26 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32502890203455488",
  "geo" : { },
  "id_str" : "32505070364921856",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 cats are like \"what did u do that 4?\" & dogs \"RU OK? Someone call 911!\" LOL",
  "id" : 32505070364921856,
  "in_reply_to_status_id" : 32502890203455488,
  "created_at" : "2011-02-01 18:26:27 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 74, 78 ]
    } ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32500836441526272",
  "geo" : { },
  "id_str" : "32504071915048961",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 well this round girl is getting used to embarassment taking #TKD. I keep hubby amused..lol",
  "id" : 32504071915048961,
  "in_reply_to_status_id" : 32500836441526272,
  "created_at" : "2011-02-01 18:22:29 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "kindle",
      "indices" : [ 46, 53 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32503475338215424",
  "text" : "@darkelms D\/L.. look forward to reading on my #kindle : )",
  "id" : 32503475338215424,
  "created_at" : "2011-02-01 18:20:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32502132351434752",
  "geo" : { },
  "id_str" : "32503194621841408",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 im lucky never 2 have broken any bones.. so far..lol",
  "id" : 32503194621841408,
  "in_reply_to_status_id" : 32502132351434752,
  "created_at" : "2011-02-01 18:19:00 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Paul Mansfield Keefe",
      "screen_name" : "thrillerXpert",
      "indices" : [ 0, 14 ],
      "id_str" : "203583284",
      "id" : 203583284
    }, {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 15, 28 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32502001795342336",
  "geo" : { },
  "id_str" : "32503025536868353",
  "in_reply_to_user_id" : 203583284,
  "text" : "@thrillerXpert @GeneDoucette RD is one of hubby's faves!",
  "id" : 32503025536868353,
  "in_reply_to_status_id" : 32502001795342336,
  "created_at" : "2011-02-01 18:18:19 +0000",
  "in_reply_to_screen_name" : "thrillerXpert",
  "in_reply_to_user_id_str" : "203583284",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32500150517628928",
  "geo" : { },
  "id_str" : "32500658464628736",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 something about falling down stairs is so undignified..hurts ego more than anything..lol",
  "id" : 32500658464628736,
  "in_reply_to_status_id" : 32500150517628928,
  "created_at" : "2011-02-01 18:08:55 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 0, 13 ],
      "id_str" : "123068593",
      "id" : 123068593
    }, {
      "name" : "Paul Mansfield Keefe",
      "screen_name" : "thrillerXpert",
      "indices" : [ 14, 28 ],
      "id_str" : "203583284",
      "id" : 203583284
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32499714708475904",
  "geo" : { },
  "id_str" : "32500226229014528",
  "in_reply_to_user_id" : 123068593,
  "text" : "@GeneDoucette @thrillerXpert hey! I was going to say that! LOL We love Dr. Who, too.",
  "id" : 32500226229014528,
  "in_reply_to_status_id" : 32499714708475904,
  "created_at" : "2011-02-01 18:07:12 +0000",
  "in_reply_to_screen_name" : "GeneDoucette",
  "in_reply_to_user_id_str" : "123068593",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "indices" : [ 3, 12 ],
      "id_str" : "13112692",
      "id" : 13112692
    } ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Egypt",
      "indices" : [ 30, 36 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32499834984337408",
  "text" : "RT @gemswinc: We are with you #Egypt",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.echofon.com\/\" rel=\"nofollow\"\u003EEchofon\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ {
        "text" : "Egypt",
        "indices" : [ 16, 22 ]
      } ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32499412445954048",
    "text" : "We are with you #Egypt",
    "id" : 32499412445954048,
    "created_at" : "2011-02-01 18:03:58 +0000",
    "user" : {
      "name" : "Cindy",
      "screen_name" : "gemswinc",
      "protected" : false,
      "id_str" : "13112692",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/796466012036198401\/X1tNLI22_normal.jpg",
      "id" : 13112692,
      "verified" : false
    }
  },
  "id" : 32499834984337408,
  "created_at" : "2011-02-01 18:05:39 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32498853139718144",
  "geo" : { },
  "id_str" : "32499700045189120",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 I fell down icy stairs once right on tailbone. ouch.. took FOREVER to heal. Glad Mom ok! : )",
  "id" : 32499700045189120,
  "in_reply_to_status_id" : 32498853139718144,
  "created_at" : "2011-02-01 18:05:06 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Christopher R Cat",
      "screen_name" : "ChrisGroove1",
      "indices" : [ 0, 13 ],
      "id_str" : "68905287",
      "id" : 68905287
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32496154914590721",
  "geo" : { },
  "id_str" : "32498558292721664",
  "in_reply_to_user_id" : 68905287,
  "text" : "@ChrisGroove1 oh no! ((hugs))",
  "id" : 32498558292721664,
  "in_reply_to_status_id" : 32496154914590721,
  "created_at" : "2011-02-01 18:00:34 +0000",
  "in_reply_to_screen_name" : "ChrisGroove1",
  "in_reply_to_user_id_str" : "68905287",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "indices" : [ 3, 17 ],
      "id_str" : "140966649",
      "id" : 140966649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32496884949983232",
  "text" : "RT @Seeds4Parents: Those who are hardest to love, need love the most.",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32494385157373953",
    "text" : "Those who are hardest to love, need love the most.",
    "id" : 32494385157373953,
    "created_at" : "2011-02-01 17:43:59 +0000",
    "user" : {
      "name" : "Meg Lawton",
      "screen_name" : "Seeds4Parents",
      "protected" : false,
      "id_str" : "140966649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2987441175\/f67f303d2d1d9e2789d66cc3080e16d0_normal.jpeg",
      "id" : 140966649,
      "verified" : false
    }
  },
  "id" : 32496884949983232,
  "created_at" : "2011-02-01 17:53:55 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32496340910997505",
  "text" : "RT @GlobalRhythmz: Are you an author or a poet and want to be interviewed to promote your work? Email me at G-radio@GlobalRhythmz.com!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32495846624862208",
    "text" : "Are you an author or a poet and want to be interviewed to promote your work? Email me at G-radio@GlobalRhythmz.com!",
    "id" : 32495846624862208,
    "created_at" : "2011-02-01 17:49:48 +0000",
    "user" : {
      "name" : "Angie",
      "screen_name" : "KnittWittGlobal",
      "protected" : false,
      "id_str" : "194642448",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1621139558\/logo6860_normal.png",
      "id" : 194642448,
      "verified" : false
    }
  },
  "id" : 32496340910997505,
  "created_at" : "2011-02-01 17:51:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/www.weetapp.com\" rel=\"nofollow\"\u003EWeet\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "indices" : [ 3, 14 ],
      "id_str" : "8449382",
      "id" : 8449382
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32487250755325953",
  "text" : "RT @quantafire: Just when you're about to judge someone, they say something that totally has you get them. Love those knife-edge moments...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32485299695124480",
    "text" : "Just when you're about to judge someone, they say something that totally has you get them. Love those knife-edge moments...",
    "id" : 32485299695124480,
    "created_at" : "2011-02-01 17:07:53 +0000",
    "user" : {
      "name" : "Marc Quinn",
      "screen_name" : "quantafire",
      "protected" : false,
      "id_str" : "8449382",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2943941501\/b15b399a7823bad25f64b6482704e678_normal.jpeg",
      "id" : 8449382,
      "verified" : false
    }
  },
  "id" : 32487250755325953,
  "created_at" : "2011-02-01 17:15:38 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32485182564995072",
  "text" : "today is a pepto day.. bleh",
  "id" : 32485182564995072,
  "created_at" : "2011-02-01 17:07:25 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32484099725725696",
  "text" : "RT @GeneDoucette: Not that there aren't samples up from Immortal. There are. Here's a chapter excerpt: http:\/\/bit.ly\/hRM1FU",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32482118009360385",
    "text" : "Not that there aren't samples up from Immortal. There are. Here's a chapter excerpt: http:\/\/bit.ly\/hRM1FU",
    "id" : 32482118009360385,
    "created_at" : "2011-02-01 16:55:15 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 32484099725725696,
  "created_at" : "2011-02-01 17:03:07 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "indices" : [ 3, 12 ],
      "id_str" : "16649649",
      "id" : 16649649
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32483405367091200",
  "text" : "RT @bcmouser: my god is polyamorous. \/via @dtatusko \/\/ t-shirt material!!!!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.tweetings.net\/\" rel=\"nofollow\"\u003ETweetings Classic for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32482384838397952",
    "text" : "my god is polyamorous. \/via @dtatusko \/\/ t-shirt material!!!!",
    "id" : 32482384838397952,
    "created_at" : "2011-02-01 16:56:18 +0000",
    "user" : {
      "name" : "Brandon Mouser",
      "screen_name" : "bcmouser",
      "protected" : false,
      "id_str" : "16649649",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/798907519804395520\/I7g1nZIN_normal.jpg",
      "id" : 16649649,
      "verified" : false
    }
  },
  "id" : 32483405367091200,
  "created_at" : "2011-02-01 17:00:22 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "indices" : [ 3, 16 ],
      "id_str" : "123068593",
      "id" : 123068593
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32481290439630848",
  "text" : "RT @GeneDoucette: The Immortal fan page on Facebook: do join! http:\/\/on.fb.me\/fritaE",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32480837249269761",
    "text" : "The Immortal fan page on Facebook: do join! http:\/\/on.fb.me\/fritaE",
    "id" : 32480837249269761,
    "created_at" : "2011-02-01 16:50:09 +0000",
    "user" : {
      "name" : "Gene Doucette",
      "screen_name" : "GeneDoucette",
      "protected" : false,
      "id_str" : "123068593",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/2043087747\/Image_normal.jpg",
      "id" : 123068593,
      "verified" : false
    }
  },
  "id" : 32481290439630848,
  "created_at" : "2011-02-01 16:51:57 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32481103436587008",
  "text" : "@Skandhasattva omg'ness, so sweet. we had a little black dog that would sit quietly w me when I was sick. feel better soon, Jen!",
  "id" : 32481103436587008,
  "created_at" : "2011-02-01 16:51:13 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "TKD",
      "indices" : [ 17, 21 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32479577603317760",
  "text" : "Im def the worst #TKD student in my school. Yet I feel there's a reason 4 me 2 do it. Im learning life lessons there.",
  "id" : 32479577603317760,
  "created_at" : "2011-02-01 16:45:09 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32478685349027842",
  "text" : "the universe is in control. have to remember that. whatever happens is ok. it all works out. sometimes I forget that!",
  "id" : 32478685349027842,
  "created_at" : "2011-02-01 16:41:36 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32477721594433536",
  "text" : "I got to get back to being stoic...",
  "id" : 32477721594433536,
  "created_at" : "2011-02-01 16:37:46 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 3, 13 ],
      "id_str" : "29738127",
      "id" : 29738127
    }, {
      "name" : "Jilly Twenty",
      "screen_name" : "1morehandmedwn",
      "indices" : [ 18, 33 ],
      "id_str" : "114196966",
      "id" : 114196966
    }, {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "indices" : [ 35, 45 ],
      "id_str" : "29738127",
      "id" : 29738127
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32477376248020993",
  "text" : "RT @petsalive: RT @1morehandmedwn: @petsalive I hope people do not expect money back when they RETURN an animal, they should be ashamed!",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/www.ubertwitter.com\/bb\/download.php\" rel=\"nofollow\"\u003E\u00DCberSocialOrig\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "Jilly Twenty",
        "screen_name" : "1morehandmedwn",
        "indices" : [ 3, 18 ],
        "id_str" : "114196966",
        "id" : 114196966
      }, {
        "name" : "Pets Alive",
        "screen_name" : "petsalive",
        "indices" : [ 20, 30 ],
        "id_str" : "29738127",
        "id" : 29738127
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32475349077983232",
    "text" : "RT @1morehandmedwn: @petsalive I hope people do not expect money back when they RETURN an animal, they should be ashamed!",
    "id" : 32475349077983232,
    "created_at" : "2011-02-01 16:28:21 +0000",
    "user" : {
      "name" : "Pets Alive",
      "screen_name" : "petsalive",
      "protected" : false,
      "id_str" : "29738127",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/378800000828926855\/848030511c428b580cbe024b8d75615b_normal.jpeg",
      "id" : 29738127,
      "verified" : false
    }
  },
  "id" : 32477376248020993,
  "created_at" : "2011-02-01 16:36:24 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "Horny Whore",
      "screen_name" : "SaDiECrAzYbABe",
      "indices" : [ 0, 15 ],
      "id_str" : "2857525467",
      "id" : 2857525467
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32476689229422592",
  "text" : "@SaDiECrAzYbABe jeepers.. sad.",
  "id" : 32476689229422592,
  "created_at" : "2011-02-01 16:33:40 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 113, 124 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "32471139217309697",
  "geo" : { },
  "id_str" : "32473595108130816",
  "in_reply_to_user_id" : 6994832,
  "text" : "re: 1\/32 sec.. fascinated by idea of getting smaller but never reaching end. can always halve the amount. weird! @TrishScott",
  "id" : 32473595108130816,
  "in_reply_to_status_id" : 32471139217309697,
  "created_at" : "2011-02-01 16:21:23 +0000",
  "in_reply_to_screen_name" : "TrishScott",
  "in_reply_to_user_id_str" : "6994832",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "indices" : [ 3, 14 ],
      "id_str" : "6994832",
      "id" : 6994832
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "32473055137628160",
  "text" : "RT @TrishScott: We speak of NOW but what exactly is NOW? 1 sec? 1\/16th of a sec? 1\/32nd of a sec? It's the same as YOU and ME before con ...",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"https:\/\/about.twitter.com\/products\/tweetdeck\" rel=\"nofollow\"\u003ETweetDeck\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "32471139217309697",
    "text" : "We speak of NOW but what exactly is NOW? 1 sec? 1\/16th of a sec? 1\/32nd of a sec? It's the same as YOU and ME before conception.",
    "id" : 32471139217309697,
    "created_at" : "2011-02-01 16:11:37 +0000",
    "user" : {
      "name" : "TrishTumbleweedScott",
      "screen_name" : "TrishScott",
      "protected" : false,
      "id_str" : "6994832",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/525814610381639680\/BjuKfoNZ_normal.jpeg",
      "id" : 6994832,
      "verified" : false
    }
  },
  "id" : 32473055137628160,
  "created_at" : "2011-02-01 16:19:14 +0000",
  "user" : {
    "name" : "Gabrielle P Campbell",
    "screen_name" : "moosebegab",
    "protected" : false,
    "id_str" : "93747129",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1618032034\/gabipodtouchchair_normal.jpg",
    "id" : 93747129,
    "verified" : false
  }
} ]